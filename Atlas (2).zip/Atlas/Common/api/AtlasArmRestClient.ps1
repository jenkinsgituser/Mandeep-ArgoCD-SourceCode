#Run these using Az CLI
#######################################################
function Get-AtlasAppServicePlanVirtualConnections {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $AppServicePlanName,

        [Parameter(Mandatory = $false)]
        [string] $AccessToken
    )

    $subscriptionID = $(az account show --query "id" -o tsv)
    $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Web/serverfarms/$AppServicePlanName/virtualNetworkConnections?api-version=2018-02-01"
    $accessToken = if ([string]::IsNullOrEmpty($accessToken)) { $($(az account get-access-token) | ConvertFrom-Json).accessToken } else { $accessToken }
    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -uri $uri -Headers $headers -Method 'GET'
    Return $($response.Content | ConvertFrom-Json)
}


function Get-AtlasServiceBus-NetworkRules {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $Namespace,

        [Parameter(Mandatory = $false)]
        [string] $AccessToken
    )

    $subscriptionID = $(az account show --query "id" -o tsv)
    $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.ServiceBus/namespaces/$Namespace/networkRuleSets/default?api-version=2017-04-01"
    $accessToken = if ([string]::IsNullOrEmpty($accessToken)) { $($(az account get-access-token) | ConvertFrom-Json).accessToken } else { $accessToken }
    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -uri $uri -Headers $headers -Method 'GET'
    Return $($response.Content | ConvertFrom-Json)
}


function Set-AtlasServiceBus-NetworkRules {
    [CmdletBinding(DefaultParameterSetName = "PowerShellObject")]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $Namespace,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [PSObject] $RulesObj,

        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $JsonBody,

        [Parameter(Mandatory = $false, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $false, ParameterSetName = "JsonBody")]
        [string] $AccessToken
    )

    if ($RulesObj) {
        #if the object has any Members other than "properties", remove them
        #this allows us to test by passing in objects retrieved from prior calls with minimal
        #modification necessary on our end
        $RulesObj.PSObject.Properties | Where-Object { $_.Name -ne "properties" } | ForEach-Object { $RulesObj.PSObject.Properties.Remove($_.Name) }
        $JsonBody = $RulesObj | ConvertTo-Json -Depth 10
    }

    $subscriptionID = $(az account show --query "id" -o tsv)
    $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.ServiceBus/namespaces/$Namespace/networkRuleSets/default?api-version=2017-04-01"
    $accessToken = if ([string]::IsNullOrEmpty($accessToken)) { $($(az account get-access-token) | ConvertFrom-Json).accessToken } else { $accessToken }
    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -uri $uri -Headers $headers -Method 'PUT' -Body $JsonBody
    Return $($response.Content | ConvertFrom-Json)
}


#This isn't going to handle every input scenario,
#but the current working concern is primarily testing
#dev network access, not production use cases
###################################################
function Add-AtlasServiceBus-IPRuleAllow {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $Namespace,

        [Parameter(Mandatory = $true)]
        [string] $IPAddress
    )

    $RulesObj = Get-AtlasServiceBus-NetworkRules -ResourceGroup $ResourceGroup -Namespace $Namespace -AccessToken $accessToken
    if ($RulesObj.properties.ipRules) {
        $newRule = $RulesObj.properties.ipRules[0]
        $newRule.ipMask = $IPAddress
        $RulesObj.properties.ipRules += $newRule
    }
    else {
        $newrule = New-Object PSObject
        Add-Member -InputObject $newrule -MemberType NoteProperty -Name ipMask -Value $IPAddress
        Add-Member -InputObject $newrule -MemberType NoteProperty -Name action -Value "Allow"
        $RulesObj.properties.ipRules += $newRule
    }

    return $(Set-AtlasServiceBus-NetworkRules -ResourceGroup $ResourceGroup -Namespace $Namespace -RulesObj $RulesObj)
}

function Add-AtlasServiceBus-subNetRule {
    [CmdletBinding(DefaultParameterSetName = "vNetRG")]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = "vNetRG")]
        [Parameter(Mandatory = $true, ParameterSetName = "SubNetURI")]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true, ParameterSetName = "vNetRG")]
        [Parameter(Mandatory = $true, ParameterSetName = "SubNetURI")]
        [string] $Namespace,

        [Parameter(Mandatory = $true, ParameterSetName = "vNetRG")]
        [string] $vNetResourceGroup,

        [Parameter(Mandatory = $false, ParameterSetName = "vNetRG")]
        [string] $vNetName,

        [Parameter(Mandatory = $true, ParameterSetName = "SubNetURI")]
        [string] $subNetURI
    )

    if ([string]::IsNullOrEmpty($subNetURI)) {
        $subnetURI = Get-SubNetID -ResourceGroup $vNetResourceGroup
    }

    $RulesObj = Get-AtlasServiceBus-NetworkRules -ResourceGroup $ResourceGroup -Namespace $Namespace -AccessToken $accessToken

    $newrule = New-Object PSObject
    Add-Member -InputObject $newrule -MemberType NoteProperty -Name subnet -Value @{"id" = $subNetURI }
    Add-Member -InputObject $newrule -MemberType NoteProperty -Name ignoreMissingVnetServiceEndpoint -Value $true
    $RulesObj.properties.virtualNetworkRules += $newRule

    return $(Set-AtlasServiceBus-NetworkRules -ResourceGroup $ResourceGroup -Namespace $Namespace -RulesObj $RulesObj)
}

function Remove-AtlasServiceBus-SubNetRule {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $Namespace,

        [Parameter(Mandatory = $true)]
        [string] $vNetName,

        [Parameter(Mandatory = $true)]
        [string] $subnetName
    )

    $RulesObj = Get-AtlasServiceBus-NetworkRules -ResourceGroup $ResourceGroup -Namespace $Namespace -AccessToken $accessToken

    $RulesObj.properties.virtualNetworkRules = Remove-AtlasSubnetByInputMatchRulesObj -virtualNetworkRules $RulesObj.properties.virtualNetworkRules `
        -vNetName $vNetName `
        -subnetName $subnetName

    return $(Set-AtlasServiceBus-NetworkRules -ResourceGroup $ResourceGroup -Namespace $Namespace -RulesObj $RulesObj)
}


function Copy-AtlasServiceBus-NetworkRules {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $SourceResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $SourceNamespace,

        [Parameter(Mandatory = $true)]
        [string] $DestResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $DestResource,

        [Parameter(Mandatory = $false)]
        [string] $AccessToken
    )
    #todo if need arises
}