
Function Invoke-AtlasSelfServeRunbook {
  param
  (
    [Parameter(Mandatory = $true)]
    [PSObject] $Parameters,

    [Parameter(Mandatory = $true)]
    [PSObject] $RunbookName
  )

  $sub = (Get-AzContext).Subscription.Name
  if ($sub -match "Sandbox") {
    $AA_NAME = if ($env:AA_NAME) { $env:AA_NAME } else { "AA-CMFG-NP1-Atlas-Self-Serve" }
    $RUNBOOK = if ($env:AA_RUNBOOK) { $env:AA_RUNBOOK } else { $RunbookName }
    $RG_NAME = if ($env:AA_RG_NAME) { $env:AA_RG_NAME } else { "RG-CMFG-NC1-D01-ITInfrastructure" }
  }
  else {
    # prod values
    $AA_NAME = if ($env:AA_NAME) { $env:AA_NAME } else { "AA-CMFG-PR1-Atlas-Self-Serve" }
    $RUNBOOK = if ($env:AA_RUNBOOK) { $env:AA_RUNBOOK } else { $RunbookName }
    $RG_NAME = if ($env:AA_RG_NAME) { $env:AA_RG_NAME } else { "RG-CMFG-NC1-P01-ITInfrastructure" }
  }

  if ($RunbookName -eq $CONST_RESOURCE_PERMISSIONS_RUNBOOK_NAME) {
    # pull release Info off the release
    $ReleaseID = if ($env:SYSTEM_DEFINITIONID) { "$env:SYSTEM_DEFINITIONID" } `
      elseif ($env:RELEASE_DEFINITIONID) { "$env:RELEASE_DEFINITIONID" } `
      else { Write-Error "Unable to determine SYSTEM_DEFINITIONID. Please ensure script is run from Azure DevOps release." }
    Write-Verbose "ReleaseID: $ReleaseID" -Verbose
    $Parameters.Add("ReleaseID", $ReleaseID)

    # pull project Id off the release
    $ProjectID = if ($env:SYSTEM_TEAMPROJECTID) { "$env:SYSTEM_TEAMPROJECTID" } `
      else { Write-Error "Unable to determine SYSTEM_TEAMPROJECTID. Please ensure script is run from Azure DevOps release." }
    Write-Verbose "ProjectID: $ProjectID" -Verbose
    $Parameters.Add("ProjectID", $ProjectID)
  }

  # don't change subscriptions if we've passed overrides, else do change to use the prod runbook
  if (!$env:AA_NAME -and !$env:AA_RG_NAME -and !$env:AA_RUNBOOK) {
    if ($env:AA_SUBSCRIPTION) {
      Select-AzSubscription -SubscriptionName $env:AA_SUBSCRIPTION | Out-Null
    }
    elseif ($sub -match "Sandbox") {
      Select-AzSubscription -SubscriptionName 'CMFG NonProduction' | Out-Null
    }
    else {
      Select-AzSubscription -SubscriptionName 'CMFG Production' | Out-Null
    }
  }
  Write-Verbose "RG_NAME: $RG_NAME" -Verbose
  Write-Verbose "AA_NAME: $AA_NAME" -Verbose
  Write-Verbose "RUNBOOK: $RUNBOOK" -Verbose

  # Start functional delegate block
  $Action = {
    $job = Start-AzAutomationRunbook -AutomationAccountName $AA_NAME -Name $RUNBOOK -ResourceGroupName $RG_NAME -Parameters $Parameters
    Write-Host "`n"

    # Loop through looking to see when the runbook has completed.
    $pollingSeconds = 5
    $maxTimeout = 10800
    $waitTime = 0
    while ((IsJobTerminalState $job.Status) -eq $false -and $waitTime -lt $maxTimeout) {
      Start-Sleep -Seconds $pollingSeconds
      #Write-host "Waiting....."
      $waitTime += $pollingSeconds
      $job = $job | Get-AzAutomationJob
      if ($job.Status -eq "New") {
        Write-Host "Provisioning Status: Queued"
      }
      else {
        Write-Host "Provisioning Status:"  $job.Status
      }
    }

    $jobId = $job.JobId
    $jobOutput = (Get-AzAutomationJobOutput -ResourceGroupName $RG_NAME -Id $jobId -AutomationAccountName $AA_NAME)
    $jobOutputRecords = $jobOutput | Get-AzAutomationJobOutputRecord
    $jobErrors = $jobOutputRecords | Where-Object { $_.Type -eq "Error" }
    $jobWarnings = $jobOutputRecords | Where-Object { $_.Type -eq "Warning" }
    # get the full record instead of the summary output
    $jobOutputRecordSummary = $jobOutputRecords.Value.Message | Where-Object { $_ -match "INFO|ERROR|WARN" }

    Write-Host "Job output:"
    # write each line out seprately, replacing "INFO:" with an empty string but retaining ERROR and WARN messages
    $jobOutputRecordSummary | ForEach-Object { Write-Host $_.Replace("INFO:", "") }

    ################################################################
    #reverting to the subscription we started in
    Select-AzSubscription -SubscriptionName $sub | Out-Null

    # write warnings where appropriate
    foreach ($warning in $jobWarnings) {
      Write-Warning $warning.Value.Message
    }

    # throw an exception if an ERROR message stream is returned in the job output
    if ($null -ne $job.Exception) {
      Throw $job.Exception

    }
    elseif ($job.Status -eq "Failed") {
      Throw "Request to $RUNBOOK failed."

    }
    elseif (($jobOutputRecordSummary -match "\*\*ERROR") -or ($jobOutputRecordSummary -match "ERROR:")) {
      Throw "Resource permission request did not complete successfully! Please review request inputs and error log above."

    }
    elseif ($jobErrors -ne $null) {
      foreach ($jobError in $jobErrors) {
        Write-Host $jobError.Value.Message
        Throw "Request to $RUNBOOK did not complete successfully."
      }
    }
  }

  # wrap the above in a functional delegate for improved resiliency
  Retry-FunctionalDelegate -Action $Action

}

