#grabs the Instrumentation key to the AIS from the appropriate vault based on the subscription.
#different AIS for each subscription, stored in a different key vault
function Get-AppInsightsInstrumentationKey {

    ## Bring in Atlas-CommonCode for Get-SubscriptionProperties
 . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

    $subscriptionDetails = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
    $environment = $subscriptionDetails.environment

    switch ($environment) {
        $CONST_PROD_SUB {
            $vault = $CONST_KV_SHAREDSVCS_P
        }
        $CONST_NONPROD_SUB {
            $vault = $CONST_KV_SHAREDSVCS_NP
        }
        $CONST_SANDBOX_SUB {
            $vault = $CONST_KV_SANDBOX_NP
        }
        default {
            throw "AIS logging is not enabled in the subscription $subscription"
        }
    }
    $keySecret = Get-AzKeyVaultSecret -VaultName $vault -Name $CONST_ATLAS_INSTRUMENTATION_SECRET_NAME
    $key = [System.Net.NetworkCredential]::new("", $($keySecret.SecretValue)).Password

    return $key
}

function Get-AppInsightsClient {

    $TelemetryClientType = 'Microsoft.ApplicationInsights.TelemetryClient'
    if (-not ([System.Management.Automation.PSTypeName]$TelemetryClientType).Type) {
        Add-Type -Path "$INFRA_FOLDER\SharedSvcs\lib\microsoft.applicationinsights\2.11.0\lib\netstandard2.0\Microsoft.ApplicationInsights.dll"
    }
    if ($env:LoggerUnavailable) {
        throw "App Insights Logger Client is unavailable. Not re-attempting to instantiate"
    }
    else {
        if (!$global:logger) {
            try {
                $instrumentKey = Get-AppInsightsInstrumentationKey
                $global:logger = New-Object Microsoft.ApplicationInsights.TelemetryClient
                $global:logger.InstrumentationKey = $instrumentKey
            }
            catch {
                $env:LoggerUnavailable = $true
            }
        }
    }

    return $global:logger
}

function Write-AtlasDeploymentTelemetry {
    param (
        [Parameter(Mandatory = $true)][string] $FileName
    )

    $psVersion = Get-Host | Select-Object Version

    # need to temporarily manipulate error preference to avoid az --version
    # causing a terminating error
    $tempErrorPref = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"
    $azVersion = (az --version) 2>$null | Select-String 'azure-cli'
    $azVersionClean = Get-AzCliSemVersionFromString -versionString $azVersion
    $ErrorActionPreference = $tempErrorPref

    $azPowershellModule = Get-Module Az.Accounts

    $deploymentObj = @{ AtlasVersion = $TEMPLATE_VERSION;
        PowerShellVersion            = $psVersion.Version.ToString();
        AzPowerShellVersion          = $azPowershellModule.Version.ToString();
        AzCliVersion                 = $azVersionClean
        DeploymentFile               = $FileName;
        Subscription                 = $SUBSCRIPTION_NAME;
        ReleaseAccount               = $SPName;
        DevOpsProject                = $env:SYSTEM_TEAMPROJECT;
        DevOpsReleaseStageName       = $env:SYSTEM_STAGEDISPLAYNAME;
        DevOpsAgentName              = $env:AGENT_NAME;
        DevOpsAgentOs                = $env:AGENT_OS;
        DevOpsReleaseDefinitionId    = $env:SYSTEM_DEFINITIONID;
    }

    $hashTableString = Get-StringFromHashTable -HashTable $deploymentObj

    Write-AtlasTelemetryMessage -Message $hashTableString
}

function Write-AtlasTelemetryMessage {
    param (
        [Parameter(Mandatory = $true)][string] $Message
    )

    try {
        $appInsights = Get-AppInsightsClient
        $appInsights.TrackEvent($message, $null)
        $appInsights.Flush()
    }
    catch {
        Write-AtlasOutput -LogLevel "WARN" -Message "Unable to write Application Insights log message. Error: $($_.Exception.Message)"
    }
}

function Write-AtlasTelemetryException {
    param (
        [Parameter(Mandatory = $true)][PSObject] $Exception,
        [Parameter(Mandatory = $false)][PSObject] $InvocationInfo
    )

    try {
        $appInsights = Get-AppInsightsClient

        $cException = New-Object "Microsoft.ApplicationInsights.DataContracts.ExceptionTelemetry"
        $cException.Exception = $exception

        if ($InvocationInfo -and $InvocationInfo.GetType().Name -eq 'InvocationInfo') {
            $cException.Message = $InvocationInfo.PositionMessage
        }

        $appInsights.TrackException($cException)
        $appInsights.Flush()
    }
    catch {
        Write-Warning "Unable to write Application Insights log exception. Error: $($_.Exception.Message)"
    }
}

function Write-AtlasTelemetryMetric {
    param (
        [Parameter(Mandatory = $true)][string] $Name,
        [Parameter(Mandatory = $true)][string] $Value
    )

    try {
        $appInsights = Get-AppInsightsClient

        $metric = New-Object "Microsoft.ApplicationInsights.DataContracts.MetricTelemetry"
        $metric.Name = $name
        $metric.Value = $value

        $appInsights.TrackMetric($metric)
        $appInsights.Flush()
    }
    catch {
        Write-Warning "Unable to write Application Insights log metric. Error: $($_.Exception.Message)"
    }
}