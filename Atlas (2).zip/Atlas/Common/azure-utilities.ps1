# In general, this file contains common functions that rely on the presence of
# azure command line utlities -- either Az CLI or Az PowerShell. At this time
# there is no breakdown or segregation amongst these two dependencies because we've
# found valid use cases for potentially using both in the same function (rare but possible)
#********************************************************************************************

function Add-TitanVersionTagToRG {
    param
    (
        [Parameter (Mandatory = $true)] [string] $resourceGroup,
        [Parameter (Mandatory = $false)] [string] $TemplateVersionValue = "Titan-Atlas"
    )
    Write-Verbose "Grabbing initial tags..." -Verbose
    $initialTags = $(az group show --name $resourceGroup --query "tags") | ConvertFrom-Json

    $tags = @()
    #grab pre-existing tags
    foreach ($tag in $initialTags.psobject.properties) {
        $tags += "$($tag.Name)=$($tag.Value)"
    }

    #note the tagString will end with a space
    Write-Verbose "Tagging resource group $resourceGroup with TemplateVersion tag $TemplateVersionValue" -Verbose
    $tags += "TemplateVersion=$TemplateVersionValue"

    Write-Verbose "Final tag string: '$tags'" -Verbose
    $origErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "Stop"
}

function Validate-DeploymentRGIsAtlas {
    param
    (
        [Parameter (Mandatory = $true)] [string] $resourceGroup,
        [Parameter (Mandatory = $false)] [string] $forceFlag
    )
 
    $isAtlasCompliant = $false
    $hasPermissionPolicy = $false
    $isAtlasRG = Is-RGAtlas -resourceGroup $resourceGroup
    $subscriptionID = (Get-AzContext).Subscription.id
    $groupObjID = Get-GroupObjectId -GroupName "R-TeamTitan-LSA"
    $TemplateVersionValue = Get-AtlasVersionNumber

    #scoping and retrieving role permissions for R-TeamTitan-LSA in current subscription and provided resource group
    $scope = "/subscriptions/$($subscriptionID)/resourceGroups/$($resourceGroup)"
    $rgRoles = Get-AzRoleAssignment -ObjectId $groupObjID -Scope $scope

    #check if R-TeamTitan-LSA has read access on resource group - this is set by Titan scripts
    foreach ($role in $rgRoles) {
        if ($role.RoleDefinitionName.Contains("Reader")) {
            $hasPermissionPolicy = $true
            Write-Verbose -Verbose "The group R-TeamTitan-LSA has read access on resource group $($resourceGroup)"
        }
    }

    $isAtlasCompliant = $hasPermissionPolicy -and $isAtlasRG

    if ($isAtlasCompliant) {
        Write-Verbose -Verbose "Resource group is Atlas compliant. Continuing with deployment..."
        #add the latest template version
        Add-TitanVersionTagToRG -resourceGroup $resourceGroup -TemplateVersionValue $TemplateVersionValue
    }
    elseif (!$isAtlasCompliant -and ($forceFlag -eq $true)) {
        Write-Verbose -Verbose "Resource group is not Atlas compliant but has the FORCE_NONATLAS_DEPLOY set to true. Continuing with deployment..."
        #override the $TEMPLATE_VERSION value set in setupEnvironment script with non-Atlas value
        $latestVersionValue = $TemplateVersionValue.Split("-")[2]
        $global:TEMPLATE_VERSION = "Non-Atlas deployment using Atlas artifacts-$($latestVersionValue)"
        Write-Verbose -Verbose "Template version value updated to: $TEMPLATE_VERSION"

    }
    else {
        Write-Verbose -Verbose "Atlas compliant flag: $($isAtlasCompliant). Force flag $($forceFlag)"
        throw "** You are attempting to deploy Atlas resources to a non-Atlas Resource Group. ** `
            -Please create an Atlas Resource Group for deploying Atlas resources. When you create a Resource Group using the DevOps task, `
             select the option to enable it for Atlas. `
            -If you intend to use an Atlas deployment artifact to deploy to a Non-Atlas resource group (and opt out of all Atlas `
             controls), check the Atlas wiki for usage of the FORCE_NONATLAS_DEPLOY variable."
        exit
    }
}


function Get-MyIp {
    # no need to ever do this more than once in an execution -- it shouldn't be changing, and if it is
    # we shouldn't be expecting it to actually work
    if (!$env:myIp) {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

        if ($SUBSCRIPTION_NAME -match $CONST_SANDBOX_SUB) {
            $getMeMyIpSecret = $(Get-AzKeyVaultSecret -VaultName $CONST_KV_SANDBOX_NP -Name $CONST_KV_SECRET_NAME).SecretValue
            $getMeMyIp = [System.Net.NetworkCredential]::new("", $getMeMyIpSecret).Password
        }
        else {
            $getMeMyIpSecret = $(Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $CONST_KV_SECRET_NAME).SecretValue
            $getMeMyIp = [System.Net.NetworkCredential]::new("", $getMeMyIpSecret).Password
        }

        try {
            $myIp = Invoke-RestMethod -Method Get -Uri $getMeMyIp
            #}catch [WebCmdletWebResponseException] {
        }
        catch {
            if ($env:IsLocal) {
                try {
                    # catch a specific exception type thrown locally...reset your proxy and hope it works the second time
                    Invoke-WebRequest "www.google.com" | Out-Null
                    $myIp = Invoke-RestMethod -Method Get -Uri $getMeMyIp
                    #}catch [WebCmdletWebResponseException] {
                }
                catch {
                    Write-Verbose "well, we tried, can't determine your external ip, so setting it to $($CONST_LOCAL_EXTERNAL_IP)" -Verbose
                    $myIp = $CONST_LOCAL_EXTERNAL_IP
                    Write-Verbose 'if that is not the correct ip, you can set the environment variable $env:myIp to your ip' -Verbose
                }
            }
        }
        $env:myIp = "$($myIp)/32"
    }

    return $env:myIp
}

function Add-AtlasExceptionTag {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$resourceName,
        [Parameter(Mandatory = $true)][string]$tagValueToAdd,
        [Parameter(Mandatory = $true)][string]$resourceType
    )

    Write-Verbose "Atlas Exception tag value to add is $tagValueToAdd" -Verbose
    Write-Verbose "Grabbing initial tags on resource $resourceName..." -Verbose
    $newTagName = "AtlasExceptions"

    $initialTagsPS = (az resource list --resource-group $resourceGroup --name $resourceName --resource-type $resourceType --query "[0].tags") | ConvertFrom-Json

    $tagUpdated = $false
    $tagAdded = $false
    $newTags = @()

    #Get Resource and tags
    $initialTagsHT = @{}
    $initialTagsPS.psobject.properties | ForEach-Object { $initialTagsHT[$_.Name] = $_.Value }
    #update appropriate tag
    if ($initialTagsHT.AtlasExceptions) {
        #meaning tag already exists
        #check for network value and add if not already there
        if (($initialTagsHT.AtlasExceptions).Contains("$tagValueToAdd")) {
            #set flag and print out
            $tagExists = $true
            Write-Verbose "AtlasException tag with value of $tagValueToAdd already exists" -Verbose
        }
        else {
            #need to add tag value to the atlas exceptions tag
            $tagUpdated = $true
            $oldValue = $initialTagsHT.AtlasExceptions
            $initialTagsHT["$newTagName"] = "$oldValue,$tagValueToAdd"
            Write-Verbose "About to update AtlasException tag with new value of $tagValueToAdd" -Verbose
        }
    }
    else {
        #tag does not exist add new
        $tagAdded = $true
        $initialTagsHT.Add("$newTagName", "$tagValueToAdd")
        Write-Verbose "About to add AtlasException tag with value of $tagValueToAdd as a new tag" -Verbose
    }


    if ($tagUpdated -or $tagAdded) {
        $resource = Get-AzResource -Name $resourceName -ResourceGroup $resourceGroup -ResourceType $resourceType
        $updateTagResult = Update-AzTag -ResourceId $resource.id -Tag $initialTagsHT -Operation Replace
        Write-Verbose "AtlasException tag added/updated" -Verbose
    }

    $newTags = (az resource list --resource-group $resourceGroup --name $resourceName --resource-type $resourceType --query "[0].tags") | ConvertFrom-Json

    Write-Verbose "Final tag list for resource $resourceName is: $($newTags.psobject.properties.name)" -Verbose
}

function Remove-AtlasExceptionTag {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$resourceName,
        [Parameter(Mandatory = $true)][string]$tagValueToRemove,
        [Parameter(Mandatory = $true)][string]$resourceType
    )

    $tagExists = $true
    #Get Resource and tags
    $initialTagsPS = $(az resource show --name $resourceName --resource-group $resourceGroup --resource-type $resourceType --query "tags") | ConvertFrom-Json
    $initialTags = @{}
    $initialTagsPS.psobject.properties | ForEach-Object { $initialTags[$_.Name] = $_.Value }

    #update appropriate tag
    if ($initialTags.AtlasExceptions) {
        #meaning tag exists
        #check for network value and add if not already there
        if (($initialTags.AtlasExceptions).Contains("$tagValueToRemove")) {
            #Check if tag to remove is only value
            $oldValue = $initialTags.AtlasExceptions
            if ($oldValue -eq "$tagValueToRemove") {
                #value to remove is only value -> remove tag completely
                $initialTags.Remove("AtlasExceptions")
                Write-Verbose "About to remove AtlasException tag with value of $tagValueToRemove from resource $resourceName" -Verbose
            }
            else {
                #other values loop through
                $tagArray = ($oldValue).Split(',')
                foreach ($value in $tagArray) {
                    if ($value -eq $tagValueToRemove) {
                        if ($count -eq 0) { $count -= 1 }
                        Write-Verbose "About to remove value of $tagValueToRemove from AltasExceptions tag on resource $resourceName" -Verbose

                    }
                    else {
                        #add value into new tag value
                        if ($count -le 0) {
                            $newTagValue += "$value"
                        }
                        else {
                            $newTagValue += ",$value"
                        }
                        $count += 1
                    }
                }
                #Set new value for atlasExceptions tag
                $initialTags["AtlasExceptions"] = $newTagValue
            }
        }
        else {
            #exception does not exist in tag
            $tagExists = $false
            Write-Verbose "AtlasExceptions does not contain $tagValueToRemove" -Verbose
        }
    }
    else {
        #tag does not exist do not remove anything
        $tagExists = $false
        Write-Verbose "AtlasExceptions tag does not exist"
    }

    #apply back to resource
    if ($tagExists) {
        $resource = Get-AzResource -Name $resourceName -ResourceGroup $resourceGroup -ResourceType $resourceType
        $results = Update-AzTag -ResourceId $resource.id -Operation Replace -Tag $initialTags
        Write-Verbose "AtlasException tag with value of $tagValueToRemove has been removed" -Verbose

        $newTags = $(az resource show --name $resourceName --resource-group $resourceGroup --resource-type $resourceType --query "tags") | ConvertFrom-Json
        Write-Verbose "Final tag list for resource $resourceName is: $($newTags.psobject.properties.name)" -Verbose
    }
    else {
        Write-Verbose "AtlasException tag with value of $tagValueToRemove was not found on resource $resourceName...no action taken" -Verbose
    }
}
function Add-AtlasPurposeTag {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$resourceName,
        [Parameter(Mandatory = $true)][string]$tagValueToAdd,
        [Parameter(Mandatory = $true)][string]$resourceType
    )

    $tagExists = $false

    #Get Resource and tags
    $initialTagsJson = $(az resource show --name $resourceName --resource-group $resourceGroup --resource-type $resourceType --query "tags")

    #todo: Between the blocks can be abstracted into something testable as a unit function
    #*************************************************************************************
    $initialTags = @{ }
    $initialTagsPS = $initialTagsJson | ConvertFrom-Json
    $initialTagsPS.psobject.properties | ForEach-Object { $initialTags[$_.Name] = $_.Value }
    #update appropriate tag
    if ($initialTags.AtlasPurpose) {
        #meaning tag already exists
        #check for network value and add if not already there
        if (($initialTags.AtlasPurpose).Contains("$tagValueToAdd")) {
            #set flag and print out
            $tagExists = $true
            Write-Verbose "Tag already exists" -Verbose
        }
        else {
            #need to add tag value to the atlas exceptions tag
            $oldValue = $initialTags.AtlasPurpose
            $initialTags["AtlasPurpose"] = "$oldValue,$tagValueToAdd"
            Write-Verbose "Purpose $tagValueToAdd has been added to existing tag" -Verbose
        }
    }
    else {
        #tag does not exist add new
        $initialTags.Add("AtlasPurpose", "$tagValueToAdd")
        Write-Verbose "Purpose $tagValueToAdd has been added as a new tag" -Verbose
    }

    #apply back to resource
    if (!$tagExists) {
        $finalTagsJSON = $initialTags | ConvertTo-Json
        $finalTagsPS = $finalTagsJSON | ConvertFrom-Json
        $tags = @()
        #grab pre-existing tags
        foreach ($tag in $finalTagsPS.psobject.properties) {
            $value = $tag.Value
            $tags += "$($tag.Name)=$value"
        }
        #*************************************************************************************

        az resource tag -n $resourceName -g $resourceGroup --resource-type $resourceType --tags $tags | Out-Null
    }#else if tag exists do nothing because nothing to update

}

function Remove-AtlasPurposeTag {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$resourceName,
        [Parameter(Mandatory = $true)][string]$tagValueToRemove,
        [Parameter(Mandatory = $true)][string]$resourceType
    )

    $tagExists = $true
    #Get Resource and tags
    $initialTagsJson = $(az resource show --name $resourceName --resource-group $resourceGroup --resource-type $resourceType --query "tags")
    $initialTags = @{ }
    $initialTagsPS = $initialTagsJson | ConvertFrom-Json
    $initialTagsPS.psobject.properties | ForEach-Object { $initialTags[$_.Name] = $_.Value }

    #update appropriate tag
    if ($initialTags.AtlasPurpose) {
        #meaning tag exists
        #check for network value and add if not already there
        if (($initialTags.AtlasPurpose).Contains("$tagValueToRemove")) {
            #Check if tag to remove is only value
            $oldValue = $initialTags.AtlasPurpose
            if ($oldValue -eq "$tagValueToRemove") {
                #value to remove is only value -> remove tag completely
                $initialTags.Remove("AtlasPurpose")
            }
            else {
                #other values loop through
                $tagArray = ($oldValue).Split(',')
                foreach ($value in $tagArray) {
                    if ($value -eq $tagValueToRemove) {
                        if ($count -eq 0) { $count -= 1 }
                        Write-Verbose "Removing $tagValueToRemove from AtlasPurpose" -Verbose

                    }
                    else {
                        #add value into new tag value
                        if ($count -le 0) {
                            $newTagValue += "$value"
                        }
                        else {
                            $newTagValue += ",$value"
                        }
                        $count += 1
                    }
                }
                #Set new value for atlasExceptions tag
                $initialTags["AtlasPurpose"] = $newTagValue
            }
        }
        else {
            #exception does not exist in tag
            $tagExists = $false
            Write-Verbose "AtlasPurpose does not contain $tagValueToRemove" -Verbose
        }
    }
    else {
        #tag does not exist do not remove anything
        $tagExists = $false
        Write-Verbose "Tag does not exist" -Verbose
    }

    #apply back to resource
    if ($tagExists) {
        $finalTagsJSON = $initialTags | ConvertTo-Json
        $finalTagsPS = $finalTagsJSON | ConvertFrom-Json
        $tags = @()
        #grab pre-existing tags
        foreach ($tag in $finalTagsPS.psobject.properties) {
            $value = $tag.Value
            $tags += "$($tag.Name)=$value"
        }
        az resource tag -n $resourceName -g $resourceGroup --resource-type $resourceType --tags $tags | Out-Null
    }#else if tag exists do nothing because nothing to update

}

function Set-NetworkRulesKV {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [array]$ipArrayToSet,
        [Parameter(Mandatory = $false)]
        [array]$vNetResourceIdArrayToSet
    )

    $currentNetworkAcls = (Get-AzKeyVault -VaultName $keyVault).NetworkAcls
    Write-Verbose "Setting allowed Ips to be $ipArrayToSet, allowed vNet Ids to be $vNetResourceIdArrayToSet" -Verbose
    if ($currentNetworkAcls.VirtualNetworkResourceid) {
        Update-AzKeyVaultNetworkRuleSet -VaultName $keyVault -IpAddressRange $ipArrayToSet `
            -Bypass $currentNetworkAcls.ByPass `
            -VirtualNetworkResourceId $currentNetworkAcls.VirtualNetworkResourceid
    }
    else {
        Update-AzKeyVaultNetworkRuleSet -VaultName $keyVault -IpAddressRange $ipArrayToSet `
            -Bypass $currentNetworkAcls.ByPass
    }
}

function Add-NetworkRuleToKV {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $false)]
        [string]$ipRuleToAdd,
        [Parameter(Mandatory = $false)]
        [string]$subnetRuleToAdd
    )

    $kv = az keyvault show -n $keyvault | ConvertFrom-Json
    if ($ipRuleToAdd) {
        #check if tag network rules
        $kvIpRules = $kv.properties.networkAcls.ipRules.value
        if (!($kvIpRules -Contains $ipRuleToAdd)) {
            #if network rules not exists add it
            Write-Verbose "Adding $ipRuleToAdd" -Verbose
            Invoke-CommandWithRetries -Command "az keyvault network-rule add --name $keyvault --ip-address $ipRuleToAdd" | Out-Null
        }  #else do nothing
    }
    elseif ($subnetRuleToAdd) {
        $kvSubnetRules = $kv.properties.networkAcls.virtualNetworkRules.id
        if (!($kvSubnetRules -Contains $subnetRuleToAdd)) {
            #if network rules not exists add it
            Write-Verbose "Adding $subnetRuleToAdd" -Verbose
            Invoke-CommandWithRetries -Command "az keyvault network-rule add --name $keyvault --subnet $subnetRuleToAdd" | Out-Null
        }  #else do nothing
    }
    else {
        Write-Error -Message "Please enter a valid rule to add"
    }
}

function Remove-NetworkRuleFromKV {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $false)]
        [string]$ipRuleToRemove,
        [Parameter(Mandatory = $false)]
        [string]$subnetRuleToRemove
    )

    #get kv network rules
    $kv = az keyvault show -n $keyvault | ConvertFrom-Json

    if ($ipRuleToRemove) {
        $kvIpRules = $kv.properties.networkAcls.ipRules.value
        #check if tag network rules
        if ($kvIpRules -Contains $ipRuleToRemove) {
            #if network rules exists remove it
            Write-Verbose "Removing $ipRuleToRemove" -Verbose
            Invoke-CommandWithRetries -Command "az keyvault network-rule remove --name $keyvault --ip-address $ipRuleToRemove" | Out-Null
        }#else do nothing
    }
    elseif ($subnetRuleToRemove) {
        $kvSubnetRules = $kv.properties.networkAcls.virtualNetworkRules.id
        #check if tag network rules
        if ($kvSubnetRules -Contains $subnetRuleToRemove) {
            #if network rules exists remove it
            Write-Verbose "Removing $subnetRuleToRemove" -Verbose
            Invoke-CommandWithRetries -Command "az keyvault network-rule remove --name $keyvault --subnet $subnetRuleToRemove" | Out-Null
        }#else do nothing
    }
    else {
        Write-Error -Message "Please enter a valid rule to remove"
    }

}

function Add-SecretToAtlasKeyvault {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [string]$secretName,
        [Parameter(Mandatory = $true)]
        [string]$secretValue,
        [Parameter(Mandatory = $false)]
        [bool]$removeWhenComplete = $true
    )

    $kvRG = $(az keyvault show -n $keyvault | ConvertFrom-Json).resourceGroup

    #get hosted agent ip with Ken's function
    $myIp = Get-MyIp

    #put network exception tag on kv
    Add-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToAdd "Network" -resourceType "Microsoft.KeyVault/vaults"

    #tag kv as a function app kv -Atlas-FunctionApp
    Add-AtlasPurposeTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToAdd "Atlas-FunctionApp" -resourceType "Microsoft.KeyVault/vaults"

    #open kv firewall
    Add-NetworkRuleToKV -keyvault $keyvault -ipRuleToAdd $myIp -subnetRuleToAdd ""

    #vault key
    $result = Invoke-CommandWithRetries -Command "az keyvault secret set --name $secretName --vault-name $keyvault --value '$secretValue'" -LineNumber $MyInvocation.ScriptLineNumber
    if (!$result) {
        Write-Error "No result received from secret set command!"
    }

    if ($removeWhenComplete) {
        #close kv firewall
        Remove-NetworkRuleFromKV -keyvault $keyvault -ipRuleToRemove $myIp -subnetRuleToRemove ""

        #remove network exception tag on kv
        Remove-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToRemove "Network" -resourceType "Microsoft.KeyVault/vaults"
    }
}

function Get-SecretFromAtlasKeyvault {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [string]$secretName,
        [Parameter(Mandatory = $false)]
        [bool]$openNetwork = $true
    )

    $kvRG = $(az keyvault show -n $keyvault | ConvertFrom-Json).resourceGroup

    #get hosted agent ip with Ken's function
    $myIp = Get-MyIp

    #put network exception tag on kv
    Add-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToAdd "Network" -resourceType "Microsoft.KeyVault/vaults"

    if ($openNetwork) {
        #tag kv as a function app kv -Atlas-FunctionApp
        Add-AtlasPurposeTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToAdd "Atlas-FunctionApp" -resourceType "Microsoft.KeyVault/vaults"

        #open kv firewall
        Add-NetworkRuleToKV -keyvault $keyvault -ipRuleToAdd $myIp -subnetRuleToAdd ""
    }

    #vault key
    $result = Invoke-CommandWithRetries -Command "az keyvault secret show --name $secretName --vault-name $keyvault" -LineNumber $MyInvocation.ScriptLineNumber

    if ($openNetwork) {
        #close kv firewall
        Remove-NetworkRuleFromKV -keyvault $keyvault -ipRuleToRemove $myIp -subnetRuleToRemove ""

        #remove network exception tag on kv
        Remove-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToRemove "Network" -resourceType "Microsoft.KeyVault/vaults"
    }

    return $result
}

function Remove-SecretFromAtlasKeyvault {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [string]$secretName,
        [Parameter(Mandatory = $false)]
        [bool]$openNetwork = $true
    )

    $kvRG = $(az keyvault show -n $keyvault | ConvertFrom-Json).resourceGroup

    #todo JON -- replace this block with Get-NetworkConnectionToKV
    #*************************************************************************
    #get hosted agent ip with Ken's function
    $myIp = Get-MyIp

    if ($openNetwork) {
        #put network exception tag on kv
        Add-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToAdd "Network" -resourceType "Microsoft.KeyVault/vaults"

        #open kv firewall
        Add-NetworkRuleToKV -keyvault $keyvault -ipRuleToAdd $myIp -subnetRuleToAdd ""
    }

    Write-Verbose "Deleting secret $secretName" -Verbose
    #*************************************************************************

    #delete secret
    az keyvault secret delete --vault-name $keyVault --name $secretName | Out-Null
    #Sleep after deleting
    $i = 0
    do {
        Write-Verbose "Waiting for Secret to be deleted" -Verbose
        Start-Sleep -Seconds 5
        $i = $i + 1
        $x = $i * 5
        Write-Verbose -Message "Waiting for $x seconds" -Verbose
    } while (($null -ne $(az keyvault secret show --name $secretName --vault-name $keyVault)) -and ($i -lt 20))

    Write-Verbose "Purging secret $secretName" -Verbose

    #purge secret
    az keyvault secret purge --vault-name $keyVault --name $secretName | Out-Null

    if ($openNetwork) {
        #close kv firewall
        Remove-NetworkRuleFromKV -keyvault $keyvault -ipRuleToRemove $myIp -subnetRuleToRemove ""

        #remove network exception tag on kv
        Remove-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToRemove "Network" -resourceType "Microsoft.KeyVault/vaults"
    }
}

function Get-NetworkConnectionToKV {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault
    )

    $kvRG = $(az keyvault show -n $keyvault | ConvertFrom-Json).resourceGroup
    #get my ip
    $myIp = Get-MyIp

    #add tag to KV
    Add-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToAdd "Network" -resourceType "Microsoft.KeyVault/vaults"

    #open fw rules
    Add-NetworkRuleToKV -keyvault $keyvault -ipRuleToAdd $myIp -subnetRuleToAdd ""

    # we're going to hold here until we know the Key Vault *Should* respect our source IP or we timeout
    $currentAttempts = -1 #start with -1 as we're going to fail once simply to grab the config. we want to retry up to the constant max attempts
    while ($kvConfig -and ($kvConfig.properties.networkAcls.ipRules.value -notContains $myIp -and $currentAttempts -lt $CONST_MAX_ATTEMPTS)) {
        # get the KV config, check for new IP rule...loop while it's not there with a timeout to sit
        Start-Sleep -Seconds $CONST_SLEEP_TIME
        $kvConfig = az keyvault show -n $keyVault | ConvertFrom-Json
        $currentAttempts++
    }

    if ($currentAttempts -eq $CONST_MAX_ATTEMPTS) {
        Write-Error "Maximum attempts made to acquire Key Vault connection without success!"
    }
    else {
        Write-Verbose "Connection opened for $myIP to $keyvault!" -Verbose
    }
}

function Remove-NetworkConnectionToKV {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault
    )
    $kvRG = $(az keyvault show -n $keyvault | ConvertFrom-Json).resourceGroup

    if ($env:ATLASHOSTEDAGENT_SUBNET_ID) {
        try {
            # Remove fw rules using subnet Id
            Remove-NetworkRuleFromKV -keyvault $keyvault -ipRuleToRemove "" -subnetRuleToRemove $env:ATLASHOSTEDAGENT_SUBNET_ID
            Write-Verbose "Removed subnet $($env:ATLASHOSTEDAGENT_SUBNET_ID) as allowed source." -Verbose
        }
        catch {
            # Remove fw rules using IP address
            Write-Verbose "Failed to remove subnet as service endpoint. Attempting to remove IP address. Error: $($_.Exception.Message)" -Verbose
            #get my ip
            $myIp = Get-MyIp
            #remove fw rule
            Remove-NetworkRuleFromKV -keyvault $keyvault -ipRuleToRemove $myIp -subnetRuleToRemove ""
        }
    }
    else {
        #get my ip
        $myIp = Get-MyIp
        #remove fw rule
        Remove-NetworkRuleFromKV -keyvault $keyvault -ipRuleToRemove $myIp -subnetRuleToRemove ""
    }


    #remove tag from KV
    Remove-AtlasExceptionTag -resourceGroup $kvRG -resourceName $keyvault -tagValueToRemove "Network" -resourceType "Microsoft.KeyVault/vaults"

}


####################################################
# This function exists because Azure tags don't
# always update immediately to reflect the request
####################################################
function Invoke-RetryGetTags {
    param(
        [Parameter(Mandatory = $true)]
        [string]$resourceName,
        [Parameter(Mandatory = $true)]
        [string]$resourceGroup,
        [Parameter(Mandatory = $true)]
        [string]$resourceType,
        [Parameter(Mandatory = $true)]
        [string]$tagOfInterest,
        [Parameter(Mandatory = $true)]
        [string]$action
    )

    $i = 0
    $maxAttempts = 12
    $waitTime = 10
    $taggingWorked = $false

    while (!$taggingWorked -and $i -lt $maxAttempts) {

        #new secret in key vault
        Write-Verbose "Attempting to get tags." -Verbose
        $TagsJson = $(az resource show --name $resourceName --resource-group $resourceGroup --resource-type $resourceType --query "tags")
        $Tags = @{ }
        $TagsPS = $TagsJson | ConvertFrom-Json
        $TagsPS.psobject.properties | ForEach-Object { $Tags[$_.Name] = $_.Value }
        if (($action -eq "Add" -and $null -ne $Tags["$tagOfInterest"]) `
                -or ($action -eq "Remove" -and $null -eq $Tags["$tagOfInterest"])) {
            $taggingWorked = $true
        }
        Write-Verbose "Tags are still updating attempt $i." -Verbose
        if ($i -lt $maxAttempts -and !$taggingWorked) {
            Write-Verbose "Attempting to get tags again in $waitTime seconds." -Verbose
            Start-Sleep -Seconds $waitTime
        }
        $i++
    }
    return $Tags
}

#######################################################
#this function takes in a resourceGroup and vnet
#parameters and returns the private subnet resource ID
#for the identified vnet
#######################################################
function Get-SubNetID {
    param (
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $false)][string]$vNet,
        [Parameter(Mandatory = $false)][string]$subnetName = ""
    )
    $ErrorActionPreference = "Stop"

    if ([string]::IsNullOrEmpty($vNet)) {
        $vNets = az network vnet list -g $resourceGroup
        #this assuming only one Vnet in RG per current configuration 4/3/19
        $vNet = ($vNets | ConvertFrom-Json).name
    }
    #else do nothing because vnet name was entered in

    try {
        #query the subnets for taz he RG and vNet
        $subnets = az network vnet subnet list --resource-group $resourceGroup --vnet-name $vNet --query "[].id"
    }
    catch {
        Write-Verbose "Error while retrieving the Titan Atlas Vnet: " -Verbose
        Write-Error "ERROR: $($_.Exception.Message)" -Verbose
    }

    #select line(s) which have a subnet containing the string "private"
    if ([string]::IsNullOrEmpty($subnetName)) {
        $privateId = $subnets | Select-String "private"
    }
    else {
        $privateId = $subnets | Select-String $subnetName
    }

    #remove all leading and trailing whitespace. Remove any commas
    $privateId = $privateId -replace '(^\s+|\s+$)', '' -replace '\s+', '' -replace ',', '' -replace '"'

    #return the ID
    return $privateId
}

function Remove-AtlasSubnetByInputMatchIdsOnly {
    param (
        [Parameter(Mandatory = $true)][psobject]$virtualNetworkRules,
        [Parameter(Mandatory = $true)][string]$vNetName,
        [Parameter(Mandatory = $true)][string]$subnetName
    )

    #prune the intended rule, keep rules which match one of vnet name or subnet name, but not a match on both
    return [array] $($virtualNetworkRules | `
            Where-Object {
            $($_ -match $vNetName -and $_ -notmatch $subnetName) `
                -or $($_ -notmatch $vNetName -and $_ -match $subnetName)
        })
}


function Get-AtlasRemovedSubnetByInputMatch {
    param (
        [Parameter(Mandatory = $true)][psobject]$virtualNetworkRules,
        [Parameter(Mandatory = $true)][string]$vNetName,
        [Parameter(Mandatory = $true)][string]$subnetName
    )

    $initialVirtualNetworkRules = $virtualNetworkRules

    #prune the intended rule, keep rules which match one of vnet name or subnet name, but not a match on both
    $updatedVirtualNetworkRules = Remove-AtlasSubnetByInputMatchIdsOnly -virtualNetworkRules $virtualNetworkRules -vNetName $vNetName -subnetName $subnetName

    $diff = Compare-Object -ReferenceObject $initialVirtualNetworkRules -DifferenceObject $updatedVirtualNetworkRules

    return $diff[0].InputObject
}

function Set-NetworkRulesJSON {
    param (
        [Parameter(Mandatory = $true)][array]$resourceGroups,
        [Parameter(Mandatory = $false)][array]$vNets = @(),
        [Parameter(Mandatory = $false)][array]$subnetNames = @(),
        [Parameter(Mandatory = $false)][string]$resourceType = "Microsoft.KeyVault/vaults"
    )

    $networkRules = [string]::Empty #intialize rules to be blank
    if ($resourceGroups) {
        $currentposition = 0
        foreach ($aksRG in $resourceGroups) {
            #check if RG is Atlas if not Atlas skip this RG
            if ($(Is-RGAtlas -resourceGroup $aksRG)) {
                Write-Verbose "Individual RG: $aksRG" -Verbose
                if ($vNets.Length -gt $currentposition) { $vnet = $vNets[$currentposition] } else { $vnet = $null }
                Write-Verbose "Vnet: $vnet" -Verbose

                if ($subnetNames.Length -gt $currentposition) { $subnet = $subnetNames[$currentposition] } else { $subnet = $null }
                Write-Verbose "Subnet: $subnet" -Verbose

                $subnetid = $(Get-SubNetID -resourceGroup $aksRG -vNet $vnet -subnetName $subnet)

                # coming from v1 atlas, we have two versions of this function which differ only on the point below
                # if we get to a third type and more, we should change this to a switch
                if ($resourceType -eq "Microsoft.ServiceBus/namespaces") {
                    $newRule = "{`"subnet`":{`"id`":`"$subnetid`"},`"ignoreMissingVnetServiceEndpoint`":true}"
                }
                else {
                    $newRule = "{`"id`":`"$subnetid`",`"action`":`"Allow`"}"
                }

                if ($currentposition -ne 0) {
                    #if not the first rule - meaning there are multiple
                    #add a comma before adding new rule
                    $networkRules += ",$newRule"
                }
                else {
                    #else first rule no comma needed
                    $networkRules += $newRule
                }
            }
            else {
                Write-Verbose "The Resource Group $aksRG is not Atlas and cannot be added to an Atlas resource.  Moving to next RG ..." -Verbose
            }
            $currentposition += 1
        }
    }
    $networkRules = "[$networkRules]" #wrap in brackets to be handled as an array in json
    $networkRules = ConvertTo-Json $networkRules #putting this back to pass in array as JSON to template

    return $networkRules
}

function Get-FunctionSubnets {
    param ([string]$functionName)

    # define array to use for subnetIds
    $functionSubnetIds = [System.Collections.ArrayList]@()
  
    $functionName = $functionName.trim()  #trim leading/trailing spaces

    # get function resourceId
    $functionId = az functionapp list --query "[?name=='$functionName'].id" -o tsv

    # get function subnetIds
    #if (!(az functionapp list --query "[?name=='$functionName']")) {
    if (!($functionId)) {
        throw "Function Name not found: $functionName.  Unable to get subNet."
    }

    # get function subnetId
    $subnetId = ($(az resource show --ids "$functionId/config/virtualNetwork") | ConvertFrom-Json).properties.subnetResourceId

    $functionSubnetIds.Add($subnetId) | Out-Null

    return $functionSubnetIds

}

function Get-AKSsubnets {
    param ([array]$aksClusterNames)

    # define array to use for subnetIds
    $AKSclusterSubnetIds = [System.Collections.ArrayList]@()

    # get all aks clusters
    $aksClusters = az aks list
    # can't convertfrom-json due to duplicate keys (case is different, but same text), so just change the name of one value
    $aksClusters = $aksClusters.Replace("httpapplicationroutingzonename", "httpapplicationroutingzonename2") | ConvertFrom-Json

    # loop through input clusterNames
    foreach ($aksClusterName in $aksClusterNames) {

        $aksClusterName = $aksClusterName.trim()  #trim leading/trailing spaces

        #find the aks cluster the user input
        $akscluster = $aksClusters | Where-Object { $_.name -eq $aksClusterName }
        #get the vnetSubnetId for the cluster
        #$aksSubnetId = $aksCluster.agentpoolprofiles.vnetSubnetId
        $AKSclusterSubnetIds.Add(($aksCluster.agentpoolprofiles.vnetSubnetId | Sort-Object | Get-Unique)) | Out-Null

        #validate we have only one cluster and therefore one vnet/subnet to add firewall rule
        if ($akscluster.name.count -eq 0) {
            Write-Verbose $('AKS cluster name not found ' + $akscluster) -Verbose
            Throw $('AKS cluster name not found ' + $akscluster)
        }
        if ($akscluster.name.count -ne 1) {
            Write-Verbose $('More than one AKS cluster found with name ' + $akscluster) -Verbose
            Throw $('More than one AKS cluster found with name ' + $akscluster)
        }
    }
    return $AKSclusterSubnetIds
}

function Set-StorageAccountSubnetRules {
    Param(
        [Parameter(Mandatory = $true)]
        [string]$storageAccount,
        [Parameter(Mandatory = $true)]
        [string]$resourceGroup,
        [Parameter(Mandatory = $false)]
        [array]$aksClusterNames,
        [Parameter(Mandatory = $false)]
        [array]$functionNames,
        [Parameter(Mandatory = $false)]
        [array]$additionalSubnetIds
    )

    $allSubnetIds = @()
    if ($aksClusterNames) {
        $aksSubnetIds = @(Get-AKSsubnets -aksClusterNames $aksClusterNames)
        $allSubnetIds = $allSubnetIds + $aksSubnetIds
    }

    if ($functionNames) {
        $functionSubnetIds = @(Get-FunctionSubnets -functionNames $functionNames)
        $allSubnetIds = $allSubnetIds + $functionSubnetIds
    }

    if ($additionalSubnetIds) {
        $allSubnetIds = $allSubnetIds + $additionalSubnetIds
    }

    # apply subnet firewall rules
    if ($allSubnetIds) {
        foreach ($subnetId in $allSubnetIds) {
            $subnetId = $subnetId.trim()  #trim leading/trailing spaces
            Write-Verbose "Check subnet to verify it is from an Atlas resource:" -Verbose
            Write-Verbose "SubnetId:  $subnetId" -Verbose
            $atlasSubnet = Is-subnetAtlas $subnetId
            if ($atlasSubnet) {
                Write-Verbose "applying storage account firewall rule for subnetId: $subnetId" -Verbose
                az storage account network-rule add --account-name $storageAccount -g $resourceGroup --action 'Allow' --subnet $subnetId --query "networkRuleSet"
                Write-Verbose "$subnetId has been allowed on $storageAccount" -Verbose
            }
            else {
                Write-Verbose "Subnet is not an Atlas resource, so it is not being added to the storage account firewall rules:" -Verbose
                Write-Verbose "SubnetId:  $subnetId" -Verbose
            }
        }
    }
}

function Get-TagsOnResourceGroup {
    param (
        [Parameter (Mandatory = $true)] [string] $resourceGroup
    )

    Write-Verbose "Grabbing initial tags..." -Verbose
    $initialTags = $(az group show --name $resourceGroup --query "tags") | ConvertFrom-Json

    $tags = @()
    #grab pre-existing tags
    foreach ($tag in $initialTags.psobject.properties) {
        $tags += "$($tag.Name)=$($tag.Value)"
    }

    #note the tagString will end with a space
    Write-Verbose "Acqquired tags from resource group $resourceGroup..." -Verbose
    Write-Verbose "Generated tag array: '$tags'" -Verbose

    return $tags
}


function Is-RGAtlas {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup
    )

    $tags = Get-TagsOnResourceGroup -resourceGroup $resourceGroup

    $RGIsAtlas = $false
    ForEach ($tag in $tags) {
        If ($tag.Contains("TemplateVersion")) {
            If ($tag.Contains("Titan-Atlas")) {
                $RGIsAtlas = $true
            }#else ignore
        }#else ignore
    }

    return $RGIsAtlas

}

function Is-subnetAtlas {
    param(
        [Parameter(Mandatory = $true)][string]$subnetId
    )

    # determine resource group from subnetId
    $subnetResourceGroup = $subnetId.Split("/")[4]

    # check if resource group is an Atlas resource group
    return (Is-RGAtlas $subnetResourceGroup)
}


# returns an az cli resource given name and group
# uses resourceType as tie-breaker if multiple resources conflict
Function Get-AtlasResourceFromInputs {
    param(
        [Parameter(Mandatory = $true)]  [string] $resourceName,
        [Parameter(Mandatory = $true)]  [string] $resourceGroup,
        # we'll try to lookup using name and group, but if there's a conflict (e.g., two resources same name)
        # we'll fallback to resource type to determine which one we're hitting
        [Parameter(Mandatory = $false)] [string] $resourceType
    )
    $resourceResult = $null

    $targetResource = az resource list -n $resourceName -g $resourceGroup | ConvertFrom-Json
    if ($targetResource.Count -eq 0) {
        Throw "No resources found matching $resourceName in $resourceGroup!"
    }
    elseif ($targetResource.Count -gt 1) {
        Write-Verbose "Multiple resources found matching $resourceName in $resourceGroup! Checking for specific resource type..." -Verbose
        if (![string]::IsNullOrEmpty($resourceType)) {
            $resourceResult = $targetResource | Where-Object { $_.type -eq $resourceType }
        }
        else {
            Throw "Multiple resources found matching $resourceName in $resourceGroup but no resourceType specified to narrow resultset!"
        }
    }
    else {
        $resourceResult = $targetResource
    }

    return $resourceResult
}

Function Clean-ServiceBusNetworkRules {
    Param(
        [Parameter(Mandatory = $true)] [string] $namespace,
        [Parameter(Mandatory = $true)] [string] $resourceGroup
    )
    # confirm/set resource to have no network rules at test time
    $existingRules = az servicebus namespace network-rule list --namespace-name $namespace --resource-group $resourceGroup | ConvertFrom-Json
    if ($existingRules.virtualNetworkRules.subnet) {
        $existingRules.virtualNetworkRules.subnet.id | ForEach-Object { az servicebus namespace network-rule remove --namespace-name $namespace --resource-group $resourceGroup --subnet $_ | Out-Null }
    }
    $existingRules = az servicebus namespace network-rule list --namespace-name $namespace --resource-group $resourceGroup | ConvertFrom-Json

    return $existingRules.virtualNetworkRules
}

Function Clean-StorageAccountNetworkRules {
    Param(
        [Parameter(Mandatory = $true)] [string] $storageAccount,
        [Parameter(Mandatory = $true)] [string] $resourceGroup
    )
    # confirm/set resource to have no network rules at test time
    $existingRules = az storage account network-rule  list --account-name $storageAccount --resource-group $resourceGroup | ConvertFrom-Json
    if ($existingRules.virtualNetworkRules) {
        $existingRules.virtualNetworkRules.virtualNetworkResourceId | ForEach-Object { az storage account network-rule remove --account-name $storageAccount --resource-group $resourceGroup --subnet $_ | Out-Null }
    }
    $existingRules = az storage account network-rule  list --account-name $storageAccount --resource-group $resourceGroup | ConvertFrom-Json

    return $existingRules.virtualNetworkRules
}

Function Clean-KeyVaultNetworkRules {
    Param(
        [Parameter(Mandatory = $true)] [string] $keyVault,
        [Parameter(Mandatory = $true)] [string] $resourceGroup
    )
    # confirm/set resource to have no network rules at test time
    $existingRules = az keyvault network-rule  list --name $keyVault --resource-group $resourceGroup | ConvertFrom-Json
    if ($existingRules.virtualNetworkRules) {
        $existingRules.virtualNetworkRules.id | ForEach-Object { az keyvault network-rule remove --name $keyVault --resource-group $resourceGroup --subnet $_ | Out-Null }
    }
    $existingRules = az keyvault network-rule  list --name $keyVault --resource-group $resourceGroup | ConvertFrom-Json

    return $existingRules.virtualNetworkRules
}

Function Clean-SqlServerNetworkRules {
    Param(
        [Parameter(Mandatory = $true)] [string] $sqlServer,
        [Parameter(Mandatory = $true)] [string] $resourceGroup
    )
    # confirm/set resource to have no network rules at test time
    $existingRules = az sql server vnet-rule list --server $sqlServer --resource-group $resourceGroup | ConvertFrom-Json
    if ($existingRules) {
        $existingRules | ForEach-Object { az sql server vnet-rule delete --server $sqlServer --resource-group $resourceGroup --name $_.name | Out-Null }
    }
    $existingRules = az sql server vnet-rule list --server $sqlServer --resource-group $resourceGroup | ConvertFrom-Json

    return $existingRules.virtualNetworkSubnetId
}

Function Clean-EventHubsNetworkRules {
    Param(
        [Parameter(Mandatory = $true)] [string] $namespace,
        [Parameter(Mandatory = $true)] [string] $resourceGroup
    )
    # confirm/set resource to have no network rules at test time
    $existingRules = az eventhubs namespace network-rule list --namespace-name $namespace --resource-group $resourceGroup | ConvertFrom-Json
    if ($existingRules.virtualNetworkRules.subnet) {
        $existingRules.virtualNetworkRules.subnet.id | ForEach-Object { az eventhubs namespace network-rule remove --namespace-name $namespace --resource-group $resourceGroup --subnet $_ | Out-Null }
    }
    $existingRules = az eventhubs namespace network-rule list --namespace-name $namespace --resource-group $resourceGroup | ConvertFrom-Json

    return $existingRules.virtualNetworkRules
}

function Wait-ResourceProvisioningState {
    param(
        [Parameter(Mandatory = $true)][string]$resourceId,
        [Parameter(Mandatory = $false)][string]$desiredState = "Succeeded"
    )

    $info = $(az resource show --ids $resourceId) | ConvertFrom-Json
    if (!$info.properties.provisioningState) {
        Write-Warning "Passed resource does not expose a provisioningState field."
    }
    else {
        $i = 0
        while ($info.properties.provisioningState -ne $desiredState -and $i -lt $CONST_MAX_ATTEMPTS) {
            Write-Verbose "Desired state '$desiredState' not found for '$resourceId'. Will re-attempt in $CONST_SLEEP_TIME seconds..." -Verbose
            Start-Sleep -Seconds $CONST_SLEEP_TIME
            $info = $(az resource show --ids $resourceId) | ConvertFrom-Json
            $i++
        }
    }
    return $info
}

function Set-TagOnAtlasResource {
    param
    (
        [Parameter (Mandatory = $true)] [string] $resourceGroup,
        [Parameter (Mandatory = $true)] [string] $resourceName,
        [Parameter (Mandatory = $true)] [string] $resourceType,
        [Parameter (Mandatory = $true)] [string] $tagName,
        [Parameter (Mandatory = $true)] [string] $tagValue
    )

    Write-Verbose "Tag name is $tagName" -Verbose
    Write-Verbose "Tag value is $tagValue" -Verbose
    Write-Verbose "Grabbing initial tags..." -Verbose
    $initialTagsPS = (az resource list --resource-group $resourceGroup --name $resourceName --resource-type $resourceType --query "[0].tags") | ConvertFrom-Json

    $tagUpdated = $false
    $tagAdded = $false

    $initialTagsHT = @{}
    $initialTagsPS.psobject.properties | ForEach-Object { $initialTagsHT[$_.Name] = $_.Value }

    if ($initialTagsHT.$tagName) {
        #meaning tag already exists
        #check for network value and add if not already there
        if (($initialTagsHT.$tagName).Contains("$tagValue")) {
            #set flag and print out
            $tagExists = $true
            Write-Verbose "Atlas tag with value of $tagValue already exists on resource $resourceName" -Verbose
        }
        else {
            #need to add tag value to the atlas exceptions tag
            $tagUpdated = $true
            $initialTagsHT["$tagName"] = "$tagValue"
            Write-Verbose "About to update Atlas tag with new value of $tagValue on resource $resourceName" -Verbose
        }
    }
    else {
        #tag does not exist add new
        $tagAdded = $true
        $initialTagsHT.Add("$tagName", "$tagValue")
        Write-Verbose "About to add Atlas tag with value of $tagValue to resource $resourceName as a new tag" -Verbose
    }

    if ($tagUpdated -or $tagAdded) {
        $resource = Get-AzResource -Name $resourceName -ResourceGroup $ResourceGroup -ResourceType $resourceType
        $updateTagResult = Update-AzTag -ResourceId $resource.id -Tag $initialTagsHT -Operation Replace
        Write-Verbose "Added/Updated resource $resourceName with tagname $tagName and tagvalue $tagValue" -Verbose
    }

    $finalTagList = (az resource list --resource-group $resourceGroup --name $resourceName --resource-type $resourceType --query "[0].tags") | ConvertFrom-Json
    Write-Verbose "Final tag list for resource $resourceName is: $($finalTagList.psobject.properties.name)" -Verbose


}
################################################################
# App Service Specific Functions
################################################################
function Add-CORS-Origins {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$appName,
        [Parameter(Mandatory = $true)][string]$rgName,
        [Parameter(Mandatory = $true)][string]$corsAlowedOrigins
    )

    if (!($corsAlowedOrigins)) {
        Write-Verbose -Message "No CORS origins have been specified" -Verbose
    }
    else {
        Write-Verbose -Message "CORS origin(s) defined" -Verbose

        $origins = $corsAlowedOrigins.Split(" ")

        foreach ($origin in $origins) {

            $matchedOrigins = az webapp cors show  `
                --name "$appName" `
                --resource-group "$rgName" `
                --query "allowedOrigins[?contains(@, '$origin')]" | ConvertFrom-Json

            if ($matchedOrigins) {
                Write-Verbose -Message "CORS origin already exists called $origin" -Verbose
            }
            else {
                Write-Verbose -Message "Adding CORS origin called $origin" -Verbose

                az webapp cors add `
                    --name "$appName" `
                    --resource-group "$rgName" `
                    --allowed-origins "$origin"
            }
        }
    }
}


function Remove-CORS-Origins {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$appName,
        [Parameter(Mandatory = $true)][string]$rgName,
        [Parameter(Mandatory = $true)][string]$corsAlowedOrigins
    )

    if (!($corsAlowedOrigins)) {
        Write-Verbose -Message "No CORS origins have been specified" -Verbose
    }
    else {
        Write-Verbose -Message "CORS origin(s) defined" -Verbose

        $origins = $corsAlowedOrigins.Split(" ")

        foreach ($origin in $origins) {

            $matchedOrigins = az webapp cors show  `
                --name "$appName" `
                --resource-group "$rgName" `
                --query "allowedOrigins[?contains(@, '$origin')]" | ConvertFrom-Json

            if (!($matchedOrigins)) {
                Write-Verbose -Message "No CORS origin exists called $origin" -Verbose
            }
            else {
                Write-Verbose -Message "Removing CORS origin called $origin" -Verbose

                az webapp cors remove `
                    --name "$appName" `
                    --resource-group "$rgName" `
                    --allowed-origins "$origin"
            }
        }
    }
}

function Get-AtlasAppServiceIdentities {
    param
    (
        [Parameter(Mandatory = $false)]
        [string] $resourceName,

        [Parameter(Mandatory = $false)]
        [string] $resourceGroupName = $null
    )

    $systemIdentity = $(az webapp identity show --name $resourceName --resource-group $resourceGroupName | ConvertFrom-Json).principalId

    $userIdentities = @()
    $idObj = $(az webapp identity show --name $resourceName --resource-group $resourceGroupName | ConvertFrom-Json)
    foreach ($id in $idObj.userAssignedIdentities) {
        $name = $id.psobject.properties.name
        $principalId = $id.$name.principalId
        $userIdentities += $principalId
    }

    return  @{systemIdentity = $systemIdentity; userIdentities = $userIdentities }
}


##################################################################################################
# Original AKS Functions
##################################################################################################

function Get-Atlas-Subscription {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$subscription,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting Virtual Network value for '$queryParam'" -Verbose
            $result = az account show --subscription "$subscription" --query "$queryParam" -o tsv 2> $null
        }
        Else {
            Write-Verbose "Getting Virtual Network json data" -Verbose
            $result = az account show --subscription "$subscription" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}

function Get-Atlas-AD-Service-Principal {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$appIdUri,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting AD Service Principal value for '$queryParam'" -Verbose
            $result = az ad sp show --id "$appIdUri" --query "$queryParam" -o tsv 2> $null
        }
        else {
            Write-Verbose "Getting AD Service Principal json data" -Verbose
            $result = az ad sp show --id "$appIdUri" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}

#This function takes in a Service Principal name and returns its guid
#this is the service principal object id NOT the app registration object id
function Get-SPObjectId {
    param(
        [Parameter(Mandatory = $true)][string]$SPName
    )

    $account = az ad sp list --display-name $SPName | ConvertFrom-Json
    Write-Verbose "Account Signed in: $account" -Verbose
    $guid = $account.id
    Write-Verbose "Guid for Account Signed in: $guid" -Verbose

    return $guid
}

# This function takes in an Azure AD User name and returns its ObjectId guid
function Get-UserObjectId {
    param(
        [Parameter(Mandatory = $true)][string]$UserName
    )

    $account = az ad user show --id $UserName | ConvertFrom-Json
    Write-Verbose "User Name: $UserName" -Verbose
    $guid = $account.id
    Write-Verbose "User ObjectId: $guid" -Verbose

    return $guid
}

# This function takes in an Azure AD Group name and returns its ObjectId guid
function Get-GroupObjectId {
    param(
        [Parameter(Mandatory = $true)][string]$GroupName
    )

    $account = az ad group list --display-name $GroupName | ConvertFrom-Json
    Write-Verbose "AD Group Name: $GroupName" -Verbose
    $guid = $account.id
    Write-Verbose "AD Group ObjectId: $guid" -Verbose

    return $guid
}

# This function returns the portfolio name associated with an RM Account based on App Id guid
function Get-PortfolioByRunningAppId {
    param(
        [Parameter(Mandatory = $true)][string]$RmAcctAppId
    )
    $rmAcctDisplayName = $(Get-AzADServicePrincipal -ApplicationId $RmAcctAppId).DisplayName
    Write-Verbose "running as rm acct:   $rmAcctDisplayName" -Verbose
    switch -wildcard ($rmAcctDisplayName) {
        "SP-RM-*-P" {
            $portName = $rmAcctDisplayName.Substring(6, ($rmAcctDisplayName.Length - 8))
            Write-Verbose "Based on Running ID, port is: $portName"
        }
        default {
            throw "Unable to determine running context. ApplicationID: $RmAcctAppId not found"
        }
    }
    return $portName
}

#$AA_SP_PROVISIONING_SP = "4087210c-fdf5-4514-bcdc-17c1b7507890"
function Get-ProvisioningObjectId {

    $guid = Get-SPObjectId -SPName "SP-AA-SpProvisioning-P"

    return $guid
}

function Get-AD-Service-Principal-By-Display-Name {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$displayName,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting AD Service Principal value for '$queryParam'" -Verbose
            $result = az ad sp list --display-name "$displayName" --query "[0].$queryParam" -o tsv 2> $null
        }
        else {
            Write-Verbose "Getting AD Service Principal json data" -Verbose
            $result = az ad sp list --display-name "$displayName" --query "[0]" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}

function Get-AD-Group-ObjectId {
    [CmdletBinding()]
    param([string]$a)

    $objectId = $null

    try {
        #BugFix-1221276 -- "More than one groups match name of 'R-Scrumbirds'
        $objectId = (az ad group list --display-name "$a" --query "[?displayName=='$a'].objectId" -o tsv) 2>$null
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $objectId
}

function Get-Key-Vault-Secret {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$kvName,
        [Parameter(Mandatory = $true)][string]$secretName,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting value for secret called '$secretName' from a key vault called '$kvName'" -Verbose
            $result = az keyvault secret show --name "$secretName" --vault-name "$kvName" --query "$queryParam" -o tsv 2> $null
        }
        else {
            Write-Verbose "Getting secret called '$secretName' from a key vault called '$kvName'" -Verbose
            $result = az keyvault secret show --name "$secretName" --vault-name "$kvName" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}

function Set-Key-Vault-Secret {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$kvName,
        [Parameter(Mandatory = $true)][string]$secretName,
        [Parameter(Mandatory = $true)][string]$secretValue
    )

    $setSecret = $true

    try {
        # Get a secret from the key vault
        $value = Get-Key-Vault-Secret `
            -kvName "$kvName" `
            -secretName "$secretName" `
            -queryParam "value"

        if ($null -ne $value) {
            if ($value -eq $secretValue) {
                $setSecret = $false
                Write-Verbose "A secret called '$secretName' in a key vault called '$kvName' already has the desired value." -Verbose
            }
        }
        else {
            Write-Verbose "Unable to find secret called '$secretName' in a key vault called '$kvName'" -Verbose
        }

        if ($true -eq $setSecret) {
            Write-Verbose "Setting value for secret called '$secretName' in a key vault called '$kvName'" -Verbose

            az keyvault secret set `
                --name "$secretName" `
                --vault-name "$kvName" `
                --value "$secretValue"
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $hasSecret
}

function Get-Service-Principal {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$appIdUri,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting AD Service Principal value for '$queryParam'" -Verbose
            $result = az ad sp show --id "$appIdUri" --query "$queryParam" -o tsv 2> $null
        }
        else {
            Write-Verbose "Getting AD Service Principal json data" -Verbose
            $result = az ad sp show --id "$appIdUri" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}

function Get-MSI {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$msiName,
        [Parameter(Mandatory = $true)][string]$rgName,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting MSI value for '$queryParam'" -Verbose
            $result = az identity show --name "$msiName" --resource-group "$rgName" --query "$queryParam" -o tsv 2> $null
        }
        else {
            Write-Verbose "Getting MSI json data" -Verbose
            $result = az identity show --name "$msiName" --resource-group "$rgName" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}


function Get-WebApp-Identity {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$appName,
        [Parameter(Mandatory = $true)][string]$rgName,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting Web App Identity value for '$queryParam'" -Verbose
            $result = az webapp identity show --name "$appName" --resource-group "$rgName" --query "$queryParam" -o tsv 2> $null
        }
        else {
            Write-Verbose "Getting Web App Identity json data" -Verbose
            $result = az webapp identity show --name "$appName" --resource-group "$rgName" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}

function Get-AD-Group {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$groupName,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting AD Group value for '$queryParam'" -Verbose
            $result = az ad group show -g "$groupName" --query "$queryParam" -o tsv 2> $null
        }
        else {
            Write-Verbose "Getting AD Group json data" -Verbose
            $result = az ad group show -g "$groupName" # 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}


function Invoke-AtlasWebClient {
    param(
        [Parameter(Mandatory = $true)][string]$Uri
    )
    if ($PSVersionTable.PSVersion.Major -lt 6) {
        return Invoke-AtlasWebClientV5 -Uri $Uri
    }
    else {
        return Invoke-AtlasWebClientV6 -Uri $Uri
    }
}

function Invoke-AtlasWebClientV6 {
    param(
        [Parameter(Mandatory = $true)][string]$Uri
    )
    $StatusCode = 500
    $Body = ""
    $headers = @{Accept = "*/*" }

    # the next section sets up the client to use TLS 1.2 and ignore the fact that we're hitting
    # the endpoint via IP, which leads to the cert failing verification
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    try {
        # Invoke-WebRequest has differing behavior depending on whether you're in PS Core or not...
        $result = Invoke-WebRequest -Uri $Uri -Headers $headers -SkipCertificateCheck
        $StatusCode = $result.StatusCode
        $Body = $result.Content
    }
    catch {
        $StatusCode = $_.Exception.Response.StatusCode.value__
        if (!$StatusCode) {
            throw $_.Exception.Message
        }
    }

    return @{StatusCode = $StatusCode; Body = $Body }
}

function Invoke-AtlasWebClientV5 {
    param(
        [Parameter(Mandatory = $true)][string]$Uri
    )
    $StatusCode = 500
    $Body = ""

    # the next section sets up the client to use TLS 1.2 and ignore the fact that we're hitting
    # the endpoint via IP, which leads to the cert failing verification
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true } ;

    try {
        # Invoke-WebRequest has differing behavior depending on whether you're in PS Core or not...
        $wc = New-Object Net.WebClient
        $wc.Headers.Add("Accept: */*")
        $wc.Headers.Add("User-Agent: AtlasTester")
        $result = $wc.DownloadString($Uri)

        if ($result) {
            $StatusCode = 200
        }
        $Body = $result
    }
    catch [System.Net.WebException] {
        Write-Verbose "Error executing Invoke-AtlasWebClientV5: $($_.Exception.Message)" -Verbose
        $Body = $_.Exception.Message
        $StatusCode = $_.Exception.Response.StatusCode.value__
        if ([string]::IsNullOrEmpty($StatusCode)) {
            $StatusCode = "500"
        }
    }

    return @{StatusCode = $StatusCode; Body = $Body }
}


# Function to return all clusters which use the passed in Service Princpal
# Checks only the subscriptions fed into the function
# Returns a custom type as a result
function Get-AtlasClustersUsingInputServicePrincpal {
    param
    (
        [Parameter (Mandatory = $true)]
        [string] $ServicePrincipalName,

        [Parameter (Mandatory = $true)]
        [array] $TargetSubscriptions
    )

    $results = @()
    foreach ($subscription in $TargetSubscriptions) {
        az account set -s $subscription | Out-Null

        # intentionally plucking the desired attributes on the following query as for CMFG NonProduction the az aks list results
        # cannot be piped directly into ConvertFrom-Json due to conflicting casing in identical key values
        $clusterInfo = (az aks list --query "[].{name: name, resourceGroup: resourceGroup, servicePrincipalProfile: servicePrincipalProfile, tags: tags}") | ConvertFrom-Json

        $atlasClusterInfo = $clusterInfo | Where-Object { $_.tags -and $_.tags.TemplateVersion -match "Titan-Atlas" }
        foreach ($cluster in $atlasClusterInfo) {
            # map each found SP to their KV, check the KV to ensure the SP secret is currently vaulted there
            $discoveredSpName = (az ad sp show --id $cluster.servicePrincipalProfile.clientId --query "displayName" -o tsv)
            if ($ServicePrincipalName.ToLower() -eq $discoveredSpName.ToLower()) {
                $results += @{Subscription = $subscription; ClusterName = $($cluster.name); `
                        ServicePrincipalName = $discoveredSpName; `
                        ServicePrincipalClientId = $($cluster.servicePrincipalProfile.clientId); `
                        ClusterResourceGroup = $($cluster.resourceGroup)
                }
            }
        }
    }

    return $results
}


########################################################################################################
# This function is a wrapper for the recursive lookup and validation.
# Input a role group and an array list to catch the invalid members, and get a result and populated
#   arraylist for inspection/reporting.
# Must pass in role group for inspection and ArrayList to store invalid members in.
########################################################################################################
function Ensure-OnlyElevatedAccessAccounts {
    Param
    (
        [Parameter(Mandatory = $true)]
        [string] $groupName
    )

    # source the commonCode implementation of this function. Pass through calls to the core implementation
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

    return (Ensure-OnlyElevatedAccessAccounts -groupName $groupName)

}

########################################################################################################
# This function validates the existence of a resource group
# Input a resource group and a boolean will be returned indicating
# $true (exists) or $false (does not exist).
########################################################################################################

function Validate-ResourceGroupExists {
    Param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName
    )

    $RG_Exists = $false

    $RG_Exists = Get-AzResourceGroup -resourcegroupname $resourceGroupName -ErrorAction SilentlyContinue


    if ($RG_Exists) {
        return $true
    }
    else {
        return $false
    }
}
########################################################################################################
# This function validates whether the subscription is in Sandbox or NonProd or Prod  then return the subscripiton type.
########################################################################################################


function Validate-TargetSourceSubscriptionIsAtlasAllowed {

    Param
    (
        [Parameter(Mandatory = $true)]
        [string]  $targetSubscription = $targetSubscriptionName,
        [Parameter(Mandatory = $true)]
        [string]  $sourceSubscription = $sourceSubscriptionName
    )
    $targetSub = Get-SubscriptionProperties -SubscriptionName $targetSubscription
    $sourceSub = Get-SubscriptionProperties -SubscriptionName $sourceSubscription
    if ( $targetSub.environment -eq $sourceSub.environment) {
        Write-Verbose "Both source and target resource are in the $($targetSub.environment) subscription." -Verbose
    }
    else {
        Write-Error "Error while validating the subscription for the source and target resource.Both source and target resource must be either in $($targetSub.environment) or $($sourceSub.environment) subscription." -Verbose
        throw "The target resrouce is in the $targetSubscription,but the subnet of the source resource is in the $sourceSubscription. We can't enable this source resource to access a target PaaS resource as they both need to be in the same type of environment."
    }
}
