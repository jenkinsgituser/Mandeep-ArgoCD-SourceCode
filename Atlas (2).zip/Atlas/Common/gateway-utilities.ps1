
$CONST_AG_TEMPLATE_JSON_DEPTH = 15

function Get-Atlas-Subscription {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$subscription,
        [Parameter(Mandatory = $false)][string]$queryParam
    )

    $result = $null

    try {
        If ($queryParam) {
            Write-Verbose "Getting Virtual Network value for '$queryParam'" -Verbose
            $result = az account show --subscription "$subscription" --query "$queryParam" -o tsv 2> $null
        }
        Else {
            Write-Verbose "Getting Virtual Network json data" -Verbose
            $result = az account show --subscription "$subscription" 2> $null
        }
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $result
}

#**************************************************
# Get Azure Resources using Azure CLI
#**************************************************


function Get-Titan-AG-WAF {
    [CmdletBinding()]
    param([string]$g, [string]$n)

    $AG_WAF = $null

    try {
        $AG_WAF = az network application-gateway show -g "$g" -n "$n" 2>$null
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $AG_WAF
}

function Get-Titan-AG-WAF-Public-IP {
    [CmdletBinding()]
    param([string]$g, [string]$n)

    $PUBLIC_IP = $null

    try {
        $PUBLIC_IP = az network public-ip show  -g "$g" -n "$n-IP" 2>$null
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $PUBLIC_IP
}


function Get-Titan-Subnet {
    [CmdletBinding()]
    param([string]$g, [string]$n, [string]$v)

    $SUBNET = $null

    try {
        $SUBNET = az network vnet subnet show -g "$g" -n "$n" --vnet-name "$v" 2>$null
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $SUBNET
}

function Get-Titan-VNet {
    [CmdletBinding()]
    param([string]$g, [string]$n)

    $VNET = $null

    try {
        $VNET = az network vnet show -g "$g" -n "$n" 2>$null
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $VNET
}

function Get-Titan-NSG {
    [CmdletBinding()]
    param([string]$g, [string]$n)

    $NSG = $null

    try {
        $NSG = az network nsg show  -g "$g" -n "$n" 2>$null
    }
    catch {
    }
    finally {
        $global:lastExitCode = $null
    }

    return $NSG
}

function Add-GwIpToAppService {
    param(
        [Parameter(Mandatory = $true)][string]$appName,
        [Parameter(Mandatory = $false)][string]$appResourceGroup,
        [Parameter(Mandatory = $true)][string]$appType,
        [Parameter(Mandatory = $true)][string]$gwResourceGroup,
        [Parameter(Mandatory = $true)][string]$gwName
    )

    $ipAddressObject = Get-Titan-AG-WAF-Public-IP -g $gwResourceGroup -n $gwName
    $ipAddressObject = $ipAddressObject | ConvertFrom-Json
    $ipAddress = $ipAddressObject.ipAddress

    Write-Verbose "Updating $appName to only allow traffic from $ipAddress" -Verbose
    $tempErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = 'stop'

    if (($appType -eq $CONST_AS_RESOURCE_TYPE_WEB_APP ) -or ($appType -eq $CONST_AS_RESOURCE_TYPE_WEB_APP_PRIVATE)) {
        try {
            $webApp = az webapp show --name $appName --resource-group $appResourceGroup 2> $null
        }
        catch {
            Write-Verbose "WARN: App does not exist: $appName" -Verbose
        }
        if ($webApp) {
            $test = az resource update --name "$appName/config/web" --resource-group $appResourceGroup --resource-type "Microsoft.Web/sites/config" --set properties.ipSecurityRestrictions="[{'ipAddress':'$ipAddress/32'}]"
        }
    }
    else {

        # Function App type -- newer Az CLI versions don't treat web app and function app as the same unlike prior versions
        try {
            $functionApp = az functionapp show --name $appName --resource-group $appResourceGroup 2> $null
        }
        catch {
            Write-Verbose "WARN: App does not exist: $appName" -Verbose
        }
        if ($functionApp) {
            $test = az resource update --name "$appName/config/web" --resource-group $appResourceGroup --resource-type "Microsoft.Web/sites/config" --set properties.ipSecurityRestrictions="[{'ipAddress':'$ipAddress/32'}]"
        }

    }
    $ErrorActionPreference = $tempErrorActionPreference
    return $ipAddress

}

function Set-AgWafParametersJSON {
    param(
        [Parameter(Mandatory = $true)][string]$certName,
        [Parameter(Mandatory = $true)][string]$certPassword,
        [Parameter(Mandatory = $true)][string]$keyvaultId,
        [Parameter(Mandatory = $true)][string]$certParam,
        [Parameter(Mandatory = $true)][string]$passwordParam,
        [Parameter(Mandatory = $false)][string]$parametersFilePath
    )

    #check if entered param file
    if ($parametersFilePath -eq "") {
        #if no param file, then initialize one
        $AG_TEMPLATE_PARAMETERS_JSON =
        "
{
    `"`$schema`": `"https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#`",
    `"contentVersion`": `"1.0.0.0`",
    `"parameters`": {
        `"$certParam`": {
            `"reference`": {
                `"keyVault`": {
                    `"id`": `"__VAULT_ID__`"
                },
                `"secretName`": `"__CERT_SECRET_NAME__`"
            }
        },
        `"$passwordParam`": {
            `"reference`": {
                `"keyVault`": {
                    `"id`": `"__VAULT_ID__`"
                },
                `"secretName`": `"___CERT_PWD_SECRET_NAME__`"
            }
        }
    }
}
"
        $AG_TEMPLATE_PARAMETERS = ConvertFrom-Json -InputObject $AG_TEMPLATE_PARAMETERS_JSON
        #Set values
        $AG_TEMPLATE_PARAMETERS.parameters.$certParam.reference.keyVault.id = "$keyvaultId"
        $AG_TEMPLATE_PARAMETERS.parameters.$certParam.reference.secretName = "$certName"
        $AG_TEMPLATE_PARAMETERS.parameters.$passwordParam.reference.keyVault.id = "$keyvaultId"
        $AG_TEMPLATE_PARAMETERS.parameters.$passwordParam.reference.secretName = "$certPassword"

        $AG_TEMPLATE_PARAMETERS_OUT = ConvertTo-Json -InputObject $AG_TEMPLATE_PARAMETERS -Depth $CONST_AG_TEMPLATE_JSON_DEPTH
        $AG_WAF_PARAMETERS_FILE = "$env:INFRA_FOLDER/AppGateway/WAFv2/src/azuredeployGatewayWAF_v2_ssl.parameters.json"

        Out-File -FilePath $AG_WAF_PARAMETERS_FILE -InputObject $AG_TEMPLATE_PARAMETERS_OUT -Force
    }
    else {
        #if param file then concat onto existing one
        $AG_WAF_PARAMETERS_FILE = $parametersFilePath
        $AG_TEMPLATE_PARAMETERS_JSON = Get-Content -Path $AG_WAF_PARAMETERS_FILE
        $AG_TEMPLATE_PARAMETERS = $AG_TEMPLATE_PARAMETERS_JSON | ConvertFrom-Json
        $Parameters = $AG_TEMPLATE_PARAMETERS.parameters

        #create new parameter object
        #set keyvault object
        $kvProperties = @{
            id = $keyvaultId
        }
        $keyvault = New-Object psobject -Property $kvProperties

        #set reference objects
        $certReferenceProperties = @{
            keyVault   = $keyvault
            secretName = $certName
        }
        $passwordReferenceProperties = @{
            keyVault   = $keyvault
            secretName = $certPassword
        }
        $certReference = New-Object psobject -Property $certReferenceProperties
        $passwordReference = New-Object psobject -Property $passwordReferenceProperties

        #create parent objects
        $certProperties = @{
            reference = $certReference
        }
        $passwordProperties = @{
            reference = $passwordReference
        }
        $certObject = New-Object psobject -Property $certProperties
        $passwordObject = New-Object psobject -Property $passwordProperties

        #add to params
        $Parameters | Add-Member -MemberType NoteProperty -Name $certParam -Value $certObject
        $Parameters | Add-Member -MemberType NoteProperty -Name $passwordParam -Value $passwordObject

        #convert to JSON and out to file
        $AG_TEMPLATE_PARAMETERS_OUT = ConvertTo-Json -InputObject $AG_TEMPLATE_PARAMETERS -Depth $CONST_AG_TEMPLATE_JSON_DEPTH
        Out-File -FilePath $AG_WAF_PARAMETERS_FILE -InputObject $AG_TEMPLATE_PARAMETERS_OUT -Force

    }

    return $AG_WAF_PARAMETERS_FILE
}

function Get-AGParametersFile {
    param(
        [Parameter(Mandatory = $true)][string]$fileName,
        [Parameter(Mandatory = $true)][string]$keyvaultId
    )
    #need to add check if empty and set to default template
    #find file
    if (!$fileName.EndsWith(".json")) {
        $fileName = "$fileName.json"
    }

    # if running local or using the Default override...
    if ($env:isLocal -or $env:FORCE_AG_DEFAULT_OVERRIDE) {
        if (!(Test-Path -Path $fileName)) {
            Write-Error "You need to enter in the full path name to the App Gateway parameter file for execution."
        }
        else {
            $agWafParametersFilePath = $fileName
        }
    }
    else {
        if (!(Test-Path $fileName)) {
            $agWafParametersFilePath = $(Get-ChildItem "$env:SYSTEM_DEFAULTWORKINGDIRECTORY/../" -Recurse -Force | Where-Object { $_.Name -match "^$fileName" }).FullName
        }
        else {
            $agWafParametersFilePath = $fileName
        }

    }

    if ($null -eq $agWafParametersFilePath) {
        Write-Error -Message "ERROR: Unable to locate $fileName" -ErrorAction Stop
    }
    Write-Verbose "AG_WAF_PARAMETERS_FILE_PATH: $agWafParametersFilePath" -Verbose

    $agWafParametersFile = Get-Content -Path $agWafParametersFilePath
    $agTemplateParametersIn = $agWafParametersFile | ConvertFrom-Json
    Write-Verbose "AG_TEMPLATE_PARAMETERS_IN: $agTemplateParametersIn" -Verbose

    #Check that Vnet entered in is Atlas
    $subnetId = $agTemplateParametersIn.gatewayIPConfigurations.properties.subnet.id
    $subnetName = $subnetId.split('/')[10]
    $subnetResourceGroup = $subnetId.split('/')[4]

    $RGAtlas = Is-RGAtlas -resourceGroup $subnetResourceGroup
    if (!$RGAtlas) {
        Write-Error -Message "ERROR: Subnet Associated is not an Atlas Subnet.  Please fix and try again." -ErrorAction Stop
    }

    #read in template file
    $Path = "$env:INFRA_FOLDER/AppGateway/WAFv2/src/azuredeployGatewayWAF_v2_ssl.json"

    $agWafTemplateFile = Get-Content -Path $Path

    #template file
    $agTemplateTemplateIn = $agWafTemplateFile | ConvertFrom-Json
    $parameters = $agTemplateTemplateIn.parameters
    #ssl certs from params file
    $sslCertificates = $agTemplateParametersIn.sslCertificates
    Write-Verbose "sslCertificates: $sslCertificates" -Verbose
    $index = 0
    #replace tokens for certificates in parameters file and add a param for each cert in template
    foreach ($cert in $sslCertificates) {
        #initialize parameter names
        $certParam = "frontendCertData$index"
        $passwordParam = "frontendCertPassword$index"

        #add the parameters to the parameters section in the template file
        $properties = @{
            type = "securestring"
        }
        $ParamObject = New-Object psobject -Property $properties
        $parameters | Add-Member -MemberType NoteProperty -Name $certParam -Value $ParamObject
        $parameters | Add-Member -MemberType NoteProperty -Name $passwordParam -Value $ParamObject

        #Set Cert info in
        Write-Verbose "CertName: $($cert.name)" -Verbose

        #look up cert secret and password and replace token in object
        $certToken = $cert.properties.data
        $passwordToken = $cert.properties.password

        #process given token
        Write-Verbose "certToken: $certToken" -Verbose
        Write-Verbose "passwordToken: $passwordToken" -Verbose
        #lowercase
        $certToken = $certToken.ToLower()
        $passwordToken = $passwordToken.ToLower()

        #strip '__'
        $certToken = $certToken.replace('__', '')
        $passwordToken = $passwordToken.replace('__', '')

        #replace '_' with '-'
        $certToken = $certToken.replace('_', '-')
        $passwordToken = $passwordToken.replace('_', '-')

        #replace data with cert-secret
        $certToken = $certToken.replace('data', 'secret')

        #need to determine keyvault to pull from
        Write-Verbose "certToken: $certToken" -Verbose

        #pull cert secret
        $cert.properties.data = "[parameters('$certParam')]"
        #Write-Verbose "cert: $($cert.properties.data)" -Verbose

        #pull cert password
        Write-Verbose "passwordToken: $passwordToken" -Verbose
        $cert.properties.password = "[parameters('$passwordParam')]"
        #$cert.properties.password.reference.keyvault.id = "$keyvaultId"

        if ($index -eq 0) {
            $agWafParametersFilePath = Set-AgWafParametersJSON -certName $certToken -certPassword $passwordToken -keyvaultId $keyvaultId -certParam $certParam -passwordParam $passwordParam -parametersFilePath ""
        }
        else {
            $agWafParametersFilePath = Set-AgWafParametersJSON -certName $certToken -certPassword $passwordToken -keyvaultId $keyvaultId -certParam $certParam -passwordParam $passwordParam -parametersFilePath $agWafParametersFilePath
        }

        #update parameters in template file

        $index += 1
    }
    #check app services to make sure they are have AS- prepended to them
    $backends = $agTemplateParametersIn.backendAddressPools
    $index = 0
    foreach ($backend in $backends) {
        $index = 0
        $backendAddresses = $backend.properties.backendAddresses
        foreach ($fqdn in $backendAddresses) {
            $fqdn = $backend.properties.backendAddresses[$index].fqdn

            if (!$fqdn.StartsWith('as-') -and !$fqdn.StartsWith('AS-') -and !$fqdn.StartsWith('FA-') -and !$fqdn.StartsWith('fa-')) {
                $fqdn = "as-$fqdn"
            }
            $backend.properties.backendAddresses[$index].fqdn = "$fqdn"
            $index += 1
        }
    }
    $($agTemplateTemplateIn.resources[1]).properties = $agTemplateParametersIn

    $agTemplateTemplateOut = ConvertTo-Json -InputObject $agTemplateTemplateIn -Depth $CONST_AG_TEMPLATE_JSON_DEPTH

    $agWafTemplateFilePathEditted = "$env:INFRA_FOLDER/AppGateway/WAFv2/src/azuredeployGatewayWAF_v2_ssl_editted.json"

    #after done replacing tokens put back out to the file
    Out-File -FilePath $agWafTemplateFilePathEditted -InputObject $agTemplateTemplateOut -Force | Out-Null

    # returning a tuple is more explicit than a comma delimited string
    return @{TemplateFilePath = $agWafTemplateFilePathEditted; ParametersFilePath = $agWafParametersFilePath }
}

function Get-AGWAF-AppServiceBackends {
    param(
        [Parameter(Mandatory = $true)][string]$filePath
    )

    $agWafParametersFile = Get-Content -Path $filePath
    #Write-Verbose "Template: $agWafParametersFile" -Verbose
    $agTemplateParameters = $agWafParametersFile | ConvertFrom-Json
    #Write-Verbose "Template: $agTemplateParameters" -Verbose
    $resource = $agTemplateParameters.resources[1]
    #Write-Verbose "resource: $resource" -Verbose
    $properties = $resource.properties
    $backendPools = $properties.backendAddressPools
    #Write-Verbose "backends: $backendPools"
    $appServices = @()

    foreach ($backend in $backendPools) {
        $fqdn = $backend.properties.backendAddresses.fqdn

        #try for web apps first
        $allSubWebApps = $(az webapp list) | ConvertFrom-Json
        $appResource = $allSubWebApps | Where-Object { $_.defaultHostName -eq $fqdn }
        if ($appResource.Count -gt 1) {
            throw "Multiple backends found matching FQDN '$fqdn'. Aborting to avoid misconfiguration!"
        }
        if ($WEB_APP_PRIVATE_ACCESS) {
            $appResourceType = $CONST_AS_RESOURCE_TYPE_WEB_APP_PRIVATE
        }
        else {
            $appResourceType = $CONST_AS_RESOURCE_TYPE_WEB_APP
        }


        #try a fallback for function apps
        if (!$appResource) {
            $allFunctionApps = $(az functionapp list) | ConvertFrom-Json
            $appResource = $allFunctionApps | Where-Object { $_.defaultHostName -eq $fqdn }
            if ($appResource.Count -gt 1) {
                throw "Multiple backends found matching FQDN '$fqdn'. Aborting to avoid misconfiguration!"
            }
            $appResourceType = $CONST_AS_RESOURCE_TYPE_FUNCTION_APP
        }

        if (!$appResource) {
            Write-Verbose -Verbose "No App Service resource found for FQDN '$fqdn'"
            Continue
        }

        $appService = @{Name = $($appResource.name); ResourceGroup = $($appResource.resourceGroup); Type = $appResourceType }
        $appServices += $appService
    }

    return $appServices
}

function Get-GwDomainLabel {
    param(
        [Parameter(Mandatory = $true)][string]$gwResourceGroup,
        [Parameter(Mandatory = $true)][string]$gwName
    )

    $ipAddressObject = Get-Titan-AG-WAF-Public-IP -g $gwResourceGroup -n $gwName
    $ipAddressObject = $ipAddressObject | ConvertFrom-Json

    if (!$ipAddressObject.dnsSettings) {
        Write-Error "Unable to discover public IP for AGWAF: '$gwName' in RG: '$gwResourceGroup'"
    }

    $domainLabel = $ipAddressObject.dnsSettings.domainNameLabel
    if ($domainLabel.Contains('-')) {
        $domainLabel = $($domainLabel.split('-'))[0]
    }
    return $domainLabel

}

function Set-DefaultAGProperties {
    param(
        [Parameter(Mandatory = $true)][string]$subscription,
        [Parameter(Mandatory = $true)][string]$environment,
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$agWafName,
        [Parameter(Mandatory = $true)][string]$appName,
        [Parameter(Mandatory = $true)][string]$agWafLocation,
        [Parameter(Mandatory = $false)][string]$hostName, #optional
        [Parameter(Mandatory = $false)][string]$sslCertName, #optional
        [Parameter(Mandatory = $false)][string]$vnetRGName, #optional
        [Parameter(Mandatory = $false)][string]$vnetName, #optional
        [Parameter(Mandatory = $false)][string]$subnetName#optional
    )

    # Get the short location name from the location
    $LocationShortName = Get-LocationShortName -location $agWafLocation

    #Check for optional variables, if empty string set defaults
    if ($sslCertName -eq "") {
        $sslCertName = "WILDCARD_ATLASBETA_CUNAMUTUAL"
    }
    if (($vnetRGName -eq "") -and ($environment -eq "Prod") ) {
        $vnetRGName = "RG-CMFG-PR1-Atlas-Infrastructure" + $LocationShortName
    }
    elseif (($vnetRGName -eq "") -and ($environment -ne "Prod") ) {
        $vnetRGName = "RG-CMFG-NP1-Atlas-Infrastructure" + $LocationShortName
    }
    if ($vnetName -eq "") {
        $vnetName = "VNet-CMFG-Atlas-Atlantis" + $LocationShortName
    }
    if ($subnetName -eq "") {
        $subnetName = "VNet-CMFG-Atlas-Atlantis" + $LocationShortName + "-cmfg-subnet-v1"
    }

    #retrieve default file
    $Path = "$env:INFRA_FOLDER/AppGateway/WAFv2/src/azuredeployGatewayWAF_v2_ssl.defaultParameters.json"

    $tempAGPropertiesObject = $(Get-Content -Path $Path)

    #replace tokens/update file
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__SUBSCRIPTION__", $subscription.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__AG_WAF_RG_NAME__", $resourceGroup.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__AG_WAF_NAME__", $agWafName.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__APP_NAME__", $appName.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__HOST_NAME__", $hostName.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__SSL_CERT_NAME__", $sslCertName.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__VNET_RG_NAME__", $vnetRGName.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__VNET_NAME__", $vnetName.ToLower())
    $tempAGPropertiesObject = $tempAGPropertiesObject.replace("__SUBNET_NAME__", $subnetName.ToLower())


    #Write-Verbose "tempAGPropertiesObject: $tempAGPropertiesObject" -Verbose

    #print out to new temp file
    $defaultAGPropertiesFileName = "azuredeployGatewayWAF_v2_ssl.defaultParameters-editted.json"
    $defaultAGPropertiesFilePath = "$Env:INFRA_FOLDER/AppGateway/WAFv2/src/$defaultAGPropertiesFileName"
    $test = Out-File -FilePath $defaultAGPropertiesFilePath -InputObject $tempAGPropertiesObject -Force
    Write-Verbose "Default Properties Saved to: $defaultAGPropertiesFilePath" -Verbose
    #return temp file name
    return $defaultAGPropertiesFilePath
}


function Reset-GwBackendStatus {
    param(
        [Parameter(Mandatory = $true)][string]$gwResourceGroup,
        [Parameter(Mandatory = $true)][string]$gwName
    )

    # note -- this touch adds about 2 minutes to the deployment, but at this time is necessary otherwise the backend
    # pool is not picked up when the FA is deployed after the AGWAF already exists
    ##################################################################################################################
    # touch the gateway so it recognizes that the backend has been added
    # we'll keep this to superficial changes only, sizing up and down the supported configuration of the resource
    # without changing any current operational constraints
    $initialAgConfig = $(az network application-gateway show -n $gwName -g $gwResourceGroup) | ConvertFrom-Json
    az network application-gateway update -n $gwName -g $gwResourceGroup --max-capacity ($initialAgConfig.autoscaleConfiguration.maxCapacity + 1) | Out-Null
    Write-Verbose -Verbose "Gateway maxCapacity scaled up 1"

    # after doing the superficial touch, we'll dial it back to where it started
    az network application-gateway update -n $gwName -g $gwResourceGroup --max-capacity ($initialAgConfig.autoscaleConfiguration.maxCapacity) | Out-Null
    Write-Verbose -Verbose "Gateway maxCapacity scaled down to original value"
}


function Get-AGWAF-SubnetName {
    param(
        [Parameter(Mandatory = $true)][psobject]$appGatewayJson
    )

    $appGatewayJson = $appGatewayJson | ConvertFrom-Json
    $gwSubnetId = $appGatewayJson.gatewayIPConfigurations.subnet.id
    $gwvNetName = $gwSubnetId.split('/')[8]
    $gwSubNetName = $gwSubnetId.split('/')[10]
    Write-Verbose -Message "Application Gateway Subnet: $gwSubNetName" -Verbose

    return $gwSubNetName
}

# this function will analyze the AGWAF Input parm file to determine the subnet the AGWAF is being deploy to
function Get-AGWAF-subnetFromParmFile {
    param(
        [Parameter(Mandatory = $true)][string]$filePath
    )

    $agWafParametersFile = Get-Content -Path $filePath
    $agTemplateParameters = $agWafParametersFile | ConvertFrom-Json

    $subnetId = $agTemplateParameters.gatewayIPConfigurations.properties.subnet.id
    $subnet = $subnetId.Split("/")[10]

    return $subnet
}


# this function will check if the agwaf parm file is configuring a Function as a backend
function Check-AGWAF-hasBackendFunctionsFromParmFile {
    param(
        [Parameter(Mandatory = $true)][string]$filePath
    )

    $agWafParametersFile = Get-Content -Path $filePath
    $agTemplateParameters = $agWafParametersFile | ConvertFrom-Json
    $fqdns = $agTemplateParameters.backendAddressPools.properties.backendAddresses.fqdn

    $backendHasFunctions = $false
    foreach ($fqdn in $fqdns) {
        $appSvc = $fqdn.Split(".")[0]
        $appSvcKind = ((az resource list -n $appSvc --resource-type "Microsoft.Web/sites") | ConvertFrom-Json).kind
        if ($appSvcKind -match "functionapp") {
            $backendHasFunctions = $true
            Write-Warning "Function app detected: $appSvc"
        }
    }

    return $backendHasFunctions
}
