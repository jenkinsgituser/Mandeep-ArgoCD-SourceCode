#############################################################################################################
#  Atlas-CommonCode:
#    1) Setup the different Types for Write-AtlasOutput: Info, Warn, Error, etc.
#    2) Write-AtlasOutput Function
#    3) Set CONST values that can be used in any runbook
#    4) Connect to Azure Automation Account Function
#    5) Load the Automation Account Variables
#    6) Send an Email Function
#    7) Get AA context, include: AA Name, AA Resource Group, and Runbook Name
#    8) Get all Titan-Atlas Resource Groups
#    9) Get all Atlas Resource Types within a Subscription or Resource Group
#   10) Communicate an error that can't be handled gracefully
#############################################################################################################
#    Example to source Atlas-CommonCode from another runbook
#       Write-Output "Linking to Atlas-CommonCode Runbook..."
#       . ./Atlas-CommonCode.ps1
#
#############################################################################################################

#############################################################################################################
# 1) Define enum
#    a) Perform a conditional check to import the type if not already present.
#    b) enum Atlast Log Level
#############################################################################################################
# silently continue through any issues importing types, as we've
# seen cases where despite the if check, it still throws a
# "type already exists" error message
$origErrorActionPreference = $errorActionPreference
$errorActionPreference = "SilentlyContinue"

if (-not ([System.Management.Automation.PSTypeName]'LogLevel').Type) {
    Add-Type -TypeDefinition @"
    public enum LogLevel
    {
        TRACE,
        DEBUG,
        INFO,
        WARN,
        ERROR,
        FATAL
    }
"@
}


#############################################################################################################
#    c) enum Atlas Resources
#############################################################################################################
if (-not ([System.Management.Automation.PSTypeName]'AtlasResourceType').Type) {
    Add-Type -TypeDefinition @"
    public enum AtlasResourceType
    {
        FunctionApp,
        StorageAccount,
        KeyVault,
        ServiceBus
    }
"@
}

if (-not ([System.Management.Automation.PSTypeName]'AtlasIdentityInfo').Type) {
    Add-Type -TypeDefinition @"
    public enum AtlasIdentityInfo
    {
        Group,
        ServiceAccount,
        ServicePrincipal,
        UserAccount
    }
"@
}
$errorActionPreference = $origErrorActionPreference


#############################################################################################################
# 2) Function to provide standard output formats
#    https://docs.microsoft.com/en-us/azure/automation/automation-runbook-output-and-messages
#############################################################################################################
function Write-AtlasOutput {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $Message,


        [Parameter(Mandatory = $false)]
        [LogLevel] $LogLevel = [LogLevel]::INFO
    )


    $Output = "$LogLevel`: $Message"


    # Verbose message logging needs to be enabled on the runbook to capture Write-Verbose messages
    if ($LogLevel -eq [LogLevel]::TRACE -or `
            $LogLevel -eq [LogLevel]::DEBUG -or `
            $LogLevel -eq [LogLevel]::INFO) {
        Write-Verbose $Output -Verbose
    }
    elseif ($LogLevel -eq [LogLevel]::WARN) {
        Write-Warning -Message $Output
    }
    elseif ($LogLevel -eq [LogLevel]::ERROR) {
        Write-Error -Message $Output
    }
    else {
        throw $Output
    }
}



#############################################################################################################
# 3) Set up constants that will be used by all Runbooks - these are just samples, add more as needed
#############################################################################################################
$CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas"
$CONST_EXCEPTION_TAG = "AtlasExceptions"
$CONST_PROD_SHARED_SUBSCRIPTION = "CMFG Production"
$CONST_NONPROD_SHARED_SUBSCRIPTION = "CMFG NonProduction"


# duplicated because I know legacy things use the constant defined above, but this tag exists on more than
# just RG resources, and I'd like the constant to reflect that
$CONST_ATLAS_TAG_VALUE_IDENTIFIER = "Titan-Atlas"
$CONST_ATLAS_TAG_NAME_IDENTIFIER = "TemplateVersion"
$CONST_TEAM_TITAN_MAILBOX = "MB-TeamTitan@cunamutual.com"
$CONST_ATLAS_SUPPORT_TAG = "AtlasSupportEmailGroup"

# ------------------------------------------------------------------------------------------------------------------------
# Currently defined resource allowing for automated permission provisioning
# THESE VALUES MATTER, AS THEY ALL MATCH THEIR ASSOCIATED MICROSOFT RESOURCE TYPE ON A -MATCH CHECK
# https://docs.microsoft.com/en-us/azure/templates/
# ------------------------------------------------------------------------------------------------------------------------
$CONST_SERVICE_BUS_ID = "ServiceBus"
$CONST_SERVICE_BUS_PROVIDER = "Microsoft.ServiceBus"

$CONST_STORAGE_ACCOUNT_ID = "StorageAccount"
$CONST_STORAGE_ACCOUNT_PROVIDER = "Microsoft.Storage"

$CONST_ASSIGNED_MSI_ID = "AssignedIdentities"
$CONST_ASSIGNED_IDENTITY_PROVIDER = "Microsoft.ManagedIdentity"

$CONST_KEY_VAULT_ID = "KeyVault"
$CONST_KEY_VAULT_PROVIDER = "Microsoft.KeyVault"

$CONST_COSMOS_ID = "DocumentDB"
$CONST_COSMOS_PROVIDER = "Microsoft.DocumentDB"

$CONST_EVENT_HUB_ID = "EventHub"
$CONST_EVENT_HUB_PROVIDER = "Microsoft.EventHub"

$CONST_EVENT_GRID_ID = "EventGrid"
$CONST_EVENT_GRID_PROVIDER = "Microsoft.EventGrid"

$CONST_SQL_DB_ID = "Sql"
$CONST_SQL_DB_PROVIDER = "Microsoft.Sql"

$CONST_AKS_ID = "ContainerService"
$CONST_AKS_PROVIDER = "Microsoft.ContainerService"

# intentionally no v1 support for AppConfiguration
$CONST_APPCONFIG_PROVIDER = "Microsoft.AppConfiguration"

# v1 list of types
$CONST_DEFINED_RESOURCE_TYPES = @($CONST_SERVICE_BUS_ID, $CONST_STORAGE_ACCOUNT_ID, $CONST_ASSIGNED_MSI_ID, $CONST_KEY_VAULT_ID, `
        $CONST_COSMOS_ID, $CONST_EVENT_HUB_ID, $CONST_EVENT_GRID_ID, $CONST_SQL_DB_ID, $CONST_AKS_ID)

# v2 list of types
$CONST_DEFINED_RESOURCE_PROVIDERS = @($CONST_AKS_PROVIDER, $CONST_ASSIGNED_IDENTITY_PROVIDER, $CONST_COSMOS_PROVIDER, `
        $CONST_EVENT_GRID_PROVIDER, $CONST_SERVICE_BUS_PROVIDER, $CONST_STORAGE_ACCOUNT_PROVIDER, `
        $CONST_KEY_VAULT_PROVIDER, $CONST_SQL_DB_PROVIDER, $CONST_EVENT_HUB_PROVIDER, $CONST_APPCONFIG_PROVIDER)

#############################################################################################################
# 4) Connect via Azure Automation RunAs account
#############################################################################################################
function Azure-Connect {
    param
    (
        [Parameter(Mandatory = $false)] [bool] $RunHybridWorker = $false,
        [Parameter(Mandatory = $false)] [bool] $RunFromContainer = $false,
        [Parameter(Mandatory = $false)] [bool] $ReturnContext = $false
    )

    #############################################################################################################
    # https://docs.microsoft.com/en-us/azure/automation/automation-runbook-execution#working-with-multiple-subscriptions
    #############################################################################################################
    Disable-AzContextAutosave -Scope Process | Out-Null

    If ( $RunHybridWorker -eq $true -or $RunFromContainer -eq $true) {
        # Attempt to connect to hybrid runbook worker
        try {
            $profile = Connect-AzAccount -Identity
        }
        catch {
            $stopProcessing = $true
            $ErrorMessage = "ERROR: Unable to connect using managed identity!"
            Write-AtlasOutput -Message "$ErrorMessage" -LogLevel "ERROR"
            throw $ErrorMessage
        }
        if ($true -eq $RunHybridWorker -and $true -eq $ReturnContext) {
            # KenJordan: When connecting, the subscription context is set to the subscription that the Automation Account is in.
            # However, when running on a hybrid worker, the subscription context was not always the subscription of the AA/hybrid worker.
            # so we determine the proper subscription and set the context after connecting.
            $runbookSub = Get-RunbookCurrentSubscription
            Write-AtlasOutput -Message "Runbook Subscription: $($runbookSub)"
            return Set-AzContext $runbookSub
        }
    }
    else {
        try {
            Write-AtlasOutput -Message "Connecting to Automation Account"
            $spConnection = Get-AutomationConnection -Name "AzureRunAsConnection" -ErrorAction Stop
            Write-AtlasOutput -Message "Logging in to Azure with Automation Account..."

            $profile = Connect-AzAccount `
                -ServicePrincipal `
                -TenantId $spConnection.TenantId `
                -ApplicationId $spConnection.ApplicationId `
                -CertificateThumbprint $spConnection.CertificateThumbprint

            $AASPName = (Get-AzADServicePrincipal -ApplicationId $spConnection.ApplicationID).DisplayName
            Write-AtlasOutput -Message "Connected as Automation Account Connection $AASPName."
            if ($true -eq $ReturnContext) {
                return $profile.Context
            }
        }
        catch {
            if (!$spConnection) {
                $ErrorMessage = "AzureRunAsConnection not found."
                throw $ErrorMessage
            }
            else {
                Write-AtlasOutput -Message "$_.Exception" -LogLevel "ERROR"
                throw $_.Exception
            }
        }
    }
}


#############################################################################################################
# 5) Load the Automation Account Variables
#############################################################################################################
function Load-AAVariables {
    param
    (
        [Parameter(Mandatory = $true)]
        [array] $CurrentJob
    )
    Write-AtlasOutput -Message "Getting All Automation Account Varibles."
    $Vars = Get-AzAutomationVariable -AutomationAccountName $($CurrentJob.AutomationAccountName) `
        -ResourceGroupName $($CurrentJob.ResourceGroupName)


    Write-AtlasOutput -Message "`t Displaying each of the varables found.... "
    foreach ($Var in $Vars) {
        $Temp = "$($Var.name)"
        New-Variable -Name "$($Temp)" -Value $Var.value -Scope Global -Force
        # Display each variable and it's value for reference
        Write-AtlasOutput -Message "`t `t Variable Name: $Temp `t `t Value:  $($Var.value)"
    }
    Write-AtlasOutput -Message " "
}


#############################################################################################################
# 6) Send Email function
#############################################################################################################
function Send-TeamTitanEmailAlert {
    param
    (
        [Parameter(Mandatory = $false)]
        [array] $emailTo = @("TeamTitan@cunamutual.com", "DS-TeamTitanSupport@cunamutual.com"),
        [Parameter(Mandatory = $true)]
        [string] $emailFrom,
        [Parameter(Mandatory = $true)]
        [string] $emailSubject,
        [Parameter(Mandatory = $true)]
        [string] $EmailbodyData,
        [Parameter(Mandatory = $false)]
        [bool] $BodyAsHtml = $false
    )

    $SMTPServer = "smtp.cunamutual.com"
    $kvName = "kv-atlas-ITPortfolio-p"
    $kvId = "TeamTitan-SMTP"
    $emailPassword = (Get-AzKeyVaultSecret -VaultName $kvName.trim() -Name $kvId.trim()).SecretValue
    $emailCredential = New-Object System.Management.Automation.PSCredential ($kvId, $emailPassword)
    $messageBody = $EmailbodyData | Out-String

    if ($BodyAsHtml) {
        Send-MailMessage -SmtpServer $SMTPServer -Credential $emailCredential -UseSsl `
            -Port 587 -From $emailFrom -To $emailTo -Subject $emailSubject -Body $messageBody -BodyAsHtml
    }
    else {
        Send-MailMessage -SmtpServer $SMTPServer -Credential $emailCredential -UseSsl `
            -Port 587 -From $emailFrom -To $emailTo -Subject $emailSubject -Body $messageBody
    }
}



#############################################################################################################
# 7) Get the current runbook execution information
#    Must pass in subscription context
#    $CurrentJob contains:
#       ResourceGroupName, AutomationAccountName, RunbookName
#       JobId, CreationTime, Status, StatusDetails, StartTime, EndTime, Exception, LastModifiedTime,
#       LastStatusModifiedTime, JobParameters, HybridWorker, StartedBy
#############################################################################################################
Function Get-RunbookCurrentContext {

    $AutomationAccountSubscriptions = @("CMFG Production", "CMFG NonProduction", "CMFG-Sandbox")

    foreach ($subscription in $AutomationAccountSubscriptions) {
        Write-AtlasOutput "Searching for current executing job in subscription '$subscription'"
        $Context = Set-AzContext -SubscriptionName $subscription -ErrorAction SilentlyContinue
        $AutomationAccounts = Get-AzAutomationAccount -DefaultProfile $Context -ErrorAction SilentlyContinue
        $CurrentJob = $null
        foreach ($AutomationAccount in $AutomationAccounts) {
            $CurrentJob = Get-AzAutomationJob -ResourceGroupName $AutomationAccount.ResourceGroupName `
                -AutomationAccountName $AutomationAccount.AutomationAccountName `
                -Id $PSPrivateMetadata.JobId.Guid `
                -DefaultProfile $Context `
                -ErrorAction SilentlyContinue
            if (!([string]::IsNullOrEmpty($CurrentJob))) {
                # return early if we've found a match, as there's only one match across all the listed subscriptions
                return $CurrentJob
            }
        }
    }

    if ([string]::IsNullOrEmpty($CurrentJob)) {
        throw "Unable to discover Runbook Context!"
    }
    return $CurrentJob
}

#############################################################################################################
# Get the current runbook execution subscription name
#############################################################################################################
Function Get-RunbookCurrentSubscription {

    $AutomationAccountSubscriptions = @("CMFG Production", "CMFG NonProduction", "CMFG-Sandbox")

    foreach ($subscription in $AutomationAccountSubscriptions) {
        Write-AtlasOutput "Searching for current executing job in subscription '$subscription'"
        $Context = Set-AzContext -SubscriptionName $subscription -ErrorAction SilentlyContinue
        if ($Context -eq $null) {
            # if we have issues setting the subscription to the passed value, continue as the account
            # has no access in the current subscription
            Write-AtlasOutput "Context null for '$subscription'. Continuing..."
            Continue
        }
        $AutomationAccounts = Get-AzAutomationAccount -DefaultProfile $Context -ErrorAction SilentlyContinue
        $CurrentJob = $null
        foreach ($AutomationAccount in $AutomationAccounts) {
            $CurrentJob = Get-AzAutomationJob -ResourceGroupName $AutomationAccount.ResourceGroupName `
                -AutomationAccountName $AutomationAccount.AutomationAccountName `
                -Id $PSPrivateMetadata.JobId.Guid `
                -DefaultProfile $Context `
                -ErrorAction SilentlyContinue
            if ($null -ne $CurrentJob -and !([string]::IsNullOrEmpty($CurrentJob.JobId))) {
                # return early if we've found a match, as there's only one match across all the listed subscriptions
                return $subscription
            }
        }
    }

    if ([string]::IsNullOrEmpty($CurrentJob)) {
        throw "Unable to discover Runbook Subscription!"
    }

    #default to production return if failure to auto-discover
    Write-AtlasOutput -LogLevel "WARN" -Message "Unable to auto-discover RunbookCurrentSubscription. Defaulting to CMFG Production."
    return "CMFG Production"
}

#############################################################################################################
# 8) function to get all Atlas Resource Groups in the passed in subscription
#############################################################################################################
function Get-AtlasResourceGoups {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )


    $AtlasRGs = Get-AzResourceGroup -DefaultProfile $SubContext | `
        Where-Object { $_.Tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER }
    return $AtlasRGs
}



#############################################################################################################
# 9) function to get all Atlas Resource Types
#    Can get all resources types in the subscription or optionally within a resource group
#    Resource Type Examples:
#       Web Sites:           "Microsoft.Web/sites"
#       Web Site Slots:      "Microsoft.web/sites/slots"
#       Functions:           "Microsoft.Web/sites/functions"
#       App Insights:        "Microsoft.Insights/components"
#       Key Vaults:          "Microsoft.KeyVault/vaults"
#       Service Bus:         "Microsoft.ServiceBus/namespaces"
#       Automation Accounts: "Microsoft.Automation/AutomationAccounts"
#############################################################################################################
function Get-AtlasResourcesByType {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext,
        [Parameter(Mandatory = $true)]
        [PSObject] $ResourceType,
        [Parameter(Mandatory = $false)]
        [PSObject] $ResourceGroupName
    )


    if ($ResourceGroupName) {
        $AtlasResources = Get-AzResource -ResourceType $ResourceType `
            -DefaultProfile $SubContext `
            -ResourceGroupName $ResourceGroupName | `
            Where-Object { ($_.Tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER) }
        return $AtlasResources
    }
    else {
        $AtlasResources = Get-AzResource -ResourceType $ResourceType -DefaultProfile $SubContext | `
            Where-Object { $_.Tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER }
        return $AtlasResources
    }
}


#############################################################################################################

# ------------------------------------------------------------------------------------------------------------------------
# 10)Function to communicate an error that is thrown by a smoke test
#    Currently very bare bones wrapper around Send-TeamTitanEmailAlert,
#    but this is in common code so we can expand as we develop out more smoke tests
#    Notification title is the email subject, warning is the string you want to send
#    mailRecip is who's receiving the email
# ------------------------------------------------------------------------------------------------------------------------

function AtlasMonitor-HandleError {
    param (
        [Parameter (Mandatory = $true)] [String] $errorText,
        [Parameter (Mandatory = $false)] [String] $notificationTitle = "Smoke Test Failed",
        [Parameter (Mandatory = $false)] [String] $mailRecip = "DS-TeamTitanSupport@cunamutual.com"
    )
    #assemble some email body and send it
    $dateTime = Get-Date -UFormat "%A %m/%d/%Y %R %Z"

    ##TODO: link or at least build number
    $emailBody = "Encountered the following error at $dateTime .
      $errorText"
    Send-TeamTitanEmailAlert -emailBodyData $emailBody -emailTo $mailRecip -emailFrom "smokeTest@doNotReply.com" -emailSubject $notificationTitle
}

#############################################################################################################
# function to check the status of the executing runbook
#############################################################################################################
Function IsJobTerminalState {
    param(
        [Parameter(mandatory = $true)] [string] $status
    )
    return $status -eq "Completed" -or $status -eq "Failed" -or $status -eq "Stopped" -or $status -eq "Suspended"
}



#############################################################################################################
# function to get the current time stamp
#############################################################################################################
function Get-TimeStamp {
    return "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
}



#############################################################################################################
# runbook version of the Get-MyIp function
#############################################################################################################
Function Get-MyIp-Runbook {
    # had to be customized to run in automation account runbook
    $CONST_KV_SHAREDSVCS_P = if ((Get-AzContext).Subscription.Name -match "Sandbox") { "kv-atlas-sandbox-np" } else { "kv-atlas-SharedSVCs-p" }
    $CONST_KV_SECRET_NAME = "GetClientIP"


    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $getMeMyIpSecret = $(Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $CONST_KV_SECRET_NAME).SecretValue
    $getMeMyIp = [System.Net.NetworkCredential]::new("", $getMeMyIpSecret).Password

    try {
        $myIp = Invoke-RestMethod -Method Get -Uri $getMeMyIp
    }
    catch {
        Write-AtlasOutput -Message "Couldn't determine external ip"
        Throw "Unable to get runtime IP address from Atlas Function!"
    }
    return $myIp
}


#############################################################################################################
# Function to add an Atlas exception tag
#############################################################################################################
Function Add-AtlasExceptionTag-Runbook {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$resourceName,
        [Parameter(Mandatory = $true)][string]$tagValueToAdd,
        [Parameter(Mandatory = $true)][string]$resourceType,
        [Parameter(Mandatory = $true)][PSObject]$Context
    )


    #Get Resource and tags
    $initialResource = Get-AzResource -Name $resourceName -ResourceGroupName $resourceGroup -ResourceType $resourceType -DefaultProfile $Context
    if (!$initialResource) {
        throw "Unable to find resource '$resourceName' in '$resourceGroup'"
    }


    #update appropriate tag
    #The MinimalTlsVersion was mising in the properties when running the Set-AzResource command to add the tag to the SQL server and it triggers
    #the SQL Server TLS 1.2 deny policy created by the Tiger team. So we used the Update-AzTag command to fix the issue.
    if ($initialResource.Tags.AtlasExceptions) {
        #meaning tag already exists
        #check for network value and add if not already there

        if (($initialResource.Tags.AtlasExceptions).Contains("$tagValueToAdd")) {
            Write-AtlasOutput -message "Tag already exists"
        }
        else {
            Write-AtlasOutput -Message "Attempting to add exception to existing AtlasExceptions tag..."
            #need to add tag value to the atlas exceptions tag
            $oldValue = $initialResource.Tags.AtlasExceptions
            $initialResource.Tags["AtlasExceptions"] = "$oldValue,$tagValueToAdd"
            Update-AzTag -ResourceId $initialResource.ResourceId -Tag $initialResource.Tags -Operation Merge -DefaultProfile $context
            Write-AtlasOutput -Message "Exception $tagValueToAdd has been added to existing tag"
        }
    }
    elseif ($null -ne $initialResource.Tags) {
        #tag does not exist add new
        $initialResource.Tags.Add("AtlasExceptions", "$tagValueToAdd")
        Write-AtlasOutput -Message "Attempting tag add..."
        Update-AzTag -ResourceId $initialResource.ResourceId -Tag $initialResource.Tags -Operation Merge -DefaultProfile $context
        Write-AtlasOutput -Message "Exception $tagValueToAdd has been added as a new tag"
    }
    else {
        Write-AtlasOutput -Message "Adding AtlasExceptions as only tag..."
        # if for some reason the resource doesn't have any tags currently (not suspected but possible)
        Update-AzTag -ResourceId $initialResource.ResourceId -Tag @{"AtlasExceptions" = "$tagValueToAdd" } -Operation Merge -DefaultProfile $context
        Write-AtlasOutput -Message "Exception $tagValueToAdd has been added as only tag"
    }
}



#############################################################################################################
# Function to remove Atlas exception tags from a resource
#############################################################################################################


function Remove-AtlasExceptionTag-Runbook {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$resourceName,
        [Parameter(Mandatory = $true)][string]$tagValueToRemove,
        [Parameter(Mandatory = $true)][string]$resourceType,
        [Parameter(Mandatory = $true)][PSObject]$Context
    )

    #Get Resource and tags
    $initialResource = Get-AzResource -Name $resourceName -ResourceGroupName $resourceGroup -ResourceType $resourceType -DefaultProfile $Context

    #update appropriate tag
    if ($initialResource.Tags.AtlasExceptions) {
        #meaning tag exists
        #check for network value and add if not already there
        if (($initialResource.Tags.AtlasExceptions).Contains("$tagValueToRemove")) {
            #Check if tag to remove is only value
            $oldValue = $initialResource.Tags.AtlasExceptions
            if ($oldValue -eq "$tagValueToRemove") {
                #value to remove is only value -> remove tag completely
                $deletedTags = @{'AtlasExceptions' = $tagValueToRemove }
                Update-AzTag -ResourceId $initialResource.ResourceId -Tag $deletedTags -Operation Delete

            }
            else {
                #other values loop through
                $tagArray = ($oldValue).Split(',')
                foreach ($value in $tagArray) {
                    if ($value -eq $tagValueToRemove) {
                        if ($count -eq 0) { $count -= 1 }
                        Write-AtlasOutput -Message "Removing $tagValueToRemove from AltasExceptions"

                    }
                    else {
                        #add value into new tag value
                        if ($count -le 0) {
                            $newTagValue += "$value"
                        }
                        else {
                            $newTagValue += ",$value"
                        }
                        $count += 1
                    }
                }
                #Set new value for atlasExceptions tag
                $replacedTags = @{'AtlasExceptions' = $NewTagValue }
                Update-AzTag -ResourceId $initialResource.ResourceId -Tag $replacedTags -Operation Replace
            }
        }
        else {
            #exception does not exist in tag
            Write-AtlasOutput -Message "AtlasExceptions does not contain $tagValueToRemove"
        }
    }
    else {
        #tag does not exist do not remove anything
        Write-AtlasOutput -Message "Tag does not exist"
    }

}



#############################################################################################################
# returns all allowed source networks that aren't tagged Atlas
#############################################################################################################
function Get-AtlasAllowedNetworkRules {
    # at a (hopefully very near) time, this is expected to be a lookup against a data store (Storage Account Table, etc.)
    # however, we're currently maintaining this hashtable with the currently allowed resources.
    #!!!!!!!! When we do make this a remote lookup, we should cache the results of the lookup for the duration of a given
    # !!!!!!! script execution, as this function is going to be referenced as though it's a local lookup.


    # allowed rules currently can be of type "subnetResourceId" or of type "ipAddress". Private endpoints will be explicitly
    # trusted by all guardrails at the time in which they start to be used.


    # rules can be modified as necessary, with Team Titan owning the code and the final approval.
    $atlasAllowedNetworkRules = @(
        # -----------------------------------------------------------------------------------------------------
        # Corporate PAT Addresses
        # -----------------------------------------------------------------------------------------------------
        @{type = "ipAddress"; value = "208.91.239.10"; name = "Madison_Proxy_PAT1_Address"; },
        @{type = "ipAddress"; value = "208.91.239.11"; name = "Madison_Proxy_PAT2_Address"; },
        @{type = "ipAddress"; value = "208.91.239.30"; name = "Madison_PAT_Address"; },
        @{type = "ipAddress"; value = "208.91.237.161"; name = "Ashburn_Proxy_PAT1_Address"; },
        @{type = "ipAddress"; value = "208.91.237.162"; name = "Ashburn_Proxy_PAT2_Address"; },
        @{type = "ipAddress"; value = "208.91.237.190"; name = "Ashburn_PAT_Address"; },
        @{type = "ipAddress"; value = "8.36.116.204"; name = "CMFG_NetSkope_Address"; },
        @{type = "ipAddress"; value = "40.70.130.19"; name = "AtlasHostedAgent_NonProd_Address"; },
        @{type = "ipAddress"; value = "52.179.197.140"; name = "AtlasHostedAgent_Prod_Address"; },
        # Tiger IaaS firewall rules
        @{type = "ipAddress"; value = "20.80.45.128/28"; name = "pipPrefix-nc1-p01-azFirewall"; },
        @{type = "ipAddress"; value = "20.94.99.16/28"; name = "pipPrefix-ea2-p01-azFirewall"; },

        # -----------------------------------------------------------------------------------------------------
        # IT Portfolio
        # -----------------------------------------------------------------------------------------------------

        # #####################################################################################################
        # SecureCloud AKS Clusters
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/059ed1ab-6824-4344-9a65-a0504248340f/resourceGroups/RG-CMFG-NP1-SecureCloud-AKS/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-SecCloud/subnets/seccloud-private-subnet"; name = "seccloud-private-subnet" },
        @{type = "subnetResourceId"; value = "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourceGroups/RG-CMFG-PR1-SecureCloud-AKS/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-PR1-SecCloud/subnets/seccloud-private-subnet"; name = "seccloud-private-subnet" },

        # #####################################################################################################
        # North Central
        # #####################################################################################################
        # ITPort non-production, north central, gen serv,  10.126.128.0/20
        @{type = "subnetResourceId"; value = "/subscriptions/059ed1ab-6824-4344-9a65-a0504248340f/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/vnet-cmfg-nc1-d01-10.126.128.0-18/subnets/subnet-cmfg-nc1-d01-generalservers"; name = "subnet-cmfg-nc1-d01-generalservers" },
        # ITPort production, north central, gen serv,  10.126.0.0/20
        @{type = "subnetResourceId"; value = "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/vnet-cmfg-nc1-p01-10.126.0.0-18/subnets/subnet-cmfg-nc1-p01-generalservers"; name = "subnet-cmfg-nc1-p01-generalservers" },

        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        # ITPort non-production, east us 2, gen serv,  10.202.192.0/18, name matches subnet name case-wise
        @{type = "subnetResourceId"; value = "/subscriptions/059ed1ab-6824-4344-9a65-a0504248340f/resourceGroups/RG-CMFG-EA2-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-10.202.192.0_18/subnets/Subnet-CMFG-EA2-NP1-CMFG-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-CMFG-GeneralServers" },
        # ITPort production, east us 2, gen serv,  10.201.192.0/18, name matches subnet name case-wise
        @{type = "subnetResourceId"; value = "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourceGroups/RG-CMFG-EA2-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-10.201.192.0_18/subnets/Subnet-CMFG-EA2-P01-GeneralServers"; name = "Subnet-CMFG-EA2-P01-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # Commercial
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/6e72e218-393a-4fad-a5bd-2ee8a73bac0e/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-COMM-10.198.28.0_22/subnets/Subnet-CMFG-NC1-NP1-COMM-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-COMM-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/849cea0c-6a7e-4df6-8e5d-a30e508207e1/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-COMM-10.200.28.0_22/subnets/Subnet-CMFG-NC1-P01-COMM-GeneralServers"; name = "Subnet-CMFG-NC1-P01-COMM-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/6e72e218-393a-4fad-a5bd-2ee8a73bac0e/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-COMM-10.202.28.0_22/subnets/Subnet-CMFG-EA2-NP1-COMM-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-COMM-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/849cea0c-6a7e-4df6-8e5d-a30e508207e1/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-COMM-10.201.28.0_22/subnets/Subnet-CMFG-EA2-P01-COMM-GeneralServers"; name = "Subnet-CMFG-EA2-P01-COMM-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # Corporate Services
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/e2b843bf-e486-4cae-b9cb-6086c6a18ce1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-CORP-10.198.32.0_22/subnets/Subnet-CMFG-NC1-NP1-CORP-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-CORP-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/cb1acd4b-5762-4caa-9d07-2bec71d47ea0/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-CORP-10.200.32.0_22/subnets/Subnet-CMFG-NC1-P01-CORP-GeneralServers"; name = "Subnet-CMFG-NC1-P01-CORP-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        # due to a typo in the Tiger team network deloyment, they have named this one subnet different than all the others.  The standard named subnet is the first one.
        # instead of changing the value, we should support both names and then remove the old one (2nd below) later. Otherwise we have to coordinate Titan deploying that code at the same exact time that we change the subnet name
        @{type = "subnetResourceId"; value = "/subscriptions/e2b843bf-e486-4cae-b9cb-6086c6a18ce1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-CORP-10.202.32.0_22/subnets/Subnet-CMFG-EA2-NP1-CORP-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-CORP-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/e2b843bf-e486-4cae-b9cb-6086c6a18ce1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-CORP-10.202.32.0_22/subnets/Subnet-VNet-CMFG-EA2-NP1-CORP-GeneralServers"; name = "Subnet-VNet-CMFG-EA2-NP1-CORP-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/cb1acd4b-5762-4caa-9d07-2bec71d47ea0/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-CORP-10.201.32.0_22/subnets/Subnet-CMFG-EA2-P01-CORP-GeneralServers"; name = "Subnet-CMFG-EA2-P01-CORP-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # LAH
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/abf04ceb-603f-4f05-b647-c8fa71e92f80/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-LAH-10.198.36.0_22/subnets/Subnet-CMFG-NC1-NP1-LAH-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-LAH-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/a1915233-a9aa-4468-8e24-4c1a7b215b29/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-LAH-10.200.36.0_22/subnets/Subnet-CMFG-NC1-P01-LAH-GeneralServers"; name = "Subnet-CMFG-NC1-P01-LAH-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/abf04ceb-603f-4f05-b647-c8fa71e92f80/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-LAH-10.202.36.0_22/subnets/Subnet-CMFG-EA2-NP1-LAH-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-LAH-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/a1915233-a9aa-4468-8e24-4c1a7b215b29/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-LAH-10.201.36.0_22/subnets/Subnet-CMFG-EA2-P01-LAH-GeneralServers"; name = "Subnet-CMFG-EA2-P01-LAH-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # Lending
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/d6322b2a-4d08-42dc-8c34-7f115bd2a763/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-LEND-10.198.40.0_22/subnets/Subnet-CMFG-NC1-NP1-LEND-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-LEND-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/2f7457aa-1e7b-4aa6-b852-54a4ce1ad476/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-LEND-10.200.40.0_22/subnets/Subnet-CMFG-NC1-P01-LEND-GeneralServers"; name = "Subnet-CMFG-NC1-P01-LEND-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/d6322b2a-4d08-42dc-8c34-7f115bd2a763/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-LEND-10.202.40.0_22/subnets/Subnet-CMFG-EA2-NP1-LEND-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-LEND-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/2f7457aa-1e7b-4aa6-b852-54a4ce1ad476/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-LEND-10.201.40.0_22/subnets/Subnet-CMFG-EA2-P01-LEND-GeneralServers"; name = "Subnet-CMFG-EA2-P01-LEND-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # OmniChannel
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/351f164c-393d-4197-84b4-9755bc288332/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-OMNI-10.198.44.0_22/subnets/Subnet-CMFG-NC1-NP1-OMNI-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-OMNI-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/49bddc9a-04f0-45f8-84ba-2247b0ec49c3/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-OMNI-10.200.44.0_22/subnets/Subnet-CMFG-NC1-P01-OMNI-GeneralServers"; name = "Subnet-CMFG-NC1-P01-OMNI-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/351f164c-393d-4197-84b4-9755bc288332/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-OMNI-10.202.44.0_22/subnets/Subnet-CMFG-EA2-NP1-OMNI-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-OMNI-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/49bddc9a-04f0-45f8-84ba-2247b0ec49c3/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-OMNI-10.201.44.0_22/subnets/Subnet-CMFG-EA2-P01-OMNI-GeneralServers"; name = "Subnet-CMFG-EA2-P01-OMNI-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # PS
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/a3272aac-b0f0-42f4-b4bc-e903b90805e1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-PS-10.202.64.0_20/subnets/Subnet-CMFG-EA2-NP1-PS-DmzServers"; name = "Subnet-CMFG-EA2-NP1-PS-DmzServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/a3272aac-b0f0-42f4-b4bc-e903b90805e1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-PS-10.202.64.0_20/subnets/Subnet-CMFG-EA2-NP1-PS-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-PS-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # Retirement
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/40396942-0764-4c0f-9d51-471681c8f8a2/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-RETIRE-10.198.48.0_22/subnets/Subnet-CMFG-NC1-NP1-RETIRE-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-RETIRE-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/e91f2aff-25a3-470d-9156-e2870d4ddb4d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-RETIRE-10.200.48.0_22/subnets/Subnet-CMFG-NC1-P01-RETIRE-GeneralServers"; name = "Subnet-CMFG-NC1-P01-RETIRE-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/40396942-0764-4c0f-9d51-471681c8f8a2/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-RETIRE-10.202.48.0_22/subnets/Subnet-CMFG-EA2-NP1-RETIRE-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-RETIRE-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/e91f2aff-25a3-470d-9156-e2870d4ddb4d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-RETIRE-10.201.48.0_22/subnets/Subnet-CMFG-EA2-P01-RETIRE-GeneralServers"; name = "Subnet-CMFG-EA2-P01-RETIRE-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # Wealth Management
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/84ddec36-4c9d-4f0c-9687-eff8cea060d6/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-WMGMT-10.198.24.0_22/subnets/Subnet-CMFG-NC1-NP1-WMGMT-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-WMGMT-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/8809d0d7-bf8e-45e7-9ea0-051b3b188103/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-WMGMT-10.200.24.0_22/subnets/Subnet-CMFG-NC1-P01-WMGMT-GeneralServers"; name = "Subnet-CMFG-NC1-P01-WMGMT-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/84ddec36-4c9d-4f0c-9687-eff8cea060d6/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-WMGMT-10.202.24.0_22/subnets/Subnet-CMFG-EA2-NP1-WMGMT-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-WMGMT-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/8809d0d7-bf8e-45e7-9ea0-051b3b188103/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-WMGMT-10.201.24.0_22/subnets/Subnet-CMFG-EA2-P01-WMGMT-GeneralServers"; name = "Subnet-CMFG-EA2-P01-WMGMT-GeneralServers" },

        # -----------------------------------------------------------------------------------------------------
        # DLX
        # -----------------------------------------------------------------------------------------------------
        # #####################################################################################################
        # North Central
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/4d937480-7854-488b-91bd-d93964db9c24/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-DLX-10.198.52.0_22/subnets/Subnet-CMFG-NC1-NP1-DLX-GeneralServers"; name = "Subnet-CMFG-NC1-NP1-DLX-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/e4bd9a8d-0638-4a45-8603-fcb38936082d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-DLX-10.200.52.0_22/subnets/Subnet-CMFG-NC1-P01-DLX-GeneralServers"; name = "Subnet-CMFG-NC1-P01-DLX-GeneralServers" },
        # #####################################################################################################
        # East Us 2
        # #####################################################################################################
        @{type = "subnetResourceId"; value = "/subscriptions/4d937480-7854-488b-91bd-d93964db9c24/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-DLX-10.201.52.0_22/subnets/Subnet-CMFG-EA2-NP1-DLX-GeneralServers"; name = "Subnet-CMFG-EA2-NP1-DLX-GeneralServers" },
        @{type = "subnetResourceId"; value = "/subscriptions/e4bd9a8d-0638-4a45-8603-fcb38936082d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-DLX-10.202.52.0_22/subnets/Subnet-CMFG-EA2-P01-DLX-GeneralServers"; name = "Subnet-CMFG-EA2-P01-DLX-GeneralServers" } # note no comma!
    )

    # return an array composed of objects with a type and a value.
    return $atlasAllowedNetworkRules
}



#############################################################################################################
# returns true/false on whether an input network is in the allowed Atlas range
#############################################################################################################
function Validate-NetworkLocationIsAtlasAllowed {
    param(
        [Parameter(ParameterSetName = 'subnetResourceId', Mandatory = $true)] [string] $subnetResourceId,
        [Parameter(ParameterSetName = 'ipAddress', Mandatory = $true)] [string] $ipAddress,
        [Parameter(Mandatory = $true)] [PSObject] $context
    )

    $origErrorActionPreference = $errorActionPreference
    $errorActionPreference = "Continue"

    $isValid = $false
    $isDatabricksSubnet = $false

    if ($subnetResourceId -and $ipAddress) {
        throw "Pass only one of 'subnetResourceId' or 'ipAddress' in call."
    }
    elseif ($ipAddress) {
        # check the array of defined values to validate if it contains the input
        $isValid = (Get-AtlasAllowedNetworkRules).value -Contains $ipAddress
    }
    elseif ($subnetResourceId) {
        # check the array of defined values to validate if it contains the input
        $isValid = (Get-AtlasAllowedNetworkRules).value -Contains $subnetResourceId

        try {
            # if the subnet is not in the list of allowed subnets, we'll do a lookup to check if the vNet is tagged Atlas.
            # if it is tagged as Atlas, it'll get a pass.
            if ($isValid -eq $false) {
                # the vNet resource Id is a sub-section of the subnet resource Id
                # the below line splits the passed id on the forward slash delimiter, takes pieces 0 - 8,
                # and rejoins them with a forward slash. This drops all components of the subnetResourceId beyond
                # piece 8, leaving us with a vNet resource Id
                $vnetResourceId = $subnetResourceId.Split('/')[0..8] -Join '/'
                $vNetResource = Get-AzResource -Id $vnetResourceId -DefaultProfile $context
                if ($vnetResource -eq $null) {
                    Write-AtlasOutput -LogLevel WARN -Message "Error occurred while confirming vNet's tags. vNet $vnetResourceId. Exception: $($_.Exception.Message)"
                    # we need to default to true in this case, so we don't inadverdently rip off valid rules because an external Azure endpoint is malfunctioning.
                    # in this case the rule gets the benefit of the doubt.
                    $isValid = $true
                }
                elseif ($vNetResource.Tags.$CONST_ATLAS_TAG_NAME_IDENTIFIER -match $CONST_ATLAS_TAG_VALUE_IDENTIFIER) {
                    $isValid = $true
                }
                else {
                    # If databricks are present in the subnet then this is an allowed exception
                    $isDatabricksSubnet = Check-IsDatabricksSubnet -SubnetId $subnetResourceId

                    if ($isDatabricksSubnet -eq $true) {
                        Write-AtlasOutput -LogLevel INFO -Message "Subnet $subnetResourceId contains databricks and is allowed"
                        $isValid = $true
                    }
                }
            }
        }
        catch {
            Write-AtlasOutput -LogLevel WARN -Message "Error occurred while validating subnet's validity: $($_.Exception.Message)"
            $isValid = $false
        }
    }
    $errorActionPreference = $origErrorActionPreference
    return $isValid
}
#############################################################################################################
# Maintain a list as the source of trust for unquestioned modifications to Atlas resources
#############################################################################################################
function Check-CallerIsTrustedAtlasIdentity {
    param(
        [Parameter(Mandatory = $true)] [string] $callerAppId
    )


    #   SP-AA-InfraMgmt-Az-D   6e5ed314-7154-4254-84b0-e43f1c638615
    #   SP-AA-InfraMgmt-Az-P   aed58b11-d650-4e8f-b740-30704654d758
    #   VAZHYBWRKD01           18b27a8b-06f9-4e9c-b06c-f1108c1452ec
    #   VAZHYBITINFRAP1        bb5ab6f2-95ad-438a-a4bc-fa61c03c6432
    $trustedAppIds = @("6e5ed314-7154-4254-84b0-e43f1c638615", "aed58b11-d650-4e8f-b740-30704654d758", `
            "18b27a8b-06f9-4e9c-b06c-f1108c1452ec", "bb5ab6f2-95ad-438a-a4bc-fa61c03c6432")


    return $trustedAppIds -Contains $callerAppId
}

# ------------------------------------------------------------------------------------------------------------------------
# Function to get the Automation Account information.
#    This is needed to test end to end process all in the same environment, nonprod will call runbooks in nonprod
#    and not cross over to prod.
# ------------------------------------------------------------------------------------------------------------------------
function Get-TargetAutomationAccountConfig {
    param(
        [Parameter(Mandatory = $true)] [string] $AAEnv
    )
    $Result = $null
    switch ($AAEnv) {
        "Sandbox" {
            $Result = @{TargetInfraAA            = "AA-CMFG-D01-InfraMgmt-AZ"; `
                    TargetInfraResourceGroup     = "RG-CMFG-NC1-D01-ITInfrastructure"; `
                    TargetInfraHybridWorker      = "cmfgHybrid"; `
                    TargetInfraSub               = "CMFG NonProduction"; `
                    TargetSelfServeAA            = "AA-CMFG-NP1-Atlas-Self-Serve"; `
                    TargetSelfServeResourceGroup = "RG-CMFG-NC1-D01-ITInfrastructure"; `
                    TargetSelfServeSub           = "CMFG NonProduction"
            }
        }
        "NonProd" {
            $Result = @{TargetInfraAA            = "AA-CMFG-D01-InfraMgmt-AZ"; `
                    TargetInfraResourceGroup     = "RG-CMFG-NC1-D01-ITInfrastructure"; `
                    TargetInfraHybridWorker      = "cmfgHybrid"; `
                    TargetInfraSub               = "CMFG NonProduction"; `
                    TargetSelfServeAA            = "AA-CMFG-NP1-Atlas-Self-Serve"; `
                    TargetSelfServeResourceGroup = "RG-CMFG-NC1-D01-ITInfrastructure"; `
                    TargetSelfServeSub           = "CMFG NonProduction"
            }
        }
        "Prod" {
            $Result = @{TargetInfraAA            = "AA-CMFG-P01-InfraMgmt-AZ"; `
                    TargetInfraResourceGroup     = "RG-CMFG-NC1-P01-ITInfrastructure"; `
                    TargetInfraHybridWorker      = "AzWorkerGrp"; `
                    TargetInfraSub               = "CMFG Production"; `
                    TargetSelfServeAA            = "AA-CMFG-PR1-Atlas-Self-Serve"; `
                    TargetSelfServeResourceGroup = "RG-CMFG-NC1-P01-ITInfrastructure"; `
                    TargetSelfServeSub           = "CMFG Production"
            }
        }
        default { Throw "Error -- Unable to determine Automation Account environment" }
    }

    return $Result
}


# ------------------------------------------------------------------------------------------------------------------------
# Function to get the SubnetID the hybrid worker is running on
#    This is needed so we can add the subetnetId to a PaaS firewall rule to allow connectivity
# ------------------------------------------------------------------------------------------------------------------------
function Get-SourceSubnetIdForHybridWorker {

    $CONST_PROD_HYBRIDWORKERGROUP = "AzWorkerGrp"
    $CONST_PROD_GEN_SERVE_SUBNET_RULE = "Subnet-CMFG-EA2-P01-GeneralServers"

    $CONST_NONPROD_HYBRIDWORKERGROUP = "cmfgHybrid"
    $CONST_NONPROD_GEN_SERVE_SUBNET_RULE = "subnet-cmfg-nc1-d01-generalservers"

    # determine whether I'm on the prod or non-prod hybrid worker and add the necessary subnet
    try {
        $contextInfo = Get-RunbookCurrentContext
        Write-AtlasOutput "ContextInfo.HybridWorker: $($contextInfo.HybridWorker)"
    }
    catch {
        Write-AtlasOutput -LogLevel "WARN" -Message "$($_.Exception.Message)"
        Write-AtlasOutput -LogLevel "WARN" -Message "Unable to discover runbook context. Will default to Production subnet."
    }

    # production
    if ($contextInfo.HybridWorker.Trim() -eq $CONST_PROD_HYBRIDWORKERGROUP ) {
        $sourceSubnetRuleName = $CONST_PROD_GEN_SERVE_SUBNET_RULE
    }
    elseif ($contextInfo.HybridWorker.Trim() -eq $CONST_NONPROD_HYBRIDWORKERGROUP) {
        #non-production
        $sourceSubnetRuleName = $CONST_NONPROD_GEN_SERVE_SUBNET_RULE
    }
    else {
        # default to prod given current infra setup
        $sourceSubnetRuleName = $CONST_PROD_GEN_SERVE_SUBNET_RULE
    }

    Write-AtlasOutput -Message "Determined that source subnet rule is '$sourceSubnetRuleName'"
    return $sourceSubnetRuleName
}


function Get-AtlasPortfolioBySubscription {
    param(
        [Parameter(Mandatory = $true)]
        [string]$subscription
    )

    try {
        # Get the properites of the subscription from the Subscription Correlation Map
        $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $subscription

        # Check if the subscription is in the ITPortfolio.  If it is and we are not running locally check if
        # we are running under Secure Cloud account and set the portfolio name accordinly.
        if ($subscription -eq "CMFG NonProduction" -or $subscription -eq "CMFG Production") {
            if (!$env:IsLocal) {
                $rmAcctId = (Get-AzContext).Account.Id
                if ($rmAcctId.ToString().Contains("MSI@")) {
                    Write-AtlasOutput -LogLevel "INFO" -Message "Running application is MSI. Skipping SecureCloud check..."
                    $PortName = $SubscriptionProperties.portfolioName
                }
                else {
                    $rmAcct = $(Get-AzADServicePrincipal -ApplicationId $rmAcctId).DisplayName
                    Write-AtlasOutput -LogLevel "INFO" -Message "running as rm acct:   $rmAcct"
                    if ($rmAcct -match "SP-RM-SecureCloud-P") {
                        $PortName = "SecureCloud"
                    }
                    else {
                        $PortName = $SubscriptionProperties.portfolioName
                    }
                }
            }
            else {
                $PortName = $SubscriptionProperties.portfolioName
            }
        }
        else {
            $PortName = $SubscriptionProperties.portfolioName
        }
    }
    catch {
        Throw "Input subscription not found in common code subscription map '$subscription'"
    }
    return $PortName
}

#############################################################################################################

# ------------------------------------------------------------------------------------------------------------------------
# Function to call another runbook from the original runbook using target environment discovery
# ------------------------------------------------------------------------------------------------------------------------
Function Invoke-AtlasRunbookToRunbookCall {
    param(
        [Parameter(Mandatory = $true)] [PSObject] $Params,
        [Parameter(Mandatory = $true)] [string] $RunbookName,
        [Parameter(Mandatory = $false)] [bool] $RunOnHybridWorker = $false,
        [Parameter(Mandatory = $false)] [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$CurrentContext = $null
    )

    if ($null -eq $CurrentContext) {
        # Do our best to determine the context of the AA to call - assuming we are in the correct context
        # From a non-hybrid work the following command should work to determine which subscription we're in
        # From a hybrid worker, we would run Get-RunbookCurrentContext defined above
        $AASub = (Get-AzContext).Subscription.Name
    }
    else {
        # Use the context that was passed in if one was
        $AASub = $CurrentContext.Subscription.Name
    }
    Write-AtlasOutput -Message "Runbook Subscription: $($AASub)"

    $subscriptionDetails = Get-SubscriptionProperties -SubscriptionName $AASub
    $AAEnv = $subscriptionDetails.environment

    # Call Switch Function using the $AAEnv to determine AA information
    $AAData = Get-TargetAutomationAccountConfig -AAEnv $AAEnv

    # Set the values based on what was returned
    $AAName = $AAData.TargetInfraAA
    $RGName = $AAData.TargetInfraResourceGroup
    $hybridWorkerGroup = $AAData.TargetInfraHybridWorker
    $TargetAASubContext = Set-AzContext -SubscriptionName $AAData.TargetInfraSub

    $Action = {
        if ($RunOnHybridWorker) {
            Write-AtlasOutput -Message "Invoking target runbook on hybridworker $hybridWorkerGroup"
            $job = Start-AzAutomationRunbook `
                -AutomationAccountName $AAName `
                -Name $RunbookName `
                -ResourceGroupName $RGName `
                -DefaultProfile $TargetAASubContext `
                -RunOn $hybridWorkerGroup `
                -Parameters $Params
        }
        else {
            $job = Start-AzAutomationRunbook `
                -AutomationAccountName $AAName `
                -Name $RunbookName `
                -ResourceGroupName $RGName `
                -DefaultProfile $TargetAASubContext `
                -Parameters $Params
        }

        $pollingSeconds = 5
        $maxTimeout = 10800
        $waitTime = 0
        while ((IsJobTerminalState $job.Status) -eq $false -and $waitTime -lt $maxTimeout) {
            Start-Sleep -Seconds $pollingSeconds
            $waitTime += $pollingSeconds
            $job = $job | Get-AzAutomationJob
            Write-AtlasOutput -Message "    Job Status: $($job.Status)"
        }

        $jobId = $job.JobId
        $jobOutput = (Get-AzAutomationJobOutput -ResourceGroupName $RGName -Id $jobId -AutomationAccountName $AAName)
        $jobOutputRecords = $jobOutput | Get-AzAutomationJobOutputRecord
        $jobErrors = $jobOutputRecords | Where-Object { $_.Type -eq "Error" }
        $jobWarnings = $jobOutputRecords | Where-Object { $_.Type -eq "Warning" }
        # get the full record instead of the summary output
        $jobOutputRecordSummary = $jobOutputRecords.Value.Message | Where-Object { $_ -match "INFO|ERROR|WARN" }

        Write-AtlasOutput -LogLevel "INFO" -Message "Nested job output:"
        # write each line out seprately
        $jobOutputRecordSummary | ForEach-Object { Write-AtlasOutput -LogLevel "INFO" -Message $_ }

        ################################################################
        #reverting to the subscription we started in
        Select-AzSubscription -SubscriptionName $AASub | Out-Null

        # write warnings where appropriate
        foreach ($warning in $jobWarnings) {
            Write-AtlasOutput -LogLevel "WARN" -Message $warning.Value.Message
        }

        # throw an exception if an ERROR message stream is returned in the job output
        if ($null -ne $job.Exception) {
            Throw $job.Exception

        }
        elseif ($job.Status -eq "Failed") {
            Throw "Request to $RunbookName failed."

        }
        elseif (($jobOutputRecordSummary -match "\*\*ERROR") -or ($jobOutputRecordSummary -match "ERROR:")) {
            Throw "Resource permission request did not complete successfully! Please review request inputs and error log above."

        }
        elseif ($jobErrors -ne $null) {
            foreach ($jobError in $jobErrors) {
                Write-AtlasOutput -LogLevel "WARN" -Message $jobError.Value.Message
                Throw "Request to $RunbookName did not complete successfully."
            }
        }
    }

    # wrap the above in a functional delegate for improved resiliency
    Retry-FunctionalDelegate-Runbook -Action $Action
}

# ------------------------------------------------------------------------------------------------------------------------
# Function to determine if a resource group is atlas.
# ------------------------------------------------------------------------------------------------------------------------
function Is-RGAtlas-Runbook {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(mandatory = $true)] [psobject]  $Context
    )
    $RGIsAtlas = $false
    $tags = $(Get-AzResourceGroup -Name $resourceGroup -DefaultProfile $Context).Tags

    # handle cases for 'TemplateVersion' and for 'templateVersion'
    if (($null -ne $tags.$CONST_ATLAS_TAG_NAME_IDENTIFIER) -and ($tags.$CONST_ATLAS_TAG_NAME_IDENTIFIER.Contains($CONST_ATLAS_TAG_VALUE_IDENTIFIER))) {
        $RGIsAtlas = $true
    }#else ignore

    return $RGIsAtlas
}

# This function will retry a delegate passed to it. To call this function you would use the following pattern:
# The delegate can be any block of code, as long as the runtime has source any referenced functions
# Retry({SomeFunction "Some Message to return"})
# Note that the functional delegate must currently be a void as no response is returned.
function Retry-FunctionalDelegate-Runbook {
    param(
        [Parameter(Mandatory = $true)][Action]$Action,
        [Parameter(Mandatory = $false)][int]$MaxAttempts = 2,
        [Parameter(Mandatory = $false)][int]$RetryDelaySeconds = 2
    )

    $attempts = 1
    $currentException = $null

    $ErrorActionPreferenceToRestore = $ErrorActionPreference
    $ErrorActionPreference = "Stop"

    $ExceptionTypesToRetry = @("Microsoft.Azure.Management.Automation.Models.ErrorResponseException")

    # Intended to handle error:

    # First Error: Please ensure you have network connection. Error detail: HTTPSConnectionPool(host='login.microsoftonline.com', port=443):
    # Max retries exceeded with url: /***/oauth2/token (Caused by NewConnectionError('<urllib3.connection.VerifiedHTTPSConnection
    # object at 0x0507D070>: Failed to establish a new connection: [Errno 11001] getaddrinfo failed',))

    # Second Error: ERROR: The running command stopped because the preference variable "ErrorActionPreference" or common parameter is set to
    # Stop: Please ensure you have network connection. Error detail: ('Connection aborted.', OSError("(10054, 'WSAECONNRESET')",))
    $ErrorStringsToRetry = @("Errno 11001", "10054, 'WSAECONNRESET'")

    do {
        try {
            $Action.Invoke();
            break;
        }
        catch [Exception] {
            $currentException = $_

            switch ($_) {
                # Handling typed exceptions. For whatever reason, I could not handle this explicitly
                # using a typed catch as the type catching wouldn't handle the innerexception...
                { $currentException.Exception.InnerException -and `
                        $currentException.Exception.InnerException.GetType().FullName -In $ExceptionTypesToRetry } {
                    Write-Warning "Typed Expection encountered: $($currentException.Exception.InnerException.GetType().FullName). `n Message: $($currentException.Exception.Message)"
                }

                # Handling generic exceptions via the error message thrown. If there are more
                # strings to match, add them to the array and reference by location currently
                # as I don't have a clean way to do a "matchAny" if given an error message and an
                # array of potential strings to match
                { $currentException.Exception.Message.Contains($ErrorStringsToRetry[0]) -or
                    $currentException.Exception.Message.Contains($ErrorStringsToRetry[1]) } {
                    Write-Warning "Expection encountered: $($currentException.Exception.Message)"
                }

                # unhandled exception or error type -- throw
                default {
                    throw $currentException.Exception.Message
                    # break not required as the throw is terminating
                }
            }
        }

        $attempts++
        if ($attempts -le $MaxAttempts) {
            Write-Verbose -Verbose ("Action failed. Waiting " + $RetryDelaySeconds + " seconds before attempt " + $attempts + " of " + $MaxAttempts + ".")
            Start-Sleep -Seconds $RetryDelaySeconds
        }
        else {
            $ErrorActionPreference = $ErrorActionPreferenceToRestore
            throw "Maximum of $MaxAttempts retries reached: $($currentException.Exception.Message)"
        }
    } while ($attempts -le $MaxAttempts)

    # restore global errorActionPreference to original state before departing scope
    $ErrorActionPreference = $ErrorActionPreferenceToRestore
}

########################################################################################################
# Function to get all members in a specific role group
#    Get all users in the specificied role group
#    Get all users in any recursively nested role groups
#    AlreadyChecked array is used to validate we do not check the same group more than once
#       - which will prevent a loop if one group is in another and vise versa.
########################################################################################################
Function Get-RecursiveAzADGroupMembers {
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true)]
        [string] $groupName
    )

    # Get the members of the group
    $resource = "https://graph.microsoft.com"
    $accessToken = (Get-AzAccessToken -ResourceUrl $resource).Token
    $authHeader = @{
        "Authorization" = "Bearer " + $accessToken
    }

    $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"

    $group = Get-AzADGroup -DisplayName $groupName.Trim()
    Write-Verbose "Searching: $($group.displayname)" -Verbose
    # if group name is null then skip calling the API since the url will be malformed due to the group.Id not being found
    if ($null -ne $group) {
        $url = "https://graph.microsoft.com/v1.0/groups/$($group.Id)/transitiveMembers/microsoft.graph.user?`$count=true"


        Write-Verbose -Verbose "Group id is $($group.Id)"
        while ($null -ne $url) {
            $results = Invoke-RestMethod -Uri $url -Headers $authHeader -Method "GET"
            $memberList += $results.value
            $url = $results.'@odata.nextLink'
        }
    }
    if ($memberList.Count -eq 0) { return $memberList } # return an empty list if no members in group

    return $memberList.userPrincipalName # return a list of UPNs if the group has members
}


########################################################################################################
# This function to loop through a list of accounts and validate that each one is an elevated account
#    If all are elevated accounts, True is returned
#    If any account in the list is not elevated, false is returned.
#        - it will also write out the account that is invalid
########################################################################################################
Function Validate-RoleGroupMembers {
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [System.Collections.Generic.List[system.string]] $memberList

    )
    $invalidMemberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"

    foreach ($userUpn in $memberList) {
        if (!$userUpn.ToLower().StartsWith('sa-') `
                -and !($userUpn.ToLower().EndsWith("@cunamutual.onmicrosoft.com")) `
                -and !($userUpn -like "*-lsa@*") `
                -and !($userUpn -like "*-lsa-np@*") `
                -and !($userUpn -like "*dba@*") `
                -and !($userUpn -like "*dba-np@*") `
                -and !($userUpn -like "*-for@*") `
                -and !($userUpn -like "*-srv@*") `
        ) {
            $invalidMemberList.Add($userUpn)
        }
    }
    return $invalidMemberList
}

########################################################################################################
# This function is a wrapper for the recursive lookup and validation.
# Input a role group and get a result object populated for inspection/reporting.
# Must pass in role group for inspection.
########################################################################################################
Function Ensure-OnlyElevatedAccessAccounts {
    Param
    (
        [Parameter(Mandatory = $true)]
        [string] $groupName
    )

    #building an in-memory cache of results to expedite repeated lookups
    if ($global:EnsureOnlyElevatedAccessAccountsResultsCache -and $global:EnsureOnlyElevatedAccessAccountsResultsCache[$groupName] -ne $null) {
        # if defined, return the defined result. Note that we don't have a
        # mechanism to clear cache as it's only valid for the current PS runtime
        # and these guardrails are all short lived processes (minutes, not hours)
        return $global:EnsureOnlyElevatedAccessAccountsResultsCache[$groupName]
    }
    else {
        if ($global:EnsureOnlyElevatedAccessAccountsResultsCache -eq $null) {
            $global:EnsureOnlyElevatedAccessAccountsResultsCache = New-Object 'system.collections.generic.dictionary[string,object]'
        }

        $listOfAllMembers = Get-RecursiveAzADGroupMembers -groupName $groupName
        # If the list is empty do nothing to avoid calling a method on a null valued parameter
        # Otherwise, validate the list contains only elevated accounts
        if ($null -ne $listOfAllMembers) {
            $invalidMemberList = Validate-RoleGroupMembers -memberList $listOfAllMembers
        }

        # If any email-enabled accounts were found, set result to $false
        if ($null -ne $invalidMemberList -and $invalidMemberList.Count -gt 0) {
            $result = $false
        }
        else {
            # No email-enabled accounts were found, so set result to $true
            $result = $true
        }

        $resultObject = @{result = $result; invalidMemberList = $invalidMemberList }

        # add to in-memory cache
        $global:EnsureOnlyElevatedAccessAccountsResultsCache.Add($groupName, $resultObject)

        # return an object instead of dealing with references outside this library
        return $resultObject
    }
}

########################################################################################################
# This function returns the map of resource types and allowed roles for various types of identities. Where
# applicable, these permissions are segregated by environment.
# This is the future source of truth for all allowable permissions management.
########################################################################################################
Function Get-AtlasAllowedResourcePermissionMap {

    # todo -- know and handle cases where "empty" is valid --
    # Initialize permissions collection
    $atlasAllowedPermissionsColl = New-Object System.Collections.ArrayList

    # Initialize permissions object and populate map for Storage Account resource type
    $atlasAllowedPermissionsObj = New-ResourcePermissionsMapObj
    $atlasAllowedPermissionsObj.ResourceType = "Microsoft.Storage"
    $atlasAllowedPermissionsObj.GroupNonProdAllowedPermissions = @("Storage Blob Data Reader", "Storage Blob Data Contributor")
    $atlasAllowedPermissionsObj.GroupNonProdDefaultPermissions = @("Storage Blob Data Contributor")
    $atlasAllowedPermissionsObj.GroupProductionAllowedPermissions = @("Storage Blob Data Reader")
    $atlasAllowedPermissionsObj.GroupProductionDefaultPermissions = @("Storage Blob Data Reader")
    $atlasAllowedPermissionsObj.AppIdAllowedPermissions = @("Storage Blob Data Contributor", "Storage Blob Data Reader")
    $atlasAllowedPermissionsObj.AppIdDefaultPermissions = @("Storage Blob Data Contributor")
    $atlasAllowedPermissionsColl.Add($atlasAllowedPermissionsObj) | Out-Null

    # Initialize permissions object and populate map for Service Bus resource type
    $atlasAllowedPermissionsObj = New-ResourcePermissionsMapObj
    $atlasAllowedPermissionsObj.ResourceType = "Microsoft.ServiceBus"
    $atlasAllowedPermissionsObj.GroupNonProdAllowedPermissions = @("Azure Service Bus Data Owner", "Azure Service Bus Data Receiver", "Azure Service Bus Data Sender")
    $atlasAllowedPermissionsObj.GroupNonProdDefaultPermissions = @("Azure Service Bus Data Owner")
    $atlasAllowedPermissionsObj.GroupProductionAllowedPermissions = @("Azure Service Bus Data Receiver")
    $atlasAllowedPermissionsObj.GroupProductionDefaultPermissions = @("Azure Service Bus Data Receiver")
    $atlasAllowedPermissionsObj.AppIdAllowedPermissions = @("Azure Service Bus Data Owner", "Azure Service Bus Data Receiver", "Azure Service Bus Data Sender")
    $atlasAllowedPermissionsObj.AppIdDefaultPermissions = @("Azure Service Bus Data Owner")
    $atlasAllowedPermissionsColl.Add($atlasAllowedPermissionsObj) | Out-Null

    # Initialize permissions object and populate map for App Cpnfiguration resource type
    $atlasAllowedPermissionsObj = New-ResourcePermissionsMapObj
    $atlasAllowedPermissionsObj.ResourceType = "Microsoft.AppConfiguration/configurationStores"
    $atlasAllowedPermissionsObj.GroupNonProdAllowedPermissions = @("App Configuration Data Owner", "App Configuration Data Reader")
    $atlasAllowedPermissionsObj.GroupNonProdDefaultPermissions = @("App Configuration Data Reader")
    $atlasAllowedPermissionsObj.GroupProductionAllowedPermissions = @("App Configuration Data Reader")
    $atlasAllowedPermissionsObj.GroupProductionDefaultPermissions = @("App Configuration Data Reader")
    $atlasAllowedPermissionsObj.AppIdAllowedPermissions = @("App Configuration Data Owner", "App Configuration Data Reader")
    $atlasAllowedPermissionsObj.AppIdDefaultPermissions = @("App Configuration Data Reader")
    $atlasAllowedPermissionsColl.Add($atlasAllowedPermissionsObj) | Out-Null


    return $atlasAllowedPermissionsColl
}

Function New-ResourcePermissionsMapObj {
    New-Object PSObject -Property @{
        ResourceType                      = $null
        GroupNonProdAllowedPermissions    = $null
        GroupNonProdDefaultPermissions    = $null
        GroupProductionAllowedPermissions = $null
        GroupProductionDefaultPermissions = $null
        AppIdAllowedPermissions           = $null
        AppIdDefaultPermissions           = $null
    }
}

# call from the ApplyResourcePermissions script, validate the inputs against the map above
Function Validate-AtlasPermissionsRequest {
    param(
        [Parameter(Mandatory = $true)]
        [PsObject] $PermissionsJsonObject
    )

    # Extract ResourceID from $PermissionsJsonObject
    $permissionsObject = $PermissionsJsonObject | ConvertFrom-Json
    $ResourceId = $permissionsObject.Resources.ResourceId

    # Get subscription information from resourceid
    $SubscriptionId = $ResourceId.Split("/")[2]
    $Subscription = (Get-AzSubscription -SubscriptionId $SubscriptionId).Name

    # Get the environment from the subscription.  Switch "Sandbox" to Non-Prod since there is only Prod/Non-Prod options
    $subscriptionDetails = Get-SubscriptionProperties -SubscriptionName $Subscription
    $Environment = $subscriptionDetails.environment
    if ($Environment -eq "Sandbox") {
        $Environment = "NonProd"
    }

    # Get the resource type
    $ResourceProvider = $ResourceId.Split("/")[6]

    # Verify the resource type is Atlas
    $ResourceType = Confirm-AtlasResourceType -ResourceType $ResourceProvider

    # Get permissions map
    $atlasAllowedPermissionsMap = Get-AtlasAllowedResourcePermissionMap

    # Get Permission Array
    $PermissionsArray = $permissionsObject.Resources.PermissionsArray


    # Validate permissions passed in against the allowed permissions mapping
    # Note: An Application Identity can be a Service Principal, On-prem Service Account, or a Managed Identity (system-assigned or user-assigned).

    # Initialize return value of function to false
    $isValidPermissionSet = $false

    switch ($ResourceType) {
        "Microsoft.Storage" {

            Try {
                Write-AtlasOutput -LogLevel "INFO" -Message "About to call Process-PermissionArray"

                $isValidPermissionSet = Process-PermissionsArray `
                    -PermissionsMap $atlasAllowedPermissionsMap `
                    -PermissionsArray $PermissionsArray `
                    -ResourceType $ResourceType `
                    -Environment $Environment

                if ($isValidPermissionSet) {
                    Return $true
                }
            }
            Catch {
                Write-AtlasOutput -LogLevel "INFO" -Message "Values $atlasAllowedPermissionsMap  $PermissionsArray $ResourceType $Environment"
                Write-AtlasOutput -LogLevel "WARN" -Message "   **** Error ****  Invalid permissions requested"
                Throw "*** Invalid permissions payload ***"
            }
        }
    }
}
# ------------------------------------------------------------------------------------------------------------------------
# Start Function: Process the permissions array to validate permissions
# ------------------------------------------------------------------------------------------------------------------------
Function Process-PermissionsArray {
    Param (
        [Parameter(mandatory = $true)] [psobject]  $PermissionsMap,
        [Parameter(mandatory = $true)] [psobject]  $PermissionsArray,
        [Parameter(mandatory = $true)] [string]   $ResourceType,
        [Parameter(mandatory = $true)] [string]   $Environment

    )

    Write-AtlasOutput -LogLevel "INFO" -Message "About to enter for-each loop in Process-PermissionsArray"
    foreach ($requestedPerm in $PermissionsArray) {
        # initialize valid permission flag prior to calling validation routine
        $isValidPermission = $false

        Write-AtlasOutput -LogLevel "INFO" -Message "Inside for-each loop in Process-PermissionArray"

        Write-AtlasOutput -LogLevel "INFO" -Message "Context is $Context"
        $IdentityInfo = Find-AtlasIdentityInfo -Context $Context -Identity $requestedPerm.Identity #-ByPassException $true

        Write-AtlasOutput -LogLevel "INFO" -Message "Called IdentityInfo $IdentityInfo.Type"
        # Check if the identity is a group or an app identity and set variable accordingly
        if ($IdentityInfo.Type -eq [AtlasIdentityInfo]::Group) {
            $IdentityType = "Group"
        }
        else {
            $IdentityType = "AppIdentity"
        }
        Write-AtlasOutput -LogLevel "INFO" -Message "About to call isValidPermission"

        # Call Is-ValidPermission function
        $isValidPermission = Is-ValidPermission `
            -PermissionsMap $PermissionsMap `
            -RequestedPermissions $requestedPerm `
            -ResourceType $ResourceType `
            -Environment $Environment `
            -IdentityType $IdentityType

        Write-AtlasOutput -LogLevel "INFO" -Message "isValidPermissions call complete"
        if ($isValidPermission -eq $false) {
            Write-AtlasOutput -LogLevel "WARN" -Message "   **** Error ****  Invalid permissions requested"
            Throw "*** Invalid permissions payload ***"
        }
    }
    # We didn't hit a false condition above which would have thrown an error so return true.
    return $true
}
# ------------------------------------------------------------------------------------------------------------------------
# Start Function: Is_ValidPermission
# ------------------------------------------------------------------------------------------------------------------------

Function Is-ValidPermission {
    Param (
        [Parameter(mandatory = $true)] [psobject]  $PermissionsMap,
        [Parameter(mandatory = $true)] [psobject]  $RequestedPermissions,
        [Parameter(mandatory = $true)] [string]   $ResourceType,
        [Parameter(mandatory = $true)] [string]   $Environment,
        [Parameter(mandatory = $true)] [string]   $IdentityType

    )

    $isValidPermission = $false
    # Iterate through the allowed permissions map until you match by resource type

    Write-AtlasOutput -LogLevel "INFO" -Message "About to start processing Is-ValidPermission"
    foreach ($allowedPermission in $PermissionsMap) {
        # Resource type is found so check if requested permissions match any allowed permissions
        if ($allowedPermission.ResourceType -eq $ResourceType) {
            # Iterate through the requested permissions
            foreach ($permission in $RequestedPermissions.permissions) {
                if ($IdentityType -eq "Group") {
                    if ($Environment -eq "NonProd") {
                        # NonProd Group permissions mapping
                        if ($allowedPermission.GroupNonProdAllowedPermissions -contains $permission) {
                            $isValidPermission = $true
                        }
                    }
                    else {
                        # Prod Group permissions mapping
                        if ($allowedPermission.GroupProductionAllowedPermissions -contains $permission) {
                            $isValidPermission = $true
                        }
                    }
                }
                else {
                    # Application Identity mapping so no need to distinguish between environments
                    if ($allowedPermission.AppIdAllowedPermissions -contains $permission) {
                        $isValidPermission = $true
                    }
                }
            }
            Write-AtlasOutput -LogLevel "INFO" -Message "Completed Is-ValidPermissions function"
            return $isValidPermission
            #break
        }
    }
}


# ------------------------------------------------------------------------------------------------------------------------
# Start Function: Get Resource Id using the resource name
# ------------------------------------------------------------------------------------------------------------------------
Function Get-AtlasResourceObjectByNameOrId {
    Param (
        [Parameter(mandatory = $true)] [psobject]  $Context,
        [Parameter(mandatory = $false)] [string]   $ResourceName,
        [Parameter(mandatory = $false)] [string]   $ResourceType,
        [Parameter(mandatory = $false)] [string]   $ResourceId = [string]::Empty
    )
    #Use the while loop retry logic instead of the Retry-FunctionalDelegate function as the Get-AzResource command expects a return value, but the Retry-FunctionalDelegate function doesn't return an output.
    #The highest retry number was 119 during the testing. so set the max attempts as 200.
    $i = 0
    $maxAttempts = 50
    $waitTime = 10
    $FoundResource = $null
    #create a custom object for tracking the AccountName, Id, and Type
    $AtlasResourceObj = [PSCustomObject]@{
        PSTypeName = 'Atlas.Resource'
        Name       = $null
        ResourceId = $null
        Tags       = $null
    }

    while (!$FoundResource -and $i -lt $maxAttempts) {
        if ($i -lt 1) {
            Write-AtlasOutput -LogLevel "WARN" -Message  "Attempting to get the resource."
        }
        else {
            Write-AtlasOutput -LogLevel "WARN" -Message "Resource are still creating attempt $i." -Verbose
        }

        if ($ResourceId) {
            $FoundResource = Get-AzResource -ResourceId $ResourceId -DefaultProfile $Context -ErrorAction Stop
        }
        elseif ($ResourceId -and $ResourceType) {
            $FoundResource = Get-AzResource -Name $ResourceName -ResourceType $ResourceType -DefaultProfile $Context -ErrorAction Stop
        }
        else {
            $FoundResource = Get-AzResource -Name $ResourceName -DefaultProfile $Context -ErrorAction Stop
        }

        if ($i -lt $maxAttempts -and !$FoundResource) {
            Write-AtlasOutput -LogLevel "WARN" -Message "Attempting to get resource again in $waitTime seconds."
            Start-Sleep -Seconds $waitTime
        }
        $i++
    }

    if ($null -eq $FoundResource) {
        Write-AtlasOutput -LogLevel "INFO" -Message "   **** Error ****  Invalid $ResourceType entered"
        New-AtlasPermissionException -Message "**** Error ****  Invalid $ResourceType entered $ResourceName"
    }

    #it's possible we can get more than one resource back
    #if that happens, let's see if we can parse the correct one by the ResourceType variable
    if ($FoundResource.Count -gt 1) {
        $specificResourceByType = $FoundResource | Where-Object { $_.ResourceType -match $ResourceType }
        if ($specificResourceByType.Count -eq 1) {
            $FoundResource = $specificResourceByType
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "Multiple resources returned for Resource '$ResourceName'. Unable to parse single resource using provided ResourceType"
            New-AtlasPermissionException -Message "**** Error ****  Multiple resources returned for query: $ResourceName"
        }
    }

    If ($ResourceName) {
        Write-AtlasOutput -LogLevel "INFO" -Message "$ResourceName is a valid $ResourceType"
    } #elseif ($ResourceId)

    $AtlasResourceObj.ResourceId = $FoundResource.ResourceId
    $AtlasResourceObj.Name = $FoundResource.Name

    # we've found that sub-resources such as topic, queues, and individual databases do not necessarily inherit the tags of their parents. For our purposes, if the parent resource (service bus namespace, sql server)
    # is tagged then the child is atlas -- so here we're going to figure out if we're a child, and if so, grab our parent's tags and inherit them
    # a length of 9 is a parent, more than 9 and its a child
    $AtlasResourceObj.Tags = $FoundResource.Tags

    # if we have more than 9 parts, we're a child of a parent resource and we want to try to inherit
    $isChild = $($AtlasResourceObj.ResourceId.Split('/').Length -gt 9)
    if ($isChild) {
        $AtlasResourceObj.Tags = Get-ParentResourceTags -ResourceId $AtlasResourceObj.ResourceId -Context $Context
    }

    return $AtlasResourceObj
}
# ------------------------------------------------------------------------------------------------------------------------
# End Function: Get Resource (i.e. Service Bus)
# ------------------------------------------------------------------------------------------------------------------------

# ------------------------------------------------------------------------------------------------------------------------
# Start Function: Get the tags from the parent and inherit for the child
# ------------------------------------------------------------------------------------------------------------------------
Function Get-ParentResourceTags {
    Param (
        [Parameter(mandatory = $true)] [psobject]  $Context,
        [Parameter(mandatory = $false)] [string]   $ResourceId
    )

    try {
        $ParentResourceId = $($AtlasResourceObj.ResourceId.Split('/')[0..8] -Join '/')
        $ParentResource = Get-AzResource -ResourceId $ParentResourceId -DefaultProfile $Context -ErrorAction Stop

        # we only want the parent tags that aren't already present on the child resource
        if ($AtlasResourceObj.Tags) {
            $desiredParentTags = $ParentResource.Tags.keys | Where-Object { $null -eq $AtlasResourceObj.Tags[$_] }
        }
        else {
            $desiredParentTags = $ParentResource.Tags.keys
            # instantiate the key/value pair on the $AtlasResourceObj.Tags
            $AtlasResourceObj.Tags = New-Object 'system.collections.generic.dictionary[string,string]'
        }
        # for each tag we need, add it to the child object
        $desiredParentTags | ForEach-Object {
            Write-AtlasOutput -LogLevel "INFO" -Message " Tags inherited from parent for resource. Key: $($_)  Value: $($ParentResource.Tags.$_)"
            # add the key to the child object with the values of the parent
            $AtlasResourceObj.Tags.Add($_, $ParentResource.Tags[$_])
        }
    }
    catch {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t Error adding parent tags to child resource! $($_.Exception.Message)"
    }

    return $AtlasResourceObj.Tags
}




#############################################################################################################
Function Send-EmailAlert {
    [CmdletBinding()]
    Param
    (
        [Parameter (Mandatory = $false)] [string] $Subscription,
        [Parameter (Mandatory = $false)] [string] $ResourceGroupName,
        [Parameter (Mandatory = $false)] [string] $Resource,
        [Parameter (Mandatory = $false)] [string] $ResourceId,
        [Parameter (Mandatory = $true)]  [string] $Message,
        [Parameter (Mandatory = $false)] [string] $NotificationSource
    )

    # inputs must be Subscription + ResourceGroupName OR ResourceId
    if (([string]::IsNullOrEmpty($Subscription) -or [string]::IsNullOrEmpty($ResourceGroupName)) -and `
            [string]::IsNullOrEmpty($ResourceId) ) {
        # Resource is not required because the issue may be with the RG itself, not necessarily a resource within
        throw "Send-EmailAlert must be called with Subscription and ResourceGroupName or with ResourceId supplied"
    }

    # infer subscription if needed
    if (!$Subscription) {
        $Subscription = $ResourceId.Split('/')[2]
    }

    # infer RG if needed
    if (!$ResourceGroupName) {
        $ResourceGroupName = $ResourceId.Split('/')[4]
    }

    # infer the resource value from the resource Id if not specified
    if (!$Resource -and $ResourceId) {
        $idParts = $ResourceId.Split('/')
        if ($idParts.Length -ge 8) {
            $Resource = $idParts[8..($idParts.Length - 1)] -Join "/"
        }
    }

    Write-AtlasOutput -Message "Getting email list from $ResourceGroupName tag $CONST_ATLAS_SUPPORT_TAG"
    $SubContext = Set-AzContext -SubscriptionName $Subscription

    Write-AtlasOutput -Message "Getting email list from Resource Group tag $CONST_ATLAS_SUPPORT_TAG"

    # From the resource group name, get the value of the AtlasSupportEmailGroup tag
    # Remove any spaces, then split by; into an array
    $rgTags = (Get-AzResourceGroup -Name $ResourceGroupName -ErrorAction Stop).Tags
    if ($rgTags) {
        if ($rgTags.$CONST_ATLAS_SUPPORT_TAG) {
            $supportGroupTags = ($rgTags.$CONST_ATLAS_SUPPORT_TAG -replace '\s', '').Split(";").Split(",")
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "No value found for tag $CONST_ATLAS_SUPPORT_TAG on resource group $ResourceGroupName"
        }
    }
    else {
        throw "No tags were found on Resource Group: $ResourceGroupName"
    }

    if ($supportGroupTags) {
        Write-AtlasOutput -Message "Found email list from tag. Sending email to:"
        foreach ($etag in $supportGroupTags) { Write-AtlasOutput -Message "`t $etag" }
        Write-AtlasOutput -Message "`r"

        #############################################################################################################
        # This will build the email body
        $emailBody = "Atlas Email Alert.  The following is an automated alert. `r `r"
        if ($Resource) {
            $emailBody += "Resource: $Resource`r `r"
        }
        $emailBody += "Resource Group: $ResourceGroupName`r `r"
        $emailBody += "Message: $Message`r `r"
        if ($NotificationSource) {
            $emailBody += "Notification Source: $NotificationSource `r `r"
        }
        $EmailbodyData = $emailBody | Out-String

        # Call Send Email function that is located in CommonCode
        Send-TeamTitanEmailAlert -emailTo $supportGroupTags -emailFrom $CONST_TEAM_TITAN_MAILBOX -emailSubject "Atlas Automated Email Alert" -EmailbodyData $EmailbodyData -BodyAsHtml $false
        Write-AtlasOutput -Message "Email has been sent Completed.... "
    }
    else {
        Write-AtlasOutput -Message "No email address found in Resource Group Tag AtlasSupportEmailGroup " -LogLevel "WARN"
    }
}

# ------------------------------------------------------------------------------------------------------------------------
# Start Function: Check if Identity is valid
# ------------------------------------------------------------------------------------------------------------------------
Function Find-AtlasIdentityInfo {
    Param (
        [Parameter(mandatory = $true)] [psobject]  $Context,
        [Parameter(mandatory = $true)] [string]    $Identity,
        [Parameter(mandatory = $false)] [boolean]  $ByPassException = $false
    )

    #create a custom object for tracking the AccountName, Id, and Type
    $IdentityInfoObj = [PSCustomObject]@{
        PSTypeName  = 'Atlas.IdentityInfo'
        AccountName = $null
        AccountId   = $null
        Type        = $null
    }

    $AzureServicePrincipal = Get-AzADServicePrincipal -DisplayName $Identity -DefaultProfile $Context
    If ($null -ne $AzureServicePrincipal) {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t Service Principal is valid: $($AzureServicePrincipal.DisplayName)"
        $IdentityInfoObj.AccountName = $AzureServicePrincipal.DisplayName
        $IdentityInfoObj.AccountId = $AzureServicePrincipal.id
        $IdentityInfoObj.Type = [AtlasIdentityInfo]::ServicePrincipal
        return $IdentityInfoObj
    }

    $AdGroupName = Get-AzADGroup -DisplayName $Identity -DefaultProfile $Context
    If ($null -ne $AdGroupName) {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t Group Name is valid: $($AdGroupName.DisplayName)"
        $elevatedAccessResult = Ensure-OnlyElevatedAccessAccounts -groupName $AdGroupName.DisplayName
        if ($elevatedAccessResult.result -eq $true) {
            Write-AtlasOutput -Message "`t `t `t Ensure-OnlyElevatedAccessAccounts: All accounts are valid for $($AdGroupName.DisplayName)"
        }
        else {
            Write-AtlasOutput -Message "`t `t `t Warning - Mail enabled accounts exist in $($AdGroupName.DisplayName)" -LogLevel "WARN"
        }
        Write-AtlasOutput -Message "`r"
        $IdentityInfoObj.AccountName = $($AdGroupName.DisplayName)
        $IdentityInfoObj.AccountId = $AdGroupName.id
        $IdentityInfoObj.Type = [AtlasIdentityInfo]::Group
        return $IdentityInfoObj
    }

    $IsSAAcct = $Identity.ToLower().StartsWith('sa-')
    If ($IsSAAcct) {
        If (!$Identity.ToLower().EndsWith('@cmutual.com')) {
            $Identity = "$($Identity)@cmutual.com"
        }
        $SAAcct = Get-AzADUser -UserPrincipalName $Identity -DefaultProfile $Context
        If ($null -ne $SAAcct -and $SAAcct.UserPrincipalName.ToLower().EndsWith('@cmutual.com')) {
            Write-AtlasOutput -LogLevel "INFO" -Message "`t Service Account is valid: $($SAAcct.UserPrincipalName)"
            $IdentityInfoObj.AccountName = $($SAAcct.UserPrincipalName)
            $IdentityInfoObj.AccountId = $SAAcct.id
            $IdentityInfoObj.Type = [AtlasIdentityInfo]::ServiceAccount
            return $IdentityInfoObj
        }
        Else {
            Write-AtlasOutput -LogLevel "INFO" -Message "`t ***** Unknown entry $Identity. Cannot be discovered or does not end with '@cmutual.com'"
            New-AtlasPermissionException -Message "**** ERROR locating $Identity"
        }
    }
    Else {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t ***** Unknown entry $Identity"
        Write-AtlasOutput -LogLevel "INFO" -Message "`t ***** If the identity entered was an individual user account, please try again with a role group."
        if ($ByPassException -ne $true) {
            New-AtlasPermissionException -Message "**** ERROR locating $Identity"
        }
    }

    return $IdentityInfoObj
}
# ------------------------------------------------------------------------------------------------------------------------
# End Function: Check if Identity is valid
# ------------------------------------------------------------------------------------------------------------------------

Function Confirm-AtlasTaggedResource {
    param(
        [Parameter(mandatory = $true)] [PSObject] $AtlasResourceObj
    )

    if ($AtlasResourceObj.Tags.TemplateVersion -notmatch "Titan-Atlas" -and $AtlasResourceObj.Tags.templateVersion -notmatch "Titan-Atlas") {
        New-AtlasPermissionException -Message "Resource $($AtlasResourceObj.ResourceId) does not have a Titan Atlas tag. Processing aborted!"
    }
}

# ------------------------------------------------------------------------------------------------------------------------
# Start Function: Confirm specified resource type exists in defined list of Atlas resources
# ------------------------------------------------------------------------------------------------------------------------
Function Confirm-AtlasResourceType {
    Param (
        [Parameter(mandatory = $true)] [string] $ResourceType
    )
    #strip spaces from input resource types to maintain compatability with published types
    $ResourceType = $ResourceType -Replace ' '

    #CONTAINS IS NOT CASE SENSITIVE
    if (($CONST_DEFINED_RESOURCE_TYPES -notcontains $ResourceType) -and ($CONST_DEFINED_RESOURCE_PROVIDERS -notcontains $ResourceType)) {
        New-AtlasPermissionException -Message "Resource Type '$ResourceType' does match any currently defined Atlas resource.`n"
    }

    Return $ResourceType
}

# ------------------------------------------------------------------------------------------------------------------------
# Start Function: Define an Atlas specific throw which writes to output prior to throwing an exception.
# This ensures any consumer of a Runbook gets a response stream
# ------------------------------------------------------------------------------------------------------------------------
Function New-AtlasPermissionException {
    param(
        [Parameter(mandatory = $true)] [string] $Message
    )
    Write-AtlasOutput -LogLevel WARN -Message "$Message"
    Throw "$Message"
}

#############################################################################################################
# This will locate the Subscription ID, Resource Group Name or Resource Name from the ResourceID Passed in
#
#   Location = 2 for Subscription ID
#   Location = 4 for Resource Group Name
#   Location = 8 for Resource Name
#############################################################################################################
Function Get-InfoFromResourceID {
    [CmdletBinding()]
    Param
    (
        [Parameter (Mandatory = $true)] [string] $ResourceId,
        [Parameter (Mandatory = $true)] [int] $Location
    )

    # How many values are in the resourceID
    $TotalValues = $ResourceId.Split("/")

    # More that the number passed in, we are good.
    if ($TotalValues.count -ge $Location) {
        $Temp = $ResourceId.Split("/")[$Location]
    }
    else {
        throw "Input value was not a valid resourece id"
    }

    # if 2, subscription, validate guid.
    if ($location -eq 2) {
        [regex]$guidRegex = '(?im)^[{(]?[0-9A-F]{8}[-]?(?:[0-9A-F]{4}[-]?){3}[0-9A-F]{12}[)}]?$'
        if ($temp -notmatch $guidRegex) {
            throw "Input value was not a valid resourece id - invalid GUID"
        }
    }

    return $temp
}


#############################################################################################################
# Call the above function to get the Subscription ID from ResourceID
#  Location = 2
#############################################################################################################
Function Get-SubscriptionID {
    [CmdletBinding()]
    Param
    (
        [Parameter (Mandatory = $true)] [string] $ResourceId
    )
    Return (Get-InfoFromResourceID -ResourceId $ResourceId -Location "2")
}


#############################################################################################################
# Call the above function to get the Resource Group Name from ResourceID
#  Location = 4
#############################################################################################################
Function Get-ResourceGroupName {
    [CmdletBinding()]
    Param
    (
        [Parameter (Mandatory = $true)] [string] $ResourceId
    )
    Return (Get-InfoFromResourceID -ResourceId $ResourceId -Location "4")
}


#############################################################################################################
# Call the above function to get the Resource Name from ResourceID
#  Location = 8
#############################################################################################################
Function Get-ResourceName {
    [CmdletBinding()]
    Param
    (
        [Parameter (Mandatory = $true)] [string] $ResourceId
    )
    Return (Get-InfoFromResourceID -ResourceId $ResourceId -Location "8")
}


#############################################################################################################
# Function to get the ResourceProvider and ResourceType from the ResourceID passed in
#############################################################################################################
Function Get-ResourceProviderAndType {
    [CmdletBinding()]
    Param
    (
        [Parameter (Mandatory = $true)] [string] $ResourceId
    )

    $Temp = ($ResourceId -Split "providers/", 0, "simplematch")[1]
    if ($temp) {
        $Result = @{ResProvider = $Temp.Split("/")[0] ; `
                ResType         = $Temp.Split("/")[1]
        }

        Return  $Result
    }
    else {
        throw "Input value was not a valid resourece id - No Provider found"
    }
}

########################################################################################################
# This function returns the map of RM accounts for each Azure subscription.
# This is the future source of truth for all RM account/subscription correlations.
########################################################################################################
Function Get-AtlasRMAccountCorrelationMap {

    # todo Revisit this at some point to handle multiple Azure regions. Consider using Storage account.
    # Initialize permissions collection
    $atlasRMAccountCorrelationColl = New-Object System.Collections.ArrayList

    # Initialize RM Account Correlation object and populate map for CMFG NonProduction Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "CMFG NonProduction"
    $atlasRMAccountCorrelationObj.subscriptionID = "059ed1ab-6824-4344-9a65-a0504248340f"
    $atlasRMAccountCorrelationObj.rmaccount = "SP-RM-ITPortfolio-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "cmfgd01oms"
    $atlasRMAccountCorrelationObj.portfolioName = "ITPortfolio"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpitport"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-ITPortfolio-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-ITPortfolio-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null


    # Initialize RM Account Correlation object and populate map for CMFG Production Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "CMFG Production"
    $atlasRMAccountCorrelationObj.subscriptionID = "94f0eebc-4d31-4d69-bc92-dfc97103744a"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-ITPortfolio-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "cmfgp01oms"
    $atlasRMAccountCorrelationObj.portfolioName = "ITPortfolio"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgpritport"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-ITPortfolio-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-ITPortfolio-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for CMFG-Sandbox Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "CMFG-Sandbox"
    $atlasRMAccountCorrelationObj.subscriptionID = "4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Sandbox-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "sandboxd01oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Sandbox"
    $atlasRMAccountCorrelationObj.environment = "Sandbox"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgsandbox"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-Sandbox-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Sandbox-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Annuties-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Annuities-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "3e50010f-6547-44a4-aaa4-0267601d5c0c"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Annuities-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "annuitiesnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Annuities"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpann"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-Annuities-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Annuities-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Annuties-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Annuities-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "84803c5b-7796-43f8-a1bd-65ec7055f1d4"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Annuities-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "annuitiespr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Annuities"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprann"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-Annuities-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Annuities-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Commercial-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Commercial-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "6e72e218-393a-4fad-a5bd-2ee8a73bac0e"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Commercial-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "Commercialnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Commercial"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpComm"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-Commercial-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Commercial-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Commercial-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Commercial-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "849cea0c-6a7e-4df6-8e5d-a30e508207e1"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Commercial-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "Commercialpr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Commercial"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprComm"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-Commercial-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Commercial-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for CorporateServices-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "CorporateServices-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "e2b843bf-e486-4cae-b9cb-6086c6a18ce1"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Corporate-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "corporatenp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Corporate"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpCorp"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-CorporateServices-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Corporate-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for CorporateServices-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "CorporateServices-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "cb1acd4b-5762-4caa-9d07-2bec71d47ea0"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Corporate-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "corporatepr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Corporate"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprCorp"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-CorporateServices-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Corporate-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for DLX-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "DLX-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "4d937480-7854-488b-91bd-d93964db9c24"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-DLX-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "Dlxnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "DLX"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpdlx"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-DLX-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-DLX-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for DLX-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "DLX-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "e4bd9a8d-0638-4a45-8603-fcb38936082d"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-DLX-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "Dlxpr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "DLX"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprdlx"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-DLX-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-DLX-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Fintec-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "FinTech-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "2457f21f-85e7-4b43-a66b-91e7e6811feb"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-FinTech-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "FinTechNP1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "FinTech"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpFIN"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-FINTECH-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-FinTech-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Fintec-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "FinTech-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "fcbf50f8-f2f5-4722-87e6-8f39d394d4ac"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-FinTech-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "FinTechPR1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "FinTech"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprFIN"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-FINTECH-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-FinTech-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for LAH-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "LAH-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "abf04ceb-603f-4f05-b647-c8fa71e92f80"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-LAH-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "LAHnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "LAH"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpLAH"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-LAH-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-LAH-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for LAH-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "LAH-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "a1915233-a9aa-4468-8e24-4c1a7b215b29"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-LAH-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "LAHpr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "LAH"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprLAH"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-LAH-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-LAH-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Lending-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Lending-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "d6322b2a-4d08-42dc-8c34-7f115bd2a763"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Lending-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "lendingnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Lending"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpLend"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-Lending-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Lending-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Lending-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Lending-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "2f7457aa-1e7b-4aa6-b852-54a4ce1ad476"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Lending-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "lendingpr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Lending"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprLend"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-Lending-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Lending-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for OmniChannel-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "OmniChannel-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "351f164c-393d-4197-84b4-9755bc288332"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-OmniChannel-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "OmniChannelnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "OmniChannel"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpOmni"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-OmniChannel-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-OmniChannel-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for OmniChannel-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "OmniChannel-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "49bddc9a-04f0-45f8-84ba-2247b0ec49c3"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-OmniChannel-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "OmniChannelpr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "OmniChannel"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprOmni"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-OmniChannel-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-OmniChannel-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for PS-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "PS-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "a3272aac-b0f0-42f4-b4bc-e903b90805e1"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-PS-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "PSNP1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "PS"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpps"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-PS-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-PS-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for PS-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "PS-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "d05362ca-df16-4573-b4a1-9e51580048f8"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-PS-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "PSPR1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "PS"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprps"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-PS-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-PS-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Retirement-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Retirement-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "40396942-0764-4c0f-9d51-471681c8f8a2"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Retirement-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "retirementnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Retirement"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpRetire"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-Retirement-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Retirement-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for Retirement-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "Retirement-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "e91f2aff-25a3-470d-9156-e2870d4ddb4d"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Retirement-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "retirementpr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "Retirement"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprRetire"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-Retirement-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-Retirement-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for WMGMT-NonProd Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "WMGMT-NonProd"
    $atlasRMAccountCorrelationObj.subscriptionID = "84ddec36-4c9d-4f0c-9687-eff8cea060d6"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Wmgmt-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "wmgmtnp1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "WMGMT"
    $atlasRMAccountCorrelationObj.environment = "NonProd"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgnpWMGMT"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-NP1-WMGMT-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-WMGMT-np"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null

    # Initialize RM Account Correlation object and populate map for WMGMT-Prod Subscription
    $atlasRMAccountCorrelationObj = New-RMAccountCorrelationMapObj
    $atlasRMAccountCorrelationObj.subscriptionName = "WMGMT-Prod"
    $atlasRMAccountCorrelationObj.subscriptionID = "8809d0d7-bf8e-45e7-9ea0-051b3b188103"
    $atlasRMAccountCorrelationObj.rmAccount = "SP-RM-Wmgmt-P"
    $atlasRMAccountCorrelationObj.omsWorkspace = "wmgmtpr1oms"
    $atlasRMAccountCorrelationObj.portfolioName = "WMGMT"
    $atlasRMAccountCorrelationObj.environment = "Prod"
    $atlasRMAccountCorrelationObj.acrName = "acrcmfgprWMGMT"
    $atlasRMAccountCorrelationObj.acrResourceGroup = "RG-CMFG-EA2-PR1-WMGMT-ACR"
    $atlasRMAccountCorrelationObj.atlaskvName = "kv-atlas-WMGMT-p"
    $atlasRMAccountCorrelationObj.atlaskvResourceGroup = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    $atlasRMAccountCorrelationColl.Add($atlasRMAccountCorrelationObj) | Out-Null


    return $atlasRMAccountCorrelationColl
}

########################################################################################################
# This function creates a custom object for use in the RM Account Subscription Correlation Map.
########################################################################################################
Function New-RMAccountCorrelationMapObj {
    New-Object PSObject -Property @{
        subscriptionName     = $null
        rmAccount            = $null
        subscriptionID       = $null
        omsWorkspace         = $null
        portfolioName        = $null
        environment          = $null
        acrName              = $null
        acrResourceGroup     = $null
        atlaskvName          = $null
        atlaskvResourceGroup = $null
    }
}

########################################################################################################
# This function returns a subscription object with properties created from RM Account Subscription
# Correlation Map. These properties include the following:
#   Subscription Name
#   RM Account
#   OMS Workspace
#   Portfolio Name
#
# To add more properites, update the New-RMAccountCorrelationMapObj and Get-AtlasRMAccountCorrelationMap
# functions.
########################################################################################################

Function Get-SubscriptionProperties {
    param(
        [Parameter(Mandatory = $false)][string] $SubscriptionName,
        [Parameter(Mandatory = $false)][string] $SubscriptionID
    )

    if (!$SubscriptionName -and !$SubscriptionID) {
        Write-AtlasOutput -LogLevel "ERROR" -Message "   **** Error ****  Subscription Name or Subscription ID must be passed"
        Exit 1
    }
    # Get subscription map
    $atlasRMAccountCorrelationMap = Get-AtlasRMAccountCorrelationMap

    $isSubscriptionFound = $false
    $SubscriptionProperties = $null



    foreach ($SubscriptionObj in $atlasRMAccountCorrelationMap) {
        if ($SubscriptionName) {
            if ($SubscriptionObj.subscriptionName -eq $SubscriptionName) {
                $isSubscriptionFound = $true
                $SubscriptionProperties = $SubscriptionObj
            }
        }
        elseif ($SubscriptionID) {
            if ($SubscriptionObj.subscriptionID -eq $SubscriptionID) {
                $isSubscriptionFound = $true
                $SubscriptionProperties = $SubscriptionObj
            }
        }
    }

    if ($isSubscriptionFound -eq $false) {

        Write-AtlasOutput -LogLevel "WARN" -Message "   **** Error ****  Subscription not found in common code subscription map"
        Throw "*** Subscription Not Found in common code subscription map ***"
    }

    Return $SubscriptionProperties
}

############################################################
#FUNCTION TO GET SHORT LOCATION WHEN A LOCATION IS PASSED.
#To support multi region resources
############################################################
function Get-LocationShortName {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $Location,

        [Parameter(Mandatory = $false)]
        [string] $LocationShortNameOverride = ""
    )

    if (![string]::IsNullOrEmpty("$LocationShortNameOverride")) {
        # Allow the location shor code to be overridden.  Useful if a resource was created with
        # the wrong naming convention.  e.g. xxx-EUS-yyyy VS xxx-NCUS-yyyy
        return $LocationShortNameOverride
    }

    switch ($Location) {
        "eastus" {
            $LocationShortName = "-EUS"
        }
        "eastus2" {
            $LocationShortName = ""
        }
        "westus" {
            $LocationShortName = "-WUS"
        }
        "westus2" {
            $LocationShortName = "-WUS2"
        }
        "centralus" {
            $LocationShortName = "-CUS"
        }
        "northcentralus" {
            $LocationShortName = "-NCUS"
        }
        "southcentralus" {
            $LocationShortName = "-SCUS"
        }
        "westcentralus" {
            $LocationShortName = "-WCUS"
        }
        Default {

            Throw { "Please provide a valid Location Name in the US Region " }
        }
    }

    return $LocationShortName

}

############################################################
# This function return known system namespaces on AKS.
############################################################
Function Get-SystemNameSpaces {
    $kubeSystemNameSpaces = @("Dynatrace", "Aqua", "aad-pod-identity", "atlas", "ingress-nginx", "kube-node-lease", "kube-node-lease", "kube-public", "kube-system")
    return $kubeSystemNameSpaces
}

#########################################################################
# Function to get the active system node pool name if more than one found
##########################################################################
Function Get-AKSActiveSystemNodePoolName {
    $KubeSystemNameSpace = (kubectl get pods -n "kube-system" -o json | ConvertFrom-Json)
    foreach ($Pod in $KubeSystemNameSpace.items) {
        if ($Pod.metadata.name -match 'metrics-server-') {
            $ActiveSysPoolName = $Pod.spec.nodeName.split("-")[1]
            break
        }
    }
    return $ActiveSysPoolName
}

#########################################################################
# Function to get Azure resource information from the resource id
#########################################################################
function Get-AzureResourceInfoFromResourceId {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$ResourceId
    )

    $pattern = [regex]::new("\/subscriptions\/(?<subId>[^\/]*?)($|\/resource[g|G]roups\/(?<rgName>[^\/]*?)($|\/providers\/(?<resType>[^\/]*?)\/(?<resType2>[^\/]*?)\/(?<resName>[^\/]*?)($|\/(?<subType>[^\/]*?)\/(?<subName>[^\/]*?)$)))")
    $parse = $pattern.Match($ResourceId)

    $returnValue = @{
        "subscriptionId"    = $parse[0].Groups['subId'].Value
        "resourceGroupName" = $parse[0].Groups['rgName'].Value
        "resourceType"      = $parse[0].Groups['resType'].Value
        "resourceType2"     = $parse[0].Groups['resType2'].Value
        "resourceName"      = $parse[0].Groups['resName'].Value
        "resourceSubType"   = $parse[0].Groups['subType'].Value
        "resourceSubName"   = $parse[0].Groups['subName'].Value
    }
    return($returnValue)
}

#########################################################################
# Function to get runbook job result details
#########################################################################
function Get-JobResultDetails {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [System.Object]$JobResults,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [Microsoft.Azure.Commands.Profile.Models.Core.PSAzureContext]$Context

    )

    if ($jobResults.Status -match "Completed") {
        $jobOutput = Get-AzAutomationJobOutput -AutomationAccountName $jobResults.AutomationAccountName -Id $jobResults.JobId -ResourceGroupName $jobResults.ResourceGroupName -DefaultProfile $Context | Get-AzAutomationJobOutputRecord
        $outputDetail = $jobOutput | Where-Object { $_.Type -eq "Output" }
        $successDetails = $($outputDetail.Value.Values)
        $warningDetail = $jobOutput | Where-Object { $_.Type -eq "Warning" }
        if ($warningDetail) {
            # Warnings were encountered while running the job.  Display them in DevOps
            foreach ( $detail in $warningDetail ) {
                if ( -not [string]::IsNullOrEmpty($detail.Value.Message) ) {
                    Write-Host "##vso[task.logissue type=warning]$($detail.Value.Message)"
                }
                else {
                    Write-Host "##vso[task.logissue type=warning]$($detail.Summary)"
                }
            }
        }
    }
    elseif ( $jobResults.Status -match "Failed" ) {
        $exceptionMessage = (($job.exception).Split("("))
        throw "Resource group deployment failed with error: $($exceptionMessage[0])"
    }
    elseif ($jobResults.Status -match "suspend") {
        throw "Resource group deployment was suspended by Azure automation. Please resubmit to try again."
    }
    elseif ($jobResults.Status -match "stop") {
        throw "Resource group deployment was stopped before completion. Please resubmit to try again."
    }
    elseif ($jobResults.status -match "(new|running|starting|Queued|Resuming)") {
        throw "Resource group deployment is taking longer than expected. Please check in 5 mins to see if the resource group was created."
    }
    else {
        throw "Resource group deployment did not complete successfully. Please review job output for errors."
    }

    $createFound = $successDetails | Select-String  -Pattern 'created. Performing post processing.' -SimpleMatch
    $updateFound = $successDetails | Select-String  -Pattern 'updated successfully' -SimpleMatch

    if ($createFound) {
        $newResourceGroupName = $createFound.Line.Split(' ')[2]
        Write-Host "##vso[task.setvariable variable=newResourceGroupName;]$newResourceGroupName"
        return ("New resource group name is $newResourceGroupName")
    }
    elseif ($updateFound) {
        $newResourceGroupName = $updateFound.Line.Split(' ')[2]
        Write-Host "##vso[task.setvariable variable=newResourceGroupName;]$newResourceGroupName"
        return ("Resource group $newResourceGroupName has been successfully updated")
    }
    else {
        # There should be no way to fall through to this error condition
        throw = "Unexpected error parsing function results. Please open a ticket with the Titan team."
    }
}
#########################################################################
# Function to invoke Secure Cloud Enablement Auth API Service
#########################################################################
function Invoke-SCEAuthService {
    param(
        [Parameter(Mandatory = $false)]
        [string]$Token,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$RunbookId,

        [Parameter(Mandatory = $false)]
        [hashtable]$RunbookParameters,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$TargetId,

        [Parameter(Mandatory = $false)]
        [string]$JobTimeoutValue = 600,

        [Parameter(Mandatory = $false)]
        [string]$JobPollingInterval = 5
    )
    <#
      .SYNOPSIS
      Invoke a runbook using the SCE authorization API and return the result of the job.

      .DESCRIPTION
      Call the SCE authorization API to invoke a runbook according to the provided
      parameters. Job will be monitored to completion with the resulting job returned
      to the caller.

      .PARAMETER Token
      Optional. String containing the bearer token for the identity which the job will
      run under. If this parameter is not provided, the current context will be used
      to derive the token.

      .PARAMETER RunbookId
      Mandatory. String containing the full Azure resource id of the runbook to be
      invoked

      .PARAMETER RunbookParameters
      Optional. Hash table containing the parameters to be passed to the runbook being
      executed. Any parameters required by the runbook need to be included or the job
      will fail; if the runbook does not take any parameters, this parameter mey be
      omitted.

      .Parameter TargetId
      Mandatory. String containing the full Azure resource id of the target resource
      or resource group the runbook will act on. This is the resource for which
      access will be verified.

      .Parameter JobTimeoutValue
      Optional. Length of time, in seconds, the job status will be checked before
      considering it a potential problem and returning to the caller. If no value is
      provided, 600 (5 minutes) will be used.

      .Parameter JobPollingInterval
      Optional. Number of seconds between each status check performed on the
      runbook job when monitoring for completion. If no value is provided, 5 seconds
      will be used.

      .INPUTS
      None. This function does not accept pipeline input.

      .OUTPUTS
      PSCustomObject with two members:
        hashtable                                     apiResult
        Microsoft.Azure.Commands.Automation.Model.Job jobResult
      #>

    $authUrl = "https://gw.developer.cunamutual.com/cmfg/prod-int/secure-cloud-authentication/v1/invokerunbook?client_id=bd9821d84cbdbe986abd0e41739691a6"

    if ([string]::IsNullOrEmpty($Token)) {
        # No token was provided. Get token based on current context
        $resource = "https://securecloudauthapi"
        $tokenContext = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
        $Token = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate( `
                $tokenContext.Account, $tokenContext.Environment, $tokenContext.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, $resource).AccessToken
    }

    # Create auth header
    $authHeader = @{
        "Authorization" = "Bearer " + $Token
    }

    # Construct the API request body
    $jsonBody = @{
        "targetId"  = $TargetId;
        "runbookId" = $RunbookId;
    }

    # Since Auth API service is looking for the parameters name in capitals, we are converting them before invoking the service
    $upperCaseParameters = @{ }
    foreach ($key in $RunbookParameters.Keys) {
        $upperCaseParameters.Add(($key.toUpper()), $RunbookParameters.$key)
    }

    if ($null -ne $upperCaseParameters) {
        $jsonBody.Add("Parameters", $upperCaseParameters)
    }
    $jsonBody = $jsonBody | ConvertTo-Json

    $results = Invoke-WebRequest -Uri $authUrl -Headers $authHeader -Method "POST" -Body $jsonBody -ContentType "application/json" -UseBasicParsing
    if ($results.statusCode -ne 200) {
        $errorMessage = "Resource group deployment via auth api service failed with error: $($Results.RawContent)"
        throw $errorMessage
    }

    # To get here, the API call had to have been successful (i.e. returned a 200)
    Write-Verbose -Verbose "Result StatusCode: $($results.StatusCode)"
    Write-Verbose -Verbose "Result Content: $($results.Content)"
    $jobId = ($results.Content | ConvertFrom-Json).jobId
    Write-Verbose -Verbose "Parsing Resource Id $RunbookId"
    $runbookPath = Get-AzureResourceInfoFromResourceId -ResourceId $RunbookId
    $aaName = $runbookPath.resourceName
    $rgName = $runbookPath.resourceGroupName
    $subId = $runbookPath.subscriptionId
    $runbookContext = Set-AzContext $subId

    $waitTime = 0
    Write-Verbose -Verbose "Getting Automation Job Id $jobId"

    $allAAjobs = Get-AzAutomationJob -ResourceGroupName $rgName -AutomationAccountName $aaName -Id $jobId -DefaultProfile $runbookContext
    $job = $allAAjobs | Where-Object { $_.JobId -eq $jobId }
    Write-Verbose -Verbose "Waiting for job to complete"
    while (($job.status -notin "Completed", "Failed", "Stopped", "Suspended") -and ($waitTime -lt $JobTimeoutValue)) {
        Write-Verbose -Verbose "Current AA Job Status: $($job.status)"
        Start-Sleep -Seconds $JobPollingInterval
        $waitTime += $JobPollingInterval
        $allAAjobs = Get-AzAutomationJob -ResourceGroupName $rgName -AutomationAccountName $aaName -Id $jobId -DefaultProfile $runbookContext
        $job = $allAAjobs | Where-Object { $_.JobId -eq $jobId }
    }
    Write-Verbose -Verbose "Current AA Job Status: $($job.status)"

    return $job
}

function Check-IsDatabricksSubnet {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SubnetId
    )

    try {

        $vnetResourceId = $SubnetId.Split('/')[0..8] -Join '/'
        $vnetSubscriptionId = $subnetId.Split('/')[2]

        Write-Verbose -Verbose "SubscriptionId is $vnetSubscriptionId"
        # Get current context so we can switch context and then switch back when complete
        $CurrentContext = Get-AzContext

        $SourceSubscription = (Get-AzSubscription -SubscriptionId $vnetSubscriptionId).Name
        $TargetSubscription = $CurrentContext.Subscription.Name

        # Validation - Make sure not crossing environments (prod to nonprod or vise versa)
        if ($TargetSubscription -eq $SourceSubscription) {
        Write-Verbose "Both resources are in the same subscription, continuing..." -Verbose
        }
        else {
            # Make sure not crossing prod and nonprod subscriptions
            $TargetSubEnv = (Get-SubscriptionProperties -SubscriptionName $TargetSubscription).environment
            $SourceSubEnv = (Get-SubscriptionProperties -SubscriptionName $SourceSubscription).environment

            if ($TargetSubEnv -eq $SourceSubEnv) {
                Write-Verbose "Both resources are in the same subscription environments ($TargetSubEnv), continuing..." -Verbose
            }
            else {
                # Allow sandbox to nonprod and nonprod to sandbox
                if (($TargetSubEnv -eq "Sandbox" -and $SourceSubEnv -eq "NonProd") -or ($TargetSubEnv -eq "NonProd" -and $SourceSubEnv -eq "Sandbox")) {
                    Write-Verbose "Connection between $TargetSubEnv and $SourceSubEnv allowed, continuing..." -Verbose
                }
                else {
                    # Throw because trying to cross subscription environments (nonprod to prod)
                    throw "Cannot cross subscription environments '$TargetSubscription' and '$SourceSubscription'"
                }
            }
        }

        # Switch context to subscription of subnet that was passed in
        $Context = Set-AzContext -Subscription $vnetSubscriptionId
        Write-AtlasOutput -Loglevel INFO -Message "Switching context to $Context"

        $vnetResourceName = $subnetId.Split('/')[8]
        $resourceGroup = $subnetId.Split('/')[4]
        $subnetName = $subnetId.Split('/')[10]
        $subnet = Get-AzVirtualNetwork -Name $vnetResourceName -ResourceGroupName $resourceGroup -DefaultProfile $Context | Get-AzVirtualNetworkSubnetConfig -Name $subnetName -DefaultProfile $Context
        $delegations = Get-AzDelegation -Subnet $subnet -DefaultProfile $Context

        # Switch context back to the original context before returning
        Set-AzContext -Context $CurrentContext

        if ($delegations.Name -match "databricks") {
            # The subnet contains databricks and databricks are deployed in a dedicated subnet so this is valid
            Return $true
        }
        else {
            Return $false
        }
    } catch {
        Write-AtlasOutput -LogLevel WARN -Message "Error occurred while validating subnet's validity: $($_.Exception.Message)"
        Return $false
    }
}

#############################################################################################################

Write-AtlasOutput -Message "Finished with Atlas-CommonCode. Returning to calling runbook..."
