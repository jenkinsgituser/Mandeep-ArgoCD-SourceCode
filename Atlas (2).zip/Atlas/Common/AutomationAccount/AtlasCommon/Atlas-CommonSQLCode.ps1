
Function Get-SqlAdminAccountConfigurationInfo {
    Param (
        $environment
    )

    if (($environment -eq "Sandbox") -or ($environment -eq "NonProd")) {
        $userName = 'SA-AtlasAzSQLPerm-D@cmutual.com'
        $userKV = 'kv-atlas-sql-np'
        $userKVSecretName = 'SA-AtlasAzSQLPerm-D'
    }
    else {
        $userName = 'SA-AtlasAzSQLPerm-P@cmutual.com'
        $userKV = 'kv-atlas-sql-p'
        $userKVSecretName = 'SA-AtlasAzSQLPerm-P'
    }

    # use this when we switch to using the Service Principal and retire the domain service account
    # if ($Environment -eq "NonProd") {
    #     $userKV = "kv-Atlas-SQL-np"
    #     $userName = "SP-Atlas-SQL-Perm-np"
    #     $userKVSecretName = "SP-Atlas-SQL-Perm-np"
    #     $userAppId = "3d488139-5928-4bc2-a784-83f37f26cc80"
    # }
    # else {
    #     $userKV = "kv-Atlas-SQL-p"
    #     $userName = "SP-Atlas-SQL-Perm-p"
    #     $userKVSecretName = "SP-Atlas-SQL-Perm-p"
    #     $userAppId = "32713397-f032-4584-951e-25c1f94586b2"
    # }

    return @{userName = $userName; userKV = $userKV; userKVSecretName = $userKVSecretName }
    #return @{userName = $userName; userKV = $userKV; userKVSecretName = $userKVSecretName; userAppId = $userAppId }
}

Function Get-SqlAdminAccountConfigurationInfo-HostedAgent {
    Param (
        $environment
    )

    if (($environment -eq "Sandbox")) {
        $userName = 'SA-AtlasAzSQLPerm-D@cmutual.com'
        $userKV = 'kv-atlas-sql-np'
        $userKVSecretName = 'SA-AtlasAzSQLPerm-D'
    }
    else {
        $userName = 'SA-AtlasAzSQLPerm-P@cmutual.com'
        $userKV = 'kv-atlas-sql-p'
        $userKVSecretName = 'SA-AtlasAzSQLPerm-P'
    }

    # use this when we switch to using the Service Principal and retire the domain service account
    # if (($environment -eq "Sandbox")) {
    #     $userKV = "kv-Atlas-SQL-np"
    #     $userName = "SP-Atlas-SQL-Perm-np"
    #     $userKVSecretName = "SP-Atlas-SQL-Perm-np"
    #     $userAppId = "3d488139-5928-4bc2-a784-83f37f26cc80"
    # }
    # else {
    #     $userKV = "kv-Atlas-SQL-p"
    #     $userName = "SP-Atlas-SQL-Perm-p"
    #     $userKVSecretName = "SP-Atlas-SQL-Perm-p"
    #     $userAppId = "32713397-f032-4584-951e-25c1f94586b2"
    # }

    return @{userName = $userName; userKV = $userKV; userKVSecretName = $userKVSecretName }
    #return @{userName = $userName; userKV = $userKV; userKVSecretName = $userKVSecretName; userAppId = $userAppId }
}

Function Set-TemporarySQLFirewallRule {
    Param (
        [string]$sqlServer,
        [PsObject]$subscriptionContext
    )

    $tempErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "Stop"

    $firewallRuleAdded = $false
    ##################################################################################################
    # modify firewall to allow temporary access
    # SQL Server names are globally unique because they map a public DNS record
    $sqlResourceGroup = (Get-AzSqlServer -ServerName $sqlServer -DefaultProfile $subscriptionContext).ResourceGroupName
    Write-AtlasOutput -Message "SQL Resource Group name: $sqlResourceGroup"

    $sqlVnetRules = Get-AzSqlServerVirtualNetworkRule -ResourceGroupName $sqlResourceGroup -ServerName $sqlServer -DefaultProfile $subscriptionContext

    try {
        #TODO: Rather than try/catching this, we could look at the location of the target resource and compare
        # against the location of hybrid worker. This would make it an if/else rather than a try/catch

        # figure out what source compute subnet we're coming from
        $sourceSubnetRuleName = Get-SourceSubnetIdForHybridWorker

        # if the necessary sourceSubnetRuleName not added, add it
        if ($sqlVnetRules.VirtualNetworkRuleName -NotContains $sourceSubnetRuleName) {
            $subnetResourceId = (Get-AtlasAllowedNetworkRules | Where-Object { $_.name -eq $sourceSubnetRuleName }).value

            Write-AtlasOutput -LogLevel "INFO" -Message "Adding hybrid worker subnet '$subnetResourceId' as allowed"
            New-AzSqlServerVirtualNetworkRule -ResourceGroupName $sqlResourceGroup -ServerName $sqlServer `
                -VirtualNetworkRuleName $sourceSubnetRuleName -VirtualNetworkSubnetId $subnetResourceId `
                -DefaultProfile $subscriptionContext
            # onetime rule add...sleep to be safe and we can save all the retry code further down
            Start-Sleep -Seconds 15
        }
        elseif ($sqlVnetRules.VirtualNetworkRuleName -Contains $sourceSubnetRuleName) {
            # handles case we're currently missing where we end up adding an IP rule that we don't need
            Write-AtlasOutput -LogLevel "INFO" -Message "Hybrid worker subnet already exists on target Sql Server. Proceeding to add rules..."
        }
        else {
            throw "Database is not in the same region as the Hybrid worker"
        }
        # explicitely setting return values for this case when vNet rule was added
    }
    catch {
        # can't print the actual exception becuase it include "error:" which will cause the job to fail
        #Write-AtlasOutput -LogLevel "WARN" -Message "$($_.Exception.Message)"
        Write-AtlasOutput -LogLevel "WARN" -Message "Unable to add Hybrid Worker by Service Endpoint. Falling back to IP address!"

        # because the service endpoint failed (cross region most likely, try the IP address)
        try {
            $externalIp = Get-MyIp-Runbook
            $fwRuleName = "AtlasSQLDeploy-$(Get-Date -Format "yyyyMMddHHmmss")"
            Write-AtlasOutput -Message "Add temporary SQL firewall rule:  $($fwRuleName)"

            Write-AtlasOutput -Message "Applying a network exception to bypass the guardrail..."
            Add-AtlasExceptionTag-Runbook -resourceGroup $sqlResourceGroup -resourceName $sqlServer -tagValueToAdd "Network" -resourceType "Microsoft.Sql/servers" -Context $subscriptionContext

            $firewallRuleAdded = $true
            New-AzSqlServerFirewallRule -ResourceGroupName $sqlResourceGroup -ServerName $sqlServer `
                -FirewallRuleName $fwRuleName -StartIpAddress $externalIp `
                -EndIpAddress $externalIp -DefaultProfile $subscriptionContext -ErrorAction Stop | Out-Null
            Write-AtlasOutput -Message "Firewall rule created for $externalIp"

        }
        catch {
            Write-AtlasOutput -LogLevel "ERROR" -Message "Unable to add IP rule!"
            throw $_
        }
    }
    $ErrorActionPreference = $tempErrorActionPreference
    return $firewallRuleAdded
}

Function Get-SubnetAddressRangeForCIDR {
    Param
    (
        [Parameter(Mandatory = $true)][string] $CIDR
    )

    # convert the cidr to ip and maskbits
    [IPAddress]$IP = $CIDR.Split("/")[0]
    [int]$MaskBits = $CIDR.Split("/")[1]

    # Convert the mask to type [IPAddress]:
    $mask = ([Math]::Pow(2, $MaskBits) - 1) * [Math]::Pow(2, (32 - $MaskBits))
    $maskbytes = [BitConverter]::GetBytes([UInt32] $mask)
    $DottedMask = [IPAddress]((3..0 | ForEach-Object { [String] $maskbytes[$_] }) -join '.')

    # bitwise AND them together, and you've got the subnet ID
    $lower = [IPAddress] ( $ip.Address -band $DottedMask.Address )

    # We can do a similar operation for the broadcast address
    # subnet mask bytes need to be inverted and reversed before adding
    $LowerBytes = [BitConverter]::GetBytes([UInt32] $lower.Address)
    [IPAddress]$upper = (0..3 | ForEach-Object { $LowerBytes[$_] + ($maskbytes[(3 - $_)] -bxor 255) }) -join '.'

    # Make an object for use elsewhere
    Return [pscustomobject][ordered]@{
        firstIp = $lower.IPAddressToString
        lastIp  = $upper.IPAddressToString
    }
}


# Check and verify sql server firewall rules
###########################################################
function Ensure-SqlFirewallRules {
    param
    (
        [Parameter(Mandatory = $true)][string] $sqlServerRG,
        [Parameter(Mandatory = $true)][string] $sqlServerName,
        [parameter(Mandatory = $true)][PsObject] $Context
    )

    Write-AtlasOutput -LogLevel "INFO" -Message "--Processing SQL Server: $sqlServerName in Resource Group $sqlServerRG"

    # build object containing standard allowed rules so we can compare to existing rules
    $allowedNetworkRulesObj = [PSCustomObject]@()
    $standardNetworkRules = Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }
    foreach ($standardNetworkRule in $standardNetworkRules) {
        if ($standardNetworkRule.value -notmatch "/") {
            $sqlFwObj = [PSCustomObject]@{
                ResourceGroupName = $sqlServerRG
                ServerName        = $sqlServerName
                StartIpAddress    = $standardNetworkRule.value
                EndIpAddress      = $standardNetworkRule.value
                FirewallRuleName  = $standardNetworkRule.name
            }
            $allowedNetworkRulesObj += $sqlFwObj
        }
        else {
            # the rule was in CIDR format, so we need to convert that
            $ipRange = Get-SubnetAddressRangeForCIDR -CIDR $standardNetworkRule.value
            $sqlFwObj = [PSCustomObject]@{
                ResourceGroupName = $sqlServerRG
                ServerName        = $sqlServerName
                StartIpAddress    = $ipRange.firstIp
                EndIpAddress      = $ipRange.lastIp
                FirewallRuleName  = $standardNetworkRule.name
            }
            $allowedNetworkRulesObj += $sqlFwObj
        }
    }

    # don't rmeove rules unless we KNOW we have our standard rules loaded/populated correctly
    if (($null -eq $allowedNetworkRulesObj) -or ($allowedNetworkRulesObj.Count -le 1)) {
        throw "Atlas standard allowed ip rules not found, exiting now so we don't remove ip rules `
         on azure resources incorrectly and cause application outages. `
         Ip Rules on Atlas resoruces have not been verified!"
        exit
    }

    Write-AtlasOutput -Message "get current azure sql firewall rules" -Verbose
    $sqlServerFirewallRulesObj = Get-AzSqlServerFirewallRule -ResourceGroupName $sqlServerRG -ServerName $sqlServerName -DefaultProfile $Context
    Write-AtlasOutput -Message "found $($sqlServerFirewallRulesObj.Count) current azure sql firewall rules" -Verbose
    # Remove existing rules not in the allowed list
    foreach ($sqlServerFirewallRule in $sqlServerFirewallRulesObj) {
        $foundRule = $false
        foreach ($allowedNetworkRule in $allowedNetworkRulesObj) {
            $diff = Compare-Object -ReferenceObject $sqlServerFirewallRule -DifferenceObject $allowedNetworkRule -Property ResourceGroupName, ServerName, StartIpAddress, EndIpAddress, FirewallRuleName
            if ([string]::IsNullOrEmpty($diff)) {
                $foundRule = $true
                break # leave loop, no reason to keep going
            }
        }
        if (!$foundRule) {
            try {
                Write-AtlasOutput -LogLevel "WARN" -Message "non-standard rule being removed: $($sqlServerFirewallRule.FirewallRuleName)"
                Remove-AzSqlServerFirewallRule -ResourceGroupName $sqlServerRG -ServerName $sqlServerName `
                    -FirewallRuleName $($sqlServerFirewallRule.FirewallRuleName) -DefaultProfile $Context
                Write-AtlasOutput -Message "rule removed"
            }
            catch {
                Write-AtlasOutput -LogLevel "INFO" -Message "Unable to remove firewall rule. Guardrail execution has run in interim."
            }
        }
    }

    # Add missing allowed rules
    # get current existing rules again since they potentially changed via above code
    $sqlServerFirewallRulesObj = Get-AzSqlServerFirewallRule -ResourceGroupName $sqlServerRG -ServerName $sqlServerName -DefaultProfile $Context
    foreach ($allowedNetworkRule in $allowedNetworkRulesObj) {
        $foundRule = $false
        foreach ($sqlServerFirewallRule in $sqlServerFirewallRulesObj) {
            $diff = Compare-Object -ReferenceObject $sqlServerFirewallRule -DifferenceObject $allowedNetworkRule -Property ResourceGroupName, ServerName, StartIpAddress, EndIpAddress, FirewallRuleName
            if ([string]::IsNullOrEmpty($diff)) {
                $foundRule = $true
                break # leave loop, no reason to keep going
            }
        }
        if (!$foundRule) {
            Write-AtlasOutput -Message "add missing standard rule: $($allowedNetworkRule.FirewallRuleName)"
            New-AzSqlServerFirewallRule -ResourceGroupName $sqlServerRG -ServerName $sqlServerName -FirewallRuleName $($allowedNetworkRule.FirewallRuleName) `
                -StartIpAddress $($allowedNetworkRule.StartIpAddress) -EndIpAddress $($allowedNetworkRule.EndIpAddress) -DefaultProfile $Context
            Write-AtlasOutput -Message "rule added"
        }
    }
}

Function Format-MitigateSqlInjection {
    [CmdletBinding()]
    [OutputType([string])]
    Param (
        [string]$query
    )

    try {
        $result = $query -replace ";", "" -replace """", ""
    }
    catch {
        $errorMsg = $('There was an error in Format-MitigateSqlInjection for query: ' + $query)
        Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        Throw $_
    }
    return $result
}


Function Get-AtlasSqlManagementServicePrincipal {
    # get the az context for the service principal, we'll need this for Azure AD queries in this script
    # apparently it is not possible to grant a managed identity api access to azure ad (this script runs via hybrid worker and managed identity)
    Write-AtlasOutput -Message "Connect to azure with service principal for azure AD queries."

    $tenantId = "a00452fd-8469-409e-91a8-bb7a008e2da0"
    if ($Environment -eq "NonProd") {
        $sqlSPVaultName = "kv-Atlas-SQL-np"
        $sqlPermSP = "SP-Atlas-SQL-Perm-np"
        $sqlPermSPAppId = "3d488139-5928-4bc2-a784-83f37f26cc80"
    }
    else {
        $sqlSPVaultName = "kv-Atlas-SQL-p"
        $sqlPermSP = "SP-Atlas-SQL-Perm-p"
        $sqlPermSPAppId = "32713397-f032-4584-951e-25c1f94586b2"
    }

    $AtlasSqlPermPw = (Get-AzKeyVaultSecret -VaultName $sqlSPVaultName -Name $sqlPermSP -DefaultProfile $runbookContext).SecretValue
    $psCred = New-Object System.Management.Automation.PSCredential -ArgumentList ($sqlPermSPAppId, $AtlasSqlPermPw)

    return Connect-AzAccount -ServicePrincipal -Credential $psCred -Tenant $tenantId
}


Function Approve-RequestedGrants {
    [CmdletBinding()]
    [OutputType([bool])]
    Param (
        [array]$allowedGrants,
        [array]$RequestedGrants
    )

    Write-AtlasOutput -Message "AllowedGrants: $($allowedGrants)"
    Write-AtlasOutput -Message "RequestedGrants: $($RequestedGrants)"

    $validGrants = $true;
    try {
        foreach ($requestedGrant in $RequestedGrants) {
            if ($allowedGrants -notcontains $requestedGrant) {
                $validGrants = $false;
            }
        }

    }
    catch {
        Write-AtlasOutput -LogLevel "ERROR" -Message 'There was an error in Approve-RequestedGrants.'
        Throw $_
    }

    Write-AtlasOutput -Message "RequestedGrants allowed: $($validGrants)"
    return $validGrants
}


Function Check-AtlasUserAlreadyExistsInDatabase {
    Param (
        $Username,
        $Connection
    )

    $userExists = $false
    $cmd = New-Object System.Data.SqlClient.SqlCommand
    $query = "select name from sys.database_principals where name = '$Username'"
    $query = Format-MitigateSqlInjection -query $query
    $cmd.CommandText = $query
    $cmd.Connection = $Connection
    $dataReader = $cmd.ExecuteReader()
    if ($dataReader.HasRows) {
        Write-AtlasOutput $("dbUser already exists: " + $Username)
        $userExists = $true
    }
    $dataReader.Close()

    return $userExists
}


Function Create-AtlasDatabaseUser {
    [CmdletBinding()]
    [OutputType([bool])]
    Param (
        $Username,
        $Connection
    )

    try {
        Write-AtlasOutput $("Create dbUser.")

        #check if user already exists in database
        $userExists = Check-AtlasUserAlreadyExistsInDatabase -Username $Username -Connection $Connection

        #if user doesn't exist in database, create it
        if (!$userExists) {
            $cmd = New-Object System.Data.SqlClient.SqlCommand
            $query = "CREATE USER [$Username] FROM EXTERNAL PROVIDER"
            $query = Format-MitigateSqlInjection -query $query
            $cmd.CommandText = $query
            $cmd.Connection = $Connection
            Write-AtlasOutput -Message "$(  'Executing: ' + $query)"
            $x = $cmd.ExecuteNonQuery()
            Write-AtlasOutput $("dbUserCreated: " + $Username)
        }
        else {
            Write-AtlasOutput -Message "Requested database user already exists in database, user not created."
        }

    }
    catch [System.Data.SqlClient.SqlException] {
        Write-AtlasOutput -LogLevel "ERROR" -Message  "sql exception checking if userId exists or creating user:"
        Write-AtlasOutput -LogLevel "ERROR" -Message  $_.Exception.Message
        Throw $_
    }
    catch {
        $errorMsg = $('There was an error in Create-AtlasDatabaseUser for user: ' + $Username)
        Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        Throw $_
    }
    #return "nothing to return"
}

Function Drop-AtlasDatabaseUser {
    [CmdletBinding()]
    [OutputType([bool])]
    Param (
        $Username,
        $Connection
    )

    try {
        Write-AtlasOutput $("Drop dbUser.")
        #check if user already exists in database
        $userExists = Check-AtlasUserAlreadyExistsInDatabase -Username $Username -Connection $Connection

        #if user doesn't exist in database, create it
        if ($userExists) {
            $cmd = New-Object System.Data.SqlClient.SqlCommand
            $query = "DROP USER IF EXISTS [$Username] "
            $query = Format-MitigateSqlInjection -query $query
            $cmd.CommandText = $query
            $cmd.Connection = $Connection
            Write-AtlasOutput -Message "$(  'Executing: ' + $query)"
            $x = $cmd.ExecuteNonQuery()
            Write-AtlasOutput $("dbUserDeleted: " + $Username)
        }
        else {
            Write-AtlasOutput -Message "Requested user does not currently exist in database. No action performed!"
        }

    }
    catch [System.Data.SqlClient.SqlException] {
        Write-AtlasOutput -LogLevel "ERROR" -Message  "sql exception checking if userId exists or creating user:"
        Write-AtlasOutput -LogLevel "ERROR" -Message  $_.Exception.Message
        Throw $_.Exception.Message
    }
    catch {
        $errorMsg = $('There was an error in Create-AtlasDatabaseUser for user: ' + $Username)
        Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        Throw $_.Exception.Message
    }
}

Function Provision-AtlasGroupPermissions {
    [CmdletBinding()]
    [OutputType([bool])]
    Param (
        $Environment,
        $RequestedGrants,
        $Username
    )

    Write-AtlasOutput -Message $("ProvisionGroupPerms.")
    try {
        if (($Environment.ToLower() -eq 'nonprod') -or $Environment.ToLower() -eq 'sandbox' ) {
            $allowedGrants = $CONST_ALLOWED_GRANTS_GROUPS_NONPROD
        }
        elseif ($Environment.ToLower() -eq 'prod') {
            $allowedGrants = $CONST_ALLOWED_GRANTS_GROUPS_PROD
        }
        else {
            $errorMessage = "The environment - $Environment is invalid."
            Write-AtlasOutput -Message $errorMessage
            Throw $errorMessage
        }

        $valid = Approve-RequestedGrants -allowedGrants $allowedGrants -RequestedGrants $RequestedGrants
        if ($valid) {
            foreach ($requestedGrant in $RequestedGrants) {
                $cmd = New-Object System.Data.SqlClient.SqlCommand
                $query = "grant $requestedGrant to [$Username]"
                $query = Format-MitigateSqlInjection -query $query
                $cmd.CommandText = $query
                $cmd.Connection = $connection
                Write-AtlasOutput -Message "$(  'Executing: ' + $query)"
                $execResult = $cmd.ExecuteNonQuery()
            }
        }
        else {
            Write-AtlasOutput -Message 'There was an issue, invalid grants for group.'
            $msg = $('GROUP: ' + $Username + ' REQUESTED GRANTS: ' + $RequestedGrants)
            Write-AtlasOutput -LogLevel "ERROR" -Message $msg
            Throw $_.Exception.Message
        }
    }
    catch {
        Write-AtlasOutput -LogLevel "ERROR" -Message 'There was an error in Provision-AtlasGroupPermissions.'
        Throw $_.Exception.Message
    }
    Write-AtlasOutput $("ProvisionGroupPerms complete.")
}

Function Provision-AtlasDbRoles {
    [CmdletBinding()]
    [OutputType([bool])]
    Param (
        $Environment,
        $RequestedGrants,
        $Username
    )

    Write-AtlasOutput $("ProvisionDBRoles.")
    try {
        $valid = Approve-RequestedGrants -allowedGrants $CONST_ALLOWED_GRANTS_GROUPS_DBROLES_NONPROD -RequestedGrants $RequestedGrants
        if ($valid) {
            foreach ($requestedGrant in $RequestedGrants) {
                $cmd = New-Object System.Data.SqlClient.SqlCommand
                $query = "alter role $requestedGrant add member [$Username];"
                $query = Format-MitigateSqlInjection -query $query
                $cmd.CommandText = $query
                $cmd.Connection = $connection
                Write-AtlasOutput -Message "$(  'Executing: ' + $query)"
                $execResult = $cmd.ExecuteNonQuery()
            }
        }
        else {
            Write-AtlasOutput -LogLevel "ERROR" -Message 'There was an issue, invalid dbRole grants requested.' "Error"
            $msg = $('USER: ' + $Username + ' REQUESTED GRANTS: ' + $RequestedGrants)
            Write-AtlasOutput -LogLevel "ERROR" -Message $msg
        }
    }
    catch {
        Write-AtlasOutput -LogLevel "ERROR" -Message 'There was an error in Provision-AtlasDbRoles.'
        Throw $_
    }
    Write-AtlasOutput $("ProvisionDBRoles complete.")
}

Function Provision-AtlasServiceAccountPermissions {
    [CmdletBinding()]
    [OutputType([bool])]
    Param (
        $RequestedGrants,
        $Username
    )

    Write-AtlasOutput $("ProvisionServiceAccountPerms.")
    try {
        $valid = Approve-RequestedGrants -allowedGrants $CONST_ALLOWED_GRANTS_SERVICE_ACCOUNTS -RequestedGrants $RequestedGrants
        if ($valid) {
            foreach ($requestedGrant in $RequestedGrants) {
                $cmd = New-Object System.Data.SqlClient.SqlCommand
                $query = "grant $requestedGrant to [$Username]"
                $query = Format-MitigateSqlInjection -query $query
                $cmd.CommandText = $query
                $cmd.Connection = $connection
                Write-AtlasOutput -Message "$(  'Executing: ' + $query)"
                $execResult = $cmd.ExecuteNonQuery()
            }
        }
        else {
            Write-AtlasOutput -LogLevel "ERROR" -Message 'There was an issue, invalid grants for service account.'
            $msg = $('Service Account: ' + $Username + ' REQUESTED GRANTS: ' + $RequestedGrants)
            Write-AtlasOutput -LogLevel "ERROR" -Message $msg
            Throw $_
        }
    }
    catch {
        Write-AtlasOutput -LogLevel "ERROR" -Message 'There was an error in Provision-AtlasServiceAccountPermissions.'
        Throw $_
    }
    Write-AtlasOutput $("ProvisionServiceAccountPerms complete.")
}


Function Create-AtlasDatabasePermissions {
    Param (
        $Environment,
        $sqlPermissionsArray,
        $Username,
        $IdentityInfoType,
        $sqlDbRoleArray
    )

    # provision domain group access
    if ($IdentityInfoType -eq [AtlasIdentityInfo]::Group) {
        Provision-AtlasGroupPermissions -Environment $Environment -RequestedGrants $sqlPermissionsArray -Username $Username

        if ($Environment -eq "NonProd") {
            if ($sqlDbRoleArray) {
                Provision-AtlasDbRoles -Environment $Environment -RequestedGrants $sqlDbRoleArray -Username $Username
            }
        }
        else {
            Write-AtlasOutput -Message "Will not provision DbRoles in 'Prod' environment."
        }
    }
    elseif (($IdentityInfoType -eq [AtlasIdentityInfo]::ServiceAccount) -or ($IdentityInfoType -eq [AtlasIdentityInfo]::ServicePrincipal)) {
        #provision service account or service principal access
        Provision-AtlasServiceAccountPermissions -RequestedGrants $sqlPermissionsArray -Username $Username
        if ($sqlDbRoleArray) {
            Write-AtlasOutput -Message "No dbRoles can be assigned to service accounts, service principals or managed identities."
            Write-AtlasOutput -Message "dbRoles requested will not be assigned: $($sqlDbRoleArray)"
        }
    }
    else {
        Write-AtlasOutput -LogLevel "ERROR" -Message 'There was an error in Create-AtlasDatabasePermissions.'
        throw "Unable to process request as Identity type is not group, service account, or service principal. Passed IdentityType is '$($IdentityInfoType)'!"
    }
}


######################################################################################
# Function to create the Schema
######################################################################################
Function Create-SQLSchema {
    [CmdletBinding()]
    [OutputType([bool])]
    PARAM (
        $SchemaName,
        $connection
    )

    Try {
        #check if schema already exists in database
        $SchemaExists = $false
        $cmd = New-Object System.Data.SqlClient.SqlCommand
        $query = "SELECT  schema_name FROM information_schema.schemata WHERE schema_name = '$SchemaName'"
        $query = Format-MitigateSqlInjection -query $query
        $cmd.CommandText = $query
        $cmd.Connection = $connection
        $dataReader = $cmd.ExecuteReader()
        if ($dataReader.HasRows) {
            $SchemaExists = $true
            Write-AtlasOutput -Message "  Schema $SchemaName already exists..."
        }
        else {
            $SchemaExists = $false
        }
        $dataReader.Close()

        #if schema doesn't exist in database, create it
        $schemaCreated = $false
        if (!$SchemaExists) {
            $cmd = New-Object System.Data.SqlClient.SqlCommand
            $query = "CREATE SCHEMA [$SchemaName] AUTHORIZATION [dbo]"
            $query = Format-MitigateSqlInjection -query $query
            $cmd.CommandText = $query
            $cmd.Connection = $connection
            Write-AtlasOutput -Message $("  Executing: " + $query)
            $x = $cmd.ExecuteNonQuery()
            $schemaCreated = $true
        }
    }
    catch [System.Data.SqlClient.SqlException] {
        Write-AtlasOutput -Message "sql exception checking if schema exists or creating schema:"
        Write-AtlasOutput -Message $_.Exception.Message
        exit
    }
    catch {
        Throw $_
        $errorMsg = $('There was an error in Format-CreateSchema for schema: ' + $SchemaName)
        Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        exit
    }
    return $schemaCreated
}


function validate-SqlTemporalTableScript {
    Param(
        [Parameter(mandatory = $true)]
        [string] $sqlScript
    )

    # some of these are redundant, but listing all for explicity
    $sqlBlacklist = @(
        [pscustomobject]@{criteriaName = "CREATE LOGIN"; regEx = "create[\s]+login" }
        [pscustomobject]@{criteriaName = "ALTER LOGIN"; regEx = "alter[\s]+login" }
        [pscustomobject]@{criteriaName = "DROP LOGIN"; regEx = "drop[\s]+login" }
        [pscustomobject]@{criteriaName = "CREATE USER"; regEx = "create[\s]+user" }
        [pscustomobject]@{criteriaName = "ALTER USER"; regEx = "alter[\s]+user" }
        [pscustomobject]@{criteriaName = "DROP USER"; regEx = "drop[\s]+user" }
        [pscustomobject]@{criteriaName = "CREATE DATABASE"; regEx = "create[\s]+database" }
        [pscustomobject]@{criteriaName = "ALTER DATABASE"; regEx = "alter[\s]+database" }
        [pscustomobject]@{criteriaName = "DROP DATABASE"; regEx = "drop[\s]+database" }
        [pscustomobject]@{criteriaName = "CREATE PROCEDURE"; regEx = "create[\s]+procedure" }
        [pscustomobject]@{criteriaName = "ALTER PROCEDURE"; regEx = "alter[\s]+procedure" }
        [pscustomobject]@{criteriaName = "DROP PROCEDURE"; regEx = "drop[\s]+procedure" }
        [pscustomobject]@{criteriaName = "CREATE FUNCTION"; regEx = "create[\s]+function" }
        [pscustomobject]@{criteriaName = "ALTER FUNCTION"; regEx = "alter[\s]+function" }
        [pscustomobject]@{criteriaName = "DROP FUNCTION"; regEx = "drop[\s]+function" }
        [pscustomobject]@{criteriaName = "CREATE ROLE"; regEx = "create[\s]+role" }
        [pscustomobject]@{criteriaName = "ALTER ROLE"; regEx = "alter[\s]+role" }
        [pscustomobject]@{criteriaName = "DROP ROLE"; regEx = "drop[\s]+role" }
        [pscustomobject]@{criteriaName = "CREATE CERTIFICATE"; regEx = "create[\s]+certificate" }
        [pscustomobject]@{criteriaName = "ALTER CERTIFICATE"; regEx = "alter[\s]+certificate" }
        [pscustomobject]@{criteriaName = "DROP CERTIFICATE"; regEx = "drop[\s]+certificate" }
        [pscustomobject]@{criteriaName = "ALTER AUTHERIZATION"; regEx = "alter[\s]+authorization" }
        [pscustomobject]@{criteriaName = "GRANT"; regEx = "grant[\s]+" }
        [pscustomobject]@{criteriaName = "DENY"; regEx = "deny[\s]+" }
        [pscustomobject]@{criteriaName = "REVOKE"; regEx = "revoke[\s]+" }
        [pscustomobject]@{criteriaName = "Kill Process"; regEx = "kill[\s]+[0-9]" }
        [pscustomobject]@{criteriaName = "create schema"; regEx = "create[\s]+schema" }
        [pscustomobject]@{criteriaName = "alter schema"; regEx = "alter[\s]+schema" }
        [pscustomobject]@{criteriaName = "drop schema"; regEx = "drop[\s]+schema" }
        [pscustomobject]@{criteriaName = "backup database"; regEx = "backup[\s]+database" }
        [pscustomobject]@{criteriaName = "restore database"; regEx = "restore[\s]+database" }
        [pscustomobject]@{criteriaName = "DBCC"; regEx = "dbcc[\s]" }
        [pscustomobject]@{criteriaName = "exec as"; regEx = "exec[\s]+as" }
        [pscustomobject]@{criteriaName = "execute as"; regEx = "execute[\s]+as" }
        [pscustomobject]@{criteriaName = "sp_addrolemember"; regEx = "sp_addrolemember" } #covered by next lines, but belt & suspenders
        [pscustomobject]@{criteriaName = "execute system stored proc"; regEx = "^sp_" }
        [pscustomobject]@{criteriaName = "execute system stored proc"; regEx = "[\s]sp_" }
        [pscustomobject]@{criteriaName = "exec statement"; regEx = "exec[\s]" }
    )

    $scriptValid = $false
    foreach ($sqlBlacklistStmt in $sqlBlacklist) {
        $scriptValid = $sqlScript -notmatch $sqlBlacklistStmt.regEx
        if (!$scriptValid) {
            return $scriptValid, $($sqlBlacklistStmt.criteriaName)
        }
    }
    return $scriptValid
}


#############################################################################################################
Write-AtlasOutput -Message "Finished with Atlas-CommonSQLCode. Returning to calling runbook..."
