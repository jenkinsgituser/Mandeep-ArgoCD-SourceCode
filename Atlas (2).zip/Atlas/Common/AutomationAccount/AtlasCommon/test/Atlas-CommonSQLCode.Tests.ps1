
Describe "Atlas-CommonSQLCode Tests" {
  BeforeAll {
    # commonSqlCode relies on certain functions within Atlas-CommonCode, so sourcing that first
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1"
  }



  It "Target Functions Discoverable" {
    (Get-ChildItem function:\).Name | Should -Contain "Create-AtlasDatabaseUser"
    (Get-ChildItem function:\).Name | Should -Contain "Drop-AtlasDatabaseUser"
  }

  It "Get-SqlAdminAccountConfiguration - CMFG Production" {
    $result = Get-SqlAdminAccountConfigurationInfo -Subscription "CMFG Production"
    $result.userName | Should -Be "SA-AtlasAzSQLPerm-P@cmutual.com"
    $result.userKV | Should -Be "kv-atlas-sql-p"
    $result.userKVSecretName | Should -Be "SA-AtlasAzSQLPerm-P"
  }

  It "Get-SqlAdminAccountConfiguration - Lending Production" {
    $result = Get-SqlAdminAccountConfigurationInfo -Subscription "Lending-Prod"
    $result.userName | Should -Be "SA-AtlasAzSQLPerm-P@cmutual.com"
    $result.userKV | Should -Be "kv-atlas-sql-p"
    $result.userKVSecretName | Should -Be "SA-AtlasAzSQLPerm-P"
  }

  It "Format-MitigateSqlInjection - Bad input1" {
    Format-MitigateSqlInjection -query "123;test;"";" | Should -Be "123test"
  }

  It "Format-MitigateSqlInjection - Bad input2" {
    Format-MitigateSqlInjection -query "1;23""" | Should -Be "123"
  }

  It "Format-MitigateSqlInjection - Good Input" {
    Format-MitigateSqlInjection -query "select * from dbo.systables" | Should -Be "select * from dbo.systables"
  }

  It "Approve-RequestedGrants - Good Grants" {
    $allowedGrants = @("test", "one", "two")
    $requestedGrants = @("test", "one")
    Approve-RequestedGrants -allowedGrants $allowedGrants -requestedGrants $requestedGrants | Should -Be $true
  }

  It "Approve-RequestedGrants - Bad Grants" {
    $allowedGrants = @("one", "two")
    $requestedGrants = @("test", "one")
    Approve-RequestedGrants -allowedGrants $allowedGrants -requestedGrants $requestedGrants | Should -Be $false
  }


  # other commands currently untested due to reliance on connection to DB
}