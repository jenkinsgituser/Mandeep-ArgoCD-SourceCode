
Describe "Atlas-CommonCode Tests" {
    BeforeAll {
        $KNOWN_ATLAS_SUBNET = if ($env:KNOWN_ATLAS_SUBNET) { $env:KNOWN_ATLAS_SUBNET } else { "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-RP-Test/subnets/rp-test-private-subnet" }
        $KNOWN_NOT_ATLAS_SUBNET = if ($env:KNOWN_NOT_ATLAS_SUBNET) { $env:KNOWN_NOT_ATLAS_SUBNET } else { "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/test-nonatlas-eastus2/subnets/default" }

        # dot source the target script
        . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
    }


    It "Target Functions Discoverable" {
        (Get-ChildItem function:\).Name | Should -Contain "Get-AtlasAllowedNetworkRules"
        (Get-ChildItem function:\).Name | Should -Contain "Validate-NetworkLocationIsAtlasAllowed"
    }

    It "Constants correctly set" {
        $CONST_ATLAS_RG_TAG_IDENTIFIER | Should -Be "Titan-Atlas"
        $CONST_EXCEPTION_TAG | Should -Be "AtlasExceptions"
        $CONST_PROD_SHARED_SUBSCRIPTION | Should -Be "CMFG Production"
        $CONST_NONPROD_SHARED_SUBSCRIPTION | Should -Be "CMFG NonProduction"
        $CONST_ATLAS_TAG_VALUE_IDENTIFIER | Should -Be "Titan-Atlas"
        $CONST_ATLAS_TAG_NAME_IDENTIFIER | Should -Be "TemplateVersion"
    }

    Context "Enums" {
        It "LogLevel sourced" {
            [LogLevel] | Should -Be $true
        }

        It "AtlasResourceType sourced" {
            [AtlasResourceType] | Should -Be $true
        }

        It "AtlasIdentityInfo sourced" {
            [AtlasIdentityInfo] | Should -Be $true
        }
    }

    Context "Get-ResourceProviderAndType Test" {
        It "Not a valid reource id input" {
            { Get-ResourceProviderAndType -ResourceId "Junk" } | Should -Throw
        }

        It "Resourceid - Subscription Scope" {
            { Get-ResourceProviderAndType -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a" } | Should -Throw
        }

        It "Resourceid - Resource Group Scope" {
            { Get-ResourceProviderAndType -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS" } | Should -Throw
        }

        It "Resourceid - Resource Scope" {
            $ResourceId = "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS/providers/Microsoft.ContainerService/managedClusters/AKS-PR1-SecCloud"
            $env = Get-ResourceProviderAndType -ResourceId $ResourceId
            $env.ResProvider | Should -Be "Microsoft.ContainerService"
            $env.ResType | Should -Be "managedClusters"
        }
    }

    Context "Get-SubscriptionID - Get Subscription GUID Test" {
        It "Not a valid reource id input" {
            { Get-SubscriptionID -ResourceId "Junk" } | Should -Throw
        }

        It "Resourceid - Subscription Scope" {
            Get-SubscriptionID -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a" | Should -Be "94f0eebc-4d31-4d69-bc92-dfc97103744a"
        }

        It "Resourceid - Resource Group Scope" {
            Get-SubscriptionID -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS" | Should -Be "94f0eebc-4d31-4d69-bc92-dfc97103744a"
        }

        It "Resourceid - Resource Scope" {
            Get-SubscriptionID -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS/providers/Microsoft.ContainerService/managedClusters/AKS-PR1-SecCloud" | Should -Be "94f0eebc-4d31-4d69-bc92-dfc97103744a"
        }
    }

    Context "Get-ResourceGroupName - Get Resource Group Name Test" {
        It "Not a valid ResourceID input" {
            { Get-ResourceGroupName -ResourceId "Junk" } | Should -Throw
        }

        It "Fails - Resourceid - Subscription Scope" {
            { Get-ResourceGroupName -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a" } | Should -Throw
        }

        It "Resourceid - Resource Group Scope" {
            Get-ResourceGroupName -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS" | Should -Be "RG-CMFG-PR1-SecureCloud-AKS"
        }

        It "Resourceid - Resource Scope" {
            Get-ResourceGroupName -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS/providers/Microsoft.ContainerService/managedClusters/AKS-PR1-SecCloud" | Should -Be "RG-CMFG-PR1-SecureCloud-AKS"
        }
    }

    Context "Get-ResourceName - Get Resource Name Test" {
        It "Not a valid ResourceID input" {
            { Get-ResourceName -ResourceId "Junk" } | Should -Throw
        }

        It "Fails - Resourceid - Subscription Scope" {
            { Get-ResourceName -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a" } | Should -Throw
        }

        It "Fails - Resourceid - Resource Group Scope" {
            { Get-ResourceName -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS" } | Should -Throw
        }

        It "Resourceid - Resource Scope" {
            Get-ResourceName -ResourceId "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourcegroups/RG-CMFG-PR1-SecureCloud-AKS/providers/Microsoft.ContainerService/managedClusters/AKS-PR1-SecCloud" | Should -Be "AKS-PR1-SecCloud"
        }
    }
    Context "Send-EmailAlert Tests" {

        # bad input -- missing valid parameter set
        It "Fails on Incorrect Parameters Set - 1" {
            { Send-EmailAlert -Subscription "1234" -Resource "1234" -Message "Testing 123" } | Should -Throw "Send-EmailAlert must be called with Subscription and ResourceGroupName or with ResourceId supplied"
        }

        It "Fails on Incorrect Parameter Set - 2" {
            { Send-EmailAlert -Subscription "1234" -Message "Testing 123" } | Should -Throw "Send-EmailAlert must be called with Subscription and ResourceGroupName or with ResourceId supplied"
        }

        It "Fails on Incorrect Parameter Set- 3" {
            { Send-EmailAlert -ResourceGroupName "1234" -Resource "Test123" -Message "Testing 123" } | Should -Throw "Send-EmailAlert must be called with Subscription and ResourceGroupName or with ResourceId supplied"
        }

        # resource group does not exist
        It "Resource Group does not Exist" {
            Mock Get-AzResourceGroup { return $null }
            Mock Send-TeamTitanEmailAlert { return $null }

            { Send-EmailAlert -Subscription "CMFG-Sandbox" -ResourceGroupName "Test1234" -Resource "KAG" -Message "Testing 123" *> $null } | Should -Throw

            Assert-MockCalled Send-TeamTitanEmailAlert -Times 0 -Scope It
        }

        # resource group does not have tags
        It "Resource Group lacks tags" {
            Mock Get-AzResourceGroup { return @{ } }
            Mock Send-TeamTitanEmailAlert { return $null }

            { Send-EmailAlert -Subscription "CMFG-Sandbox" -ResourceGroupName "Test1234" -Resource "KAG" -Message "Testing 123" *> $null } | Should -Throw "No tags were found on Resource Group: Test1234"

            Assert-MockCalled Send-TeamTitanEmailAlert -Times 0 -Scope It
        }

        # resource group does not have type tag
        It "Resource Group lacks desired tag" {
            Mock Get-AzResourceGroup { return @{Tags = @{test = "123" } } }
            Mock Send-TeamTitanEmailAlert { return $null }

            Send-EmailAlert -Subscription "CMFG-Sandbox" -ResourceGroupName "Test1234" -Resource "KAG" -Message "Testing 123" *> $output

            # no testable assertion for line 1399 (as of this commit) so simply asserting the email is not sent as no appropriate tag found
            Assert-MockCalled Send-TeamTitanEmailAlert -Times 0 -Scope It
        }

        # single value specified in notification tag
        It "Success - Send with Single Team in Notification Tag" {
            Mock Get-AzResourceGroup { return @{Tags = @{AtlasSupportEmailGroup = "DS-TeamTitanSupport" } } }
            Mock Send-TeamTitanEmailAlert { return $null }

            Send-EmailAlert -Subscription "CMFG-Sandbox" -ResourceGroupName "Test1234" -Resource "KAG" -Message "Testing 123" *> $null

            Assert-MockCalled Send-TeamTitanEmailAlert -Times 1 -Scope It
        }

        # multiple values specified in notification tag
        It "Success - Send with Multiple Teams in Notification Tag" {
            Mock Get-AzResourceGroup { return @{Tags = @{AtlasSupportEmailGroup = "DS-TeamTitanSupport@cunamutual.com;DS-ThisIsATest@cunamutual.com" } } }
            Mock Send-TeamTitanEmailAlert { return $null }

            Send-EmailAlert -Subscription "CMFG-Sandbox" -ResourceGroupName "Test1234" -Resource "KAG" -Message "Testing 123" *> $null

            Assert-MockCalled Send-TeamTitanEmailAlert -Times 1 -Scope It
        }

        # resource group w/o resource
        It "Success - Send with Resource Group, No Resource Specified" {
            Mock Get-AzResourceGroup { return @{Tags = @{AtlasSupportEmailGroup = "DS-TeamTitanSupport" } } }
            Mock Send-TeamTitanEmailAlert { return $null }

            Send-EmailAlert -Subscription "CMFG-Sandbox" -ResourceGroupName "Test1234" -Resource "KAG" -Message "Testing 123" *> $null

            Assert-MockCalled Send-TeamTitanEmailAlert -Times 1 -Scope It
        }

        # ResourceId specified instead of other params
        It "Success - Send with ResourceId Specified" {
            Mock Get-AzResourceGroup { return @{Tags = @{AtlasSupportEmailGroup = "DS-TeamTitanSupport" } } }
            Mock Send-TeamTitanEmailAlert { return $null }

            Send-EmailAlert -ResourceId "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Storage/storageAccounts/safatestsubnets" `
                -Message "Testing 123" *> $null

            Assert-MockCalled Send-TeamTitanEmailAlert -Times 1 -Scope It
        }
    }

    Context "Elevated Account Role Group Membership Tests" {
        It "Validate-RoleGroupMembers -- Handles all expected use cases - LSA postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-LSA@cmutual.com") | Out-Null
            $memberList.Add("testuser2-lsa@cmutual.com") | Out-Null
            $memberList.Add("testuser3-lsa@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -BeTrue
        }

        # 04/13/2020 -- LSA-NP postfix not currently treated as a valid elevated account
        It "Validate-RoleGroupMembers -- Handles all expected use cases - LSA-np postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-LSA-np@cmutual.com") | Out-Null
            $memberList.Add("testuser2-lsa-np@cmutual.com") | Out-Null
            $memberList.Add("testuser3-lsa-np@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -BeTrue
        }

        It "Validate-RoleGroupMembers -- Handles all expected use cases - dba postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1dba@cmutual.com") | Out-Null
            $memberList.Add("testuser2DBA@cmutual.com") | Out-Null
            $memberList.Add("testuser3dba@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -BeTrue
        }

        # 04/13/2020 -- dba-NP postfix not currently treated as a valid elevated account
        It "Validate-RoleGroupMembers -- Handles all expected use cases - dba-np postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-DBA-np@cmutual.com") | Out-Null
            $memberList.Add("testuser2-dba-np@cmutual.com") | Out-Null
            $memberList.Add("testuser3-dba-np@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -BeTrue
        }

        It "Validate-RoleGroupMembers -- Handles all expected use cases - for postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-for@cmutual.com") | Out-Null
            $memberList.Add("testuser2-FOR@cmutual.com") | Out-Null
            $memberList.Add("testuser3-for@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -BeTrue
        }

        # 04/13/2020 -- for-NP postfix not currently treated as a valid elevated account
        It "Validate-RoleGroupMembers -- Handles all expected use cases - for-np postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-for-np@cmutual.com") | Out-Null
            $memberList.Add("testuser2-FOR-np@cmutual.com") | Out-Null
            $memberList.Add("testuser3-for-np@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Not -Be $null
            ($result.Count -eq 0) | Should -Be $false
        }

        It "Validate-RoleGroupMembers -- Handles all expected use cases - srv postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-SRV@cmutual.com") | Out-Null
            $memberList.Add("testuser2-srv@cmutual.com") | Out-Null
            $memberList.Add("testuser3-srv@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -BeTrue
        }

        # 04/13/2020 -- srv-NP postfix not currently treated as a valid elevated account
        It "Validate-RoleGroupMembers -- Handles all expected use cases - srv-np postfix" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-srv-np@cmutual.com") | Out-Null
            $memberList.Add("testuser2-SRV-np@cmutual.com") | Out-Null
            $memberList.Add("testuser3-srv-np@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Not -Be $null
            ($result.Count -eq 0) | Should -Be $false
        }

        # 04/13/2020 -- SA- prefix not currently treated as a valid elevated account
        It "Validate-RoleGroupMembers -- Handles all expected use cases - SA account" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("SA-Test-Something@cmutual.com") | Out-Null
            $memberList.Add("SA-Test2-Something@cmutual.com") | Out-Null
            $memberList.Add("SA-Test3-Something@cmutualm.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -Be $true
            ($result.Count -eq 0) | Should -BeTrue
        }

        It "Validate-RoleGroupMembers -- Mocked call, Mixed membership - Expect False" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-SRV@cmutual.com") | Out-Null
            $memberList.Add("SA-Test-Something@cmutual.com") | Out-Null
            $memberList.Add("Michael.Droessler@cunamutual.com") | Out-Null
            $memberList.Add("Jon.McCabe@cunamutual.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Not -Be $null
            ($result.Count -eq 0) | Should -Be $false
            ($result.Count -eq 2) | Should -BeTrue
        }

        It "Validate-RoleGroupMembers -- Mocked call - Expect True" {
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.string]"
            $memberList.Add("testuser1-SRV@cmutual.com") | Out-Null
            $memberList.Add("testuser2dba@cmutual.com") | Out-Null
            $memberList.Add("testuser3-for@cmutualm.com") | Out-Null
            $memberList.Add("testuser4-LSA@cmutual.com") | Out-Null

            $result = Validate-RoleGroupMembers -memberList $memberList

            $result | Should -Be $null
            ($result.Count -eq 0) | Should -BeTrue
        }


        It "Get-RecursiveAzADGroupMembers -- Resolves Mocked Memberships 1 -- Circular" -Skip {
            # Mock Setup
            $groupName1 = "R-MockTest-Circular"
            $groupName2 = "R-MockTest-Circular2"
            $groupName3 = "R-MockTest-Circular3"


            Mock Get-AzADGroup { return [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphGroup]@{Id = $groupName1; DisplayName = $groupName1; } } -ParameterFilter { $DisplayName -eq $groupName1 }
            Mock Get-AzADGroup { return [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphGroup]@{Id = $groupName2; DisplayName = $groupName2; } } -ParameterFilter { $DisplayName -eq $groupName2 }
            Mock Get-AzADGroup { return [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphGroup]@{Id = $groupName3; DisplayName = $groupName3; } } -ParameterFilter { $DisplayName -eq $groupName3 }


            Mock Get-AzADGroupMember { return @([Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName2; Id = $groupName2 }, [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName3; Id = $groupName3 }) } -ParameterFilter { $_.Id -eq $groupName1 }
            Mock Get-AzADGroupMember { return @([Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName1; Id = $groupName1 }, [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName3; Id = $groupName3 }) } -ParameterFilter { $_.Id -eq $groupName2 }
            Mock Get-AzADGroupMember { return @([Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName1; Id = $groupName1 }, [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName2; Id = $groupName2 }) } -ParameterFilter { $_.Id -eq $groupName3 }
            # End Setup

            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.object]"

            $memberList = Get-RecursiveAzADGroupMembers -groupName $groupName1

            ($memberList.Count -eq 0) | Should -Be $true

        }


        It "Get-RecursiveAzADGroupMembers -- Resolves Mocked Memberships 2 -- Multiple layers of nesting" -Skip {
            # Mock Setup
            $groupName1 = "R-MockTest-Nested"
            $groupName2 = "R-MockTest-Nested2"
            $groupName3 = "R-MockTest-Nested3"
            $group3Children = @([Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphUser]@{type = "User"; DisplayName = "Ken" })


            Mock Get-AzADGroup { return [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphGroup]@{Id = $groupName1; DisplayName = $groupName1; } } -ParameterFilter { $DisplayName -eq $groupName1 }
            Mock Get-AzADGroup { return [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphGroup]@{Id = $groupName2; DisplayName = $groupName2; } } -ParameterFilter { $DisplayName -eq $groupName2 }
            Mock Get-AzADGroup { return [Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphGroup]@{Id = $groupName3; DisplayName = $groupName3; } } -ParameterFilter { $DisplayName -eq $groupName3 }



            Mock Get-AzADGroupMember { return @([Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName2; Id = $groupName2 }) } -ParameterFilter { $_.Id -eq $groupName1 }
            Mock Get-AzADGroupMember { return @([Microsoft.Azure.PowerShell.Cmdlets.Resources.MSGraph.Models.ApiV10.IMicrosoftGraphDirectoryObject]@{type = "Group"; DisplayName = $groupName3; Id = $groupName3 }) } -ParameterFilter { $_.Id -eq $groupName2 }
            Mock Get-AzADGroupMember { return @($group3Children) } -ParameterFilter { $_.Id -eq $groupName3 }
            # End Setup

            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.object]"

            $memberList = Get-RecursiveAzADGroupMembers -groupName $groupName1

            ($memberList.Count -eq 1) | Should -Be $true
        }

        It "INTEGRATION: Get-RecursiveAzADGroupMembers --  Basic resolution" {
            $groupName = "R-TeamTitan-LSA"
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.object]"

            $memberList = Get-RecursiveAzADGroupMembers -groupName $groupName

            ($memberList.Count -gt 0) | Should -Be $true
        }

        It "INTEGRATION: Get-RecursiveAzADGroupMembers -- Resolves large number of group memberships" {
            $groupName = "P-VMPJUMPP02-RemoteDesktopUsers"
            $memberList = New-Object -TypeName "System.Collections.Generic.List[system.object]"

            $memberList = Get-RecursiveAzADGroupMembers -groupName $groupName

            ($memberList.Count -gt 0) | Should -Be $true

        }

        It "Global Result Cache" {
            Ensure-OnlyElevatedAccessAccounts -groupName "TestGroup1"
            Ensure-OnlyElevatedAccessAccounts -groupName "TestGroup2"

            $global:EnsureOnlyElevatedAccessAccountsResultsCache.Keys | Should -Contain "TestGroup1"
            $global:EnsureOnlyElevatedAccessAccountsResultsCache.Keys | Should -Contain "TestGroup2"
        }
    }

    Context "Network Functions" {
        BeforeAll {
            $Context = Set-AzContext -Subscription "CMFG-Sandbox"
        }


        It "Network Rules matches expected IP addresses" {
            $values = (Get-AtlasAllowedNetworkRules).value
            $values | Should -Contain "208.91.239.10"
            $values | Should -Contain "208.91.239.11"
            $values | Should -Contain "208.91.239.30"
            $values | Should -Contain "208.91.237.161"
            $values | Should -Contain "208.91.237.162"
            $values | Should -Contain "208.91.237.190"
            $values | Should -Contain "8.36.116.204"
            $values | Should -Contain "20.80.45.128/28"
            $values | Should -Contain "20.94.99.16/28"
        }

        It "Network Rules matches expected subnetResourceIds - IT Portfolio" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # IT Portfolio
            $values | Should -Contain "/subscriptions/059ed1ab-6824-4344-9a65-a0504248340f/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/vnet-cmfg-nc1-d01-10.126.128.0-18/subnets/subnet-cmfg-nc1-d01-generalservers"
            $values | Should -Contain "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/vnet-cmfg-nc1-p01-10.126.0.0-18/subnets/subnet-cmfg-nc1-p01-generalservers"
            $values | Should -Contain "/subscriptions/059ed1ab-6824-4344-9a65-a0504248340f/resourceGroups/RG-CMFG-EA2-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-10.202.192.0_18/subnets/Subnet-CMFG-EA2-NP1-CMFG-GeneralServers"
            $values | Should -Contain "/subscriptions/94f0eebc-4d31-4d69-bc92-dfc97103744a/resourceGroups/RG-CMFG-EA2-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-10.201.192.0_18/subnets/Subnet-CMFG-EA2-P01-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - Commercial" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # Commercial
            $values | Should -Contain "/subscriptions/6e72e218-393a-4fad-a5bd-2ee8a73bac0e/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-COMM-10.198.28.0_22/subnets/Subnet-CMFG-NC1-NP1-COMM-GeneralServers"
            $values | Should -Contain "/subscriptions/849cea0c-6a7e-4df6-8e5d-a30e508207e1/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-COMM-10.200.28.0_22/subnets/Subnet-CMFG-NC1-P01-COMM-GeneralServers"
            $values | Should -Contain "/subscriptions/6e72e218-393a-4fad-a5bd-2ee8a73bac0e/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-COMM-10.202.28.0_22/subnets/Subnet-CMFG-EA2-NP1-COMM-GeneralServers"
            $values | Should -Contain "/subscriptions/849cea0c-6a7e-4df6-8e5d-a30e508207e1/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-COMM-10.201.28.0_22/subnets/Subnet-CMFG-EA2-P01-COMM-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - Corporate Services" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # Corporate Services
            $values | Should -Contain "/subscriptions/e2b843bf-e486-4cae-b9cb-6086c6a18ce1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-CORP-10.198.32.0_22/subnets/Subnet-CMFG-NC1-NP1-CORP-GeneralServers"
            $values | Should -Contain "/subscriptions/cb1acd4b-5762-4caa-9d07-2bec71d47ea0/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-CORP-10.200.32.0_22/subnets/Subnet-CMFG-NC1-P01-CORP-GeneralServers"
            $values | Should -Contain "/subscriptions/e2b843bf-e486-4cae-b9cb-6086c6a18ce1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-CORP-10.202.32.0_22/subnets/Subnet-VNet-CMFG-EA2-NP1-CORP-GeneralServers"
            $values | Should -Contain "/subscriptions/e2b843bf-e486-4cae-b9cb-6086c6a18ce1/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-CORP-10.202.32.0_22/subnets/Subnet-CMFG-EA2-NP1-CORP-GeneralServers"
            $values | Should -Contain "/subscriptions/cb1acd4b-5762-4caa-9d07-2bec71d47ea0/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-CORP-10.201.32.0_22/subnets/Subnet-CMFG-EA2-P01-CORP-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - LAH" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # LAH
            $values | Should -Contain "/subscriptions/abf04ceb-603f-4f05-b647-c8fa71e92f80/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-LAH-10.198.36.0_22/subnets/Subnet-CMFG-NC1-NP1-LAH-GeneralServers"
            $values | Should -Contain "/subscriptions/a1915233-a9aa-4468-8e24-4c1a7b215b29/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-LAH-10.200.36.0_22/subnets/Subnet-CMFG-NC1-P01-LAH-GeneralServers"
            $values | Should -Contain "/subscriptions/abf04ceb-603f-4f05-b647-c8fa71e92f80/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-LAH-10.202.36.0_22/subnets/Subnet-CMFG-EA2-NP1-LAH-GeneralServers"
            $values | Should -Contain "/subscriptions/a1915233-a9aa-4468-8e24-4c1a7b215b29/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-LAH-10.201.36.0_22/subnets/Subnet-CMFG-EA2-P01-LAH-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - Lending" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # Lending
            $values | Should -Contain "/subscriptions/d6322b2a-4d08-42dc-8c34-7f115bd2a763/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-LEND-10.198.40.0_22/subnets/Subnet-CMFG-NC1-NP1-LEND-GeneralServers"
            $values | Should -Contain "/subscriptions/2f7457aa-1e7b-4aa6-b852-54a4ce1ad476/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-LEND-10.200.40.0_22/subnets/Subnet-CMFG-NC1-P01-LEND-GeneralServers"
            $values | Should -Contain "/subscriptions/d6322b2a-4d08-42dc-8c34-7f115bd2a763/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-LEND-10.202.40.0_22/subnets/Subnet-CMFG-EA2-NP1-LEND-GeneralServers"
            $values | Should -Contain "/subscriptions/2f7457aa-1e7b-4aa6-b852-54a4ce1ad476/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-LEND-10.201.40.0_22/subnets/Subnet-CMFG-EA2-P01-LEND-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - OmniChannel" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # OmniChannel
            $values | Should -Contain "/subscriptions/351f164c-393d-4197-84b4-9755bc288332/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-OMNI-10.198.44.0_22/subnets/Subnet-CMFG-NC1-NP1-OMNI-GeneralServers"
            $values | Should -Contain "/subscriptions/49bddc9a-04f0-45f8-84ba-2247b0ec49c3/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-OMNI-10.200.44.0_22/subnets/Subnet-CMFG-NC1-P01-OMNI-GeneralServers"
            $values | Should -Contain "/subscriptions/351f164c-393d-4197-84b4-9755bc288332/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-OMNI-10.202.44.0_22/subnets/Subnet-CMFG-EA2-NP1-OMNI-GeneralServers"
            $values | Should -Contain "/subscriptions/49bddc9a-04f0-45f8-84ba-2247b0ec49c3/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-OMNI-10.201.44.0_22/subnets/Subnet-CMFG-EA2-P01-OMNI-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - Retirement" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # Retirement
            $values | Should -Contain "/subscriptions/40396942-0764-4c0f-9d51-471681c8f8a2/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-RETIRE-10.198.48.0_22/subnets/Subnet-CMFG-NC1-NP1-RETIRE-GeneralServers"
            $values | Should -Contain "/subscriptions/e91f2aff-25a3-470d-9156-e2870d4ddb4d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-RETIRE-10.200.48.0_22/subnets/Subnet-CMFG-NC1-P01-RETIRE-GeneralServers"
            $values | Should -Contain "/subscriptions/40396942-0764-4c0f-9d51-471681c8f8a2/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-RETIRE-10.202.48.0_22/subnets/Subnet-CMFG-EA2-NP1-RETIRE-GeneralServers"
            $values | Should -Contain "/subscriptions/e91f2aff-25a3-470d-9156-e2870d4ddb4d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-RETIRE-10.201.48.0_22/subnets/Subnet-CMFG-EA2-P01-RETIRE-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - Wealth Mgmt" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # Wealth Mgmt
            $values | Should -Contain "/subscriptions/84ddec36-4c9d-4f0c-9687-eff8cea060d6/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-WMGMT-10.198.24.0_22/subnets/Subnet-CMFG-NC1-NP1-WMGMT-GeneralServers"
            $values | Should -Contain "/subscriptions/8809d0d7-bf8e-45e7-9ea0-051b3b188103/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-WMGMT-10.200.24.0_22/subnets/Subnet-CMFG-NC1-P01-WMGMT-GeneralServers"
            $values | Should -Contain "/subscriptions/84ddec36-4c9d-4f0c-9687-eff8cea060d6/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-WMGMT-10.202.24.0_22/subnets/Subnet-CMFG-EA2-NP1-WMGMT-GeneralServers"
            $values | Should -Contain "/subscriptions/8809d0d7-bf8e-45e7-9ea0-051b3b188103/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-WMGMT-10.201.24.0_22/subnets/Subnet-CMFG-EA2-P01-WMGMT-GeneralServers"
        }

        It "Network Rules matches expected subnetResourceIds - DLX" {
            $values = (Get-AtlasAllowedNetworkRules).value

            # DLX
            $values | Should -Contain "/subscriptions/4d937480-7854-488b-91bd-d93964db9c24/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-NP1-DLX-10.198.52.0_22/subnets/Subnet-CMFG-NC1-NP1-DLX-GeneralServers"
            $values | Should -Contain "/subscriptions/e4bd9a8d-0638-4a45-8603-fcb38936082d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-NC1-P01-DLX-10.200.52.0_22/subnets/Subnet-CMFG-NC1-P01-DLX-GeneralServers"
            $values | Should -Contain "/subscriptions/4d937480-7854-488b-91bd-d93964db9c24/resourceGroups/RG-CMFG-NC1-D01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-DLX-10.201.52.0_22/subnets/Subnet-CMFG-EA2-NP1-DLX-GeneralServers"
            $values | Should -Contain "/subscriptions/e4bd9a8d-0638-4a45-8603-fcb38936082d/resourceGroups/RG-CMFG-NC1-P01-ITNetwork/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-P01-DLX-10.202.52.0_22/subnets/Subnet-CMFG-EA2-P01-DLX-GeneralServers"
        }

        It "Validate Known Atlas Network Subnet" {
            Validate-NetworkLocationIsAtlasAllowed -subnetResourceId $KNOWN_ATLAS_SUBNET -context $Context | Should -Be $true
        }

        It "Validate Known Not-Atlas Network Subnet" {
            Validate-NetworkLocationIsAtlasAllowed -subnetResourceId $KNOWN_NOT_ATLAS_SUBNET -context $Context | Should -Be $false
        }

        It "Validate Made up Network Subnet" {
            Validate-NetworkLocationIsAtlasAllowed -subnetResourceId "definitelynotmadeup" -context $Context 2>$null | Should -Be $true
            # why is this test supposed to be true? This is to ensure the check fails to "true" if the target subnet cannot be discovered
            # during evaluation. This behavior accounts for the rare, but possible, case where a vnet rule exists but the source vnet cannot
            # be pulled at runtime (typically due to Azure connectivity blip) for verification. In this case, we're going to assume
            # the best. this could lead to made up vNets existing on a resource, but most (all?) resources perform validations when adding these
            # rules so this is not expected to be a frequent occurrence.
        }
    }

    Context "Trusted Caller Ids" {
        It "Validate SP-AA-InfraMgmt-Az-D Trusted" {
            Check-CallerIsTrustedAtlasIdentity -callerAppId "6e5ed314-7154-4254-84b0-e43f1c638615" | Should -Be $true
        }
        It "Validate SP-AA-InfraMgmt-Az-P Trusted" {
            Check-CallerIsTrustedAtlasIdentity -callerAppId "aed58b11-d650-4e8f-b740-30704654d758" | Should -Be $true
        }
        It "Validate VAZHYBWRKD01 Trusted" {
            Check-CallerIsTrustedAtlasIdentity -callerAppId "18b27a8b-06f9-4e9c-b06c-f1108c1452ec" | Should -Be $true
        }
        It "Validate VAZHYBITINFRAP1 Trusted" {
            Check-CallerIsTrustedAtlasIdentity -callerAppId "bb5ab6f2-95ad-438a-a4bc-fa61c03c6432" | Should -Be $true
        }
        It "Validate Random Id is Untrusted" {
            Check-CallerIsTrustedAtlasIdentity -callerAppId "11111111-95ad-438a-a4bc-fa61c03c6432" | Should -Be $false
        }
        It "Validate Random Id is Untrusted2" {
            Check-CallerIsTrustedAtlasIdentity -callerAppId "11111111-95ad-438a-a4bc-903828kjlkjl" | Should -Be $false
        }
        It "Validate Random Id is Untrusted3" {
            Check-CallerIsTrustedAtlasIdentity -callerAppId "11111111-95ad-438a-a4bc-flkjlkjlkjlklkja61c03c6432" | Should -Be $false
        }
    }

    Context "Automation Account Environment Lookups" {

        It "Get-TargetAutomationAccountConfig - Prod" {
            $inputEnv = "Prod"
            $env = Get-TargetAutomationAccountConfig -AAEnv $inputEnv
            $env.TargetInfraAA | Should -Be "AA-CMFG-P01-InfraMgmt-AZ"
            $env.TargetInfraResourceGroup | Should -Be "RG-CMFG-NC1-P01-ITInfrastructure"
            $env.TargetInfraHybridWorker | Should -Be "AzWorkerGrp"
            $env.TargetInfraSub | Should -Be "CMFG Production"
        }

        It "Get-TargetAutomationAccountConfig - NonProd" {
            $inputEnv = "NonProd"
            $env = Get-TargetAutomationAccountConfig -AAEnv $inputEnv
            $env.TargetInfraAA | Should -Be "AA-CMFG-D01-InfraMgmt-AZ"
            $env.TargetInfraResourceGroup | Should -Be "RG-CMFG-NC1-D01-ITInfrastructure"
            $env.TargetInfraHybridWorker | Should -Be "cmfgHybrid"
            $env.TargetInfraSub | Should -Be "CMFG NonProduction"
        }

        It "Get-TargetAutomationAccountConfig - Sandbox" {
            $inputEnv = "Sandbox"
            $env = Get-TargetAutomationAccountConfig -AAEnv $inputEnv
            $env.TargetInfraAA | Should -Be "AA-CMFG-D01-InfraMgmt-AZ"
            $env.TargetInfraResourceGroup | Should -Be "RG-CMFG-NC1-D01-ITInfrastructure"
            $env.TargetInfraHybridWorker | Should -Be "cmfgHybrid"
            $env.TargetInfraSub | Should -Be "CMFG NonProduction"
        }

        It "Get-TargetAutomationAccountConfig - Junk" {
            $inputEnv = "Junk"
            { Get-TargetAutomationAccountConfig -AAEnv $inputEnv } | Should -Throw
        }
    }

    Context "Is-RGAtlas-Runbook Tests" {
        BeforeAll {
            # simple test - make sure we're getting more than one result
            $currentContext = (Get-AzContext)
            $allResourceGroups = Get-AzResourceGroup
            $i = 0

            $atlasResourceGroups = $allResourceGroups | Where-Object { $_.Tags -and $_.Tags.TemplateVersion -ne $null }
            foreach ($rg in $atlasResourceGroups) {
                if (Is-RGAtlas-Runbook -resourceGroup $rg.ResourceGroupName -Context $currentContext) {
                    $i++
                }

                # break early once we've found a few
                if ($i -gt 2) {
                    break
                }
            }
        }


        It "There should be Atlas RGs in CMFG-Sandbox" {
            $i | Should -BeGreaterThan 0
        }


        It "Matching RG should be Atlas" {
            foreach ($rg in $AtlasTestResourceGroups) {
                    Is-RGAtlas-Runbook -resourceGroup $rg.ResourceGroupName -Context $currentContext | Should -Be $true
                }
        }
    }

    Context "Get-AtlasResourceObjectByNameOrId Tests" {
        BeforeAll {
            $Context = Set-AzContext -Subscription "CMFG-Sandbox"
        }

        It "AtlasResourceObj Correctly Configured-Single Resource Match" {
            $AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName "kv-atlas-Sandbox-np" -ResourceType $CONST_KEY_VAULT_ID 4> $null

            $AtlasResourceObj.ResourceId | Should -Be "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-NP1-Atlas-Shared-Resources/providers/Microsoft.KeyVault/vaults/kv-atlas-Sandbox-np"
            $AtlasResourceObj.Name | Should -Be "kv-atlas-Sandbox-np"
            $AtlasResourceObj.Tags.TemplateVersion | Should -Not -Be $null

            $AtlasResourceObj.ResourceId | Should -Be "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-NP1-Atlas-Shared-Resources/providers/Microsoft.KeyVault/vaults/kv-atlas-Sandbox-np"
            $AtlasResourceObj.Name | Should -Be "kv-atlas-Sandbox-np"
            $AtlasResourceObj.Tags | Should -Not -Be $null
        }

        It "AtlasResourceObj Correctly Configured-Single Resource Match-ResourceId-TagInheritance" {
            $AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context `
                -ResourceId "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Sql/servers/sql-networking-testing-subnets/databases/test_db" `
                -ResourceType $CONST_SQL_DB_ID 4> $null

            $AtlasResourceObj.ResourceId | Should -Be "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Sql/servers/sql-networking-testing-subnets/databases/test_db"
            $AtlasResourceObj.Name | Should -Be "test_db"
            $AtlasResourceObj.Tags.TemplateVersion | Should -Not -Be $null
        }

        It "AtlasResourceObj Correctly Configured-Multiple Resource Match" {
            $AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName "AKS-NP1-RP-Test" -ResourceType $CONST_AKS_ID 4> $null

            $AtlasResourceObj.ResourceId | Should -Be "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourcegroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.ContainerService/managedClusters/AKS-NP1-RP-Test"
            $AtlasResourceObj.Name | Should -Be "AKS-NP1-RP-Test"
            $AtlasResourceObj.Tags.TemplateVersion | Should -Not -Be $null
            $AtlasResourceObj.Tags.TemplateVersion | Should -Match "Titan-Atlas"
        }
    }
    Context "Validate-AtlasPermissionsRequest Tests" {
        BeforeAll {
            Set-AzContext -Subscription "CMFG-Sandbox"

            $ValidPermissionsRequestFile = "$env:INFRA_FOLDER/StorageAccount/test/TestValidContainerPermissions_GroupAndAppIdentity.json"
            $InvalidPermissionsRequestForAppFile = "$env:INFRA_FOLDER/StorageAccount/test/TestInvalidStorageAccountPermissions_BadPermsForAppIdentity.json"
            $InvalidPermissionsRequestForGroupFile = "$env:INFRA_FOLDER/StorageAccount/test/TestInvalidStorageAccountPermissions_BadPermsForGroupIdentity.json"
        }


        It "Not a Valid Json Permission Payload File Input - Junk File" {
            { Validate-AtlasPermissionsRequest -PermissionsJsonObject "Junk" } | Should -Throw
        }

        It "Invalid Permissions Request For Application Identity " {
            { Validate-AtlasPermissionsRequest -PermissionsJsonObject $InvalidPermissionsRequestForAppFile } | Should -Throw
        }

        It "Invalid Permissions Request For Group Identity " {
            { Validate-AtlasPermissionsRequest -PermissionsJsonObject $InvalidPermissionsRequestForAppFile } | Should -Throw
        }

        It "Valid Json Permissions Payload File Input" {
            { Validate-AtlasPermissionsRequest -PermissionsJsonObject $TargetPermissionsFile } | Should -Be $true
        }

    }

    Context "Get-SubscriptionProperties Tests" {
        BeforeAll {
            $SubscriptionProperties = $null
            Set-AzContext -Subscription "CMFG-Sandbox"

        }


        It "Subscription Not Found in RM Account Correlation Map" {
            { $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "NonExistentSubscription" } | Should -Throw
        }

        It "Subscription Properties Correctly Retrieved For -NonProd subscription format" {
            $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "Lending-NonProd"
            $SubscriptionProperties.subscriptionName | Should -Be "Lending-NonProd"
            $SubscriptionProperties.rmAccount | Should -Be "SP-RM-Lending-P"
            $SubscriptionProperties.omsWorkspace | Should -Be "lendingnp1oms"
            $SubscriptionProperties.portfolioName | Should -Be "Lending"
            $SubscriptionProperties.environment | Should -Be "NonProd"
            $SubscriptionProperties.acrName | Should -Be "acrcmfgnpLend"
            $SubscriptionProperties.acrResourceGroup | Should -Be "RG-CMFG-EA2-NP1-Lending-ACR"
        }

        It "Subscription Properties Correctly Retrieved For NonProduction subscription format" {
            $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "CMFG NonProduction"
            $SubscriptionProperties.subscriptionName | Should -Be "CMFG NonProduction"
            $SubscriptionProperties.environment | Should -Be "NonProd"
        }

        It "Lending-Prod Subscription Properties Correctly Retrieved " {
            $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "Lending-Prod" 4> $null
            $SubscriptionProperties.subscriptionName | Should -Be "Lending-Prod"
            $SubscriptionProperties.rmAccount | Should -Be "SP-RM-Lending-P"
            $SubscriptionProperties.omsWorkspace | Should -Be "lendingpr1oms"
            $SubscriptionProperties.portfolioName | Should -Be "Lending"
            $SubscriptionProperties.environment | Should -Be "Prod"
            $SubscriptionProperties.acrName | Should -Be "acrcmfgprLend"
            $SubscriptionProperties.acrResourceGroup | Should -Be "RG-CMFG-EA2-PR1-Lending-ACR"
        }

        It "Subscription Properties Correctly Retrieved For Production subscription format" {
            $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "CMFG Production"
            $SubscriptionProperties.subscriptionName | Should -Be "CMFG Production"
            $SubscriptionProperties.environment | Should -Be "Prod"
        }

        It "CMFG-Sandbox Subscription Properties Retrieved" {
            $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "CMFG-Sandbox"
            $SubscriptionProperties.subscriptionName | Should -Be "CMFG-Sandbox"
            $SubscriptionProperties.rmAccount | Should -Be "SP-RM-Sandbox-P"
            $SubscriptionProperties.omsWorkspace | Should -Be "sandboxd01oms"
            $SubscriptionProperties.portfolioName | Should -Be "Sandbox"
            $SubscriptionProperties.environment | Should -Be "Sandbox"
            $SubscriptionProperties.acrName | Should -Be "acrcmfgsandbox"
            $SubscriptionProperties.acrResourceGroup | Should -Be "RG-CMFG-EA2-NP1-Sandbox-ACR"
            $SubscriptionProperties.acrName | Should -Be "acrcmfgsandbox"
            $SubscriptionProperties.acrResourceGroup | Should -Be "RG-CMFG-EA2-NP1-Sandbox-ACR"
        }
    }
}