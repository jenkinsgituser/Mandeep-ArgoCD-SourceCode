# need this in the event that the constants are sourced more than once during a complex operation
if (!$CONSTANTS_SETUP_COMPLETE) {

    # General Subscription Constants
    #**********************************************************
    Set-Variable -Name CONST_SANDBOX_SUB -Value "Sandbox" -Option Constant -Scope Global
    Set-Variable -Name CONST_PROD_SUB -Value "Prod" -Option Constant -Scope Global
    Set-Variable -Name CONST_NONPROD_SUB -Value "NonProd" -Option Constant -Scope Global
    Set-Variable -Name CONST_ITPORT -Value "ITPortfolio" -Option Constant -Scope Global
    Set-Variable -Name CONST_SECURECLOUD -Value "SecureCloud" -Option Constant -Scope Global
    Set-Variable -Name CONST_CMFG -Value "CMFG" -Option Constant -Scope Global

    # Azure Type Constants
    #**********************************************************
    Set-Variable -Name CONST_APP_SERVICE_TYPE -Value "Microsoft.Web/sites" -Option Constant -Scope Global
    Set-Variable -Name CONST_AKS_TYPE -Value "Microsoft.ContainerService/managedClusters" -Option Constant -Scope Global
    Set-Variable -Name CONST_KEY_VAULT_TYPE -Value "Microsoft.KeyVault/vaults" -Option Constant -Scope Global
    Set-Variable -Name CONST_SERVICE_BUS_TYPE -Value "Microsoft.ServiceBus/namespaces" -Option Constant -Scope Global
    Set-Variable -Name CONST_STORAGE_ACCOUNT_TYPE -Value "Microsoft.Storage/storageAccounts" -Option Constant -Scope Global
    Set-Variable -Name CONST_SQL_SERVER_TYPE -Value "Microsoft.Sql/servers" -Option Constant -Scope Global
    Set-Variable -Name CONST_EVENT_HUBS_TYPE -Value "Microsoft.EventHub/namespaces" -Option Constant -Scope Global

    # Atlas Specific things
    #**********************************************************
    Set-Variable -Name CONST_ATLAS_IDENTIFIER -Value "Titan-Atlas" -Option Constant -Scope Global
    Set-Variable -Name CONST_ATLAS_EXCEPTIONS_TAG -Value "AtlasExceptions" -Option Constant -Scope Global
    Set-Variable -Name CONST_LOCAL_EXTERNAL_IP -Value "208.91.239.10" -Option Constant -Scope Global
    Set-Variable -Name CONST_RESOURCE_PERMISSIONS_RUNBOOK_NAME -Value "Atlas-ResourcePermissions" -Option Constant -Scope Global

    # App Service  Constants (Shared by Web and Function Apps)
    #**********************************************************
    Set-Variable -Name CONST_APP_PREFIX -Value "AS-" -Option Constant -Scope Global
    Set-Variable -Name CONST_LOCATION_DEFAULT -Value "eastus2" -Option Constant -Scope Global
    Set-Variable -Name CONST_APP_ALWAYS_ON_DEFAULT -Value "true" -Option Constant -Scope Global
    Set-Variable -Name CONST_APP_RUNTIME_FUNCTIONAPP_STACK_DEFAULT -Value "dotnet" -Option Constant -Scope Global
    Set-Variable -Name CONST_APP_RUNTIME_WEBAPP_STACK_DEFAULT -Value "dotnetcore" -Option Constant -Scope Global
    Set-Variable -Name CONST_CORS_ALLOWED_ORIGINS_DEFAULT -Value $null -Option Constant -Scope Global
    Set-Variable -Name CONST_FUNCTIONS_EXTENSION_VERSION -Value "~4" -Option Constant -Scope Global
    Set-Variable -Name CONST_WEBSITE_NODE_DEFAULT_VERSION -Value "10.14.1" -Option Constant -Scope Global

    # App Service Plan
    #**********************************************************
    Set-Variable -Name CONST_ASP_CREATE_NEW_DEFAULT -Value $false -Option Constant -Scope Global
    Set-Variable -Name CONST_ASP_PREFIX -Value "ASP-" -Option Constant -Scope Global
    Set-Variable -Name CONST_ASP_NUM_INSTANCES_DEFAULT -Value 1 -Option Constant -Scope Global
    # This sku now required for vNet integration...
    Set-Variable -Name CONST_ASP_SKU_CODE_DEFAULT -Value "P1V2" -Option Constant -Scope Global
    Set-Variable -Name CONST_AS_RESOURCE_TYPE_WEB_APP -Value "web" -Option Constant -Scope Global
    Set-Variable -Name CONST_AS_RESOURCE_TYPE_FUNCTION_APP -Value "function" -Option Constant -Scope Global
    Set-Variable -Name CONST_AS_RESOURCE_TYPE_WEB_APP_PRIVATE -Value "webprivate" -Option Constant -Scope Global


    # App Insights
    #**********************************************************
    Set-Variable -Name CONST_AIS_PREFIX -Value "AIS-" -Option Constant -Scope Global

    # Storage Account Constants
    #**********************************************************
    Set-Variable -Name CONST_SA_PREFIX -Value "sa" -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_ACCOUNT_TYPE_DEFAULT -Value "Standard_LRS" -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_ACCESS_TIER_DEFAULT -Value "Hot" -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_PURPOSE_DEFAULT -Value "Atlas-GeneralPurpose-StorageAccount" -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_PURPOSE_FUNCTION_APP -Value "Atlas-FunctionApp-StorageAccount" -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_PURPOSE_LARGE_TRANSFER_SERVICE -Value "Atlas-ServiceBus-LargeFileTransfer" -Option Constant -Scope Global
    Set-Variable -Name CONST_ENDPOINT_SUFFIX -Value "core.windows.net" -Option Constant -Scope Global
    Set-Variable -Name CONST_ENDPOINT_PROTOCOL -Value "https" -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_DELETE_LIFECYCLE_DAYS -Value 7 -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_DELETE_LIFECYCLE_DAYS_MIN_VALUE -Value 1 -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_DELETE_LIFECYCLE_DAYS_MAX_VALUE -Value 2555 -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_BLOB_SOFT_DELETE_DAYS -Value 7 -Option Constant -Scope Global
    Set-Variable -Name CONST_SA_CONTAINER_SOFT_DELETE_DAYS -Value 7 -Option Constant -Scope Global

    # Key Vault Constants
    #**********************************************************
    Set-Variable -Name CONST_KV_PREFIX -Value "kv-" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_SKU_DEFAULT -Value "Premium" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_CREATE_NEW_DEFAULT -Value $true -Option Constant -Scope Global

    Set-Variable -Name CONST_KV_SANDBOX_NP -Value "kv-atlas-Sandbox-np" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_SANDBOX_RG_NP -Value "RG-CMFG-EA2-NP1-Atlas-Shared-Resources" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_SANDBOX_SUB_NP -Value "CMFG-Sandbox" -Option Constant -Scope Global

    Set-Variable -Name CONST_KV_SHAREDSVCS_NP -Value "kv-atlas-SharedSVCs-np" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_SHAREDSVCS_RG_NP -Value "RG-CMFG-EA2-NP1-Atlas-Shared-Resources" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_SHAREDSVCS_SUB_NP -Value "CMFG NonProduction" -Option Constant -Scope Global

    Set-Variable -Name CONST_KV_SHAREDSVCS_P -Value "kv-atlas-SharedSVCs-p" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_SHAREDSVCS_RG_P -Value "RG-CMFG-EA2-PR1-Atlas-Shared-Resources" -Option Constant -Scope Global
    Set-Variable -Name CONST_KV_SHAREDSVCS_SUB_P -Value "CMFG Production" -Option Constant -Scope Global

    Set-Variable -Name CONST_KV_SECRET_NAME -Value "GetClientIP" -Option Constant -Scope Global

    # Traffic Manager Constants
    #**********************************************************
    Set-Variable -Name CONST_TM_PREFIX -Value "tm-" -Option Constant -Scope Global

    # AzureSQL Constants
    #**********************************************************
    Set-Variable -Name CONST_SQL_PREFIX -Value "sql-" -Option Constant -Scope Global
    # adding objId as a constant along with the AAD Admin display name to save the lookup of the objId. bug #1542008
    Set-Variable -Name CONST_SQL_AADADMIN_NONPROD -Value "R-AzureSQL-Admins-NonProd" -Option Constant -Scope Global
    Set-Variable -Name CONST_SQL_AADADMIN_NONPROD_OBJID -Value "fa584910-7e24-4254-9186-540d0f8e3001" -Option Constant -Scope Global
    Set-Variable -Name CONST_SQL_AADADMIN_PROD -Value "R-AzureSQL-Admins" -Option Constant -Scope Global
    Set-Variable -Name CONST_SQL_AADADMIN_PROD_OBJID -Value "ea0ff2a3-e057-4392-af03-d6ab89ac7db3" -Option Constant -Scope Global

    # Service Bus Constants
    #**********************************************************
    Set-Variable -Name CONST_KEY_ROTATION_EXCEPTION_VALUE -Value "KeyRotationException" -Option Constant -Scope Global
    Set-Variable -Name CONST_SERVICE_BUS_RESOURCE_TYPE -Value "Microsoft.ServiceBus/namespaces" -Option Constant -Scope Global

    # App Configuration Constants
    #**********************************************************
    Set-Variable -Name CONST_APP_CONFIG_PREFIX -Value "ac-" -Option Constant -Scope Global

    # Managed Identity Constants
    #**********************************************************

    # AKS Constants
    #**********************************************************
    #v2.1
    Set-Variable -Name CONST_LATEST_ALLOWED_K8S_VERSION -Value "1.25"
    Set-Variable -Name CONST_LOWEST_ALLOWED_K8S_VERSION -Value "1.23"
    Set-Variable -Name CONST_PREVIEW_IDENTIFIER -Value "preview"

    # Retry Logic Constants
    #**********************************************************
    Set-Variable -Name CONST_MAX_ATTEMPTS -Value 5 -Option Constant -Scope Global
    Set-Variable -Name CONST_SLEEP_TIME -Value 10 -Option Constant -Scope Global

    # Atlantis Constants
    #**********************************************************
    Set-Variable -Name CONST_PRIVATE_FILTER -Value "-private-" -Option Constant -Scope Global
    Set-Variable -Name CONST_PRIVATEFUNCTION_FILTER -Value "-privatefunctions-" -Option Constant -Scope Global
    Set-Variable -Name CONST_PRIVATEWEB_FILTER -Value "-privateweb-" -Option Constant -Scope Global
    Set-Variable -Name CONST_UNABLE_TO_ALLOCATE_EXCEPTION -Value "Unable to allocate subnet in Atlantis vNet. Please contact DS-TeamTitanSupport and share your release logs for assistance." -Option Constant -Scope Global


    # Telemetry Constants
    #**********************************************************
    Set-Variable -Name CONST_ATLAS_INSTRUMENTATION_SECRET_NAME -Value "AtlasInstrumentationKey" -Option Constant -Scope Global


    # Mark that setup has been successfully completed
    Set-Variable -Name CONSTANTS_SETUP_COMPLETE -Value $true -Option Constant -Scope Global


}
