#This script is only used by Atlas-ChaosMonkeyEventTriggerTester.yaml

$resourceGroupPrefix = "RG-CMFG-T01-Atlas-Test-"
$commitID = "$($env:BUILD_SOURCEVERSION)".substring(0, 8)

# BUILD_BUILDNUMBER contains both date and build number (20201102-687036), this will pick off just the build number
$buildID = "$($env:BUILD_BUILDNUMBER)"
$buildIDRG = $buildID.Split("-")[1]

#Setting 'subnet' must have a name that begins with an alphabet or underscore and not end with whitespace, dot or underscore.
#^ to comply, if the commitID starts with a number pre-pend a z and take the first 7 commitID numbers
$regex = [regex] '^[a-zA-Z][a-zA-Z0-9]+$'

if ($commitID -notmatch $regex) {
    $commitID = "z" + "$($commitID.substring(0,7))"
}

$RgType = "devSandbox"
$EnvironmentCode = "T01"
$RgAppDesc = "Atlas-Test-" + $commitID + "-" + $buildIDRG

$resourceGroup = "RG-CMFG-" + $EnvironmentCode + "-" + $RgAppDesc + "-" + $RgType

Write-Host "##vso[task.setvariable variable=SQL_RESOURCE_GROUP;]$resourceGroup"
Write-Host "##vso[task.setvariable variable=BUILD_RG_NAME;]$resourceGroup"

$sqlServerName = "sql-atlastest-" + $commitID + "-" + $buildID
Write-Host "##vso[task.setvariable variable=SQL_SERVER_NAME;]$sqlServerName"
