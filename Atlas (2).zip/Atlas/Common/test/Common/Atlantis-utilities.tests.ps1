Describe "Atlantis-Utilities Tests" {
    BeforeAll {
        . ("$env:COMMON_FOLDER/test/Common/_includes.tests.ps1")
    }



    It "Main Scripts can be dot sourced" {
        (Get-ChildItem function:/).Name | Should -Contain "Get-AtlasNextAvailableAtlantisSubnet"
        (Get-ChildItem function:/).Name | Should -Contain "Remove-AtlasPurposeTag"
    }


    Describe "Split-NetworkStringIntoPSObject Tests" {
        It "Test 1 - 10.0.0.0/8" {
            $obj = Split-NetworkStringIntoPSObject -Network "10.0.0.0/8"
            $obj.FirstOctet | Should -Be 10
            $obj.SecondOctet | Should -Be 0
            $obj.ThirdOctet | Should -Be 0
            $obj.FourthOctet | Should -Be 0
            $obj.Mask | Should -Be 8
        }

        It "Test 2 - 10.2.0.0/16" {
            $obj = Split-NetworkStringIntoPSObject -Network "10.2.0.0/16"
            $obj.FirstOctet | Should -Be 10
            $obj.SecondOctet | Should -Be 2
            $obj.ThirdOctet | Should -Be 0
            $obj.FourthOctet | Should -Be 0
            $obj.Mask | Should -Be 16
        }

        It "Test 3 - 172.98.230.85/32" {
            $obj = Split-NetworkStringIntoPSObject -Network "172.98.230.85/32"
            $obj.FirstOctet | Should -Be 172
            $obj.SecondOctet | Should -Be 98
            $obj.ThirdOctet | Should -Be 230
            $obj.FourthOctet | Should -Be 85
            $obj.Mask | Should -Be 32
        }

        It "Test 4 - Gibberish '093409328409'" {
            { Split-NetworkStringIntoPSObject -Network "093409328409" } | Should -Throw
        }

        It "Test 5 - Gibberish Network '128.9.11111.9090/32'" {
            { Split-NetworkStringIntoPSObject -Network "128.9.11111.9090/32" } | Should -Throw
        }

        It "Test 6 - Gibberish Network2 '128.9.11.11/64'" {
            { Split-NetworkStringIntoPSObject -Network "128.9.11.11/64" } | Should -Throw
        }

        It "Test 7 - 10.244.230.128/25" {
            $obj = Split-NetworkStringIntoPSObject -Network "10.244.230.128/25"
            $obj.FirstOctet | Should -Be 10
            $obj.SecondOctet | Should -Be 244
            $obj.ThirdOctet | Should -Be 230
            $obj.FourthOctet | Should -Be 128
            $obj.Mask | Should -Be 25
        }
    }

    Describe "Get-NextAvailableSubnetFromSortedSubnets Tests" {
        BeforeAll {
            $subnet1 = [PSCustomObject]@{
                FirstOctet  = 10
                SecondOctet = 0
                ThirdOctet  = 0
                FourthOctet = 0
                Mask        = 25
            }

            $subnet2 = [PSCustomObject]@{
                FirstOctet  = 10
                SecondOctet = 0
                ThirdOctet  = 0
                FourthOctet = 128
                Mask        = 25
            }

            $subnet3 = [PSCustomObject]@{
                FirstOctet  = 10
                SecondOctet = 0
                ThirdOctet  = 1
                FourthOctet = 0
                Mask        = 25
            }

            $testArray = @($subnet1, $subnet2, $subnet3)

        }


        It "Test 1 - Happy Path Allocation" {
            $nextSubnet = Get-NextAvailableSubnetFromSortedSubnets -SortedSubnetArray $testArray
            $nextSubnet.FirstOctet | Should -Be 10
            $nextSubnet.SecondOctet | Should -Be 0
            $nextSubnet.ThirdOctet | Should -Be 1
            $nextSubnet.FourthOctet | Should -Be 128
            $nextSubnet.Mask | Should -Be 25
        }



        It "Test 2 - A Random /16 Appears!" {
            $subnet4 = [PSCustomObject]@{
                FirstOctet  = 10
                SecondOctet = 1
                ThirdOctet  = 0
                FourthOctet = 0
                Mask        = 16
            }

            $testArray = @($subnet1, $subnet2, $subnet3, $subnet4)
            $nextSubnet = Get-NextAvailableSubnetFromSortedSubnets -SortedSubnetArray $testArray
            $nextSubnet.FirstOctet | Should -Be 10
            $nextSubnet.SecondOctet | Should -Be 2
            $nextSubnet.ThirdOctet | Should -Be 0
            $nextSubnet.FourthOctet | Should -Be 0
            $nextSubnet.Mask | Should -Be 25
        }


        It "Test 3 - Increment a 255" {
            $subnet4 = [PSCustomObject]@{
                FirstOctet  = 10
                SecondOctet = 1
                ThirdOctet  = 255
                FourthOctet = 128
                Mask        = 16
            }

            $testArray = @($subnet1, $subnet2, $subnet3, $subnet4)

            $nextSubnet = Get-NextAvailableSubnetFromSortedSubnets -SortedSubnetArray $testArray
            $nextSubnet.FirstOctet | Should -Be 10
            $nextSubnet.SecondOctet | Should -Be 2
            $nextSubnet.ThirdOctet | Should -Be 0
            $nextSubnet.FourthOctet | Should -Be 0
            $nextSubnet.Mask | Should -Be 25
        }



        It "Test 4 - How'd We Get This Input?" {
            $subnetBAD = [PSCustomObject]@{
                FirstOctet  = 10
                SecondOctet = 257
                ThirdOctet  = 255
                FourthOctet = 128
                Mask        = 16
            }
            $testArray = @($subnet1, $subnet2, $subnet3, $subnetBAD)

            { Get-NextAvailableSubnetFromSortedSubnets -SortedSubnetArray $testArray } | Should -Throw
        }
    }
    Describe "Get-LocationShortName" {
        BeforeAll {
        #dot source common code
        . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

            $TESTLOCATION1 = "eastus2"
            $TESTLOCATION2 = "westindia"
            $TESTLOCATION3 = "wetus"
            $TESTLOCATION4 = "westus"
            $TESTLOCATION5 = "centralus"
            $TESTLOCATION6 = ""
            $TESTLOCATION7 = " "
            $TESTLOCATION8 = "northcentralus"
            $TESTLOCATION9 = "eastus"
            $TESTLOCATION10 = "westus2"
            $TESTLOCATION11 = "southcentralus"
            $TESTLOCATION12 = "westcentralus"


            $TESTRESULT1 = Get-LocationShortName -Location $TESTLOCATION1
        }


        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION1" {
            $TESTRESULT1 | Should -Not -Be $null
            $TESTRESULT1 | Should -Be ""
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION2" {
            try {
                $TESTRESULT2 = Get-LocationShortName -Location $TESTLOCATION2
            }
            catch {
                $TESTRESULT2 | Should -Be $null
            }
        }
        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION3" {
            try {
                $TESTRESULT3 = Get-LocationShortName -Location $TESTLOCATION3
            }
            catch {
                $TESTRESULT3 | Should -Be $null
            }
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION4" {
            $TESTRESULT4 = Get-LocationShortName -Location $TESTLOCATION4
            $TESTRESULT4 | Should -Not -Be $null
            $TESTRESULT4 | Should -Be "-WUS"
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION5" {
            $TESTRESULT5 = Get-LocationShortName -Location $TESTLOCATION5
            $TESTRESULT5 | Should -Not -Be $null
            $TESTRESULT5 | Should -Be "-CUS"
        }
        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION6" {
            try {
                $TESTRESULT6 = Get-LocationShortName -Location $TESTLOCATION6
            }
            catch {
                $TESTRESULT6 | Should -Be $null
            }
        }
        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION7" {
            try {
                $TESTRESULT7 = Get-LocationShortName -Location $TESTLOCATION7
            }
            catch {
                $TESTRESULT7 | Should -Be $null
            }
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION8" {
            $TESTRESULT8 = Get-LocationShortName -Location $TESTLOCATION8
            $TESTRESULT8 | Should -Not -Be $null
            $TESTRESULT8 | Should -Be "-NCUS"
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION9" {
            $TESTRESULT9 = Get-LocationShortName -Location $TESTLOCATION9
            $TESTRESULT9 | Should -Not -Be $null
            $TESTRESULT9 | Should -Be "-EUS"
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION10" {
            $TESTRESULT10 = Get-LocationShortName -Location $TESTLOCATION10
            $TESTRESULT10 | Should -Not -Be $null
            $TESTRESULT10 | Should -Be "-WUS2"
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION11" {
            $TESTRESULT11 = Get-LocationShortName -Location $TESTLOCATION11
            $TESTRESULT11 | Should -Not -Be $null
            $TESTRESULT11 | Should -Be "-SCUS"
        }

        It "Can Successfully Identify Shortname, based on Location value passed: $TESTLOCATION12" {
            $TESTRESULT12 = Get-LocationShortName -Location $TESTLOCATION12
            $TESTRESULT12 | Should -Not -Be $null
            $TESTRESULT12 | Should -Be "-WCUS"
        }


    }


}