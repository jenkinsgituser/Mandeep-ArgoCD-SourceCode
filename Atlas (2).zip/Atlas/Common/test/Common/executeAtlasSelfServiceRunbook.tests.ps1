

Describe "Permissions Runbook Behavior Tests" {
    BeforeAll {
        . ("$env:COMMON_FOLDER/test/Common/_includes.tests.ps1")
        $CONST_TARGET_NAMESPACE = "Atlas-Sandbox-Test-ESB"
        $CONST_TARGET_IDENTITY = "R-TeamTitan"
        $CONST_TARGET_PERMS = "Azure Service Bus Data Receiver"
        $CONST_TARGET_RESOURCEID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.ServiceBus/namespaces/Atlas-Sandbox-Test-ESB"

        . "$COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1"

    }


    It "Invoke-AtlasSelfServeRunbook Function Available" {
        (Get-ChildItem function:/).Name | Should -Contain "Invoke-AtlasSelfServeRunbook"

        Write-Verbose -Verbose "The following tests rely on the presence of the ResourcePermissions runbook!"
    }



    It "Throws on gross error - 1" -skip {
        $JsonESB_Add = @(
            @{
                Subscription = "CMFG-Sandbox"
                Resources    = @(
                    @{
                        ResourceType     = "This is junk data"
                        PermissionsArray = @(
                            @{
                                Name        = "So is this"
                                Identity    = $CONST_TARGET_IDENTITY
                                Permissions = @($CONST_TARGET_PERMS)
                            }
                        )
                    }
                )
            }
        )
        #strip any newlines, carriage returns, and tabs -- not required but cleans up input for logs
        [string]$Payload = $JsonESB_Add | ConvertTo-Json -Depth 10
        Write-Verbose "Permission Payload: $Payload" -Verbose

        $Params = @{"Payload" = $Payload }
        { Invoke-AtlasSelfServeRunbook -RunbookName $CONST_RESOURCE_PERMISSIONS_RUNBOOK_NAME -Parameters $Params } | Should -Throw
    }

    It "Throws on gross error - 2" -skip {
        $JsonESB_Add = @(
            @{
                Subscription = "CMFG-Sandbox"
                Resources    = @(
                    @{
                        ResourceType     = "Service Bus"
                        PermissionsArray = @(
                            @{
                                Name        = $CONST_TARGET_NAMESPACE
                                Identity    = "This sure better not resolve as an ID"
                                Permissions = @($CONST_TARGET_PERMS)
                            }
                        )
                    }
                )
            }
        )
        #strip any newlines, carriage returns, and tabs -- not required but cleans up input for logs
        [string]$Payload = $JsonESB_Add | ConvertTo-Json -Depth 10
        Write-Verbose "Permission Payload: $Payload" -Verbose

        $Params = @{"Payload" = $Payload }
        { Invoke-AtlasSelfServeRunbook -RunbookName $CONST_RESOURCE_PERMISSIONS_RUNBOOK_NAME -Parameters $Params } | Should -Throw
    }
}