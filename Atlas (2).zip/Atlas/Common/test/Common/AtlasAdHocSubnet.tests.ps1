# to levelset, these tests require a source
# and destination resource of each type to adequately complete.
# if any of the destination resources are missing or unavailable, we're going
# to see all these tests fail regardless of any functional changes.
Describe "AtlasAllowedSubnet Tests" {
    BeforeAll {

        . "$env:COMMON_FOLDER/test/Common/_includes.tests.ps1"


        $REFERENCE_RESOURCE_GROUP = "RG-CMFG-EA2-Test-Atlas-ResourcePermissions"
        $REFERNECE_SUBSCRIPTION = "CMFG-Sandbox"

        $REFERENCE_AKS_RESOURCE = "AKS-NP1-RP-Test"
        $REFERENCE_AKS_SUBNET_ID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-RP-Test/subnets/rp-test-private-subnet"

        $REFERENCE_WEB_APP_RESOURCE = "AS-WEB-Test-Subnets"
        $REFERENCE_WEB_APP_SUBNET_ID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Testing/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-Atlas-Atlantis/subnets/88a4285f-fad4-4157-a453-48fe27e7f9c7-private-subnet-v1"

        $REFERENCE_FUNCTION_APP_RESOURCE = "AS-FA-Test-Subnets"
        $REFERENCE_FUNCTION_APP_SUBNET_ID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Testing/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-Atlas-Atlantis/subnets/49cb8034-9bbd-459d-a0d2-930e4f9d58f3-privatefunctions-subnet-v1"

        $REFERENCE_SERVICE_BUS_RESOURCE = "Atlas-Sandbox-Test-ESB"
        $REFERENCE_STORAGE_ACCOUNT_RESOURCE = "saatlassandboxtest"
        $REFERENCE_KEY_VAULT_RESOURCE = "kv-Atlas-Sandbox-TestRP"
        $REFERENCE_SQL_SERVER_RESOURCE = "sql-networking-testing-subnets"
        $REFERENCE_EVENT_HUB_RESOURCE = "atlas-rp-test-eh"

        $rgInfo = az group show -n $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json

    }


    It "Get-AtlasResourceFromInputs Function Available" {
        (Get-ChildItem function:/).Name | Should -Contain "Get-AtlasResourceFromInputs"
    }


    It "Reference resource group exists" {
        # will error if RG doesn't exist
        $rgInfo | Should -Not -Be $null
    }

    It "Not Tagged as currently performing tests" {
        $rgInfo.tags.CurrentTest | Should -Be $null
    }


    It "All required reference resources exist in reference RG" {
        $resources = az resource list -g $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
        $resources.name | Should -Contain $REFERENCE_AKS_RESOURCE
        $resources.name | Should -Contain $REFERENCE_FUNCTION_APP_RESOURCE
        $resources.name | Should -Contain $REFERENCE_WEB_APP_RESOURCE
        $resources.name | Should -Contain $REFERENCE_SERVICE_BUS_RESOURCE
        $resources.name | Should -Contain $REFERENCE_STORAGE_ACCOUNT_RESOURCE
        $resources.name | Should -Contain $REFERENCE_KEY_VAULT_RESOURCE
        $resources.name | Should -Contain $REFERENCE_SQL_SERVER_RESOURCE
    }

    ##############################################
    # Service Bus
    ##############################################
    Context "Service Bus Network Rule Tests" {
        BeforeAll {
            $existingRulesVirtualNetworkRules = Clean-ServiceBusNetworkRules -namespace $REFERENCE_SERVICE_BUS_RESOURCE `
            -resourceGroup $REFERENCE_RESOURCE_GROUP
            Write-Verbose "Existing SB Rules: $existingRulesVirtualNetworkRules" -Verbose
        }


        It "Pre-Test Cleanup and Verification Complete" {
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }

        It "Adds AKS Cluster correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null
            $existingRules = az servicebus namespace network-rule list --namespace-name $REFERENCE_SERVICE_BUS_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_AKS_SUBNET_ID
        }

        It "Bug 1519768 -- Ensure Duplicate Rule not Added" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null
            $existingRules = az servicebus namespace network-rule list --namespace-name $REFERENCE_SERVICE_BUS_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_AKS_SUBNET_ID

            # there should not be more than one of these same rules
            $existingRuleCount = ($existingRules.virtualNetworkRules.subnet.id | Where-Object { $_ -eq $REFERENCE_AKS_SUBNET_ID }).Count
            $existingRuleCount | Should -Be 1
        }

        It "Adds Function App correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_FUNCTION_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az servicebus namespace network-rule list --namespace-name $REFERENCE_SERVICE_BUS_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_FUNCTION_APP_SUBNET_ID
        }

        It "Adds Web App correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_WEB_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az servicebus namespace network-rule list --namespace-name $REFERENCE_SERVICE_BUS_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_WEB_APP_SUBNET_ID
        }

        It "Adds Web App Second Time While Already Existing -- Correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_WEB_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az servicebus namespace network-rule list --namespace-name $REFERENCE_SERVICE_BUS_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_WEB_APP_SUBNET_ID
        }

        It "Removes Subnet correctly" {
            $existingRules = az servicebus namespace network-rule list --namespace-name $REFERENCE_SERVICE_BUS_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            if ($existingRules.virtualNetworkRules -and $existingRules.virtualNetworkRules.subnet -and $existingRules.virtualNetworkRules.subnet.id) {
                $ruleToRemove = $existingRules.virtualNetworkRules.subnet.id[0]
                . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceSubnetId $ruleToRemove 4> $null

                $existingRules = az servicebus namespace network-rule list --namespace-name $REFERENCE_SERVICE_BUS_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
                $existingRules.virtualNetworkRules.subnet.id | Should -Not -Contain $ruleToRemove
            }
            else {
                Write-Warning "Unable to discover any pre-existing rules assigned. Skipping assertion..."
            }
        }

        It "Post-Test Cleanup and Verification Complete" {
            . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -allSubnets $true
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }
    }

    ##############################################
    # Storage Account
    ##############################################
    Context "Storage Account Network Rule Tests" {
        BeforeAll {
            $existingRulesVirtualNetworkRules = Clean-StorageAccountNetworkRules -storageAccount $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
            -resourceGroup $REFERENCE_RESOURCE_GROUP
        }

        It "Pre-Test Cleanup and Verification Complete" {
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }

        It "Adds AKS Cluster correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az storage account network-rule  list --account-name $REFERENCE_STORAGE_ACCOUNT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.virtualNetworkResourceId | Should -Contain $REFERENCE_AKS_SUBNET_ID
        }

        It "Bug 1519768 -- Ensure Duplicate Rule not Added" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az storage account network-rule  list --account-name $REFERENCE_STORAGE_ACCOUNT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.virtualNetworkResourceId | Should -Contain $REFERENCE_AKS_SUBNET_ID

            # there should not be more than one of these same rules
            $existingRuleCount = ($existingRules.virtualNetworkRules.virtualNetworkResourceId | Where-Object { $_ -eq $REFERENCE_AKS_SUBNET_ID }).Count
            $existingRuleCount | Should -Be 1
        }

        It "Adds Function App correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_FUNCTION_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az storage account network-rule  list --account-name $REFERENCE_STORAGE_ACCOUNT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.virtualNetworkResourceId | Should -Contain $REFERENCE_FUNCTION_APP_SUBNET_ID
        }

        It "DOES NOT ADD. Backend restriction -- Web App" {
            $tempPreference = $ErrorActionPreference
            $ErrorActionPreference = "Stop"
            { . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceResourceName $REFERENCE_WEB_APP_RESOURCE `
                    -sourceResourceGroup $REFERENCE_RESOURCE_GROUP *> $null } | Should -Throw
            $ErrorActionPreference = $tempPreference

            $existingRules = az storage account network-rule  list --account-name $REFERENCE_STORAGE_ACCOUNT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.virtualNetworkResourceId | Should -Not -Contain $REFERENCE_WEB_APP_SUBNET_ID
        }

        It "Removes Subnet correctly" {
            $existingRules = az storage account network-rule  list --account-name $REFERENCE_STORAGE_ACCOUNT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json

            if ($existingRules.virtualNetworkRules -and $existingRules.virtualNetworkRules.virtualNetworkResourceId) {
                $ruleToRemove = $existingRules.virtualNetworkRules.virtualNetworkResourceId[0]
                . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceSubnetId $ruleToRemove 4> $null

                $existingRules = az storage account network-rule  list --account-name $REFERENCE_STORAGE_ACCOUNT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
                $existingRules.virtualNetworkRules.virtualNetworkResourceId | Should -Not -Contain $ruleToRemove
            }
            else {
                Write-Warning "Unable to discover any pre-existing rules assigned. Skipping assertion..."
            }
        }

        It "Post-Test Cleanup and Verification Complete" {
            . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -allSubnets $true
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }
    }

    ##############################################
    # Key Vault
    ##############################################
    Context "Key Vault Network Rule Tests" {
        BeforeAll {
            $existingRulesVirtualNetworkRules = Clean-KeyVaultNetworkRules -keyVault $REFERENCE_KEY_VAULT_RESOURCE `
            -resourceGroup $REFERENCE_RESOURCE_GROUP
        }

        It "Pre-Test Cleanup and Verification Complete" {
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }

        It "Adds AKS Cluster correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az keyvault network-rule  list --name $REFERENCE_KEY_VAULT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.id | Should -Contain $REFERENCE_AKS_SUBNET_ID
        }

        It "Bug 1519768 -- Ensure Duplicate Rule not Added" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az keyvault network-rule  list --name $REFERENCE_KEY_VAULT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.id | Should -Contain $REFERENCE_AKS_SUBNET_ID

            # there should not be more than one of these same rules
            $existingRuleCount = ($existingRules.virtualNetworkRules.id | Where-Object { $_ -eq $REFERENCE_AKS_SUBNET_ID }).Count
            $existingRuleCount | Should -Be 1
        }

        It "Adds Function App correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_FUNCTION_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az keyvault network-rule  list --name $REFERENCE_KEY_VAULT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.id | Should -Contain $REFERENCE_FUNCTION_APP_SUBNET_ID
        }

        It "Adds Web App correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_WEB_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az keyvault network-rule  list --name $REFERENCE_KEY_VAULT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.id | Should -Contain $REFERENCE_WEB_APP_SUBNET_ID
        }

        It "Adds Web App Second Time While Already Existing -- Correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_WEB_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az keyvault network-rule  list --name $REFERENCE_KEY_VAULT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.id | Should -Contain $REFERENCE_WEB_APP_SUBNET_ID
        }

        It "Removes Subnet correctly" {
            $existingRules = az keyvault network-rule  list --name $REFERENCE_KEY_VAULT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            if ($existingRules.virtualNetworkRules -and $existingRules.virtualNetworkRules.id) {
                $ruleToRemove = $existingRules.virtualNetworkRules.id[0]
                . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceSubnetId $ruleToRemove 4> $null

                $existingRules = az keyvault network-rule  list --name $REFERENCE_KEY_VAULT_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
                $existingRules.virtualNetworkRules.id | Should -Not -Contain $ruleToRemove
            }
            else {
                Write-Warning "Unable to discover any pre-existing rules assigned. Skipping assertion..."
            }
        }

        It "Post-Test Cleanup and Verification Complete" {
            . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -allSubnets $true
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }
    }

    ##############################################
    # SQL
    ##############################################
    Context "Sql Server Network Rule Tests" {
        BeforeAll {
            # confirm/set resource to have no network rules at test time
            $existingRulesVirtualNetworkRules = Clean-SqlServerNetworkRules -sqlServer $REFERENCE_SQL_SERVER_RESOURCE `
            -resourceGroup $REFERENCE_RESOURCE_GROUP
        }


        It "Pre-Test Cleanup and Verification Complete" {
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }

        It "Adds AKS Cluster correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SQL_SERVER_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az sql server vnet-rule  list --server $REFERENCE_SQL_SERVER_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkSubnetId | Should -Contain $REFERENCE_AKS_SUBNET_ID
        }

        It "Bug 1519768 -- Ensure Duplicate Rule not Added" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SQL_SERVER_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az sql server vnet-rule  list --server $REFERENCE_SQL_SERVER_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkSubnetId | Should -Contain $REFERENCE_AKS_SUBNET_ID

            # there should not be more than one of these same rules
            $existingRuleCount = ($existingRules.virtualNetworkSubnetId | Where-Object { $_ -eq $REFERENCE_AKS_SUBNET_ID }).Count
            $existingRuleCount | Should -Be 1
        }

        It "Adds Function App correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SQL_SERVER_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_FUNCTION_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az sql server vnet-rule  list --server $REFERENCE_SQL_SERVER_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkSubnetId | Should -Contain $REFERENCE_FUNCTION_APP_SUBNET_ID
        }

        It "DOES NOT ADD. Backend restriction -- Web App" {
            $tempPreference = $ErrorActionPreference
            $ErrorActionPreference = "Stop"
            { . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SQL_SERVER_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceResourceName $REFERENCE_WEB_APP_RESOURCE `
                    -sourceResourceGroup $REFERENCE_RESOURCE_GROUP *> $null } | Should -Throw
            $ErrorActionPreference = $tempPreference

            $existingRules = az sql server vnet-rule  list --server $REFERENCE_SQL_SERVER_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkSubnetId | Should -Not -Contain $REFERENCE_WEB_APP_SUBNET_ID
        }

        It "Removes Subnet correctly" {
            $existingRules = az sql server vnet-rule  list --server $REFERENCE_SQL_SERVER_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            if ($existingRules.virtualNetworkSubnetId) {
                $ruleToRemove = $existingRules.virtualNetworkSubnetId[0]
                . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SQL_SERVER_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceSubnetId $ruleToRemove 4> $null

                $existingRules = az sql server vnet-rule  list --server $REFERENCE_SQL_SERVER_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
                $existingRules.virtualNetworkSubnetId | Should -Not -Contain $ruleToRemove
            }
            else {
                Write-Warning "Unable to discover any pre-existing rules assigned. Skipping assertion..."
            }
        }

        It "Post-Test Cleanup and Verification Complete" {
            . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SQL_SERVER_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -allSubnets $true
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }
    }

    ##############################################
    # Event Hubs
    ##############################################
    Context "Event Hub Network Rule Tests" {
        BeforeAll {
            # confirm/set resource to have no network rules at test time
            $existingRulesVirtualNetworkRules = Clean-EventHubsNetworkRules -namespace $REFERENCE_EVENT_HUB_RESOURCE `
            -resourceGroup $REFERENCE_RESOURCE_GROUP
        }


        It "Pre-Test Cleanup and Verification Complete" {
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }

        It "Adds AKS Cluster correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_EVENT_HUB_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az eventhubs namespace network-rule list --namespace-name $REFERENCE_EVENT_HUB_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_AKS_SUBNET_ID
        }

        It "Bug 1519768 -- Ensure Duplicate Rule not Added" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_EVENT_HUB_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceType "Microsoft.ContainerService/managedClusters" `
                -sourceResourceName $REFERENCE_AKS_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az eventhubs namespace network-rule list --namespace-name $REFERENCE_EVENT_HUB_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_AKS_SUBNET_ID
            # there should not be more than one of these same rules
            $existingRuleCount = ($existingRules.virtualNetworkRules.subnet.id | Where-Object { $_ -eq $REFERENCE_AKS_SUBNET_ID }).Count
            $existingRuleCount | Should -Be 1
        }

        # currently being skipped as the Service Endpoint is not present on the target infrastructure, and the guardrail will
        # complain as-is.
        It "Adds Function App correctly" {
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_EVENT_HUB_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_FUNCTION_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az eventhubs namespace network-rule list --namespace-name $REFERENCE_EVENT_HUB_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_FUNCTION_APP_SUBNET_ID
        }

        # same reason as the Function App above. Need to come back and re-test after enabling Service Endpoints
        It "Adds Web App correctly" {
            $tempPreference = $ErrorActionPreference
            . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_EVENT_HUB_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -sourceResourceName $REFERENCE_WEB_APP_RESOURCE `
                -sourceResourceGroup $REFERENCE_RESOURCE_GROUP 4> $null

            $existingRules = az eventhubs namespace network-rule list --namespace-name $REFERENCE_EVENT_HUB_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            $existingRules.virtualNetworkRules.subnet.id | Should -Contain $REFERENCE_WEB_APP_SUBNET_ID
        }

        It "Removes Subnet correctly" {
            $existingRules = az eventhubs namespace network-rule list --namespace-name $REFERENCE_EVENT_HUB_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            if ($existingRules.virtualNetworkRules.subnet.id) {
                $ruleToRemove = $existingRules.virtualNetworkRules.subnet.id[0]
                . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_EVENT_HUB_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceSubnetId $ruleToRemove 4> $null

                $existingRules = az eventhubs namespace network-rule list --namespace-name $REFERENCE_EVENT_HUB_RESOURCE --resource-group $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
                $existingRules.virtualNetworkRules.subnet.id | Should -Not -Contain $ruleToRemove
            }
            else {
                Write-Warning "Unable to discover any pre-existing rules assigned. Skipping assertion..."
            }
        }

        It "Post-Test Cleanup and Verification Complete" {
            . "$env:DEPLOY_FOLDER/Common/RemoveAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_EVENT_HUB_RESOURCE `
                -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                -allSubnets $true
            $existingRulesVirtualNetworkRules.Count | Should -Be 0
        }
    }



    Context "Source Compute Resource Negative Validation" {
        # test with a source resource that isn't in the allowed list of resource to confirm failure
        It "Fails when passing a Service Bus as source resource" {
            { . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                    -sourceResourceGroup $REFERENCE_RESOURCE_GROUP } | Should -Throw
        }

        It "Fails when passing a Storage Account as source resource" {
            { . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceResourceName $REFERENCE_STORAGE_ACCOUNT_RESOURCE `
                    -sourceResourceGroup $REFERENCE_RESOURCE_GROUP } | Should -Throw
        }

        It "Fails when passing a Key Vault as source resource" {
            { . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceResourceName $REFERENCE_KEY_VAULT_RESOURCE `
                    -sourceResourceGroup $REFERENCE_RESOURCE_GROUP } | Should -Throw
        }

        It "Fails when passing a Sql Server as source resource" {
            { . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceResourceName $REFERENCE_SQL_SERVER_RESOURCE `
                    -sourceResourceGroup $REFERENCE_RESOURCE_GROUP } | Should -Throw
        }

        It "Fails when passing an Event Hub as source resource" {
            { . "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $REFERENCE_SERVICE_BUS_RESOURCE `
                    -targetResourceGroup $REFERENCE_RESOURCE_GROUP `
                    -sourceResourceName $REFERENCE_EVENT_HUB_RESOURCE `
                    -sourceResourceGroup $REFERENCE_RESOURCE_GROUP } | Should -Throw
        }
        AfterAll {
            $rgInfo = az group show -n $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
            # Post testing cleanup
            if ($rgInfo.tags.CurrentTest) {
                $tags = @()
                foreach ($tag in $rgInfo.tags.psobject.properties) {
                    if ($tag.Name -ne "CurrentTest") {
                        $tags += "$($tag.Name)=$($tag.Value)"
                    }
                }
                $result = $(az group update --name $REFERENCE_RESOURCE_GROUP --tags $tags)
                Write-Verbose "Removed CurrentTest tag from Resource Group." -Verbose
            }
        }
    }

}