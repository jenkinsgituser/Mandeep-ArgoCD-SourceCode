

Describe "Logging Utilities Unit Tests" {
    BeforeAll {
        . ("$env:COMMON_FOLDER/test/Common/_includes.tests.ps1")
    }
    Context "Get-AppInsightsInstrumentationKey tests" {
        It "Returns the sandbox key when passing in sandbox subscription" {
            $SUBSCRIPTION_NAME = "CMFG-Sandbox"

            Mock Get-AzKeyVaultSecret -ParameterFilter { $vaultName -eq $CONST_KV_SANDBOX_NP } { return New-Object PSObject -Property @{"SecretValue" = (ConvertTo-SecureString -String "nonprodkey" -AsPlainText -Force) } }
            Mock Get-SubscriptionProperties -ParameterFilter {$SubscriptionName -eq $SUBSCRIPTION_NAME}  {return @{Environment = "Sandbox" }}
            Get-AppInsightsInstrumentationKey | Should -be "nonprodkey"
        }
        It "returns the prod key when passing in prod subscription" {
            $SUBSCRIPTION_NAME = "CMFG Production"

            Mock Get-AzKeyVaultSecret -ParameterFilter { $vaultName -eq $CONST_KV_SHAREDSVCS_P } { return New-Object PSObject -Property @{"SecretValue" = (ConvertTo-SecureString -String "prodkey" -AsPlainText -Force) } }
            Mock Get-SubscriptionProperties -ParameterFilter {$SubscriptionName -eq $SUBSCRIPTION_NAME}  {return @{Environment = "Prod" }}
            Get-AppInsightsInstrumentationKey | Should -be "prodkey"
        }
        It "returns the prod key when passing in nonprod subscription" {
            $SUBSCRIPTION_NAME = "CMFG Non-Production"

            Mock Get-AzKeyVaultSecret -ParameterFilter { $vaultName -eq $CONST_KV_SHAREDSVCS_NP } { return New-Object PSObject -Property @{"SecretValue" = (ConvertTo-SecureString -String "nonprodkey" -AsPlainText -Force) } }
            Mock Get-SubscriptionProperties -ParameterFilter {$SubscriptionName -eq $SUBSCRIPTION_NAME}  {return @{Environment = "NonProd" }}
            Get-AppInsightsInstrumentationKey | Should -be "nonprodkey"
        }
        It "Throws an exception when using an invalid subscription" {
            $SUBSCRIPTION_NAME = "CMFG Production"

            Mock Get-SubscriptionProperties -ParameterFilter {$SubscriptionName -eq $SUBSCRIPTION_NAME}  {return $null }
            { Get-AppInsightsInstrumentationKey } | Should -Throw
        }
    }
}