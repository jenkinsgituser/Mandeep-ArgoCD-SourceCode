

Describe "Add and Remove Purpose Tag Tests" {
    BeforeAll {
        . ("$env:COMMON_FOLDER/test/Common/_includes.tests.ps1")

        $CONST_KV_NAME = $( if ($env:KV_NAME) { $env:KV_NAME } else { "kv-buildtesting" })
        $CONST_KV_RG = $( if ($env:KV_RG_NAME) { $env:KV_RG_NAME } else { "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared" })
        $CONST_RESOURCE_TYPE = "Microsoft.KeyVault/vaults"
        $CONST_TAG_VALUE = "Atlas-FunctionApp"
        $EXPECTED_REMOVE_TAG_VALUE = $null
        $EXPECTED_ADD_TAG_VALUE = "Atlas-FunctionApp"

        Remove-AtlasPurposeTag -resourceGroup $CONST_KV_RG -resourceName $CONST_KV_NAME -tagValueToRemove $CONST_TAG_VALUE -resourceType $CONST_RESOURCE_TYPE

        $initialTags = @{ }
        $initialTags = Invoke-RetryGetTags -resourceName $CONST_KV_NAME -resourceGroup $CONST_KV_RG -resourceType $CONST_RESOURCE_TYPE `
            -tagOfInterest "AtlasPurpose" -action "Remove" 4> $null

    }

    It "Remove function works" {
        $initialTags["AtlasPurpose"] | Should -Not -Match $EXPECTED_ADD_TAG_VALUE
    }


    It "Add function works" {
        Add-AtlasPurposeTag -resourceGroup $CONST_KV_RG -resourceName $CONST_KV_NAME -tagValueToAdd $CONST_TAG_VALUE -resourceType $CONST_RESOURCE_TYPE

        $addTags = @{ }
        $addTags = Invoke-RetryGetTags -resourceName $CONST_KV_NAME -resourceGroup $CONST_KV_RG `
            -resourceType $CONST_RESOURCE_TYPE -tagOfInterest "AtlasPurpose" -action "Add" 4> $null


        $addTags["AtlasPurpose"] | Should -Not -Be $null
        $addTags["AtlasPurpose"] | Should -Match $EXPECTED_ADD_TAG_VALUE

    }

    It "Remove function works again" {
        Remove-AtlasPurposeTag -resourceGroup $CONST_KV_RG -resourceName $CONST_KV_NAME -tagValueToRemove $CONST_TAG_VALUE -resourceType $CONST_RESOURCE_TYPE

        $finalTags = @{ }
        $finalTags = Invoke-RetryGetTags -resourceName $CONST_KV_NAME -resourceGroup $CONST_KV_RG `
            -resourceType $CONST_RESOURCE_TYPE -tagOfInterest "AtlasPurpose" -action "Remove" 4> $null


        $finalTags["AtlasPurpose"] | Should -Not -Match $EXPECTED_ADD_TAG_VALUE
    }


}

Describe "Validate-ResourceGroupExists" {
    It "FindMockedResourceGroup" {
        $MockedResourceGroup = (New-Guid)
        Mock  Get-AzResourceGroup { return @{resourcegroupname = $MockedResourceGroup } }
        $result = Validate-ResourceGroupExists -resourcegroupname $MockedResourceGroup
        Assert-MockCalled Get-AzResourceGroup

        $result | Should -Be $true
    }
    It "MockedNotFoundResourceGroup" {
        $MockedResourceGroup = (New-Guid)
        Mock  Get-AzResourceGroup { return $null }
        $result = Validate-ResourceGroupExists -resourcegroupname $MockedResourceGroup
        Assert-MockCalled Get-AzResourceGroup
        $result | Should -Be $false
    }
    It "NotFoundRemoteResourceGroup" {
        $result = Validate-ResourceGroupExists -resourcegroupname (New-Guid)
        $result | Should -Be $false
    }
}


# could be refactored to pull these resources from an input object.
# as-is will fail if these resources are not present
Describe "Get-AtlasResourceFromInputs Test" {
    BeforeAll {
        $REFERENCE_RESOURCE_GROUP = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
        $REFERNECE_SUBSCRIPTION = "CMFG-Sandbox"

        $REFERENCE_RESOURCE_ONE_NAME = "AGWAF-CMFG-EA2-NP1-TEST"
        $REFERENCE_RESOURCE_TWO_NAME = "as-infrasharedtest1"
        $REFERENCE_RESOURCE_THREE_NAME = "MI-Atlas-Build-Shared"

        $REFERENCE_RESOURCE_DUPLICATE_NAME = "kv-buildtesting"
        $DUPLICATE_TARGET_RESOURCE_TYPE = "Microsoft.KeyVault/vaults"
        $REFERENCE_RESOURCE_DOES_NOT_EXIST = "theresnowaythisresourcenamewillbeusedKAG"
    }


    It "Get-AtlasResourceFromInputs Function Available" {
        (Get-ChildItem function:/).Name | Should -Contain "Get-AtlasResourceFromInputs"
    }

    It "Reference resource group exists" {
        # will error if RG doesn't exist
        az group show -n $REFERENCE_RESOURCE_GROUP | Should -Not -Be $null
    }


    It "Reference resources all exist in group" {
        $resources = az resource list -g $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
        $resources.name | Should -Contain $REFERENCE_RESOURCE_ONE_NAME
        $resources.name | Should -Contain $REFERENCE_RESOURCE_TWO_NAME
        $resources.name | Should -Contain $REFERENCE_RESOURCE_THREE_NAME
    }

    It "Finds initial resource - no duplicate" {
        $result = Get-AtlasResourceFromInputs -resourceName $REFERENCE_RESOURCE_ONE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP
        $result | Should -Not -Be $null
        $result.name | Should -Be $REFERENCE_RESOURCE_ONE_NAME
    }

    It "Finds initial resource2 - no duplicate" {
        $result = Get-AtlasResourceFromInputs -resourceName $REFERENCE_RESOURCE_TWO_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP
        $result | Should -Not -Be $null
        $result.name | Should -Be $REFERENCE_RESOURCE_TWO_NAME
    }

    It "Finds initial resource3 - no duplicate" {
        $result = Get-AtlasResourceFromInputs -resourceName $REFERENCE_RESOURCE_THREE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP
        $result | Should -Not -Be $null
        $result.name | Should -Be $REFERENCE_RESOURCE_THREE_NAME
    }

    It "Fails when duplicates exist - no resource type passed" {
        { Get-AtlasResourceFromInputs -resourceName $REFERENCE_RESOURCE_DUPLICATE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP } | Should -Throw
    }

    It "Succeeds when duplicates exist - resource type passed" {
        $result = Get-AtlasResourceFromInputs -resourceName $REFERENCE_RESOURCE_DUPLICATE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP -resourceType $DUPLICATE_TARGET_RESOURCE_TYPE
        $result | Should -Not -Be $null
        $result.name | Should -Be $REFERENCE_RESOURCE_DUPLICATE_NAME
        $result.type | Should -Be $DUPLICATE_TARGET_RESOURCE_TYPE
    }

    It "Fails when no resource found" {
        { Get-AtlasResourceFromInputs -resourceName $REFERENCE_RESOURCE_DOES_NOT_EXIST -resourceGroup $REFERENCE_RESOURCE_GROUP } | Should -Throw
    }
}

Describe "Set-TagOnAtlasResource Tests" {
    BeforeAll {
        $REFERENCE_RESOURCE_GROUP = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
        $REFERNECE_SUBSCRIPTION = "CMFG-Sandbox"

        $targetResourcePrefix = "MI-Atlas-Build-CommonTesting-"
        $REFERENCE_RESOURCE_ONE_NAME = "$targetResourcePrefix-$(New-Guid)"
        Write-Verbose -Verbose "Test resource to be created with name $REFERENCE_RESOURCE_ONE_NAME"

        $REFERENCE_RESOURCE_ONE_TYPE = "Microsoft.ManagedIdentity/userAssignedIdentities"

        $kagTag1 = "KAG"
        $kagTag2 = "KAG2"
        $kagTag3 = "KAG3"
    }


    It "Set-TagOnAtlasResource Function Available" {
        (Get-ChildItem function:/).Name | Should -Contain "Set-TagOnAtlasResource"
    }

    It "Reference resource group exists" {
        # will error if RG doesn't exist
        az group show -n $REFERENCE_RESOURCE_GROUP | Should -Not -Be $null
    }


    It "Reference resource exists" {
        # create an identity for testing
        az identity create --name $REFERENCE_RESOURCE_ONE_NAME --resource-group $REFERENCE_RESOURCE_GROUP

        $resource = az resource list -g $REFERENCE_RESOURCE_GROUP | ConvertFrom-Json
        $resource.name | Should -Contain $REFERENCE_RESOURCE_ONE_NAME
    }



    It "No KAG Tags to Start" {
        # need to manage the tags as an array rather than a string due to the pipes in some of the tags
        $initialTags = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags"
        $tagsOrig = @()
        foreach ($tag in $initialTags.psobject.properties) {
            $tags += "$($tag.Name)=$($tag.Value)"
        }
        $tags = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags"
        $tags.$kagTag1 | Should -Be $null
        $tags.$kagTag2 | Should -Be $null
    }

    It "Set KAG Tag Resource" {
        Set-TagOnAtlasResource -resourceName $REFERENCE_RESOURCE_ONE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP -tagName $kagTag1 -tagValue $kagTag1 -resourceType $REFERENCE_RESOURCE_ONE_TYPE
        $tagsUpdated = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags" | ConvertFrom-Json
        $tagsUpdated.$kagTag1 | Should -Be $kagTag1
    } 4> $null

    It "Set KAG2 Tag Resource" {
        Set-TagOnAtlasResource -resourceName $REFERENCE_RESOURCE_ONE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP -tagName $kagTag2 -tagValue $kagTag2 -resourceType $REFERENCE_RESOURCE_ONE_TYPE
        $tagsUpdated = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags" | ConvertFrom-Json
        $tagsUpdated.$kagTag2 | Should -Be $kagTag2
    } 4> $null

    It "Update KAG Tag " {
        $tagsUpdated = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags" | ConvertFrom-Json
        $tagsUpdated.$kagTag1 | Should -Be $kagTag1

        Set-TagOnAtlasResource -resourceName $REFERENCE_RESOURCE_ONE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP -tagName $kagTag1 -tagValue $kagTag3 -resourceType $REFERENCE_RESOURCE_ONE_TYPE
        $tagsUpdated = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags" | ConvertFrom-Json
        $tagsUpdated.$kagTag1 | Should -Be $kagTag3
    } 4> $null

    It "Update KAG2 Tag" {
        $tagsUpdated = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags" | ConvertFrom-Json
        $tagsUpdated.$kagTag2 | Should -Be $kagTag2

        Set-TagOnAtlasResource -resourceName $REFERENCE_RESOURCE_ONE_NAME -resourceGroup $REFERENCE_RESOURCE_GROUP -tagName $kagTag2 -tagValue $kagTag3 -resourceType $REFERENCE_RESOURCE_ONE_TYPE

        $tagsUpdated = az resource show -n $REFERENCE_RESOURCE_ONE_NAME -g $REFERENCE_RESOURCE_GROUP --resource-type $REFERENCE_RESOURCE_ONE_TYPE --query "tags" | ConvertFrom-Json
        $tagsUpdated.$kagTag2 | Should -Be $kagTag3
    } 4> $null


    It "Reference resource no longer exists" {

        # get and delete all Ids that match target prefix in case we've had poor cleanup from prior tests
        $idsToDelete = $(az identity list -g $REFERENCE_RESOURCE_GROUP) | ConvertFrom-Json
        $idsToDelete | Where-Object { $_.name -match $targetResourcePrefix } | ForEach-Object {
        Write-Verbose "Deleting identity $($_.name)..." -Verbose
        az identity delete --name $_.name --resource-group $REFERENCE_RESOURCE_GROUP
        }

        $resource = $(az resource list -g $REFERENCE_RESOURCE_GROUP) | ConvertFrom-Json | Where-Object { $_.name -match $targetResourcePrefix }
        $resource.name | Should -Be $null
    }

}
Describe "Validate-TargetSourceSubscriptionIsAtlasAllowed" {

    It "Throw an error if the target subscription is in sandbox but the source subscription is in Nonprod" {
        $targetSubscriptionName = "cmfg-sandbox"
        $sourceSubscriptionName = "cmfg nonproduction"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Throw
    }
    It "Throw an error if the target subscription is in sandbox but the source subscription is in prod" {
        $targetSubscriptionName = "cmfg-sandbox"
        $sourceSubscriptionName = "cmfg production"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Throw
    }
    It "Throw an error if the target subscription is in nonprod but the source subscription is in sandbox" {
        $targetSubscriptionName = "cmfg nonproduction"
        $sourceSubscriptionName = "cmfg-sandbox"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Throw
    }
    It "Throw an error if the target subscription is in nonprod but the source subscription is in prod" {
        $targetSubscriptionName = "cmfg nonproduction"
        $sourceSubscriptionName = "cmfg production"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Throw
    }
    It "Throw an error if the target subscription is in prod but the source subscription is in sandbox" {
        $targetSubscriptionName = "cmfg production"
        $sourceSubscriptionName = "cmfg-sandbox"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Throw
    }
    It "Throw an error if the target subscription is in prod but the source subscription is in nonprod" {
        $targetSubscriptionName = "cmfg production"
        $sourceSubscriptionName = "cmfg nonproduction"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Throw
    }
    It "Both source subscription and target subscription are in sandbox subscriptions" {
        $targetSubscriptionName = "cmfg-sandbox"
        $sourceSubscriptionName = "cmfg-sandbox"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Not -Throw
    }
    It "Both source subscription and target subscription are in same NonProd subscriptions" {
        $targetSubscriptionName = "cmfg nonproduction"
        $sourceSubscriptionName = "cmfg nonproduction"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Not -Throw
    }
    It "Both source subscription and target subscription are in different NonProd subscriptions" {
        $targetSubscriptionName = "cmfg nonproduction"
        $sourceSubscriptionName = "Lending-Nonprod"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Not -Throw
    }
    It "Both source subscription and target subscription are in same Prod subscriptions" {
        $targetSubscriptionName = "cmfg production"
        $sourceSubscriptionName = "cmfg production"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Not -Throw
    }
    It "Both source subscription and target subscription are in different Prod subscriptions" {
        $targetSubscriptionName = "cmfg production"
        $sourceSubscriptionName = "Lending-Prod"
        { Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName } | Should -Not -Throw
    }
}

