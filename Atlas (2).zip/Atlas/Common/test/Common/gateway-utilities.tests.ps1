
Describe "Gateway Utility Tests" {
    BeforeAll {
        . "$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
        . "$env:COMMON_FOLDER/gateway-utilities.ps1"
        . "$env:COMMON_FOLDER/azure-utilities.ps1"

        $TESTFILEPATH = "$env:INFRA_FOLDER/AppGateway/WAFv2/src/azuredeployGatewayWAF_v2_ssl_editted.json"

    }


    It "Main Script can be dot sourced" {
        (Get-ChildItem function:/).Name | Should -Contain "Get-AGParametersFile"
    }

    Describe "Set-DefaultAGProperties Tests" {
        BeforeAll {
            $TESTSUBSCRIPTION = "4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe"
            $TESTENVIRONMENT = "NonProd"
            $TESTRESOURCEGROUP = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
            $TESTAGWAFNAME = "AGWAF-CMFG-EA2-NP1-Atlas-Test"
            $TESTAPPNAME = "Atlas-Test"
            $TESTHOSTNAME = "atlas-test.atlasbeta.cunamutual.com"
            $TESTSSLCERTNAME = ""
            $TESTVNETRGNAME = ""
            $TESTVNETNAME = ""
            $TESTSUBNETNAME = ""
            $TESTAGWAFLOCATION = "eastus2"

            $RESULT = Set-DefaultAGProperties -subscription $TESTSUBSCRIPTION -environment $TESTENVIRONMENT -resourceGroup $TESTRESOURCEGROUP -agWafName $TESTAGWAFNAME `
                -appName $TESTAPPNAME -hostName $TESTHOSTNAME -sslCertName $TESTSSLCERTNAME -vnetRGName $TESTVNETRGNAME -vnetName $TESTVNETNAME -subnetName $TESTSUBNETNAME `
                -agWafLocation $TESTAGWAFLOCATION
            $Path = "$RESULT"
            $TESTFILEPATH = $Path
            if (!(Test-Path -Path $Path)) {
                Write-Error "ERROR: Required file '$Path' cannot be found"
                Exit 1
            }

            if ($($Path | Measure-Object).Count -gt 1) {
                $Path = $Path[0]
            }
            $RESULTOBJECT = $(Get-Content -Path $Path) | ConvertFrom-Json

            $EXPECTEDSUBNETID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/rg-cmfg-np1-atlas-infrastructure/providers/Microsoft.Network/virtualNetworks/vnet-cmfg-atlas-atlantis/subnets/vnet-cmfg-atlas-atlantis-cmfg-subnet-v1"
        }

        It "Function Sets Correct Subnet ID" {
            $RESULTOBJECT.gatewayIPConfigurations | Should -Not -Be $null
            $RESULTOBJECT.gatewayIPConfigurations.properties.subnet.id | Should -Not -Be $null
            $RESULTOBJECT.gatewayIPConfigurations.properties.subnet.id | Should -Match $EXPECTEDSUBNETID
        }


        It "Function Sets Proper SSL Cert Names" {
            $EXPECTEDSSLCERTNAME = "WILDCARD_ATLASBETA_CUNAMUTUAL"
            $EXPECTEDCERTDATA = "__WILDCARD_ATLASBETA_CUNAMUTUAL_CERT_DATA__"
            $EXPECTEDCERTPASSWORD = "__WILDCARD_ATLASBETA_CUNAMUTUAL_CERT_PASSWORD__"

            $RESULTOBJECT.sslCertificates | Should -Not -Be $null
            $RESULTOBJECT.sslCertificates.name | Should -Not -Be $TESTCERTNAME
            $RESULTOBJECT.sslCertificates.name | Should -Match $EXPECTEDSSLCERTNAME
            $RESULTOBJECT.sslCertificates.properties.data | Should -Not -Be $null
            $RESULTOBJECT.sslCertificates.properties.data | Should -Match $EXPECTEDCERTDATA
            $RESULTOBJECT.sslCertificates.properties.password | Should -Not -Be $null
            $RESULTOBJECT.sslCertificates.properties.password | Should -Match $EXPECTEDCERTPASSWORD
        }


        It "Function Sets Correct Public IP ID" {
            $EXPECTEDPUBLICIPID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/publicIPAddresses/agwaf-cmfg-ea2-np1-atlas-test-IP"
            $RESULTOBJECT.frontendIPConfigurations | Should -Not -Be $null
            $RESULTOBJECT.frontendIPConfigurations.properties.publicIPAddress.id | Should -Not -Be $null
            $RESULTOBJECT.frontendIPConfigurations.properties.publicIPAddress.id | Should -Match $EXPECTEDPUBLICIPID
        }


        It "Function Sets Correct Backend Address FQDN" {

            $EXPECTEDBACKENDADDRESSPOOLNAME = "atlas-test-backend-pool"
            $EXPECTEDBACKENDFQDN = "atlas-test.azurewebsites.net"
            $RESULTOBJECT.backendAddressPools | Should -Not -Be $null
            $RESULTOBJECT.backendAddressPools.name | Should -Not -Be $null
            $RESULTOBJECT.backendAddressPools.name | Should -Match $EXPECTEDBACKENDADDRESSPOOLNAME
            $RESULTOBJECT.backendAddressPools.properties.backendAddresses.fqdn | Should -Not -Be $null
            $RESULTOBJECT.backendAddressPools.properties.backendAddresses.fqdn | Should -Match $EXPECTEDBACKENDFQDN
        }


        It "Function Sets Correct Probe" {
            $EXPECTEDPROBENAME = "atlas-test-https-probe"
            $RESULTOBJECT.probes | Should -Not -Be $null
            $RESULTOBJECT.probes.name | Should -Not -Be $null
            $RESULTOBJECT.probes.name | Should -Match $EXPECTEDPROBENAME
        }

        $EXPECTEDHTTPLISTENERNAME = "atlas-test.atlasbeta.cunamutual.com-http-listener"
        $EXPECTEDHTTPSLISTENERNAME = "atlas-test.atlasbeta.cunamutual.com-https-listener"
        $EXPECTEDFRNTIPCONFIGID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/frontendIPConfigurations/appGatewayFrontendIP"
        $EXPECTEDFRONTENDPORT80 = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/frontendPorts/appGatewayFrontendPort80"
        $EXPECTEDFRONTENDPORT443 = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/frontendPorts/appGatewayFrontendPort443"
        $EXPECTEDHOSTNAME = "atlas-test.atlasbeta.cunamutual.com"
        $EXPECTEDSSLCERTID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/sslCertificates/wildcard_atlasbeta_cunamutual"
        It "Function Sets Correct Http Listener Settings" {
            $RESULTOBJECT.httpListeners | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[0].name | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[0].name | Should -Match $EXPECTEDHTTPLISTENERNAME
            $RESULTOBJECT.httpListeners[0].properties.frontendIPConfiguration.id | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[0].properties.frontendIPConfiguration.id | Should -Match $EXPECTEDFRNTIPCONFIGID
            $RESULTOBJECT.httpListeners[0].properties.frontendPort.id | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[0].properties.frontendPort.id | Should -Match $EXPECTEDFRONTENDPORT80
            $RESULTOBJECT.httpListeners[0].properties.hostName | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[0].properties.hostName | Should -Match $EXPECTEDHOSTNAME
        }

        It "Function Sets Correct Https Listener Settings" {
            $RESULTOBJECT.httpListeners | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[1].name | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[1].name | Should -Match $EXPECTEDHTTPSLISTENERNAME
            $RESULTOBJECT.httpListeners[1].properties.frontendIPConfiguration.id | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[1].properties.frontendIPConfiguration.id | Should -Match $EXPECTEDFRNTIPCONFIGID
            $RESULTOBJECT.httpListeners[1].properties.frontendPort.id | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[1].properties.frontendPort.id | Should -Match $EXPECTEDFRONTENDPORT443
            $RESULTOBJECT.httpListeners[1].properties.hostName | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[1].properties.hostName | Should -Match $EXPECTEDHOSTNAME
            $RESULTOBJECT.httpListeners[1].properties.sslCertificate.id | Should -Not -Be $null
            $RESULTOBJECT.httpListeners[1].properties.sslCertificate.id | Should -Match $EXPECTEDSSLCERTID
        }


        It "Function Sets Correct Http Settings" {
            $EXPECTEDHTTPSETTINGSNAME = "atlas-test-https-settings"
            $EXPECTEDPROBEID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/probes/atlas-test-https-probe"
            $RESULTOBJECT.backendHttpSettingsCollection | Should -Not -Be $null
            $RESULTOBJECT.backendHttpSettingsCollection.name | Should -Not -Be $null
            $RESULTOBJECT.backendHttpSettingsCollection.name | Should -Match $EXPECTEDHTTPSETTINGSNAME
            $RESULTOBJECT.backendHttpSettingsCollection.properties.probe.id | Should -Not -Be $null
            $RESULTOBJECT.backendHttpSettingsCollection.properties.probe.id | Should -Match $EXPECTEDPROBEID
        }


        It "Function Sets Correct Https Routing Rules" {
            $EXPECTEDHTTPSROUTINGRULENAME = "atlas-test.atlasbeta.cunamutual.com-https-rule"
            $EXPECTEDHTTPSLISTENERID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/httpListeners/atlas-test.atlasbeta.cunamutual.com-https-listener"
            $EXPECTEDHTTPSPATHMAPID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/urlPathMaps/atlas-test.atlasbeta.cunamutual.com-https-rule"
            $RESULTOBJECT.requestRoutingRules | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[0].name | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[0].name | Should -Match $EXPECTEDHTTPSROUTINGRULENAME
            $RESULTOBJECT.requestRoutingRules[0].properties.httpListener.id | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[0].properties.httpListener.id | Should -Match $EXPECTEDHTTPSLISTENERID
            $RESULTOBJECT.requestRoutingRules[0].properties.urlPathMap.id | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[0].properties.urlPathMap.id | Should -Match $EXPECTEDHTTPSPATHMAPID
        }

        $EXPECTEDHTTPROUTINGRULENAME = "atlas-test.atlasbeta.cunamutual.com-httptohttps-rule"
        $EXPECTEDHTTPLISTENERID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/httpListeners/atlas-test.atlasbeta.cunamutual.com-http-listener"
        $EXPECTEDHTTPREDIRECTID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/redirectConfigurations/atlas-test.atlasbeta.cunamutual.com-httptohttps-rule"
        It "Function Sets Correct Http Routing Rules" {
            $RESULTOBJECT.requestRoutingRules | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[1].name | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[1].name | Should -Match $EXPECTEDHTTPROUTINGRULENAME
            $RESULTOBJECT.requestRoutingRules[1].properties.httpListener.id | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[1].properties.httpListener.id | Should -Match $EXPECTEDHTTPLISTENERID
            $RESULTOBJECT.requestRoutingRules[1].properties.redirectConfiguration.id | Should -Not -Be $null
            $RESULTOBJECT.requestRoutingRules[1].properties.redirectConfiguration.id | Should -Match $EXPECTEDHTTPREDIRECTID
        }


        It "Function Sets Correct URL Path Maps" {
            $EXPECTEDURLPATHMAPNAME = "atlas-test.atlasbeta.cunamutual.com-https-rule"
            $EXPECTEDBACKENDPOOLID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/backendAddressPools/atlas-test-backend-pool"
            $EXPECTEDHTTPSETTINGID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared/providers/Microsoft.Network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/backendHttpSettingsCollection/atlas-test-https-settings"
            $RESULTOBJECT.urlPathMaps | Should -Not -Be $null
            $RESULTOBJECT.urlPathMaps.name | Should -Not -Be $null
            $RESULTOBJECT.urlPathMaps.name | Should -Match $EXPECTEDURLPATHMAPNAME
            $RESULTOBJECT.urlPathMaps.properties.defaultBackendAddressPool.id | Should -Not -Be $null
            $RESULTOBJECT.urlPathMaps.properties.defaultBackendAddressPool.id | Should -Match $EXPECTEDBACKENDPOOLID
            $RESULTOBJECT.urlPathMaps.properties.defaultBackendHttpSettings.id | Should -Not -Be $null
            $RESULTOBJECT.urlPathMaps.properties.defaultBackendHttpSettings.id | Should -Match $EXPECTEDHTTPSETTINGID
            $RESULTOBJECT.urlPathMaps.properties.pathRules[0].properties.backendAddressPool.id | Should -Not -Be $null
            $RESULTOBJECT.urlPathMaps.properties.pathRules[0].properties.backendAddressPool.id | Should -Match $EXPECTEDBACKENDPOOLID
            $RESULTOBJECT.urlPathMaps.properties.pathRules[0].properties.backendHttpSettings.id | Should -Not -Be $null
            $RESULTOBJECT.urlPathMaps.properties.pathRules[0].properties.backendHttpSettings.id | Should -Match $EXPECTEDHTTPSETTINGID
        }


        It "Function Sets Correct Redirect Configs" {
            $EXPECTEDREDIRECTNAME = "atlas-test.atlasbeta.cunamutual.com-httptohttps-rule"
            $EXPECTEDHTTPROUTINGRULEID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/rg-cmfg-np2-atlas-infrastructure-build-shared/providers/microsoft.network/applicationGateways/agwaf-cmfg-ea2-np1-atlas-test/requestRoutingRules/atlas-test.atlasbeta.cunamutual.com-httptohttps-rule"
            $RESULTOBJECT.redirectConfigurations | Should -Not -Be $null
            $RESULTOBJECT.redirectConfigurations.name | Should -Not -Be $null
            $RESULTOBJECT.redirectConfigurations.name | Should -Match $EXPECTEDREDIRECTNAME
            $RESULTOBJECT.redirectConfigurations.properties.targetListener.id | Should -Not -Be $null
            $RESULTOBJECT.redirectConfigurations.properties.targetListener.id | Should -Match $EXPECTEDHTTPSLISTENERID
            $RESULTOBJECT.redirectConfigurations.properties.requestRoutingRules.id | Should -Not -Be $null
            $RESULTOBJECT.redirectConfigurations.properties.requestRoutingRules.id | Should -Match $EXPECTEDHTTPROUTINGRULEID
        }
    }
    Describe "Set-AgWafParametersJSON Tests" {
        BeforeAll {
            #define variables
            $TESTCERTNAME = "wildcard-atlasbeta-cunamutual-cert-secret"
            $TESTCERTPASS = "wildcard-atlasbeta-cunamutual-cert-password"
            $TESTKEYVAULTID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourcegroups/rg-cmfg-ea2-np1-atlas-shared-resources/providers/microsoft.keyvault/vaults/kv-atlas-sharedsvcs-np"
            $TESTCERTPARAM = "frontendCertData0"
            $TESTCERTPARAM2 = "frontendCertData1"
            $TESTPASSWORDPARAM = "frontendCertPassword0"
            $TESTPASSWORDPARAM2 = "frontendCertPassword1"
            $TESTPARAMETERSFILEPATH = ""
            $EXPECTEDINITIALCOUNT = 2
            $EXPECTEDFINALCOUNT = 4
            #call function with test results, check results
            $TEMPPARAMETERSFILEPATH = Set-AgWafParametersJSON -certName $TESTCERTNAME -certPassword $TESTCERTPASS -keyvaultId $TESTKEYVAULTID -certParam $TESTCERTPARAM -passwordParam $TESTPASSWORDPARAM -parametersFilePath $TESTPARAMETERSFILEPATH
        }


        It "Function Returns Valid Path" {
            $TEMPPARAMETERSFILEPATH | Should -Not -Be $null
        }

        It "Function Sets Correct Values" {
            $TEMPPARAMETERS = $(Get-Content -Path $TEMPPARAMETERSFILEPATH) | ConvertFrom-Json
            $TEMPPARAMETERS.parameters | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM.reference.keyvault.id | Should -Be $TESTKEYVAULTID
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM.reference.secretName | Should -Be $TESTCERTNAME
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM.reference.keyvault.id | Should -Be $TESTKEYVAULTID
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM.reference.secretName | Should -Be $TESTCERTPASS
        }



        It "Function Returns Valid Path after Update" {
            #call function a second time with to check addition of
            $TEMPPARAMETERSFILEPATH = Set-AgWafParametersJSON -certName $TESTCERTNAME -certPassword $TESTCERTPASS -keyvaultId $TESTKEYVAULTID -certParam $TESTCERTPARAM2 -passwordParam $TESTPASSWORDPARAM2 -parametersFilePath $TEMPPARAMETERSFILEPATH
            $TEMPPARAMETERSFILEPATH | Should -Not -Be $null
        }


        It "Function Updates Correctly" {
            $TEMPPARAMETERS = $(Get-Content -Path $TEMPPARAMETERSFILEPATH) | ConvertFrom-Json
            $TEMPPARAMETERS.parameters | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM.reference.keyvault.id | Should -Be $TESTKEYVAULTID
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM.reference.secretName | Should -Be $TESTCERTNAME
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM.reference.keyvault.id | Should -Be $TESTKEYVAULTID
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM.reference.secretName | Should -Be $TESTCERTPASS
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM2 | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM2.reference.keyvault.id | Should -Be $TESTKEYVAULTID
            $TEMPPARAMETERS.parameters.$TESTCERTPARAM2.reference.secretName | Should -Be $TESTCERTNAME
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM2 | Should -Not -Be $null
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM2.reference.keyvault.id | Should -Be $TESTKEYVAULTID
            $TEMPPARAMETERS.parameters.$TESTPASSWORDPARAM2.reference.secretName | Should -Be $TESTCERTPASS
        }

    }

    Describe "Get-AGWAF-AppServiceBackends Tests" {
        BeforeAll {
            # todo: we need to figure out how to test the functionality of this method against a static block of config rather than
            # testing against a dynamically generated file which may or may not exist

            $EXPECTEDBACKENDS = 3
            $EXPECTEDBACKENDS2 = 1
            $EXPECTEDAPPSERVICE1 = "as-infrasharedtest1"
            $EXPECTEDRG1 = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
            $EXPECTEDAPPSERVICE2 = "as-infrasharedtest2"
            $EXPECTEDRG2 = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
            $EXPECTEDAPPSERVICE3 = "$env:APP_NAME"
            $EXPECTEDRG3 = "$env:APP_RG_NAME"

            #$RESULT = Get-AGWAF-AppServiceBackends -filePath $TESTFILEPATH

            # I believe the reason this is set to skip is that it currently relies on
            # external resources that may or may not exist over time and is a tightly coupled
            # integration test. I think this can be abstracted to unit tests w/ Mocks to
            # get the value of testing this function w/o the reliance on extenal resources

            # Implementation currently relies on Az CLI which makes it difficult to mock, but
            # if we flip the implementation to Az PowerShell mocking this should be doable.
        }

        It "Function Returns Value" -Skip {
            $RESULT | Should -Not -Be $null
        }

        if ($env:AG_WAF_PROPERTIES_FILE_NAME) {
            #if not using default file
            Write-Host "'$env:AG_WAF_PROPERTIES_FILE_NAME' is set. Running tests for specified file."
            It "Function Returns Correct Number of Backends" {
                $($RESULT | Measure-Object).Count | Should -Be $EXPECTEDBACKENDS
            }

            #test each result
            $RESULT1 = $RESULT[0]
            It "Function Retrieves First Backend Information Correctly" {
                $RESULT1 | Should -Not -Be $null
                $RESULT1.Name | Should -Not -Be $null
                $RESULT1.Name | Should -Be $EXPECTEDAPPSERVICE1
                $RESULT1.ResourceGroup | Should -Not -Be $null
                $RESULT1.ResourceGroup | Should -Be $EXPECTEDRG1
            }

            $RESULT2 = $RESULT[1]
            It "Function Retrieves Second Backend Information Correctly" {
                $RESULT2 | Should -Not -Be $null
                $RESULT2.Name | Should -Not -Be $null
                $RESULT2.Name | Should -Be $EXPECTEDAPPSERVICE2
                $RESULT2.ResourceGroup | Should -Not -Be $null
                $RESULT2.ResourceGroup | Should -Be $EXPECTEDRG2
            }

            $RESULT3 = $RESULT[2]
            It "Function Retrieves Third Backend Information Correctly" {
                $RESULT3 | Should -Not -Be $null
                $RESULT3.Name | Should -Not -Be $null
                $RESULT3.Name | Should -Be $EXPECTEDAPPSERVICE3
                #not checking resource group here as it doesn't exist, as the default hasn't actually be deployed.
            }
        }
        else {
            #default deployment tests
            Write-Host "'env:AG_WAF_PROPERTIES_FILE_NAME' is NOT set. Running default tests for AGWAF deployment."

            # adding skip as this resource is shared, so for a unit test it's not going to work
            # todo: abstract to unit test
            It "Function Returns Correct Number of Backends" -Skip {
                $($RESULT | Measure-Object).Count | Should -Be $EXPECTEDBACKENDS2
            }


            It "Function Retrieves First Backend Information Correctly" -Skip {
                # adding skip as this resource is shared, so for a unit test it's not going to work
                # todo: abstract to unit test
                $RESULT1 = $RESULT
                $RESULT1 | Should -Not -Be $null
                $RESULT1.Name | Should -Not -Be $null
                $RESULT1.Name | Should -Be $EXPECTEDAPPSERVICE3
                #not checking resource group here as it doesn't exist, as the default hasn't actually be deployed.
            }
        }
    }

    Describe "Get-AGParametersFile Tests" {
        BeforeAll {
            $TESTFILENAME = "$env:INFRA_FOLDER/AppGateway/WAFv2/test/azuredeployGatewayWAF_v2_ssl.testParameters.json"
            $TESTKEYVAULTID = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourcegroups/rg-cmfg-ea2-np1-atlas-shared-resources/providers/microsoft.keyvault/vaults/kv-atlas-sandbox-np"

            $EXPECTEDTEMPLATEFILE = "azuredeployGatewayWAF_v2_ssl_editted.json"
            $EXPECTEDPARAMETERFILE = "azuredeployGatewayWAF_v2_ssl.parameters.json"

            #TODO: Fixme
            $TESTRESULT = Get-AGParametersFile -fileName $TESTFILENAME -keyvaultId $TESTKEYVAULTID

            $TESTTEMPLATEPATH = $TESTRESULT.TemplateFilePath
            $TESTPARAMETERSPATH = $TESTRESULT.ParametersFilePath

            $TESTTEMPLATE = $(Get-Content -Path $TESTTEMPLATEPATH) | ConvertFrom-Json
            $TESTPARAMETER1 = "frontendCertData0"
            $TESTPARAMETER2 = "frontendCertPassword0"

            $TESTPROPERTIES = $TESTTEMPLATE.resources[1].properties
            $INCORRECTPROPERTIES = "__PROPERTIES__"

            $TESTSSLCERTS = $TESTPROPERTIES.sslCertificates
            $EXPECTEDDATA = "[parameters('frontendCertData0')]"
            $EXPECTEDPASSWORD = "[parameters('frontendCertPassword0')]"
            $EXPECTEDNAME = "wildcard-atlasbeta-cunamutual"

            $TESTBACKENDS = $TESTPROPERTIES.backendAddressPools
        }

        It "Function Returns Result" {
            $TESTRESULT | Should -Not -Be $null
        }

        It "Function Returns Both Values" {
            $TESTTEMPLATEPATH | Should -Not -Be $null
            $TESTTEMPLATEPATH | Should -Match $EXPECTEDTEMPLATEFILE
            $TESTPARAMETERSPATH | Should -Not -Be $null
            $TESTPARAMETERSPATH | Should -Match $EXPECTEDPARAMETERFILE
        }

        # Confirm properties were replaced
        It "Function Added Cert Parameters" {
            #Confirm properties were replaced

            $TESTTEMPLATE.parameters.$TESTPARAMETER1 | Should -Not -Be $null
            $TESTTEMPLATE.parameters.$TESTPARAMETER2 | Should -Not -Be $null
        }

        #Check that properties are replaced
        It "Function correctly replaces Properties" {


            $TESTPROPERTIES | Should -Not -Be $null
            $TESTPROPERTIES | Should -Not -Be $INCORRECTPROPERTIES
            $TESTPROPERTIES.sku | Should -Not -Be $null
            $TESTPROPERTIES.gatewayIPConfigurations | Should -Not -Be $null
            $TESTPROPERTIES.sslCertificates | Should -Not -Be $null
            $TESTPROPERTIES.frontendPorts | Should -Not -Be $null
            $TESTPROPERTIES.backendAddressPools | Should -Not -Be $null
            $TESTPROPERTIES.probes | Should -Not -Be $null
            $TESTPROPERTIES.httpListeners | Should -Not -Be $null
            $TESTPROPERTIES.backendHttpSettingsCollection | Should -Not -Be $null
            $TESTPROPERTIES.requestRoutingRules | Should -Not -Be $null
            $TESTPROPERTIES.urlPathMaps | Should -Not -Be $null
            $TESTPROPERTIES.redirectConfigurations | Should -Not -Be $null
            $TESTPROPERTIES.sslPolicy | Should -Not -Be $null
            $TESTPROPERTIES.enableHttp2 | Should -Not -Be $null
            $TESTPROPERTIES.webApplicationFirewallConfiguration | Should -Not -Be $null
            $TESTPROPERTIES.autoscaleConfiguration | Should -Not -Be $null
        }

        #Test token replacement
        It "Function Correctly Replaces SSL Tokens" {
            $TESTSSLCERTS.name | Should -Not -Be $null
            $TESTSSLCERTS.name | Should -Be $EXPECTEDNAME
            $TESTSSLCERTS.properties.data | Should -Not -Be $null
            $TESTSSLCERTS.properties.data | Should -Be $EXPECTEDDATA
            $TESTSSLCERTS.properties.password | Should -Not -Be $null
            $TESTSSLCERTS.properties.password | Should -Be $EXPECTEDPASSWORD
        }

        #check that backend fqdns begins with AS
        if ($env:AG_WAF_PROPERTIES_FILE_NAME) {
            Write-Host "'$env:AG_WAF_PROPERTIES_FILE_NAME' is set. Running tests for specified file."
            It "Function Correctly Handles Backends" {
                $TESTBACKENDS[0] | Should -Not -Be $null
                $TESTBACKENDS[0].properties.backendAddresses.fqdn | Should -Not -Be $null
                $TESTBACKENDS[0].properties.backendAddresses.fqdn | Should -Match "as-"
                $TESTBACKENDS[1] | Should -Not -Be $null
                $TESTBACKENDS[1].properties.backendAddresses.fqdn | Should -Not -Be $null
                $TESTBACKENDS[1].properties.backendAddresses.fqdn | Should -Match "as-"
                $TESTBACKENDS[2] | Should -Not -Be $null
                $TESTBACKENDS[2].properties.backendAddresses.fqdn | Should -Not -Be $null
                $TESTBACKENDS[2].properties.backendAddresses.fqdn | Should -Match "as-"
            }
        }
        else {
            Write-Host "'env:AG_WAF_PROPERTIES_FILE_NAME' is NOT set. Running default tests for AGWAF deployment."
            It "Function Correctly Handles Backends" {
                $TESTBACKENDS[0] | Should -Not -Be $null
                $TESTBACKENDS[0].properties.backendAddresses.fqdn | Should -Not -Be $null
                $TESTBACKENDS[0].properties.backendAddresses.fqdn | Should -Match "as-"
            }
        }
    }



    Describe "Is-RGAtlas Tests" {
        BeforeAll {
            $TESTRESOURCEGROUP1 = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
            $TESTRESOURCEGROUP2 = "RG-CMFG-NC1-D01-OMS"

            $EXPECTEDRESULT1 = $true
            $EXPECTEDRESULT2 = $false

            $TESTRESULT1 = Is-RGAtlas -resourceGroup $TESTRESOURCEGROUP1
        }

        It "Can Successfully Identify Atlas RGs" {
            $TESTRESULT1 | Should -Not -Be $null
            $TESTRESULT1 | Should -Be $EXPECTEDRESULT1
        }


        It "Can Successfully Identify Non-Atlas RGs" {
            $TESTRESULT2 = Is-RGAtlas -resourceGroup $TESTRESOURCEGROUP2
            $TESTRESULT2 | Should -Not -Be $null
            $TESTRESULT2 | Should -Be $EXPECTEDRESULT2
        }
    }

    Describe "Get-GwDomainLabel Tests" {
        BeforeAll {
            $TESTRESOURCEGROUP1 = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
            $TESTGW1 = "AGWAF-CMFG-EA2-NP1-TEST"
            $EXPECTEDRESULT1 = "acgcmfgea2np1test"

            # This implementation should be updated to be Mock-able so that we can Mock the resource group
            # and gateway inputs rather than relying upon the presence of a remote resource.
            # NOTE: The backend function "Get-Titan-AG-WAF-Public-IP" can be mocked as-is, so these are approachble without rewriting anything!
            # Each of the tests below should be a mocked call to Get-GwDomainLabel
        }


        #TODO: Skipped due to need for shared infra - implement after AKS cluster deployed - requires long lived gateway for testing
        It "Function Returns Domain Label for Atlas GW" {
            $TESTRESULT1 = Get-GwDomainLabel -gwResourceGroup $TESTRESOURCEGROUP1 -gwName $TESTGW1
            $TESTRESULT1 | Should -Not -Be $null
            $TESTRESULT1 | Should -Be $EXPECTEDRESULT1
        }

        #TODO: Need to figure out how to re-work these tests?
        It "Function Returns Domain Label for Atlas WebApp GW" -Skip {
            $TESTRESULT2 = Get-GwDomainLabel -gwResourceGroup $TESTRESOURCEGROUP2 -gwName $TESTGW2
            $TESTRESULT2 | Should -Not -Be $null
            $TESTRESULT2 | Should -Contain $EXPECTEDRESULT2
        }
    }

    Describe "Reset-GwBackendStatus Tests" {
        BeforeAll {
            $TESTRESOURCEGROUP1 = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
            $TESTGW1 = "AGWAF-CMFG-EA2-NP1-TEST"

            $initialGateway = $(az network application-gateway show -n $TESTGW1 -g $TESTRESOURCEGROUP1) | ConvertFrom-Json
            $initialCount = $initialGateway.autoscaleConfiguration.maxCapacity

            Reset-GwBackendStatus -gwName $TESTGW1 -gwResourceGroup $TESTRESOURCEGROUP1
            $finalGateway = $(az network application-gateway show -n $TESTGW1 -g $TESTRESOURCEGROUP1) | ConvertFrom-Json
        }


        It "Max Capacity Value Set Back to Initial State" {
            $finalGateway.autoscaleConfiguration.maxCapacity | Should -Be $initialCount
        }
    }

    Describe "Get-AGWAF-SubnetType Tests" {
        BeforeAll {
            $TESTRESOURCEGROUP = "RG-CMFG-NP2-Atlas-Infrastructure-Build-Shared"
            $TESTAGWAFNAME = "AGWAF-CMFG-EA2-NP1-TEST"
            $initialGateway = $(az network application-gateway show -n $TESTAGWAFNAME -g $TESTRESOURCEGROUP)
            $expectedSubnetName = "VNet-CMFG-Atlas-Atlantis-cmfg-subnet-v1"
            $gwSubnetName = Get-AGWAF-SubnetName -appGatewayJson $initialGateway
        }

        It "Has Expected Subnet Name" {
            $gwSubnetName | Should -Be $expectedSubnetName
        }
    }

    Describe "Get-AGWAF-subnetFromParmFile Tests" {
        BeforeAll {
            $publicSubnetParmFile = "$env:INFRA_FOLDER/AppGateway/WAFv2/test/azuredeployGatewayWAF_v2_ssl_public.testParameters.json"
            $expectedPublicSubnet = "VNet-CMFG-Atlas-Atlantis-public-subnet-v1"
            $subnet = Get-AGWAF-subnetFromParmFile -filePath $publicSubnetParmFile
        }

        It "Has Expected Subnet Name -- Public Subnet" {
            $subnet | Should -Be $expectedPublicSubnet
        }

        It "Has Expected Subnet Name -- cmfg Subnet" {
            $cmfgSubnetParmFile = "$env:INFRA_FOLDER/AppGateway/WAFv2/test/azuredeployGatewayWAF_v2_ssl.testParameters.json"
            $expectedCmfgSubnet = "VNet-CMFG-Atlas-Atlantis-cmfg-subnet-v1"
            $subnet = Get-AGWAF-subnetFromParmFile -filePath $cmfgSubnetParmFile
            $subnet | Should -Be $expectedCmfgSubnet
        }
    }

    Describe "Check-AGWAF-hasBackendFunctionsFromParmFile Tests" {
        BeforeAll {
            $publicSubnetParmFile = "$env:INFRA_FOLDER/AppGateway/WAFv2/test/azuredeployGatewayWAF_v2_ssl_public.testParameters.json"
            $backendHasFunctions = Check-AGWAF-hasBackendFunctionsFromParmFile -filePath $publicSubnetParmFile
        }

        It "Has Expected Backend Resource -- Public Subnet" {
            $backendHasFunctions | Should -Be $false
        }

        It "Has Expected Backend Resource -- cmfg Subnet" {
            $cmfgSubnetParmFile = "$env:INFRA_FOLDER/AppGateway/WAFv2/test/azuredeployGatewayWAF_v2_ssl.testParameters.json"
            $backendHasFunctions = Check-AGWAF-hasBackendFunctionsFromParmFile -filePath $cmfgSubnetParmFile
            $backendHasFunctions | Should -Be $true
        }
    }

}