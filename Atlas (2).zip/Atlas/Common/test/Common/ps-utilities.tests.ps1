
# Test the functions within the ./Common/utilities.ps1 file
Describe "PS Utilities Unit Tests" {
    BeforeAll {
        . ("$env:COMMON_FOLDER/test/Common/_includes.tests.ps1")
        $functionList = (Get-ChildItem function:/).Name
    }


    Context "Functional Delegate Tests" {
        BeforeAll {
            $EXPECTED_RETRIES = 2
            $SPECIFIED_RETRIES = 4

        }


        # case - known problem, unhandled, should throw
        It "Throws when unhandled exception type occurs" -Skip {
            $Action = { throw "This isn't expected to retry..." }
            { Retry-FunctionalDelegate -Action $Action } | Should -Throw
        }

        # case - automation account, no expected issue, should not thow
        It "Successfully handles a known AA Exception Type" -Skip {
            $Action = { throw [Microsoft.Azure.Management.Automation.Models.ErrorResponseException]::new("You should see this as a WARNING") }
            # redirect and capture all output
            try {
                # dump verbose logging
                $logs = Retry-FunctionalDelegate -Action $Action 4> $null
            }
            catch {
                $errorMsg = $_.Exception.Message
            }
            $errorMsg | Should -Match "Maximum of $EXPECTED_RETRIES retries"
        }

        # case - emulate az cli issue
        It "Successfully handles an emulated Az CLI error" -Skip {
            $Action = { Write-Error "Please ensure you have network connection. Error detail: HTTPSConnectionPool(host='login.microsoftonline.com', port=443): Max retries exceeded with url: /***/oauth2/token (Caused by NewConnectionError('<urllib3.connection.VerifiedHTTPSConnection object at 0x0507D070>: Failed to establish a new connection: [Errno 11001] getaddrinfo failed',))" }
            # redirect and capture all output
            try {
                # dump verbose logging
                $logs = Retry-FunctionalDelegate -Action $Action 4> $null
            }
            catch {
                $errorMsg = $_.Exception.Message
            }
            $errorMsg | Should -Match "Maximum of $EXPECTED_RETRIES retries"
        }

        It "Successfully handles second Az CLI error" -Skip {
            $Action = { Write-Error "The running command stopped because the preference variable `"ErrorActionPreference`" or common parameter is set to Stop: Please ensure you have network connection. Error detail: ('Connection aborted.', OSError(`"(10054, 'WSAECONNRESET')`",))" }
            # redirect and capture all output
            try {
                # dump verbose logging
                $logs = Retry-FunctionalDelegate -Action $Action 4> $null
            }
            catch {
                $errorMsg = $_.Exception.Message
            }
            $errorMsg | Should -Match "Maximum of $EXPECTED_RETRIES retries"
        }

        It "Default Retry Maximum Matches Expectation" -Skip {
            # note - this test relies on having an error that matches the retry catch. If the retry catch is failing
            # then this test will also fail
            $Action = { throw [Microsoft.Azure.Management.Automation.Models.ErrorResponseException]::new("You should see this as a WARNING") }
            # redirect and capture all output
            try {
                # dump verbose logging
                $logs = Retry-FunctionalDelegate -Action $Action 4> $null
            }
            catch {
                $errorMsg = $_.Exception.Message
            }
            $errorMsg | Should -Match "Maximum of $EXPECTED_RETRIES retries"
        }

        It "Throws on emulated unhandled Az CLI error" -Skip {
            $Action = { Write-Error "The subscription of 'blah' doesn't exist in cloud 'AzureCloud'." }
            { Retry-FunctionalDelegate -Action $Action } | Should -Throw
        }

        It "Expected Behavior for a Nested Try Catch - No Throw" -Skip {
            $Action = {
                try {
                    $a = 0
                }
                catch {
                    throw $_
                }
            }
            { Retry-FunctionalDelegate -Action $Action } | Should -Not -Throw
        }

        It "Expected Behavior for a Nested Try Catch - Should Throw" -Skip {
            # similar to the case on "Throws when unhandled exception type occurs"
            # but ensures that a try/catch is still correctly handled by the implementation
            $Action = {
                try {
                    throw "this exception should throw"
                }
                catch {
                    throw $_
                }
            }
            { Retry-FunctionalDelegate -Action $Action } | Should -Throw
        }

        It "Specified Retry Maximum Matches Expectation" -Skip {
            # note - this test relies on having an error that matches the retry catch. If the retry catch is failing
            # then this test will also fail
            $Action = { throw [Microsoft.Azure.Management.Automation.Models.ErrorResponseException]::new("You should see this as a WARNING") }
            # redirect and capture all output
            try {
                # dump verbose logging
                $logs = Retry-FunctionalDelegate -Action $Action -MaxAttempts $SPECIFIED_RETRIES 4> $null
            }
            catch {
                $errorMsg = $_.Exception.Message
            }
            $errorMsg | Should -Match "Maximum of $SPECIFIED_RETRIES retries"
        }
    }

    Context "Set-ValidateResourceNameVariable Tests" {
        BeforeAll {
            $variableName = "TestVariable"
            $variableValue = "TestValue"
            $variablePrefix = "TestPrefix"
            $happyPathName = "$variablePrefix-$variableValue"

        }
        It "Method Found" {
            $functionList | Should -Contain "Set-ValidateResourceNameVariable"
        }


        It "Happy Path - Variable Value Starts with Prefix" {
            $result = Set-ValidateResourceNameVariable -variableName $variableName -variableValue $happyPathName -variablePrefix $variablePrefix
            $result | Should -Be $happyPathName
        }

        It "Sad Path - Variable value Does Not Start with Prefix" {
            { Set-ValidateResourceNameVariable -variableName $variableName `
                    -variableValue $variableValue `
                    -variablePrefix $variablePrefix } | Should -Throw
        }

        It "Case Insensitive variablePrefix test" {
            $variableName = "TestVariable"
            $variableValue = "KV-xxxxxxx-d"
            $variablePrefix = "kv-"
            $expected = $variableValue
            $actual = Set-ValidateResourceNameVariable -variableName $variableName -variableValue $variableValue -variablePrefix $variablePrefix
            $actual | Should -Be $expected
        }

        # No value in testing parameter combinations as all are currently marked as mandatory
    }

    Context "Set-ValidateResourceNameVariableCaseSpecific Tests" {
        BeforeAll {
            $variableName = "TestVariable"
            $variableValue = "TestValue"
            $variablePrefix = "TestPrefix"
            $happyPathName = "$variablePrefix-$variableValue"
        }

        It "Method Found" {
            $functionList | Should -Contain "Set-ValidateResourceNameVariableCaseSpecific"
        }


        It "Happy Path - Variable Value Starts with Prefix" {
            $variableName = "TestVariable"
            $variableValue = "TestValue"
            $variablePrefix = "TestPrefix"
            $happyPathName = "$variablePrefix-$variableValue"

            $result = Set-ValidateResourceNameVariableCaseSpecific -variableName $variableName -variableValue $happyPathName -variablePrefix $variablePrefix
            $result | Should -Be $happyPathName
        }

        It "Sad Path - Variable value Does Not Start with Prefix" {
            { Set-ValidateResourceNameVariableCaseSpecific -variableName $variableName `
                    -variableValue $variableValue `
                    -variablePrefix $variablePrefix } | Should -Throw
        }

    }

    Context "Get-AtlasVersionNumber Tests" {
        BeforeAll {
            $numberRegex = '\d.\d.\d'
        }
        It "Method Found" {
            $functionList | Should -Contain "Get-AtlasVersionNumber"
        }

        It "Necessary Constants Available" {
            $CONST_ATLAS_IDENTIFIER | Should -Not -Be $null
            $CONST_ATLAS_IDENTIFIER | Should -Match "Atlas"
        }



        It "Happy Path - Matches Expected Format" {
            $VersionNumber = Get-AtlasVersionNumber 4> $null
            $VersionNumber | Should -Match $numberRegex
            $VersionNumber | Should -Match $CONST_ATLAS_IDENTIFIER
        }


        It "Sad Path - Titan-Atlas but no version info" {
            $tempEnvAtlasRepoRoot = "$env:ATLAS_REPO_ROOT"
            $env:ATLAS_REPO_ROOT = "$env:ATLAS_REPO_ROOT/Deploy"
            $ExpectedResult = "Titan-Atlas-"
            $VersionNumber = Get-AtlasVersionNumber
            $VersionNumber | Should -Be $ExpectedResult
            $VersionNumber | Should -Not -Match $numberRegex
        }
       AfterAll {
        $env:ATLAS_REPO_ROOT = $tempEnvAtlasRepoRoot
       }

    }

    Context "Write-AtlasSanitizeInputs Tests" {
        It "Method Found" {
            $functionList | Should -Contain "Write-AtlasSanitizeInputs"
        }

        It "Sanitize Test Input 1" {
            $env:TestInput1 = "    this is a test    "
            $expected = "this is a test"
            Write-AtlasSanitizeInputs
            $env:TestInput1 | Should -Be $expected
        }

        It "Sanitize Test Input 2" {
            $env:TestInput2 = "   `t this is a test  `t  "
            $expected = "this is a test"
            Write-AtlasSanitizeInputs
            $env:TestInput2 | Should -Be $expected
        }

        It "Sanitize Test Input 3" {
            $env:TestInput3 = "  \ `t this is a test  `t / "
            $expected = "\ `t this is a test  `t /"
            Write-AtlasSanitizeInputs
            $env:TestInput3 | Should -Be $expected
        }

        It "Sanitize Test Input 4" {
            $env:TestInput4 = "  `t this is a test  `t / "
            $expected = "this is a test  `t /"
            Write-AtlasSanitizeInputs
            $env:TestInput4 | Should -Be $expected
        }
    }

    Context "Invoke-CommandWithRetries Tests" {
        It "Method Found" {
            $functionList | Should -Contain "Invoke-CommandWithRetries"
        }

        It "Happy Path - Simple Command" {
            $command = "1 + 1"
            $expected = 2
            $result = Invoke-CommandWithRetries -command $command
            $result | Should -Be $expected
        }

        It "Custom Attempt and Timer Values - 1" {
            $command = "throw 'hello world'"
            $attempts = 1
            $retryTime = 1
            { Invoke-CommandWithRetries -maxAttempts $attempts -retryTimer $retryTime `
                    -command $command 4> $null } | Should -Throw
        }

        It "Custom Attempt and Timer Values - 2" {
            $command = "throw 'hello world'"
            $attempts = 2
            $retryTime = 3
            $s = [Diagnostics.Stopwatch]::StartNew()
            { Invoke-CommandWithRetries -maxAttempts $attempts -retryTimer $retryTime `
                    -command $command 4> $null } | Should -Throw
            # for whatever reason, this stupid thing will "sleep for 3 seconds" but when we
            # evaluate the elapsed seconds it would be 2.99 something...so we're going to sleep on more
            # second for good measure.
            Start-Sleep -Seconds 1
            $s.Stop()
            $s.Elapsed.TotalSeconds | Should -BeGreaterOrEqual $retryTime
        }

        It "Line Number in Exception" {
            $command = "throw 'hello world'"
            $attempts = 1
            $retryTime = 1
            $lineNumber = 100
            { Invoke-CommandWithRetries -maxAttempts $attempts -retryTimer $retryTime `
                    -command $command -LineNumber $lineNumber 4> $null } | Should -Throw "Exception 'hello world'. Failed maximal attempts when executing line 100"
        }
    }

    Context "Get-AtlasPortfolioBySubscription Tests" {
        It "Method Found" {
            $functionList | Should -Contain "Get-AtlasPortfolioBySubscription"
        }

        It "CorporateServices Test" {
            $input = "CorporateServices-Prod"
            $expected = "Corporate"
            $actual = Get-AtlasPortfolioBySubscription -subscription $input
            $actual | Should -Be $expected
        }

        It "ItPortfolio Test" {
            $input = "CMFG NonProduction"
            $expected = "ITPortfolio"
            $actual = Get-AtlasPortfolioBySubscription -subscription $input
            $actual | Should -Be $expected
        }

        It "Sandbox Test" {
            $input = "CMFG-Sandbox"
            $expected = "Sandbox"
            $actual = Get-AtlasPortfolioBySubscription -subscription $input
            $actual | Should -Be $expected
        }

        It "Lending Test" {
            $input = "Lending-Nonprod"
            $expected = "Lending"
            $actual = Get-AtlasPortfolioBySubscription -subscription $input
            $actual | Should -Be $expected
        }

        It "LAH Test - Bad Environment Split" {
            $input = "LAH-BadSecondHalf"
            { Get-AtlasPortfolioBySubscription -subscription $input } | Should -Throw
        }

        It "SecureCloud Test" {
            $IdValue = New-Guid
            Mock Get-AzContext { return @{Account = @{Id = $IdValue } } }
            Mock Get-AzADServicePrincipal { return @{DisplayName = "SP-RM-SecureCloud-P" } } -ParameterFilter { $ApplicationId -eq $IdValue }
            $input = "CMFG Production"
            if (!$env:IsLocal) {
                $expected = "SecureCloud"
            }
            else {
                $expected = "ITPortfolio"
            }

            $actual = Get-AtlasPortfolioBySubscription -subscription $input
            $actual | Should -Be $expected
        }

        It "ItPortfolio Test -- Hybrid Worker or MSI Identity" {
            Mock Get-AzContext { return @{Account = @{Id = "MSI@12345" } } }
            $input = "CMFG Production"
            $expected = "ITPortfolio"
            $actual = Get-AtlasPortfolioBySubscription -subscription $input
            $actual | Should -Be $expected
        }
    }

    Context "Get-StringFromHashTable Tests" {
        It "Method Found" {
            $functionList | Should -Contain "Get-StringFromHashTable"
        }

        It "Returns Expected Result - 1" {
            # note that final trailing semi-colon is dropped due to -join behavior of implementation
            $table = @{a = 1; b = 2; }
            $expected = "{a='1';b='2'}"
            $actual = Get-StringFromHashTable -HashTable $table
            $actual | Should -Be $expected
        }

        It "Returns Expected Result - 2" {
            # note that final trailing semi-colon is dropped due to -join behavior of implementation
            $table = @{a = "this is a test"; b = "so is this"; }
            $expected = "{a='this is a test';b='so is this'}"
            $actual = Get-StringFromHashTable -HashTable $table
            $actual | Should -Be $expected
        }
    }

    Context "Get-AzCliSemVersionFromString Tests" {
        It "Method Found" {
            $functionList | Should -Contain "Get-AzCliSemVersionFromString"
        }

        It "Sample Known String 1" {
            $sample = "azure-cli                         2.0.75"
            $expected = "2.0.75"
            $actual = Get-AzCliSemVersionFromString -versionString $sample
            $actual | Should -Be $expected
        }

        It "Sample Known String 2" {
            $sample = "azure-cli                         2.0.72 *"
            $expected = "2.0.72"
            $actual = Get-AzCliSemVersionFromString -versionString $sample
            $actual | Should -Be $expected
        }

        It "Sample String - Behavior Confirmation" {
            $sample = "azure-cli                         2.0.75 testing"
            $expected = "testing"
            $actual = Get-AzCliSemVersionFromString -versionString $sample
            $actual | Should -Be $expected
        }
    }
}