

Describe "AppService Utliities Tests" {
    BeforeAll {
        . ("$env:COMMON_FOLDER/appService-utilities.ps1")
    }

    Context "Save-AppSettings Test" {

        # case -- remote web app not found
        It "Graceful Handling of Remote Web App Not Found" {
            $fileName = "./file1.json"
            [array]$appSettings = @(
                @{name = "key1"; value = "value1" },
                @{name = "key2"; value = "value2" }
            )
            Mock Get-AzWebApp { return $null }

            Save-AppSettings -appName "test" -appResourceGroup "test" -appSettings $appSettings -filePath $fileName 4> $null

            $finalObject = (Get-Content -Raw $fileName | ConvertFrom-Json)

            # the trim is an artifact of converting to flat file and back to psObject
            $finalObject[0].value | Should -BeIn $appSettings.value
            $finalObject[1].value | Should -BeIn $appSettings.value
            $finalObject.Length | Should -Be 2

            Remove-Item $fileName
        }

        # case -- happy path, mocked get-azwebapp, has zero values set
        It "Remote Web App Found with Customer Supplied Values" {
            $fileName = "./file2.json"
            [array]$localAppSettings = @(
                @{name = "key1"; value = "value1" },
                @{name = "key2"; value = "value2" }
            )

            Mock Get-AzWebApp { return @{SiteConfig =
                    @{AppSettings = @() }
                } }

            Save-AppSettings -appName "test" -appResourceGroup "test" -appSettings $localAppSettings -filePath $fileName 4> $null

            $finalObject = (Get-Content -Raw $fileName | ConvertFrom-Json)

            $expectedValues = $localAppSettings.value

            # the trim is an artifact of converting to flat file and back to psObject
            $finalObject[0].value | Should -BeIn $expectedValues
            $finalObject[1].value | Should -BeIn $expectedValues

            $finalObject.Length | Should -Be 2

            Remove-Item $fileName
        }

        # case -- happy path, mocked get-azwebapp, has multiple values
        It "Remote Web App Found with Customer Supplied Values" {
            $fileName = "./file3.json"
            [array]$localAppSettings = @(
                @{name = "key1"; value = "value1" },
                @{name = "key2"; value = "value2" }
            )
            [array]$remoteAppSettings = @(
                @{name = "key3"; value = "value3" },
                @{name = "key4"; value = "value4" }
            )
            Mock Get-AzWebApp { return @{SiteConfig =
                    @{AppSettings = $remoteAppSettings }
                } }

            Save-AppSettings -appName "test" -appResourceGroup "test" -appSettings $localAppSettings -filePath $fileName 4> $null

            $finalObject = (Get-Content -Raw $fileName | ConvertFrom-Json)

            $expectedValues = $localAppSettings.value + $remoteAppSettings.value

            # the trim is an artifact of converting to flat file and back to psObject
            $finalObject[0].value | Should -BeIn $expectedValues
            $finalObject[1].value | Should -BeIn $expectedValues
            $finalObject[2].value | Should -BeIn $expectedValues
            $finalObject[3].value | Should -BeIn $expectedValues

            $finalObject.Length | Should -Be 4

            Remove-Item $fileName
        }

        # case -- happy path, mocked get-azwebapp, local value to supercede remote
        It "Remote Web App Found with Customer Supplied Values - Conflicts with localAppSettings" {
            $fileName = "./file4.json"
            [array]$localAppSettings = @(
                @{name = "key1"; value = "value1" },
                @{name = "key2"; value = "value2" }
            )
            [array]$remoteAppSettings = @(
                @{name = "key2"; value = "value3" },
                @{name = "key4"; value = "value4" }
            )
            Mock Get-AzWebApp { return @{SiteConfig =
                    @{AppSettings = $remoteAppSettings }
                } }

            Save-AppSettings -appName "test" -appResourceGroup "test" -appSettings $localAppSettings -filePath $fileName 4> $null

            $finalObject = (Get-Content -Raw $fileName | ConvertFrom-Json)

            $expectedValues = $localAppSettings.value + "value4"

            # the trim is an artifact of converting to flat file and back to psObject
            $finalObject[0].value | Should -BeIn $expectedValues
            $finalObject[1].value | Should -BeIn $expectedValues
            $finalObject[2].value | Should -BeIn $expectedValues

            $finalObject.Length | Should -Be 3

            Remove-Item $fileName
        }

    }

}