
param
(
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $true)]
    [string] $TEST_ROOT
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
    . ($SetupHostPath + "/SetupHost.ps1")
}
else {
    . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

#################################################################################
#TODO: Comment out when 5.3.1 is installed in Atlashosted agents
# Import-Module -Name pester -RequiredVersion 5.3.1
# $result = Get-Module -ListAvailable -Name Pester
# Write-Host "Pester Version Installed: `n $($result.version)"

#get the resources in the RG to pass into each tests
$rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json

$tmpLocation = [System.IO.Path]::GetTempPath()
$tmpReportFile = $tmpLocation + "test.xml"
$TestResults = $(Invoke-Pester -Script @{ Path = "$TEST_ROOT/*"; Parameters = @{ resourceGroup = $resourceGroup; rgResources = $rgResources }; } -OutputFile $tmpReportFile -OutputFormat NUnitXml -PassThru)

# use this for pester v5.2
#$container = New-PesterContainer -Path "$TEST_ROOT/*" -Data @{ resourceGroup = $resourceGroup; rgResources = $rgResources }
#Invoke-Pester -Container $container


if ($TestResults.FailedCount -gt 0) {
    Write-Error "Failed '$($TestResults.FailedCount)' tests, build failed"
}
elseif ($TestResults.PassedCount -eq 0) {
    Write-Error "Passed '$($TestResults.PassedCount)' tests, build failed"
}
else {
    Write-Host "Zero tests failed Pester validation!"
}

