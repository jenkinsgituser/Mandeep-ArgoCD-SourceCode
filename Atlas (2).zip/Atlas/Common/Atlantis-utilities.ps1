$ErrorActionPreference = "Stop"

#get the private NSG as a PsObject by referenced Resource Group
function Get-AtlasPrivateWebAppNSG {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName
    )

    $nsgs = $(az network nsg list -g $resourceGroupName ) | ConvertFrom-Json
    $privateNsg = $nsgs | Where-Object { $_.name -match $CONST_PRIVATE_FILTER }
    return $privateNsg
}

function Get-AtlasPrivateFunctionAppNSG {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName
    )

    $nsgs = $(az network nsg list -g $resourceGroupName ) | ConvertFrom-Json
    $privateFunctionNsg = $nsgs | Where-Object { $_.name -match $CONST_PRIVATEFUNCTION_FILTER }
    return $privateFunctionNsg
}
#This function is used when the webapp requires access to DB, storage bus etc..
function Get-AtlasPrivatewebAccessNSG {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName
    )

    $nsgs = $(az network nsg list -g $resourceGroupName ) | ConvertFrom-Json
    $privatewebAccessNsg = $nsgs | Where-Object { $_.name -match $CONST_PRIVATEWEB_FILTER }
    return $privatewebAccessNsg
}

function Split-NetworkStringIntoPSObject {
    param
    (
        #four Octets plus mask
        #e.g., 10.0.0.0/8
        [Parameter(Mandatory = $true)]
        [string] $Network
    )
    $NetworkParseException = "Unable to parse network '$Network' into PsObject"
    $networkPieces = $network.Split('.').Split('/')
    if ($networkPieces.Length -ne 5) {
        throw $NetworkParseException
    }

    $networkObj = [PSCustomObject]@{
        FirstOctet  = [int]$networkPieces[0]
        SecondOctet = [int]$networkPieces[1]
        ThirdOctet  = [int]$networkPieces[2]
        FourthOctet = [int]$networkPieces[3]
        Mask        = [int]$networkPieces[4]
    }

    if (($networkObj.FirstOctet -gt 255 -or $networkObj.FirstOctet -lt 0) `
            -or ($networkObj.SecondOctet -gt 255 -or $networkObj.SecondOctet -lt 0) `
            -or ($networkObj.ThirdOctet -gt 255 -or $networkObj.ThirdOctet -lt 0) `
            -or ($networkObj.FourthOctet -gt 255 -or $networkObj.FourthOctet -lt 0) `
            -or ($networkObj.Mask -gt 32 -or $networkObj.Mask -lt 0) ) {
        throw "Unable to parse network '$Network' into PsObject"
    }

    return $networkObj
}


#this is split off as a function for testability of edge cases that we'll
#only infrequently encounter in production use cases (e.g., .254 incrementing)
function Get-NextAvailableSubnetFromSortedSubnets {
    param
    (
        #four Octets plus mask
        #e.g., 10.0.0.0/8
        [Parameter(Mandatory = $true)]
        [array] $SortedSubnetArray
    )
    $nextSubnet = [PSCustomObject]@{
        FirstOctet  = 0
        SecondOctet = 0
        ThirdOctet  = 0
        FourthOctet = 0
        Mask        = 25
    }

    #provision the next /25 from the bottom
    #get the largest current subnet. Figure out if it's last Octet is a .0 or a .128
    #based on whether it's a .0 or .128, increment the third and second subnets as needed
    #carrying the increment on edgecases
    $currentLastSubnet = $SortedSubnetArray[$SortedSubnetArray.Length - 1]
    if ($currentLastSubnet.Mask -eq 25) {
        if ($currentLastSubnet.FourthOctet -eq 128) {
            #do increment work
            $nextSubnet.FourthOctet = 0
            $nextSubnet.ThirdOctet = $currentLastSubnet.ThirdOctet + 1
            $nextSubnet.SecondOctet = $currentLastSubnet.SecondOctet
            $nextSubnet.FirstOctet = $currentLastSubnet.FirstOctet
            if ($nextSubnet.ThirdOctet -gt 255) {
                $nextSubnet.ThirdOctet = 0
                $nextSubnet.SecondOctet += 1
                if ($nextSubnet.SecondOctet -gt 255) {
                    Write-Output "SecondOctet attempting to increment greater than 255. Aborting with exception..."
                    throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
                }
            }
        }
        else {
            #set the fourth Octet to 128 for the /25 and copy
            #the parent for the rest
            $nextSubnet.FirstOctet = $currentLastSubnet.FirstOctet
            $nextSubnet.SecondOctet = $currentLastSubnet.SecondOctet
            $nextSubnet.ThirdOctet = $currentLastSubnet.ThirdOctet
            $nextSubnet.FourthOctet = 128
        }
    }
    elseif ($currentLastSubnet.Mask -eq 24) {
        #handle cases where previous subnet has a /24
        $nextSubnet.FirstOctet = $currentLastSubnet.FirstOctet
        $nextSubnet.SecondOctet = $currentLastSubnet.SecondOctet
        $nextSubnet.ThirdOctet = $currentLastSubnet.ThirdOctet + 1
        $nextSubnet.FourthOctet = 128
        if ($nextSubnet.ThirdOctet -gt 255) {
            $nextSubnet.ThirdOctet = 0
            $nextSubnet.SecondOctet += 1
            if ($nextSubnet.SecondOctet -gt 255) {
                Write-Output "Subnet Mask 24 subflow -- Aborting with exception..."
                Write-Output "SecondOctet attempting to increment greater than 255. Aborting with exception..."
                throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
            }
        }
    }
    elseif ($currentLastSubnet.Mask -eq 16) {
        #handle cases where previous subnet has an entire /16
        $nextSubnet.FirstOctet = $currentLastSubnet.FirstOctet
        $nextSubnet.SecondOctet = $currentLastSubnet.SecondOctet + 1
        $nextSubnet.ThirdOctet = 0
        $nextSubnet.FourthOctet = 0
        if ($nextSubnet.SecondOctet -gt 255) {
            Write-Output "Subnet Mask 16 subflow -- Aborting with exception..."
            Write-Output "SecondOctet attempting to increment greater than 255. Aborting with exception..."
            throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
        }
    }

    return $nextSubnet
}

#grab next available /25
function Get-NextAvailableNetworkSpace {
    param
    (
        #defined network
        #e.g., "10.0.0.0/8"
        [Parameter(Mandatory = $true)]
        [string] $availableNetworkRange,

        #list of network ranges in use
        #e.g., "10.1.0.0/16, 10.2.0.0/25"
        [Parameter(Mandatory = $true)]
        [array] $usedNetworkRanges,

        #mask to use for subnet allocation
        #currently only /25 supported
        [Parameter(Mandatory = $false)]
        [string] $mask = "/25"
    )

    if ($mask -ne "/25" `
            -and $mask -ne "25" ) {
        Write-Error "Invalid network mask passed: $mask. Only a /25 mask is supported (128 addresses)."
    }

    #$vnetRange = Split-NetworkStringIntoPSObject -network $availableNetworkRange

    $subnetsArray = @()
    foreach ($subnet in $usedNetworkRanges) {
        $subnetNetworkObj = Split-NetworkStringIntoPSObject -Network $subnet.ToString()
        Write-Debug "subnetNetworkObj: $subnetNetworkObj"
        $subnetsArray += $subnetNetworkObj
    }
    Write-Debug "subnetsArray.Length: $($subnetsArray.Length)"

    #since we're only working with /25 allocations a lot of assumptions are going to be made below
    #if anything other than /25 is going to be supported, this will need to be updated.
    #at this point in time, a /27 was deemed as the minimum we want to support, while a /24 was too much
    #A /25 should be above the upper bound of what will ever be needed by one subnet in an App server farm
    #while also enabling twice as much upper bound
    #^^famous last words -- mdx7683 - 05/2019

    #sort the subnets by first Octet, second, third, fourth -- ascending
    $sortedSubnets = [array]($subnetsArray | Sort-Object -Property @{Expression = { $_.FirstOctet }; Descending = $false }, `
        @{Expression = { $_.SecondOctet } ; Descending = $false }, `
        @{Expression = { $_.ThirdOctet }; Descending = $false }, `
        @{Expression = { $_.FourthOctet }; Descending = $false } )

    Write-Host "Currently allocated subnets:"
    foreach ($subnet in $sortedSubnets) {
        Write-Host "`t Subnet: $($subnet.FirstOctet).$($subnet.SecondOctet).$($subnet.ThirdOctet).$($subnet.FourthOctet)/$($subnet.Mask)"
    }

    $nextSubnetMask = Get-NextAvailableSubnetFromSortedSubnets -SortedSubnetArray $sortedSubnets
    Write-Debug "nextSubnetMask: $nextSubnetMask"

    #confirm the provisioned /25 is in the defined network
    if ($nextSubnetMask.FirstOctet -ne 10) {
        Write-Verbose "'nextSubnetMask.FirstOctet': $($nextSubnetMask.FirstOctet)" -Verbose
        Write-Verbose "nextSubnetMask.FirstOctet not provisioned as a 10.x. Aborting..." -Verbose
        throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
    }
    elseif ($nextSubnetMask.SecondOctet -gt 255) {
        Write-Verbose "'nextSubnetMask.SecondOctet': $($nextSubnetMask.SecondOctet)"
        Write-Verbose "nextSubnetMask.SecondOctet not provisioned as less than 255 Aborting..." -Verbose
        throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
    }
    elseif ($nextSubnetMask.ThirdOctet -gt 255) {
        Write-Verbose "'nextSubnetMask.ThirdOctet': $($nextSubnetMask.ThirdOctet)" -Verbose
        Write-Verbose "nextSubnetMask.ThirdOctet not provisioned as less than 255 Aborting..." -Verbose
        throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
    }
    elseif ($nextSubnetMask.FourthOctet -ne 0 -and $nextSubnetMask.FourthOctet -ne 128) {
        Write-Verbose "'nextSubnetMask.FourthOctet': $($nextSubnetMask.FourthOctet)" -Verbose
        Write-Verbose "nextSubnetMask.FourthOctet not provisioned as 0 or 128 which mismatches with a /25 mask expectation..." -Verbose
        throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
    }
    elseif ($nextSubnetMask.Mask -ne 25) {
        Write-Verbose "'nextSubnetMask.Mask': $($nextSubnetMask.Mask)" -Verbose
        Write-Verbose "nextSubnetMask.Mask not provisioned as 25 which mismatches with a /25 mask expectation..." -Verbose
        throw $CONST_UNABLE_TO_ALLOCATE_EXCEPTION
    }

    return $nextSubnetMask
}

function Add-AtlasAtlantisSubnetToWebApp {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName,

        [Parameter(Mandatory = $true)]
        [string] $vnetName,

        [Parameter(Mandatory = $true)]
        [string] $allocatedSubnetString,

        [Parameter(Mandatory = $true)]
        [string] $location
    )

    $nsg = Get-AtlasPrivateWebAppNSG -resourceGroupName $resourceGroupName
    if (!$($nsg.id)) {
        Write-Error "Unable to discover NSG to attach to Atlantis subnet. Aborting..."
        Exit 10
    }
    Write-Verbose "Private NSG: $nsg" -Verbose

    $locShortName = Get-LocationShortName -Location $location
    $subnetName = "$((New-Guid).Guid)$locShortName-private-subnet-v1"
    Write-Verbose "Name: $subnetName `t Prefix: $allocatedSubnetString" -Verbose

    Write-Verbose "Adding subnet '$subnetName' Web App in Resource Group '$resourceGroupName'" -Verbose

    $newSubnet = az network vnet subnet create `
        --address-prefixes $allocatedSubnetString `
        --name $subnetName `
        --resource-group $resourceGroupName `
        --vnet-name $vnetName `
        --network-security-group $nsg.id `
        --service-endpoints 'Microsoft.KeyVault' 'Microsoft.ServiceBus' 'Microsoft.Web' 'Microsoft.EventHub' `
        --delegations 'Microsoft.Web/serverfarms' | ConvertFrom-Json

    if (!$newSubnet) {
        Write-Warning "Unable to provision subnet!"
    }
    return $newSubnet
}

function Add-AtlasAtlantisSubnetToFunctionApp {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName,

        [Parameter(Mandatory = $true)]
        [string] $vnetName,

        [Parameter(Mandatory = $true)]
        [string] $allocatedSubnetString,

        [Parameter(Mandatory = $true)]
        [string] $location
    )

    $nsg = Get-AtlasPrivateFunctionAppNSG -resourceGroupName $resourceGroupName
    if (!$($nsg.id)) {
        Write-Error "Unable to discover NSG to attach to Atlantis subnet. Aborting..."
        Exit 10
    }
    Write-Verbose "PrivateFunction NSG: $nsg" -Verbose

    $locShortName = Get-LocationShortName -Location $location
    $subnetName = "$((New-Guid).Guid)$locShortName-privatefunctions-subnet-v1"
    Write-Verbose "Name: $subnetName `t Prefix: $allocatedSubnetString" -Verbose

    Write-Verbose "Adding subnet '$subnetName' Function App in Resource Group '$resourceGroupName'" -Verbose

    $newSubnet = az network vnet subnet create `
        --address-prefixes $allocatedSubnetString `
        --name $subnetName `
        --resource-group $resourceGroupName `
        --vnet-name $vnetName `
        --network-security-group $nsg.id `
        --service-endpoints 'Microsoft.KeyVault' 'Microsoft.ServiceBus' 'Microsoft.Web' 'Microsoft.Storage' 'Microsoft.Sql' 'Microsoft.EventHub' 'Microsoft.AzureCosmosDB' `
        --delegations 'Microsoft.Web/serverfarms' | ConvertFrom-Json

    if (!$newSubnet) {
        Write-Warning "Unable to provision subnet!"
    }
    return $newSubnet
}

function Add-AtlasAtlantisSubnetToPrivateWebAccess {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName,

        [Parameter(Mandatory = $true)]
        [string] $vnetName,

        [Parameter(Mandatory = $true)]
        [string] $allocatedSubnetString,

        [Parameter(Mandatory = $true)]
        [string] $location
    )

    $nsg = Get-AtlasPrivatewebAccessNSG -resourceGroupName $resourceGroupName
    if (!$($nsg.id)) {
        Write-Error "Unable to discover NSG to attach to Atlantis subnet. Aborting..."
        Exit 10
    }
    Write-Verbose "PrivatewebAccess for WebAapp NSG: $nsg" -Verbose

    $locShortName = Get-LocationShortName -Location $location
    $subnetName = "$((New-Guid).Guid)$locShortName-privateweb-subnet-v1"
    Write-Verbose "Name: $subnetName `t Prefix: $allocatedSubnetString" -Verbose

    Write-Verbose "Adding subnet '$subnetName' Webapp App in Resource Group '$resourceGroupName'" -Verbose

    $newSubnet = az network vnet subnet create `
        --address-prefixes $allocatedSubnetString `
        --name $subnetName `
        --resource-group $resourceGroupName `
        --vnet-name $vnetName `
        --network-security-group $nsg.id `
        --service-endpoints 'Microsoft.KeyVault' 'Microsoft.ServiceBus' 'Microsoft.Web' 'Microsoft.Storage' 'Microsoft.Sql' 'Microsoft.EventHub' 'Microsoft.AzureCosmosDB'`
        --delegations 'Microsoft.Web/serverfarms' | ConvertFrom-Json

    if (!$newSubnet) {
        Write-Warning "Unable to provision subnet!"
    }
    return $newSubnet
}


function Get-AtlasNextAvailableAtlantisSubnet {
    #all params are optional but support is present for overrides
    param
    (
        [Parameter(Mandatory = $false)]
        [string] $resourceGroupName = "RG-CMFG-ENV-Atlas-Infrastructure",

        [Parameter(Mandatory = $false)]
        [string] $vnetName,

        #Default range /27
        #override available for /24
        [Parameter(Mandatory = $false)]
        [string] $mask = "/25",

        [Parameter(Mandatory = $false)]
        [string] $resourceType = $CONST_AS_RESOURCE_TYPE_WEB_APP,

        [Parameter(Mandatory = $false)]
        [string] $location = "eastus2"
    )

    $locShortName = Get-LocationShortName -Location $location
    if (!$vnetName) {
        $vnetName = "VNet-CMFG-Atlas-Atlantis" + $locShortName
    }

    $subscription = $(az account show --query "name" -o tsv)

    #allow for a dedicated environment var override -- think build testing
    if ($env:ATLANTIS_RG_NAME) {
        $resourceGroupName = $env:ATLANTIS_RG_NAME
    }
    elseif ($resourceGroupName -match "ENV") {
        #if resourceGroupName isn't passed in it'll have the ENV placeholder
        if ($subscription -match "NonProduction" -or $subscription -match "-NonProd" -or $subscription -match "Sandbox") {
            $resourceGroupName = "RG-CMFG-NP1-Atlas-Infrastructure" + $locShortName
        }
        else {
            $resourceGroupName = "RG-CMFG-PR1-Atlas-Infrastructure" + $locShortName
        }
    }

    #get the vnet and defined address space
    $vnet = $(az network vnet show --name $vNetName -g $resourceGroupName) | ConvertFrom-Json
    $vnetAddressSpace = [string]$vnet.addressSpace.addressPrefixes

    #get the list of subnets currently allocated space in vnet
    $subnets = $(az network vnet subnet list -g $resourceGroupName --vnet-name $vnetName) | ConvertFrom-Json
    $usedRanges = [array]$subnets.addressPrefix

    #delegate determination of available space
    $allocatedSubnetObj = Get-NextAvailableNetworkSpace -availableNetworkRange $vnetAddressSpace -usedNetworkRanges $usedRanges -mask $mask

    #convert the custom object down to a string
    $allocatedSubnetString = "$($allocatedSubnetObj.FirstOctet).$($allocatedSubnetObj.SecondOctet).$($allocatedSubnetObj.ThirdOctet).$($allocatedSubnetObj.FourthOctet)/$($allocatedSubnetObj.Mask)"

    $newSubnet = $null;

    switch ($resourceType.ToLower()) {
        $CONST_AS_RESOURCE_TYPE_WEB_APP {
            try {
                $newSubnet = Add-AtlasAtlantisSubnetToWebApp `
                    -resourceGroupName "$resourceGroupName" `
                    -vnetName "$vnetName" `
                    -allocatedSubnetString "$allocatedSubnetString" `
                    -location $location
            }
            catch {
                Write-Verbose "First attempt to add subnet failed. Waiting 30 seconds before retrying one more time..."
                Start-Sleep -Seconds 30
                $newSubnet = Add-AtlasAtlantisSubnetToWebApp `
                    -resourceGroupName "$resourceGroupName" `
                    -vnetName "$vnetName" `
                    -allocatedSubnetString "$allocatedSubnetString" `
                    -location $location
            }
        }
        $CONST_AS_RESOURCE_TYPE_FUNCTION_APP {
            try {
                $newSubnet = Add-AtlasAtlantisSubnetToFunctionApp `
                    -resourceGroupName "$resourceGroupName" `
                    -vnetName "$vnetName" `
                    -allocatedSubnetString "$allocatedSubnetString" `
                    -location $location
            }
            catch {
                Write-Verbose "First attempt to add subnet failed. Waiting 30 seconds before retrying one more time..."
                Start-Sleep -Seconds 30
                $newSubnet = Add-AtlasAtlantisSubnetToFunctionApp `
                    -resourceGroupName "$resourceGroupName" `
                    -vnetName "$vnetName" `
                    -allocatedSubnetString "$allocatedSubnetString" `
                    -location $location
            }
        }

        $CONST_AS_RESOURCE_TYPE_WEB_APP_PRIVATE {
            try {
                $newSubnet = Add-AtlasAtlantisSubnetToPrivateWebAccess `
                    -resourceGroupName "$resourceGroupName" `
                    -vnetName "$vnetName" `
                    -allocatedSubnetString "$allocatedSubnetString" `
                    -location $location
            }
            catch {
                Write-Verbose "First attempt to add subnet failed. Waiting 30 seconds before retrying one more time..."
                Start-Sleep -Seconds 30
                $newSubnet = Add-AtlasAtlantisSubnetToPrivateWebAccess `
                    -resourceGroupName "$resourceGroupName" `
                    -vnetName "$vnetName" `
                    -allocatedSubnetString "$allocatedSubnetString" `
                    -location $location
            }
        }
        Default { Write-Error "Unable to determine resource type to have subnet added as allowed. Value passed was '$resourceType'." }
    }

    return $newSubnet
}

function Get-AtlasAtlantisSubnetByAppServicePlan {
    param(
        [Parameter(Mandatory = $true)]  [string] $AspName,
        [Parameter(Mandatory = $true)]  [string] $AspResourceGroup
    )

    $subnetResourceId = $null
    try {
        $subnetResourceId = (Get-AtlasAppServicePlanVirtualConnections -ResourceGroup $AspResourceGroup `
                -AppServicePlanName $AspName).properties.vnetResourceId
    }
    catch {
        Write-Verbose "Existing subnet assignment not found for App Resource called '$AspName'"
    }

    return $subnetResourceId
}


function Confirm-AppServiceTypeMatchesExistingTypeOnAsp {
    param(
        [Parameter(Mandatory = $false)]  [string] $resourceType = $CONST_AS_RESOURCE_TYPE_WEB_APP,
        [Parameter(Mandatory = $false)]  [string] $SubnetId
    )

    $isValid = $false

    if ($resourceType -eq $CONST_AS_RESOURCE_TYPE_WEB_APP -and $SubnetId -match $CONST_PRIVATE_FILTER) {
        $isValid = $true
        Write-Verbose "Resource type '$resourceType'. ASP subnet type matches '$CONST_PRIVATE_FILTER'" -Verbose
    }
    elseif ($resourceType -eq $CONST_AS_RESOURCE_TYPE_FUNCTION_APP -and $SubnetId -match $CONST_PRIVATEFUNCTION_FILTER) {
        $isValid = $true
        Write-Verbose "Resource type '$resourceType'. ASP subnet type matches '$CONST_PRIVATEFUNCTION_FILTER'" -Verbose
    }
    elseif ($resourceType -eq $CONST_AS_RESOURCE_TYPE_WEB_APP_PRIVATE -and $SubnetId -match $CONST_PRIVATEWEB_FILTER) {

        $isValid = $true
        Write-Verbose "Resource type '$resourceType'. ASP subnet type matches '$CONST_PRIVATEWEB_FILTER'" -Verbose
    }

    return $isValid
}