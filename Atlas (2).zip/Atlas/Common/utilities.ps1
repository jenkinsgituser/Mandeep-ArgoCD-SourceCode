# In general, this file contains common functions that DO NOT rely on the presence of
# any other dependencies. These functions are just plain ole PowerShell, performing business
# logic as needed
#********************************************************************************************

function Get-AtlasVersionNumber {
    $productVersionNumber = $null

    # Product Information file at the root of the source code structure (../)
    $productInformationFile = "$env:ATLAS_REPO_ROOT/productInformationV2.json"

    try {
        # Read the JSON content from the JSON file
        $productInfoJSON = Get-Content $productInformationFile | Out-String | ConvertFrom-Json

        # Update the version number in the ARM Template to the new version number provided.
        $productVersionNumber = $productInfoJSON.productVersion

        Write-Verbose $('Product version number: ' + $productVersionNumber) -Verbose
    }
    catch {
        # Supress the error
    }
    finally {
        $global:lastExitCode = $null
    }

    return ($CONST_ATLAS_IDENTIFIER + "-" + $productVersionNumber)
}


function Set-ValidateResourceNameVariableCaseSpecific {
    param
    (
        [Parameter (Mandatory = $true)] [string] $variableName,
        [Parameter (Mandatory = $true)] [string] $variableValue,
        [Parameter (Mandatory = $true)] [string] $variablePrefix
    )

    if ($variableValue.StartsWith("$variablePrefix")) {
        return "$variableValue"
    }
    else {
        # Write-Error starts each message with "ERROR" already
        Write-Error "Please enter a valid value for $variableName.  Must begin with '$variablePrefix'"
        Exit 1
    }
}

function Set-ValidateResourceNameVariable {
    param
    (
        [Parameter (Mandatory = $true)] [string] $variableName,
        [Parameter (Mandatory = $true)] [string] $variableValue,
        [Parameter (Mandatory = $true)] [string] $variablePrefix
    )

    if ($variableValue.StartsWith("$variablePrefix", 'CurrentCultureIgnoreCase')) {
        return "$variableValue"
    }
    else {
        # Write-Error starts each message with "ERROR" already
        Write-Error "Please enter a valid value for $variableName.  Must begin with '$variablePrefix'"
        Exit 1
    }
}

function Write-AtlasSanitizeInputs {
    #take all the input environment variables and trim any spaces
    #name leaves the ability to do more in the future if necessary
    Get-ChildItem Env:* | ForEach-Object { Set-Item -Path "Env:$($_.Name)" -Value $_.Value.trim() }

}

function Wait-JobCompletion {
    [CmdletBinding()]
    param($job)
    Write-Host "Waiting for job $($job.Name)"
    Wait-Job -Job $job
    Write-Host "Writing output from job $($job.Name)"
    $origErrorActionPreference = $errorActionPreference
    $errorActionPreference = "Continue"
    Receive-Job -Job $job
    $errorActionPreference = $origErrorActionPreference
}

function Invoke-CommandWithRetries {
    param(
        [Parameter(Mandatory = $false)]
        [int] $maxAttempts = 10,

        [Parameter(Mandatory = $false)]
        [int] $retryTimer = 5,

        [Parameter(Mandatory = $true)]
        [string]$command,

        [Parameter(Mandatory = $false)]
        [int]$LineNumber
    )

    $result = $null
    $i = 0
    while ($i -lt $maxAttempts -and !$result) {
        try {
            $result = Invoke-Expression -Command $command
        }
        catch {
            Write-Verbose "Attempt $i failed when removing Key Vault rule" -Verbose
            if ($i -eq ($maxAttempts - 1)) {
                Write-Error "Exception '$($_.Exception.Message)'. Failed maximal attempts when executing line $LineNumber"
                Exit 20
            }
            Start-Sleep -Seconds $retryTimer
        }
        $i++
    }

    return $result
}

function Get-StringFromHashTable {
    param(
        [Parameter(Mandatory = $true)]
        [HashTable]$HashTable
    )

    # Need to sort the hash table for Atlas hosted agents
    $SortedHashTable = $HashTable.Clone()
    $SortedHashTable = $HashTable.GetEnumerator() | Sort-Object key

    $resultString = ($SortedHashTable.GetEnumerator() | ForEach-Object { "$($_.Key)='$($_.Value)'" }) -join ';'
    return "{$resultString}"
}

#this is a bit dicey but running against a timebox!
function Get-AzCliSemVersionFromString {
    param(
        [Parameter(Mandatory = $true)][string]$versionString
    )

    $split = $versionString.split(' ')
    $splitLast = $split[-1]
    $splitSecondLast = $split[-2]

    if ($splitLast -ne '*') {
        return $splitLast
    }
    else {
        return $splitSecondLast
    }
}

Function IsJobTerminalState {
    param(
        [Parameter(mandatory = $true)] [string] $status
    )
    return $status -eq "Completed" -or $status -eq "Failed" -or $status -eq "Stopped" -or $status -eq "Suspended"
}

# This function will retry a delegate passed to it. To call this function you would use the following pattern:
# The delegate can be any block of code, as long as the runtime has source any referenced functions
# Retry({SomeFunction "Some Message to return"})
# Note that the functional delegate must currently be a void as no response is returned.
function Retry-FunctionalDelegate {
    param(
        [Parameter(Mandatory = $true)][Action]$Action,
        [Parameter(Mandatory = $false)][int]$MaxAttempts = 2,
        [Parameter(Mandatory = $false)][int]$RetryDelaySeconds = 2
    )

    $attempts = 1
    $currentException = $null

    $ErrorActionPreferenceToRestore = $ErrorActionPreference
    $ErrorActionPreference = "Stop"

    $ExceptionTypesToRetry = @("Microsoft.Azure.Management.Automation.Models.ErrorResponseException")

    # Intended to handle error:

    # First Error: Please ensure you have network connection. Error detail: HTTPSConnectionPool(host='login.microsoftonline.com', port=443):
    # Max retries exceeded with url: /***/oauth2/token (Caused by NewConnectionError('<urllib3.connection.VerifiedHTTPSConnection
    # object at 0x0507D070>: Failed to establish a new connection: [Errno 11001] getaddrinfo failed',))

    # Second Error: ERROR: The running command stopped because the preference variable "ErrorActionPreference" or common parameter is set to
    # Stop: Please ensure you have network connection. Error detail: ('Connection aborted.', OSError("(10054, 'WSAECONNRESET')",))
    $ErrorStringsToRetry = @("Errno 11001", "10054, 'WSAECONNRESET'")

    do {
        try {
            
            $ActionString = $Action.Target.Constants | Out-String
            $Action.Invoke()

            if(($ActionString.TrimStart() -like "az*") -and ($LASTEXITCODE -eq 1)){
                throw "An error occured during the arm template deployment. See above for error."
                break
            }else {
                break
            }
            
        }
        #catch [Exception] {
        catch {
            $currentException = $_
            switch ($_) {
                # Handling typed exceptions. For whatever reason, I could not handle this explicitly
                # using a typed catch as the type catching wouldn't handle the innerexception...
                { $currentException.Exception.InnerException -and `
                        $currentException.Exception.InnerException.GetType().FullName -In $ExceptionTypesToRetry } {
                    Write-Warning "Typed Exception encountered: $($currentException.Exception.InnerException.GetType().FullName). `n Message: $($currentException.Exception.Message)"
                }

                # Handling generic exceptions via the error message thrown. If there are more
                # strings to match, add them to the array and reference by location currently
                # as I don't have a clean way to do a "matchAny" if given an error message and an
                # array of potential strings to match
                { $currentException.Exception.Message.Contains($ErrorStringsToRetry[0]) -or
                    $currentException.Exception.Message.Contains($ErrorStringsToRetry[1]) } {
                    Write-Warning "Exception encountered: $($currentException.Exception.Message)"
                }

                # unhandled exception or error type -- throw
                default {
                    throw $currentException.Exception.Message
                    # break not required as the throw is terminating
                }
            }
        }
        $attempts++
        if ($attempts -le $MaxAttempts) {
            Write-Verbose -Verbose ("Action failed. Waiting " + $RetryDelaySeconds + " seconds before attempt " + $attempts + " of " + $MaxAttempts + ".")
            Start-Sleep -Seconds $RetryDelaySeconds
        }
        else {
            $ErrorActionPreference = $ErrorActionPreferenceToRestore
            throw "Maximum of $MaxAttempts retries reached: $($currentException.Exception.Message)"
        }
    } while ($attempts -le $MaxAttempts)

    # restore global errorActionPreference to original state before departing scope
    $ErrorActionPreference = $ErrorActionPreferenceToRestore
}