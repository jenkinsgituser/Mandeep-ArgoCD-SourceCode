function Save-AppSettings {
    param(
        [Parameter(Mandatory = $true)]
        [string]$appName,

        [Parameter(Mandatory = $true)]
        [string]$appResourceGroup,

        [Parameter(Mandatory = $true)]
        [array]$appSettings,

        [Parameter(Mandatory = $true)]
        [string]$filePath
    )

    Write-Verbose "Saving app settings for $appName" -Verbose

    Write-Verbose "The following Atlas-managed app settings exist for $appName" -Verbose
    $appSettings | ForEach-Object { Write-Verbose "`t$($_.Name)" -Verbose }

    Write-Verbose "Checking if the App Service $appName exists" -Verbose
    $webApp = Get-AzWebApp -ResourceGroupName $appResourceGroup -Name $appName -ErrorAction SilentlyContinue
    if ($webApp) {
        Write-Verbose "App Service $appName exists" -Verbose

        $webApp.SiteConfig.AppSettings | ForEach-Object {
            Write-Verbose "Processing app setting $($_.Name)" -Verbose

            $appSetting = $_
            # check if the setting is currently defined in the passed in set, if so skip
            $appSetting = $appSettings | Where-Object { $_.Name -eq $appSetting.Name }
            if ($null -eq $appSetting) {
                Write-Verbose "Adding custom app setting $($_.Name) value" -Verbose
                $appSettings += @{ name = $_.Name; value = $_.Value }
            }
            else {
                Write-Verbose "Skipping Atlas-managed app setting $($_.Name)" -Verbose
            }
        }
    }
    else {
        Write-Verbose "App Service $appName doesn't exist so there are no custom app settings to save" -Verbose
    }

    Write-Verbose "App settings saved for $appName" -Verbose
    $appSettings | ForEach-Object { Write-Verbose "`t$($_.Name)" -Verbose }

    Write-Verbose "Saving app settings to file $filePath" -Verbose
    ConvertTo-Json $appSettings | Set-Content $filePath
}