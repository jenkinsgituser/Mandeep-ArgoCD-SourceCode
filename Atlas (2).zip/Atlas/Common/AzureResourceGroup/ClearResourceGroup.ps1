Param
(
    [Parameter (Mandatory = $true)]
    [string] $ResourceGroupName,

    [Parameter (Mandatory = $true)]
    [bool] $Force
)

if ($Force) {
    # Create an ARM template that is empty
    $templateObj = [hashtable] @{
        '$schema'          = "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"; `
            contentVersion = "1.0.0.0"; `
            parameters     = ""; `
            variables      = ""; `
            resources      = @(); `

    }

    Write-Warning "Emptying resource group $ResourceGroupName!"
    New-AzResourceGroupDeployment -ResourceGroupName $ResourceGroupName `
        -TemplateObject $templateObj `
        -Mode 'Complete' `
        -ErrorAction 'Continue' `
        -Force

    Write-Warning "$ResourceGroupName emptied!"
}