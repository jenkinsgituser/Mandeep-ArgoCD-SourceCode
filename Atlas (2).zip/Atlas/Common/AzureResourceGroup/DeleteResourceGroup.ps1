param
(
  [Parameter(Mandatory = $true)]
  [string] $resourceGroup
)

$RGFilter1 = "RG-CMFG-T01-Atlas-Test*"
$RGFilter2 = "RG-CMFG-NP1-Atlas-Test*"

if (($resourceGroup -notlike $RGFilter1) -and ($resourceGroup -notlike $RGFilter2)) {
  Write-Error "Resource Group must match filter $RGFilter1 or $RGFilter2"
  Exit 1
}

$LockName = (Get-AzResourceLock -ResourceGroupName $resourceGroup).name

if (!$LockName) {
  Write-Verbose "Deleting Resource Group: $($resourceGroup)" -Verbose

  $ErrorActionPreference = "stop"
  $ProvisionState = "Succeeded"
  $I = 0
  
  while (($ProvisionState -eq "Succeeded") -and ($I -lt 5)) {
    $I++
    Write-Verbose "`t Attempting ($I) to the delete Resource Group" -Verbose
    $Output = Remove-AzResourceGroup -Name $resourceGroup -Force -AsJob
    try {
      $ProvisionState = (Get-AzResourceGroup -Name $resourceGroup).ProvisioningState
    }
    catch {
      $ProvisionState = $null
    }
  }

  Write-Verbose "Resource Group is being deleted..." -Verbose
}
else {
  Write-Verbose "Resource Group has a lock, not deleting" -Verbose
}