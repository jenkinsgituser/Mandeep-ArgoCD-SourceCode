$commitID = "$($env:BUILD_SOURCEVERSION)".substring(0, 8)

# BUILD_BUILDNUMBER contains both date and build number (20201102-687036), this will pick off just the build number
$buildID = "$($env:BUILD_BUILDNUMBER)"
$buildIDRG = $buildID.Split("-")[1]

#Setting 'subnet' must have a name that begins with an alphabet or underscore and not end with whitespace, dot or underscore.
#^ to comply, if the commitID starts with a number pre-pend a z and take the first 7 commitID numbers
$regex = [regex] '^[a-zA-Z][a-zA-Z0-9]+$'

if ($commitID -notmatch $regex) {
  $commitID = "z" + "$($commitID.substring(0,7))"
}

$RgType = "devSandbox"
$EnvironmentCode = "T01"
$RgAppDesc = "Atlas-Test-" + $commitID + "-" + $buildIDRG

Write-Host "##vso[task.setvariable variable=RESOURCE_GROUP_DESCRIPTION;]$RgAppDesc"

$resourceGroup = "RG-CMFG-" + $EnvironmentCode + "-" + $RgAppDesc + "-" + $RgType
Write-Verbose "Resource Group Name Input: $resourceGroup" -Verbose
Write-Host "##vso[task.setvariable variable=BUILD_RG_NAME;]$resourceGroup"

##########Testing for Central US ##########
#Set location as central us if job is scheduled on Tuesday (2)
try {
  $DayNumber = (Get-Date).dayofweek.value__
  if ($($env:BUILD_Reason) -eq "Schedule" ) {
    if ($DayNumber -eq 2) {
      #Set the location to centralus if it's Tuesday for nightly jobs
      $TuesdayScheduledLocation = "centralus"
      $ATLAS_DEFAULT_LOCATION = $TuesdayScheduledLocation
      Write-Host "##vso[task.setvariable variable=ATLAS_DEFAULT_LOCATION;]$ATLAS_DEFAULT_LOCATION"
      #Set the location for Resource group creation
      $BUILD_RG_LOCATION = $TuesdayScheduledLocation
      Write-Host "##vso[task.setvariable variable=BUILD_RG_LOCATION;]$BUILD_RG_LOCATION"
      #Location variable is used for Atlantis YAML build
      $Location = $TuesdayScheduledLocation
      Write-Host "##vso[task.setvariable variable=Location;]$Location"
      if ($env:EXPECTED_SUBNET -eq "cmfg" -and $($env:Build_DefinitionName) -Match "Params") {
        $AG_WAF_PARAMETERS_REQUEST_FILE = "azuredeployGatewayWAF_v2_ssl.testRequestParametersCentralUS.json"
      }
      elseif ($env:EXPECTED_SUBNET -eq "public") {
        $AG_WAF_PARAMETERS_REQUEST_FILE = "azuredeployGatewayWAF_v2_ssl_public.testRequestParametersCentralUS.json"
      }
      Write-Host "##vso[task.setvariable variable=AG_WAF_PROPERTIES_FILE_NAME;]$AG_WAF_PROPERTIES_FILE_NAME"
    }
  }
}
catch {
  Throw "Unable to parse the date"
}


