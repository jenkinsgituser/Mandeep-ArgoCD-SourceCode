########################################################
# This script needs to be deployed to AKS clusters to
# ensure they run the Atlas diagnostic tool
########################################################

Write-Verbose "Deploying Atlas Diagnostic Tester" -Verbose

# if existing config-tester service type is LoadBalancer, we need to delete the service so the deploy for ClusterIP works.
# This was only an issue for early adopter 1.18 cluster deploys.  This check can be removed once all clusters are fixed.
Write-Verbose "Get Atlas Diagnostic Tester Service" -Verbose
$tempErrorActionPref = $ErrorActionPreference
$ErrorActionPreference = "SilentlyContinue"
$configTesterService = kubectl get service "atlas-configuration-tester" -n "atlas" -o jsonpath='{}' | ConvertFrom-Json 2>$null
$ErrorActionPreference = $tempErrorActionPref
Write-Verbose "Atlas Diagnostic Tester Service Type $($configTesterService.spec.type)" -Verbose
if ($configTesterService.spec.type -eq "LoadBalancer") {
    Write-Verbose "Delete Atlas Diagnostic Tester Service Type $($configTesterService.spec.type) so it is recreated as ClusterIP" -Verbose
    kubectl delete service "atlas-configuration-tester" -n "atlas"
}

$AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $env:AKS_KUBERNETES_VERSION -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_LOCATION
Write-Verbose "AKS_KUBERNETES_VERSION: $AKS_KUBERNETES_VERSION" -Verbose

$DEPLOYMENT_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/config/atlas-diagnostic-tester.yaml"

Write-Verbose "DEPLOYMENT_FILE: $DEPLOYMENT_FILE" -Verbose

$DEPLOYMENT_FILE_OUTPUT = $DEPLOYMENT_FILE
if ($env:IsLocal) {
    $DEPLOYMENT_FILE_OUTPUT = $DEPLOYMENT_FILE_OUTPUT.Replace(".yaml", ".mine.yaml")
}

# Do an in-place token replace
$APPINSIGHTS_INSTRUMENTATIONKEY = $(Get-AzApplicationInsights -ResourceGroupName $env:AKS_RG_NAME).InstrumentationKey
(Get-Content $DEPLOYMENT_FILE) -replace '__AtlasEnvironment__', "$environment" -replace '__APPINSIGHTS_INSTRUMENTATIONKEY__', "$APPINSIGHTS_INSTRUMENTATIONKEY" | Set-Content $DEPLOYMENT_FILE_OUTPUT

Write-Host "kube_config-path = $KUBE_CONFIG_PATH"
Write-Host "Deployment_File_Output = $DEPLOYMENT_FILE_OUTPUT"

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f "$DEPLOYMENT_FILE_OUTPUT"

Write-Verbose "Deployed Atlas Diagnostic Tester" -Verbose