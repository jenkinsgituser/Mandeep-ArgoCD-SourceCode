param
(
  [Parameter(Mandatory = $true)]
  [string] $commandToRun
)

Write-Verbose "Requested By: $env:RELEASE_REQUESTEDFOREMAIL"

Write-Verbose "Get the directory whe the main script is executing" -Verbose
$SCRIPT_DIRECTORY = $PSScriptRoot
Write-Verbose "Script Directory: $SCRIPT_DIRECTORY" -Verbose

# Relative path for kube config file
$KUBE_CONFIG_PATH = "./.kube/config"

try {
  Write-Verbose "Get credentials and set up for kubectl to use"
  az aks get-credentials -g "$env:AKS_RG_NAME" `
    -n "$env:AKS_NAME" -a -f "$KUBE_CONFIG_PATH"

  Write-Verbose "Get kubectl version info"
  kubectl --kubeconfig "$KUBE_CONFIG_PATH" version short

  $commandToRun = $commandToRun += " --kubeconfig $KUBE_CONFIG_PATH"

  Write-Output "Run the input command string"
  if ($commandToRun[0] -eq '"') {
    Invoke-Expression "& $commandToRun"
  }
  else {
    Invoke-Expression $commandToRun
  }
}

catch {
  $currentException = $_
  Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
  if ($($currentException.Exception.Message).Contains("as current context in")) {
    Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
  }
  else {
    Write-Verbose "Error while loading supporting PowerShell Scripts" -Verbose
  }

}


finally {
  #cleanup kubeconfig file
  if (Test-Path -Path "$KUBE_CONFIG_PATH") {
    Write-Verbose "Removing kubectl config file..." -Verbose
    Remove-Item -Path "$KUBE_CONFIG_PATH"
  }
  else {
    Write-Verbose "kubectl config file does not exist" -Verbose
    Exit 1
  }
}
