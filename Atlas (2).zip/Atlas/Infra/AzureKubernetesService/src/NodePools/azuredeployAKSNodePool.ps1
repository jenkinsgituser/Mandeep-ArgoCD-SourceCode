$ErrorActionPreference = "Stop"

. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
# . ("$env:INFRA_FOLDER/AzureKubernetesService/src/NodePools/aksNodePoolVariables.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/NodePools/aksNodePoolVariables.ps1")
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")

Write-Verbose "Deploying AKS Node Pool: $AKS_NODE_POOL_NAME" -Verbose

$AKS_NODE_POOL_TEMPLATE_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/NodePools/azuredeployAKSNodePool.json"
Write-Verbose "AKS_NODE_POOL_TEMPLATE_FILE: $AKS_NODE_POOL_TEMPLATE_FILE" -Verbose

$DEPLOYMENT_NAME = "azuredeployAKSNodePool-$(Get-Date -f yyyyMMddHHmmss)"

$Action = {
    az deployment group create `
        -g "$AKS_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$AKS_NODE_POOL_TEMPLATE_FILE" `
        --parameters "clusterName=$AKS_NAME" `
        "clusterLocation=$AKS_LOCATION" `
        "NodePoolName=$AKS_NODE_POOL_NAME" `
        "NodePoolMode=$AKS_NODE_POOL_MODE" `
        "maxPods=$AKS_MAX_PODS" `
        "kubernetesVersion=$AKS_KUBERNETES_VERSION" `
        "agentCount=$AKS_AGENT_COUNT" `
        "agentVMSize=$AKS_AGENT_VM_SIZE" `
        "osDiskSizeGB=$AKS_DISK_SIZE_GB" `
        "enableAutoScaling=$AKS_ENABLE_AUTO_SCALING" `
        "AutoScalingMaxCount=$AKS_AUTO_SCALING_MAXCOUNT" `
        "AutoScalingMinCount=$AKS_AUTO_SCALING_MINCOUNT"
    }

Write-Verbose "Finished AKS Node Pool Deployment Script" -Verbose
Retry-FunctionalDelegate -Action $Action
Write-Verbose "Successfully Deployed AKS Node Pool: $AKS_NODE_POOL_NAME" -Verbose
Write-Verbose "Finished AKS Node Pool Deployment Script" -Verbose
