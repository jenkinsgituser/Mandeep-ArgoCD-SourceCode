$ErrorActionPreference = "Stop"

Function Get-RunningApplicationPodsOnNodePool {
  Param (
    [Parameter(mandatory = $true)] [string] $nodePool
  )

  # Get all running pods
  $runningPods = kubectl get pods --all-namespaces -o json --field-selector=status.phase=Running | ConvertFrom-Json
  $systemNamespaces = Get-SystemNameSpaces

  # Create an arraylist object to hold list of running application pods found
  $appPoolPodList = @()

  foreach ($pod in $runningPods.items) {

    # Check if the pod's namespace matches a known system namespace
    if ($systemNamespaces -notcontains $pod.metadata.namespace) {
      # No match found for a system node pool so add to the app pool pod array
      Write-AtlasOutput -LogLevel "INFO" -Message "Found running application pod $($pod.metadata.name)"
      $appPoolPodList += $($pod.metadata.name)
    }
  }
  if ($appPoolPodList.count -ne 0) {
    Write-AtlasOutput -LogLevel "INFO" -Message "Found running non-system application pod(s) $($appPoolPodList) in namespace $($namespace)"
  }
  else {
    Write-AtlasOutput -LogLevel "INFO" -Message "No running application pods found"
  }
  Return $appPoolPodList
}
Function DeleteNodePool {

  Param (
    [Parameter(mandatory = $true)] [string] $NodePoolName,
    [Parameter(Mandatory = $false)][string] $Force = $false
  )
  #Intialize variable to false
  $IsDeleted = $false

  try {
    az aks nodepool delete --cluster-name $AksCluster --name $NodePoolName --resource-group $ResourceGroupName | ConvertFrom-Json
    $IsDeleted = $true
  }
  catch {
    # An error was encountered when attempting to delete the system node pool so log and return result.
    $ERROR_MESSAGE = "Update failed for $($NodePoolName). $($_.Exception.Message)"
    Write-AtlasOutput -LogLevel "ERROR" -Message $ERROR_MESSAGE
    $IsDeleted = $false
  }
  Return $IsDeleted
}

Write-AtlasOutput -LogLevel "INFO" -Message "Getting AKS credentials"
az aks get-credentials -n $AksCluster -g $ResourceGroupName -a --overwrite-existing | Out-Null
Write-AtlasOutput -LogLevel "INFO" -Message "Credentials successfully retrieved"

$nodePoolToDelete = $(az aks nodepool show --cluster-name $AksCluster --name $NodePoolName --resource-group $ResourceGroupName) | ConvertFrom-Json

#  Check if node pool was found.  If not write error
Write-AtlasOutput -LogLevel "INFO" -Message "Checking for existence of node pool to delete: $NodePoolName"
if ($nodePoolToDelete) {
  # NodePool was found. Check if system or user node pool and set variable
  if ($nodePoolToDelete.mode -eq "System") {
    # This a system node pool check if it the active system node pool and verify
    # there are at least 2 system node pools before deleting
    Write-AtlasOutput -LogLevel "INFO" -Message "$($NodePoolNAME) is a system node pool"

    $nodePoolList = $(az aks nodepool list --cluster-name $AksCluster --resource-group $ResourceGroupName) | ConvertFrom-Json

    $systemNodePoolCount = ($nodePoolList | Where-Object -FilterScript { $_.Mode -eq "System" }).Count

    if ($systemNodePoolCount -gt 1) {
      # We have more than 1 system node pool so proceed with deletion request
      Write-AtlasOutput -LogLevel "INFO" -Message "More than 1 system node pool found....continuing"
      if ($Force -eq $true) {
        Write-AtlasOutput -Loglevel "INFO" -Message "Force parameter is $($Force)"
        # Force parameter is set so call function to delete node pool

        $PoolDeleted = DeleteNodePool -NodePoolName $NodePoolName -Force $true #Debug uncomment
        # Node pool delete failed so throw an error
        if ($PoolDeleted) {
          Write-AtlasOutput -Loglevel "INFO" -Message "Node pool $NodePoolName deleted"
        }
        else {
          Write-AtlasOutput -Loglevel "ERROR" -Message "Error encountered attempting to delete $NodePoolName"
          throw "Error encountered attempting to delete node pool $NodePoolName. "
        }
      }
      else {
        # Check if the node pool contains running application pods
        $RunningAppPods = Get-RunningApplicationPodsOnNodePool -NodePool $NodePoolName

        if ($RunningAppPods.count -ne 0) {
          Write-AtlasOutput  -Loglevel "ERROR" -Message "Found running application pods on node pool $NodePoolName. To delete this node pool you must set the Force parameter to true."
          Throw "Unable to delete system node pool since there are running application pods on node pool $NodePoolName"
        }
        else {
          # No running application pods found so continue with delete
          $PoolDeleted = DeleteNodePool -NodePoolName $NodePoolName
          if ($PoolDeleted) {
            Write-AtlasOutput -Loglevel "INFO" -Message "Node pool $NodePoolName deleted"
          }
          else {
            throw "Error encountered attempting to delete node pool $NodPoolName."
            Write-AtlasOutput -Loglevel "ERROR" -Message "Error encountered attempting to delete $NodePoolName"
          }
        }
      }
    }
    else {
      # We only have one system node pool so throw an error and exit
      Write-AtlasOutput  -Loglevel "ERROR" -Message "Unable to delete solitary system node pool. You must have 2 system node pools to delete one."
      Throw "Unable to delete solitary system node pool.  You must have 2 system node pools to delete one."
    }
  }
  else {
    # This is a user node pool so check for running application pods and proceed with deletion request
    Write-AtlasOutput -LogLevel "INFO" -Message "$($NodePoolNAME) is a user node pool"
    $RunningAppPods = Get-RunningApplicationPodsOnNodePool -NodePool $NodePoolName

    if ($RunningAppPods.count -ne 0) {
      if ($Force -eq $true) {
        Write-AtlasOutput -Loglevel "INFO" -Message "Force parameter is $($Force)"
        Write-AtlasOutput -LogLevel "WARN" -Message "Node pool $NodePoolName contains running application pods but Force parameter issued...deleting"
        $PoolDeleted = DeleteNodePool -NodePoolName $NodePoolName -Force $Force #Debug uncomment
        if ($PoolDeleted) {
          Write-AtlasOutput -Loglevel "INFO" -Message "Node pool $NodePoolName deleted"
        }
        else {
          throw "Unable to delete $($NodePoolName) node pool."
          Write-AtlasOutput -Loglevel "ERROR" -Message "Error encountered attempting to delete $NodePoolName"
        }
      }
      else {
        Write-AtlasOutput -Loglevel "ERROR" -Message "Application pods $($RunningAppPods) are running on node pool $NodePoolName. Use Force parameter"
        Throw "Unable to delete node pool $($NodePoolName) because it has running application pods"
      }
    }
    else {
      $PoolDeleted = DeleteNodePool -NodePoolName $NodePoolName -Force $Force
      # Node pool delete failed so throw an error
      if ($PoolDeleted) {
        Write-AtlasOutput -Loglevel "INFO" -Message "Node pool $NodePoolName deleted"
      }
      else {
        Write-AtlasOutput -Loglevel "ERROR" -Message "Value of $($PoolDeleted)"
        throw "Error encountered attempting to delete node pool $NodePoolName. "
      }
    }
  }
}
else {
  # Node pool not found so log error and exit
  Write-AtlasOutput -Loglevel "ERROR" -Message "The node pool $NodePoolName was not found within the subscription...ending script."

}

Write-AtlasOutput -LogLevel "INFO" -Message "Ending script."