if (!$AKS_ENVIRONMENT_SETUP_COMPLETE) {
    Write-Verbose "**************** Display the AKS Node Pool Variables with Values ****************" -Verbose
    $scriptPath = $PSCommandPath
    Write-Verbose "scriptPath for aksNodePooleVariables file :$scriptPath "-Verbose


    # Get the Subscription Name
    $SUBSCRIPTION_NAME = $(Get-AzContext).Subscription.Name
    Write-Verbose "SUBSCRIPTION_NAME: $SUBSCRIPTION_NAME" -Verbose

    # variable verification
    Write-Verbose "Determine environment (prod vs. nonprod)" -Verbose

    $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
    $environment = $SubscriptionProperties.environment
    Write-Verbose "Environment: $environment " -Verbose

    # AKS Name
    If ($env:AKS_NAME) {
        $AKS_NAME = $env:AKS_NAME
        Write-Verbose "AKS_NAME: $AKS_NAME" -Verbose
    }
    Else {
        Write-Error -Message "AKS_NAME was not passed in. Exiting..." -ErrorAction Stop
    }

    # AKS Resource Group
    If ($env:AKS_RG_NAME) {
        $AKS_RG_NAME = "$env:AKS_RG_NAME"
        Write-Verbose "AKS_RG_NAME: $AKS_RG_NAME" -Verbose
    }
    else {
        Write-Error -Message "AKS_RG_NAME was not passed in. Exiting..." -ErrorAction Stop
    }

    # Check if cluster already exists
    $existingAksName = ((az aks list --resource-group $AKS_RG_NAME | ConvertFrom-Json) | Where-Object { $_.name -match $AKS_NAME }).name
    if ($existingAksName) {
        $Current_AKS_Version_Detail = (Get-AzAksCluster -ResourceGroupName $AKS_RG_NAME -Name $ExistingAksName -ErrorAction SilentlyContinue).KubernetesVersion
        Write-Verbose "Current_AKS_Version_Detail: $Current_AKS_Version_Detail" -Verbose
    }
    else {
        Write-Error -Message "AKS Cluster not found in $AKS_RG_NAME. Exiting..." -ErrorAction Stop
    }

    # $AKS_NODE_POOL_NAME - all lower case and <= 12 characters
    if ($env:AKS_NODE_POOL_NAME) {
        $AKS_NODE_POOL_NAME = $env:AKS_NODE_POOL_NAME.ToLower()
        if ($AKS_NODE_POOL_NAME.length -le 12) {
            Write-Verbose "AKS_NODE_POOL_NAME: $AKS_NODE_POOL_NAME" -Verbose
        }
        else {
            Write-Error -Message "AKS_NODE_POOL_NAME cannot be greater than 12 characters. Exiting..." -ErrorAction Stop
        }
    }
    else {
        Write-Error -Message "AKS_NODE_POOL_NAME was not passed in. Exiting..." -ErrorAction Stop
    }

    #AKS_NODE_POOL_MODE
    # $AKS_NODE_POOL_MODE  - either system or user. It will default to be a "User" mode.
    if (($env:AKS_NODE_POOL_MODE -eq "User") -or ($env:AKS_NODE_POOL_MODE -eq "System")) {
        $AKS_NODE_POOL_MODE = $env:AKS_NODE_POOL_MODE
    }
    else {
        $AKS_NODE_POOL_MODE = "User"
        Write-Verbose -Message "AKS_NODE_POOL_MODE: $AKS_NODE_POOL_MODE, Selected by default." -Verbose
    }

    # Check if being called from AKS deployment where control plane was updated, if so, update
    #   the System Node Pool at the same time
    if ($env:AKS_NODE_POOL_MODE_AFTER_CONTROL_PLANE -eq "System") {
        $AKS_NODE_POOL_MODE = $env:AKS_NODE_POOL_MODE_AFTER_CONTROL_PLANE
    }
    Write-Verbose "AKS_NODE_POOL_MODE: $AKS_NODE_POOL_MODE" -Verbose
    #ensure that systempool name has agentpool in it
    if ($AKS_NODE_POOL_MODE -eq "System") {
        if ($AKS_NODE_POOL_NAME.contains("agentpool")) {
            Write-Verbose "The System Pool name is : $AKS_NODE_POOL_NAME" -Verbose
        }
        else {
            throw "System Pool name should start with agentpool. Example agentpool2"
        }
    }

    # AKS Agent VM Size
    $AKS_AGENT_VM_SIZE = $(If ($env:AKS_AGENT_VM_SIZE) { "$env:AKS_AGENT_VM_SIZE" } Else { If ($environment -eq $CONST_PROD_SUB) { "Standard_D4as_v4" } Else { "Standard_D4as_v4" } })
    Write-Verbose "AKS_AGENT_VM_SIZE: $AKS_AGENT_VM_SIZE" -Verbose

    #NodePool Autoscaling
    $AKS_ENABLE_AUTO_SCALING = $(If ($env:AKS_ENABLE_AUTO_SCALING) { "$env:AKS_ENABLE_AUTO_SCALING" } Else { "false" } )
    Write-Verbose "AKS_ENABLE_AUTO_SCALING: $AKS_ENABLE_AUTO_SCALING" -Verbose

    if ($AKS_ENABLE_AUTO_SCALING -eq "true") {
        $AKS_ENABLE_AUTO_SCALING = $true
        # AKS Auto Scaling Max Count is required
        if ($env:AKS_AUTO_SCALING_MAXCOUNT -and $env:AKS_AUTO_SCALING_MAXCOUNT -match "^[0-9]+$") {
            $AKS_AUTO_SCALING_MAXCOUNT = $env:AKS_AUTO_SCALING_MAXCOUNT
            Write-Verbose "AKS_AUTO_SCALING_MAXCOUNT: $AKS_AUTO_SCALING_MAXCOUNT" -Verbose
        }
        else {
            Write-Error "AKS_AUTO_SCALING_MAXCOUNT value is not found. Exiting..."  -ErrorAction Stop
        }

        #AKS Auto Scaling Min Count is required
        if ($env:AKS_AUTO_SCALING_MINCOUNT -and $env:AKS_AUTO_SCALING_MINCOUNT -match "^[0-9]+$") {

            $AKS_AUTO_SCALING_MINCOUNT = $env:AKS_AUTO_SCALING_MINCOUNT
            Write-Verbose "AKS_AUTO_SCALING_MINCOUNT: $AKS_AUTO_SCALING_MINCOUNT" -Verbose
        }

        else {
            Write-Error "AKS_AUTO_SCALING_MINCOUNT value is not found. Exiting..."  -ErrorAction Stop
        }

        #if max count gt min count, stop script. If equal, output a warning sign.
        if ([int]$AKS_AUTO_SCALING_MAXCOUNT -lt [int]$AKS_AUTO_SCALING_MINCOUNT ) {
            Write-Error -Message " AKS_AUTO_SCALING_MAXCOUNT: $AKS_AUTO_SCALING_MAXCOUNT is lesser than AKS_AUTO_SCALING_MINCOUNT : $AKS_AUTO_SCALING_MINCOUNT. Exiting " -ErrorAction Stop
        }
        elseif ([int]$AKS_AUTO_SCALING_MAXCOUNT -eq [int]$AKS_AUTO_SCALING_MINCOUNT ) {
            Write-Warning -Message "AKS_AUTO_SCALING_MAXCOUNT: $AKS_AUTO_SCALING_MAXCOUNT is equal to AKS_AUTO_SCALING_MINCOUNT : $AKS_AUTO_SCALING_MINCOUNT" -Verbose
        }
        else {
            Write-Verbose "AKS_AUTO_SCALING_MAXCOUNT: $AKS_AUTO_SCALING_MAXCOUNT is greater than AKS_AUTO_SCALING_MINCOUNT : $AKS_AUTO_SCALING_MINCOUNT" -Verbose
        }
    }
    else {
        $AKS_ENABLE_AUTO_SCALING = $false
        $AKS_AUTO_SCALING_MINCOUNT = 1
        $AKS_AUTO_SCALING_MAXCOUNT = 1
        Write-Verbose "AKS_ENABLE_AUTO_SCALING: $AKS_ENABLE_AUTO_SCALING" -Verbose
    }

    # AKS Disk Size - We don't want the customer to use this right now, but could be added in the future
    $AKS_DISK_SIZE_GB = $(If ($env:AKS_DISK_SIZE_GB) { "$env:AKS_DISK_SIZE_GB" } Else { "512" })
    Write-Verbose "AKS_DISK_SIZE_GB: $AKS_DISK_SIZE_GB" -Verbose


    $AKS_MAX_PODS_INT = $null
    [INT]$DEFAULT_MAX_PODS = 250
    [INT]$DEFAULT_Min_PODS = 10
    $AKS_MAX_PODS_INT = [int]$env:AKS_MAX_PODS
    if ([string]::IsNullOrEmpty($env:AKS_MAX_PODS)) {
        $AKS_MAX_PODS = "110"
    }
    else {
        if ($AKS_MAX_PODS_INT -lt $DEFAULT_Min_PODS -or $AKS_MAX_PODS_INT -gt $DEFAULT_MAX_PODS) {
            Write-Error -Message "AKS_MAX_PODS value passed in is invalid. The AKS_MAX_PODS value should be between 10 and 250." -ErrorAction Stop
        }
        else {
            $AKS_MAX_PODS = $env:AKS_MAX_PODS
        }
    }
    Write-Verbose "AKS_MAX_PODS: $AKS_MAX_PODS" -Verbose

    # Get the Location of the AKS cluster, since the pool has to be in that same location
    #$AKS_LOCATION = (Get-AzAksCluster -ResourceGroupName $AKS_RG_NAME -Name $AKS_NAME -ErrorAction SilentlyContinue).Location
    $AKS_LOCATION = (az aks show --name $AKS_NAME --resource-group $AKS_RG_NAME | ConvertFrom-Json).location

    Write-Verbose "AKS_LOCATION: $AKS_LOCATION" -Verbose
    Write-Verbose "AKS RG Name is $AKS_RG_NAME" -Verbose
    Write-Verbose "AKS Name is $AKS_NAME" -Verbose

    # AKS Version
    $latestAllowedVersion = Get-AKS-Supported-Latest-K8S-Version -AKS_Location $AKS_LOCATION
    Write-Verbose "latestAllowedVersion: $latestAllowedVersion" -Verbose

    #Check if the user-entered cluster version is valid or not
    if ([version]$Current_AKS_Version_Detail -gt [version]$latestAllowedVersion) {
        Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $Current_AKS_Version_Detail -AllowedLatestVersion $latestAllowedVersion
    }


    # Check of AKS Version Passed in
    If (![string]::IsNullOrEmpty($env:AKS_KUBERNETES_VERSION)) {
        # If AKS version only has the Major version (e.g. 1.19), set the variable to the highest minor version.
        if (($env:AKS_KUBERNETES_VERSION.Split(".")).count -eq 2) {
            $env:AKS_KUBERNETES_VERSION = $Current_AKS_Version_Detail
        }
        # Is this a new Deploy?
        if (!$Current_AKS_Version_Detail) {
            # Set the AKS cluster version as the user-entered version if no existing AKS cluster is available for the Resource group.
            # The user provided version should not greater than the latest allowed version.
            $AKS_KUBERNETES_VERSION = $env:AKS_KUBERNETES_VERSION
        }
        else {
            if ([version]$env:AKS_KUBERNETES_VERSION -lt [version]$Current_AKS_Version_Detail) {
                # Get array of all supported AKS versions in this location
                $SupportedVersions = $(az aks get-versions --location $AKS_LOCATION --query "orchestrators[?!isPreview].orchestratorVersion" -o tsv) |`
                    Where-Object { $_ -notmatch $CONST_PREVIEW_IDENTIFIER } |`
                    Sort-Object { [version] $_ }

                # check that the value entered in is a valid, supported version
                if ($SupportedVersions -match $env:AKS_KUBERNETES_VERSION) {
                    $AKS_KUBERNETES_VERSION = [version]$env:AKS_KUBERNETES_VERSION
                }
                else {
                    Write-Error "AKS_KUBERNETES_VERSION passed in: $env:AKS_KUBERNETES_VERSION is not a supported version." -Verbose
                    Exit
                }
            }
            elseif ([version]$env:AKS_KUBERNETES_VERSION -le [version]$latestAllowedVersion) {
                # Set the AKS cluster version as the user-entered cluster version if the user-entered cluster version is greater than the existing cluster version but lower than the latest cluster version.
                $AKS_KUBERNETES_VERSION = $env:AKS_KUBERNETES_VERSION
            }
            elseif ([version]$env:AKS_KUBERNETES_VERSION -gt [version]$Current_AKS_Version_Detail) {
                Write-Error "AKS_KUBERNETES_VERSION:$env:AKS_KUBERNETES_VERSION is greater than the AKS version of the existing cluster : $Current_AKS_Version_Detail " -Verbose
            }

        }
    }
    else {
        # Set the AKS cluster version to the Current version of the cluster, since User Node Pool can't be higher than the System Node Pool
        Write-Verbose "AKS_KUBERNETES_VERSION not passed, will use current AKS cluster version" -Verbose
        $AKS_KUBERNETES_VERSION = $Current_AKS_Version_Detail
    }
    Write-Verbose "AKS_KUBERNETES_VERSION: $AKS_KUBERNETES_VERSION" -Verbose

    # Verify if the node pool already exists
    $nodePoolListDetail = az aks nodepool list --cluster-name $AKS_NAME --resource-group $AKS_RG_NAME | ConvertFrom-Json
    [array]$existingnodePoolList = $nodePoolListDetail.Name
    if ($existingnodePoolList.contains( $AKS_NODE_POOL_NAME)) {
        $nodePoolShowDetail = $nodePoolListDetail | Where-Object { $_.name -eq $AKS_NODE_POOL_NAME }
        Write-Verbose "AKS_NODE_POOL_NAME: $AKS_NODE_POOL_NAME already exists" -Verbose
        $currentNodePoolMode = $nodePoolShowDetail.mode
        Write-Verbose "AKS_NODE_POOL_NAME: $AKS_NODE_POOL_NAME currently has AKS_NODE_POOL_MODE: $currentNodePoolMode " -Verbose

        #check if the current mode matched the requested mode, if not throw an error
        if ($env:AKS_NODE_POOL_MODE_AFTER_CONTROL_PLANE -ne "System") {
            if ($currentNodePoolMode -ne $AKS_NODE_POOL_MODE) {
                Write-Error -Message "Node Pool $AKS_NODE_POOL_NAME cannot be deployed with the AKS_NODE_POOL_MODE: $AKS_NODE_POOL_MODE, as it was previously deployed with mode $currentNodePoolMode " -ErrorAction Stop
            }
        }
        #check if current max pods is same as input max pods.
        $currentNodePoolMaxPods = $nodePoolShowDetail.maxPods
        Write-Verbose "AKS_NODE_POOL_NAME: $AKS_NODE_POOL_NAME currently has AKS_MAX_PODS: $currentNodePoolMaxPods " -Verbose
        if ($AKS_MAX_PODS -ne $currentNodePoolMaxPods) {
            Write-Error -Message "Node Pool $AKS_NODE_POOL_NAME cannot be deployed with the input AKS_MAX_PODS: $AKS_MAX_PODS, currently has: $currentNodePoolMaxPods max pods" -ErrorAction  Stop
        }

        #checking Node Pool AKS version.
        $CurrentNodePoolAKSVersion = $nodePoolShowDetail.orchestratorVersion
        Write-Verbose -Message "Node Pool: $AKS_NODE_POOL_NAME has a current AKS version: $CurrentNodePoolAKSVersion " -Verbose
        # do some checking to make sure the current system/user pool version is not 2 levels behind the AKS Version that is passed
        $AKSNodePoolVersionFirstTwo = $CurrentNodePoolAKSVersion.ToString().Split('.')[0..1] -Join '.'
        $AKSKubertesVersionFristTwo = $AKS_KUBERNETES_VERSION.ToString().Split('.')[0..1] -Join '.'
        if ( [decimal]$AKSKubertesVersionFristTwo - [decimal]$AKSNodePoolVersionFirstTwo -gt 0.01) {
            $ErrorOutput = "The  AKS version passed in for upgrade $AKS_KUBERNETES_VERSION is at least two minor levels higher than the Node Pool:$AKS_NODE_POOL_NAME , AKS version  $CurrentNodePoolAKSVersion"
            Write-Verbose -Message $ErrorOutput -Verbose
            Write-Verbose "`t You can not jump two minor versions" -Verbose
            Write-Verbose "`t You will need to run the deployAKSNodePool.ps1 first to upgrade system node pool to the next minor level" -Verbose
            throw $ErrorOutput
        }
        #checking current agent count
        $Current_AKS_AgentCount = $nodePoolShowDetail.Count
        Write-Warning -Message "Existing AKS_NODE_POOL_NAME: $AKS_NODE_POOL_NAME  currently has  AKS_AGENT_COUNT: $Current_AKS_AgentCount " -Verbose
        If ($env:AKS_AGENT_COUNT) {
            $AKS_AGENT_COUNT = $env:AKS_AGENT_COUNT
            Write-Verbose -Message "AKS_AGENT_COUNT set to: $env:AKS_AGENT_COUNT; value that was passed in" -Verbose
            #NODE COUNT UPDATE AND AKS VERSION UPDATE CANNOT BE DONE SIMULTANEOUSLY
            if (($AKS_AGENT_COUNT -ne $Current_AKS_AgentCount) -and ($AKS_KUBERNETES_VERSION -ne $CurrentNodePoolAKSVersion)) {
                #The agent count may get changed as a random number if the user wants to update the node pool and the node count at the same deployment.
                Write-Warning -Message "***WARNING*** AKS Node count and Node pool version cannot be modified simultaneously." -Verbose
            }

        }
        else {
            $AKS_AGENT_COUNT = $Current_AKS_AgentCount
            Write-Verbose -Message "AKS_AGENT_COUNT set to current node count: $Current_AKS_AgentCount " -Verbose
        }

    }
    else {
        if ($AKS_ENABLE_AUTO_SCALING) {
            $AKS_AGENT_COUNT = $(If ($env:AKS_AGENT_COUNT) { "$env:AKS_AGENT_COUNT" } Else { $AKS_AUTO_SCALING_MINCOUNT })
        }
        else {
            $AKS_AGENT_COUNT = $(If ($env:AKS_AGENT_COUNT) { "$env:AKS_AGENT_COUNT" } Else { If ($environment -eq $CONST_PROD_SUB) { "3" } Else { "1" } })
        }
    }
    Write-Verbose "AKS_AGENT_COUNT: $AKS_AGENT_COUNT" -Verbose
    #Ensure that there are only two system pools-more than two not allowed as of 3.22.21

    $DEFAULT_MAX_SYSTEM_POOL = 2
    if ($AKS_NODE_POOL_MODE -eq "System") {
        [array]$existingNodePoolModes = $nodePoolListDetail.mode
        $SystemNodeCounter = ($existingNodePoolModes | Where-Object { $_ -match "System" }).count
        Write-Verbose "Current number of  System Pools in the Cluster: $SystemNodeCounter" -Verbose
        if ($SystemNodeCounter -ge $DEFAULT_MAX_SYSTEM_POOL) {
            if (!($existingnodePoolList.contains( $AKS_NODE_POOL_NAME))) {

                throw "We currently allow only 2 System Pools on an AKS Cluster. Adding More than 2 System Pools are currently not supported. There are $SystemNodeCounter SystemPools on the current cluster."
            }
        }
    }

    $ERROR_FILE = "$ATLAS_REPO_ROOT/errors.log"
    Write-Verbose "Log File: $ERROR_FILE" -Verbose

    #*****************************************************************************

    $AKS_ENVIRONMENT_SETUP_COMPLETE = $true
}