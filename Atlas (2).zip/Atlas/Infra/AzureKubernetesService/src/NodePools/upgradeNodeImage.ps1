$ErrorActionPreference = "Stop"


Function Set-UpgradeNodePoolImage {

  Param (
    [Parameter(mandatory = $true)]
    [string] $Subscription,
    [Parameter(mandatory = $true)]
    [string] $ResourceGroupName,
    [Parameter(mandatory = $true)]
    [string] $AKSCluster,
    [Parameter(mandatory = $true)]
    [string] $NodePoolName

  )
  #Intialize variable to false
  $IsUpgraded = $false

  try {
      az account set -s $Subscription

      az aks nodepool upgrade `
      --resource-group $ResourceGroupName `
      --cluster-name $AKSCluster `
      --name $NodePoolName `
      --node-image-only

      Write-AtlasOutput -Loglevel "INFO" -Message "Nodepool upgrade completed"

      # Write out the image version
      $NodePoolInfo = $(az aks nodepool show --resource-group $ResourceGroupName `
      --cluster-name $AKSCluster `
      --name $NodePoolName) | ConvertFrom-Json

      Write-AtlasOutput -Loglevel "INFO" -Message "Node pool image version is $($NodePoolInfo.nodeImageVersion)"

      $IsUpgraded = $true
  }
  catch {
    # An error was encountered when attempting to upgrade the  node pool image so log and return result.
    $ERROR_MESSAGE = "Upgrade failed for node images on node pool: $($NodePoolName). $($_.Exception.Message)"
    Write-AtlasOutput -LogLevel "ERROR" -Message $ERROR_MESSAGE
    $IsUpgraded= $false
  }
  Return $IsUpgraded
}

Write-AtlasOutput -LogLevel "INFO" -Message "Getting AKS credentials"
az aks get-credentials -n $AksCluster -g $ResourceGroupName -a --overwrite-existing | Out-Null
Write-AtlasOutput -LogLevel "INFO" -Message "Credentials successfully retrieved"

$nodePoolToUpgrade = $(az aks nodepool show --cluster-name $AksCluster --name $NodePoolName --resource-group $ResourceGroupName) | ConvertFrom-Json

#  Check if node pool was found.  If not write error
Write-AtlasOutput -LogLevel "INFO" -Message "Checking for existence of node pool to upgrade image: $NodePoolName"
if ($nodePoolToUpgrade) {
  # NodePool was found. Attempt to upgrade node pool image version
  $PoolImageUpgraded = Set-UpgradeNodePoolImage -Subscription $Subscription -ResourceGroupName $ResourceGroupName -AKSCluster $AKSCluster -NodePoolName $NodePoolName
  # Node pool node image upgrade failed so throw an error
  if ($PoolImageUpgraded) {
    Write-AtlasOutput -Loglevel "INFO" -Message "Node pool image for $NodePoolName upgraded"
  }
  else {
    Write-AtlasOutput -Loglevel "ERROR" -Message "Value of $($PoolImageUpgraded)"
    throw "Error encountered attempting to upgrade node pool image for $NodePoolName. "
  }
}
else {
  # Node pool not found so log error and exit
  Write-AtlasOutput -Loglevel "ERROR" -Message "The node pool $NodePoolName was not found within the subscription...ending script."
}

Write-AtlasOutput -LogLevel "INFO" -Message "Ending script."