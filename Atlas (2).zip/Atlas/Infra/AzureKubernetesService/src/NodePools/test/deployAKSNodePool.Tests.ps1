param
(
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup,

  [Parameter(Mandatory = $false)]
  [array] $rgResources = $null
)

Describe "Atlas AKS Node Pool Tests" {
  BeforeAll {


    # source the _include file
    . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")

    $EXPECTED_NODEPOOLNAME = $env:AKS_NODE_POOL_NAME
    $EXPECTED_AGENTCOUNT = $env:AKS_AGENT_COUNT
    $EXPECTED_MAXPODS = 110
    $EXPECTED_SCALINGMAXCOUNT = $env:AKS_AUTO_SCALING_MAXCOUNT
    $EXPECTED_SCALINGMINCOUNT = $env:AKS_AUTO_SCALING_MINCOUNT
    $EXPECTED_MODE = "User"
    $AUTO_SCALING=$env:AKS_ENABLE_AUTO_SCALING


    Write-Verbose "Validating Node Pool in resource group: $resourceGroup" -Verbose

     # Get the AKS cluster name from the resource group passed in
    if ($resourceGroup -ne $null) {
      $AksName = ((az resource list -g $resourceGroup --resource-type "Microsoft.ContainerService/managedClusters") | ConvertFrom-Json).name
    }

    Write-Verbose "Validating AKS Cluster: $AksName" -Verbose

    if ($AksName -ne $null) {
      # Get the AKS Node Pool information from RG and AKS Name for Node Pool "testnodepool"
      $aksNodePool = $(az aks nodepool show --cluster-name $aksname -n $EXPECTED_NODEPOOLNAME -g $resourceGroup | ConvertFrom-Json)
    }

    Write-Verbose "Validating Node Pool settings: $($aksNodePool.name)" -Verbose

  }

  It "Resource Group variable is set" {
    $resourceGroup | Should -Not -Be $null
  }


  It "Node Pool name is '$EXPECTED_NODEPOOLNAME'" {
    $aksNodePool.name | Should -Be $EXPECTED_NODEPOOLNAME
  }

  It "Agent Count should be $EXPECTED_AGENTCOUNT" {
    if(!$AUTO_SCALING){
      $aksNodePool.count | Should -be $EXPECTED_AGENTCOUNT
    }

  }
  It "Maxpods should be $EXPECTED_MAXPODS" {
    $aksNodePool.maxPods | Should -be $EXPECTED_MAXPODS
  }
  It "Auto Scale MAX count should be $EXPECTED_SCALINGMAXCOUNT" {
    $aksNodePool.maxCount | Should -be $EXPECTED_SCALINGMAXCOUNT
  }
  It "Auto Scale MIN count should be $EXPECTED_SCALINGMINCOUNT" {
    $aksNodePool.minCount | Should -be $EXPECTED_SCALINGMINCOUNT
  }
  It "Node Pool Mode should be '$EXPECTED_MODE'" {
    $aksNodePool.mode | Should -be $EXPECTED_MODE
  }
}