##############################################################################################################################################
# This script breaks a PFX with a secret into a .crt and .key file using OpenSSL.
# To correctly function, the script needs to run in an environment which has the openssl client tools installed.

# Experimentation with nested parameter expansion was attempted unsuccessfully. Future improvements on this front are necessary, however
# the script provided below is still leagues ahead of manual provisioning and only requires an update to reference the correct secret name.

##############################################################################################################################################

Write-Verbose "Configuring AKS Ingress Controller SSL Certificate" -Verbose

Write-Verbose "Script Directory: $env:ATLAS_REPO_ROOT" -Verbose

$KEYNAME = $env:ATLAS_REPO_ROOT + "/" + $AKS_SSL_CERT_IDENTIFIER + '.key'
Write-Verbose "Key file name: $KEYNAME" -Verbose

$CRTNAME = $env:ATLAS_REPO_ROOT + "/" + $AKS_SSL_CERT_IDENTIFIER + '.crt'
Write-Verbose "CRT file name: $CRTNAME" -Verbose

$DECRYPTEDKEYNAME = $env:ATLAS_REPO_ROOT + "/" + $AKS_SSL_CERT_IDENTIFIER + '.decrypted.key'
Write-Verbose "Decrypted file name: $DECRYPTEDKEYNAME" -Verbose

$PFXPATH = $env:ATLAS_REPO_ROOT + "/" + $AKS_SSL_CERT_IDENTIFIER + ".pfx"
Write-Verbose "PFX Path: $PFXPATH" -Verbose

#############################################################################################
# Get keyvault secret for the cert password
#############################################################################################
If ($USE_PORT_VAULT_SSL) {
	#for this statement, note that the port vault and the shared vault
	#both live in the same subscription, hence no need to setup a secondary
	#variable for port subscription vault
	$PFXPWD = az keyvault secret show --name "$AKS_SSL_CERT_PWD_SECRET_NAME" `
		--vault-name "$ATLAS_PORT_VAULT_NAME" `
		--subscription "$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID" `
		--query value -o tsv
}
Else {
	$PFXPWD = az keyvault secret show --name "$AKS_SSL_CERT_PWD_SECRET_NAME" `
		--vault-name "$ATLAS_SHARED_VAULT_NAME" `
		--subscription "$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID" `
		--query value -o tsv
}


if ($null -ne $PFXPWD) {
	Write-Verbose "PFXPWD has a value" -Verbose
}
else {
	Write-Verbose "PFXPWD has no value" -Verbose
}

#############################################################################################
# Get keyvault secret for the cert file
#############################################################################################
If ($USE_PORT_VAULT_SSL) {
	#for this statement, note that the port vault and the shared vault
	#both live in the same subscription, hence no need to setup a secondary
	#variable for port subscription vault
	$CERT = az keyvault secret show --name "$AKS_SSL_CERT_NAME" `
		--vault-name "$ATLAS_PORT_VAULT_NAME" `
		--subscription "$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID" `
		--query value -o tsv
}
Else {
	$CERT = az keyvault secret show --name "$AKS_SSL_CERT_NAME" `
		--vault-name "$ATLAS_SHARED_VAULT_NAME" `
		--subscription "$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID" `
		--query value -o tsv
}

if ($null -ne $CERT) {
	Write-Verbose "CERT has a value" -Verbose
}
else {
	Write-Verbose "CERT has no value" -Verbose
}

$CERTBYTES = [System.Convert]::FromBase64String($CERT)

#############################################################################################
# Create CERTificate collection object and import encoded value.
#############################################################################################

$CERTCOLLECTION = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
$CERTCOLLECTION.Import($CERTBYTES, $null, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)

# Use Export method of certificates collection and use password provided at the beginning of the script.
$PROTECTEDCERTBYTES = $CERTCOLLECTION.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, $PFXPWD)

if ($null -ne $PROTECTEDCERTBYTES) {
	Write-Verbose "PROTECTEDCERTBYTES has a value" -Verbose
}
else {
	Write-Verbose "PROTECTEDCERTBYTES has no value" -Verbose
}


try {
	Write-Verbose "Writing the Certificate to a file on the TFS build server." -Verbose

	# Certificate will be saved in pkcs12 format. To save certificate use WriteAllBytes method of System.IO.File class.
	# NOTE:  This is saved on the TFS server when submitted via TFS
	[System.IO.File]::WriteAllBytes($PFXPATH, $PROTECTEDCERTBYTES)

	if ("True" -eq "$(Test-Path -Path "$PFXPATH")") {
		Write-Verbose "PFX file exists" -Verbose
	}
	else {
		Write-Verbose "PFX file does not exist" -Verbose
	}
}
catch {
	$ERRORMESSAGE = $_.Exception.message
	Write-Verbose "ERROR: $ERRORMESSAGE." -Verbose
}

#############################################################################################
#Break the PFX into the required CRT and KEY files to create a K8s TLS secret
#############################################################################################
if (($env:isLocal -eq $true) -and ($env:path -notmatch "mingw64")) {
	#check if path contain Git, if not add it for openssl support
	$env:path += ";C:\Program Files\Git\mingw64\bin;"  #openssl is in this directory
}

try {
	openssl pkcs12 -in $PFXPATH -nocerts -out $KEYNAME -passin "pass:$PFXPWD" -passout "pass:$PFXPWD"
	Write-Verbose "Key name out." -Verbose
	# remove clcerts param as that clears the root cert from the cert chain
	openssl pkcs12 -in $PFXPATH  -nokeys -out $CRTNAME -passin "pass:$PFXPWD" -passout "pass:$PFXPWD"
	Write-Verbose "Crt out." -Verbose

	$initialErrorActionPreference = $ErrorActionPreference
	$ErrorActionPreference = "SilentlyContinue"
	openssl rsa -in $PFXPATH -out $DECRYPTEDKEYNAME -passin "pass:$PFXPWD"  -passout "pass:$PFXPWD" -inform pkcs12 2> $null
	Write-Verbose "Decrypted key out." -Verbose
	$ErrorActionPreference = $initialErrorActionPreference

	Write-Verbose "Create Secret Name..." -Verbose
	$KUBE_TLS_CERT_SECRET_NAME = $AKS_SSL_CERT_NAME + '-tls'
	Write-Verbose "Secret Name: $KUBE_TLS_CERT_SECRET_NAME" -Verbose

	#############################################################################################
	#Apply the secret to the cluster
	#############################################################################################

	Write-Verbose "Determine whether secret exists..." -Verbose
	$kubectlErrorFile = "$env:ATLAS_REPO_ROOT/kubeErrors.log"
	$secretExists = (kubectl --kubeconfig "$KUBE_CONFIG_PATH" get secrets --namespace $INGRESS_CONTROLLER_NAMESPACE 2> $kubectlErrorFile) -match $KUBE_TLS_CERT_SECRET_NAME
	if ($secretExists.Length -gt 0) {
		Write-Verbose "Secret exists: $KUBE_TLS_CERT_SECRET_NAME, delete it." -Verbose
		kubectl --kubeconfig "$KUBE_CONFIG_PATH" delete secret $KUBE_TLS_CERT_SECRET_NAME --namespace $INGRESS_CONTROLLER_NAMESPACE 2> $kubectlErrorFile
	}

	try {
		Write-Verbose "Create Ingress Controller Namespace '$INGRESS_CONTROLLER_NAMESPACE' in AKS Cluster..." -Verbose
		kubectl --kubeconfig "$KUBE_CONFIG_PATH" create namespace $INGRESS_CONTROLLER_NAMESPACE 2> $kubectlErrorFile
	}
	catch {
		Write-Verbose "Namespace '$INGRESS_CONTROLLER_NAMESPACE' already exists in AKS Cluster..." -Verbose
		Write-Verbose $_.Exception.Message -Verbose
	}

	try {
		Write-Verbose "Create Certificate Secret '$KUBE_TLS_CERT_SECRET_NAME' in AKS Cluster..." -Verbose
		kubectl --kubeconfig "$KUBE_CONFIG_PATH" create secret tls $KUBE_TLS_CERT_SECRET_NAME --key $DECRYPTEDKEYNAME --cert $CRTNAME --namespace $INGRESS_CONTROLLER_NAMESPACE 2> $kubectlErrorFile
	}
	catch {
		Write-Verbose "Secret '$KUBE_TLS_CERT_SECRET_NAME' already exists in AKS Cluster..." -Verbose
		Write-Verbose $_.Exception.Message -Verbose
	}
}
catch {
	Write-Verbose -Verbose "An error occurred while completing certificate secret setup for your cluster:"
	Write-Verbose $_.Exception.Message -Verbose
}
finally {
	if (Test-Path $kubectlErrorFile) {
		Remove-Item $kubectlErrorFile
	}

	Remove-Item $KEYNAME
	Remove-Item $CRTNAME
	Remove-Item $DECRYPTEDKEYNAME
	Remove-Item $PFXPATH
}
