$ErrorActionPreference = "Stop"
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1")  4> $null
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1") 4> $null

function invoke-AKSDeployment {
    $AKS_TEMPLATE_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/azuredeployKubernetesServiceRBAC.json"
    $AKS_TEMPLATE_FILE_OUTPUT = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/azuredeployKubernetesServiceRBAC_editted.json"
    Write-Verbose "AKS_TEMPLATE_FILE: $AKS_TEMPLATE_FILE" -Verbose
    Write-Verbose "AKS_TEMPLATE_FILE_OUTPUT: $AKS_TEMPLATE_FILE_OUTPUT" -Verbose

    # ***********************************************************************
    # if it's local there's fun stuff to be done to skirt permissions issues
    # this was talked about by Team Titan and this approach was the least ugly at the time
    <#
    if ($env:IsLocal) {
        Write-Verbose "Local deployment detected. Using custom template without OMS." -Verbose
        $LOCAL_ONLY_TEMPLATE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/azuredeployKubernetesServiceRBAC.mine.json"

        #$templateObj = (Get-Content $AKS_TEMPLATE_FILE | ConvertFrom-Json)
        $templateObj = Get-Content $AKS_TEMPLATE_FILE

        # remove the addOnProfile section from the managedClusters object
        $templateObj.resources | Where-Object { $_.type -eq "Microsoft.ContainerService/managedClusters" } | ForEach-Object { $_.properties.PSOBject.Properties.Remove('addonProfiles') }

        Set-Content -Path $LOCAL_ONLY_TEMPLATE -Value ($templateObj | ConvertTo-Json -Depth 15) | Out-Null
        # use the localy only template instead
        $AKS_TEMPLATE_FILE = $LOCAL_ONLY_TEMPLATE
        $AKS_TEMPLATE_FILE_OUTPUT = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/azuredeployKubernetesServiceRBAC_editted.json"
    }
    #>
    # ***********************************************************************

    # using AKS-managed Active Directory and specifying the titan group likely means we don't need this role binding anymore,
    # consider removing at some point when atlas 2.0 aks is retired
    # Infra\AzureKubernetesService\src\AksCluster\AksClusterRBACRoleBindings\create-cluster-admin-group.yaml
    
    $adminGroupObjectId = "415c0242-9491-4691-83a8-8c6ee90a1936" 
    #$adminGroupObjectId = az ad group show -g "r-teamtitan-lsa" --query id



    Write-Verbose "Value of adminGroupObjectId is $adminGroupObjectId" -verbose


    if ($existingAksName) {
        Write-Verbose "Found existing Cluster, checking the system and user node pools" -Verbose
        [array]$OtherPoolProfiles = @()
        # Get a list of all User Pools
        $UserPools = (az aks nodepool list --resource-group $AKS_RG_NAME --cluster-name $AKS_NAME | ConvertFrom-Json) | Where-Object { $_.mode -eq "user" }
        if ($UserPools) {
            foreach ($UserPool in $UserPools) {
                Write-Verbose "Looking for User Node Pools" -Verbose
                $TempPool = $UserPool | Select-Object name, orchestratorVersion | ConvertTo-Json -Compress
                Write-Verbose "User Node Pools version $TempPool" -Verbose
                $OtherPoolProfiles += "`r `n" + "," + $TempPool
            }
            $OtherPoolProfiles = $OtherPoolProfiles -replace '(?m)^\s*\r?\n', ''  # remove blank lines
            [string]$OtherPoolProfiles = $OtherPoolProfiles
        }
        else {
            [string]$OtherPoolProfiles = ""
            Write-Verbose "No User Node Pool found" -Verbose
        }

        # Review list of all system pools to see if more that one
        if (($SysPools | Measure-Object).Count -gt 1) {
            Write-Verbose "Looking for System Node Pools" -Verbose
            # This will get System Pool Name of metric-server Pod, which is the active system pool
            $ActiveSystemPoolName = Get-AKSActiveSystemNodePoolName

            # Get the version of the active system pool $SysPool.name
            foreach ($SysPool in $SysPools) {
                if ($SysPool.name -eq $ActiveSystemPoolName) {
                    $SystemPoolAKSVersion = $SysPool.orchestratorVersion
                    Write-Verbose "`t Found active system pool version: $SystemPoolAKSVersion" -Verbose
                }
            }
        }
        else {
            $AKS_SYSTEMPOOL_NAME = $SysPools.name
            Write-Verbose "`t Found system pool name: $AKS_SYSTEMPOOL_NAME" -Verbose
            $SystemPoolAKSVersion = $SysPools.orchestratorVersion
            Write-Verbose "`t Found system pool version: $SystemPoolAKSVersion" -Verbose
        }
    }
    else {
        $SystemPoolAKSVersion = $AKS_KUBERNETES_VERSION
        [string]$OtherPoolProfiles = ""
        Write-Verbose "Creating a new cluster, using version: $SystemPoolAKSVersion" -Verbose
    }

    # get subnetid for cluster
    $SUBNETID = ((az network vnet subnet show -g $VNET_RG_NAME -n $SUBNET_PRIVATE_NAME --vnet-name $VNET_NAME) | ConvertFrom-Json).id

    Write-Verbose "System Node Pool Name: $AKS_SYSTEMPOOL_NAME" -Verbose
    Write-Verbose "System Node Pool Version: $SystemPoolAKSVersion" -Verbose

    # build systempool json
    # if more than one system node pool, do not set autoscale parms so it uses the current settings

    $systemPool = @"
{
    'name': '$AKS_SYSTEMPOOL_NAME',
    'mode': 'System',
    'osDiskSizeGB': $AKS_DISK_SIZE_GB,
    'count': $AKS_AGENT_COUNT,
    'maxPods': $AKS_MAX_PODS,
    'vmSize': '$AKS_AGENT_VM_SIZE',
    'osType': 'Linux',
    'storageProfile': 'ManagedDisk',
    'orchestratorVersion': '$SystemPoolAKSVersion',
    'type': 'VirtualMachineScaleSets',
    'vnetSubnetID': '$SUBNETID'
}
"@

    # If just one system node pool, then add in the auto scale parms.
    if (($SysPools | Measure-Object).Count -le 1) {
        $systemPoolAuto = @"
    'enableAutoScaling': $($AKS_ENABLE_AUTO_SCALING.ToString().ToLower()),
    'maxCount': $AKS_AUTO_SCALING_MAXCOUNT,
    'minCount': $AKS_AUTO_SCALING_MINCOUNT,
    'vnetSubnetID': '$SUBNETID'
"@
        $systemPool = $systemPool.Replace("'vnetSubnetID': '$SUBNETID'", $systemPoolAuto)
    }

    # Get list of non-active system pools and add to $OtherPoolProfiles

    if (($SysPools | Measure-Object).Count -gt 0) {
        foreach ($SysPool in $SysPools) {
            if ($SysPool.name -ne $AKS_SYSTEMPOOL_NAME) {
                $TempPool = $SysPool | Select-Object name, orchestratorVersion, mode | ConvertTo-Json -Compress
                Write-Verbose "Node Pool version $TempPool" -Verbose
                $OtherPoolProfiles += "`r `n" + "," + $TempPool
            }
        }
        $OtherPoolProfiles = $OtherPoolProfiles -replace '(?m)^\s*\r?\n', ''  # remove blank lines
        [string]$OtherPoolProfiles = $OtherPoolProfiles
    }
    # replace single quotes with double quotes
    $systemPool = ($systemPool).Replace("'", """")
    # build agentPoolProfile that includes the system pool and any additional user pools
    $agentPoolProfile = $systemPool + $OtherPoolProfiles

    if ($env:FORCE_TO_SUPPORTED_VERSION -eq "true") {
        Write-Verbose "FORCE_TO_SUPPORTED_VERSION flag set." -Verbose
        $upgrades = az aks get-upgrades --name $AKS_NAME --resource-group $AKS_RG_NAME | ConvertFrom-Json
        $versionToUpgrade = ""

        if ($upgrades.controlplaneprofile.upgrades) {
            foreach ($upgrade in $upgrades.controlplaneprofile.upgrades) {
                if ($null -eq $upgrade.isPreview) {
                    $versionToUpgrade = $upgrade.kubernetesVersion
                }
            }
        }
        Write-Verbose "Forcing an upgrade to: $versionToUpgrade" -Verbose
        $AKS_KUBERNETES_VERSION = $versionToUpgrade
    }

    # determine sku tier to use. In prod we will use "Paid" so that "Update SLA" is enabled
    # https://docs.microsoft.com/en-us/azure/aks/uptime-sla
    $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
    if ($SubscriptionProperties.environment -eq "Prod") {
        $skuTier = "Paid"
    }
    else {
        $skuTier = "Free"
    }

    Write-Verbose "AKS control plane version will be $AKS_KUBERNETES_VERSION" -Verbose
    Write-Verbose "System Pool AKS version will be $SystemPoolAKSVersion" -Verbose
    Write-Verbose "System Pool: $systemPool" -Verbose
    Write-Verbose "Other Pools: $OtherPoolProfiles" -Verbose
    Write-Verbose "agentPoolProfile: $agentPoolProfile" -Verbose

    # Do an in-place token replace for the agentpoolprofile
    (Get-Content $AKS_TEMPLATE_FILE) -replace '__agentPoolProfile__', "$agentPoolProfile" | Set-Content $AKS_TEMPLATE_FILE_OUTPUT
    $OutputJson = Get-Content -Raw -Path $AKS_TEMPLATE_FILE_OUTPUT | ConvertFrom-Json
    Write-Verbose "Output JSON: $OutputJson." -Verbose
    #######################################################

    $ATLAS_STANDARD_IP_RULES = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value

    $ATLAS_STANDARD_IP_RULES = $ATLAS_STANDARD_IP_RULES | ForEach-Object { if ($_ -notmatch "/") { $_ + "/32"} else {$_} }

    Write-Verbose "IP Rules: $ATLAS_STANDARD_IP_RULES" -Verbose

    $DEPLOYMENT_NAME = "azuredeployKubernetesServiceRBAC-$(Get-Date -f yyyyMMddHHmmss)"
    $Action = {
        az deployment group create `
            -g "$AKS_RG_NAME" `
            -n "$DEPLOYMENT_NAME" `
            --template-file "$AKS_TEMPLATE_FILE_OUTPUT" `
            --parameters "clusterName=$AKS_NAME" `
            "appInsightsLocation=$AKS_AIS_LOCATION" `
            "clusterLocation=$AKS_LOCATION" `
            "kubernetesVersion=$AKS_KUBERNETES_VERSION" `
            "enableOmsAgent=true" `
            "enableRBAC=true" `
            "adminGroupObjectId=$adminGroupObjectId" `
            "omsWorkspaceRGName=$OMS_WORKSPACE_RG_NAME" `
            "omsWorkspaceName=$OMS_WORKSPACE_NAME" `
            "skuTier=$skuTier" `
            "createdDate=$CREATED_DATE" `
            "TemplateVersion=$TEMPLATE_VERSION"  `
            "authorizedIPRange=$ATLAS_STANDARD_IP_RULES" `
            --debug
    }
    # wrap the above in a functional delegate for improved resiliency
    Retry-FunctionalDelegate -Action $Action
}
#As per microsoft documents, we can't have a cluster or node pool simultaneously upgrade and scale.Please visit https://aka.ms/aks-pending-upgrade for more details
#Handling each operation (update and scale) in separate if user want to upgrade control plane and updte the node pool scaling setting.
$SecondDeploymentRequired = $false
$Save_New_Count = $AKS_AGENT_COUNT
$Save_AKS_AUTO_SCALING_MAXCOUNT = $AKS_AUTO_SCALING_MAXCOUNT
$Save_AKS_ENABLE_AUTO_SCALING = $AKS_ENABLE_AUTO_SCALING
$Save_AKS_AUTO_SCALING_MINCOUNT = $AKS_AUTO_SCALING_MINCOUNT
Write-Verbose "Deploying AKS Cluster with Full RBAC: $AKS_NAME" -Verbose
if ($existingAksName) {
    if ($Aks_Version_Changing -or $multipleNodePool) {
        if ($AKS_AGENT_COUNT -ne $existingAksAgentCount) {
            $AKS_AGENT_COUNT = $existingAksAgentCount
            $AKS_AUTO_SCALING_MAXCOUNT = $existingAutoScalingMaxCount
            $AKS_ENABLE_AUTO_SCALING = $existingAutoScalingSetting
            $AKS_AUTO_SCALING_MINCOUNT = $existingAutoScalingMinCount
            $SecondDeploymentRequired = $true
            Write-AtlasOutput -LogLevel "WARN" -Message "Updating Kubernetes version and agent node scaling are mutually exclusive operations.Separate each operation type in two AKS deployments."
            Write-AtlasOutput -LogLevel "INFO" -Message "Start upgrading the AKS control plane version only"
            invoke-AKSDeployment
        }
        elseif ( $AKS_ENABLE_AUTO_SCALING -ne $existingAutoScalingSetting ) {
            $AKS_ENABLE_AUTO_SCALING = $existingAutoScalingSetting
            $AKS_AUTO_SCALING_MAXCOUNT = $existingAutoScalingMaxCount
            $AKS_AUTO_SCALING_MINCOUNT = $existingAutoScalingMinCount
            $SecondDeploymentRequired = $true
            Write-AtlasOutput -LogLevel "WARN" -Message "Updating Kubernetes version and agent node scaling are mutually exclusive operations.Separate each operation type in two AKS deployments."
            Write-AtlasOutput -LogLevel "INFO" -Message "Start upgrading the AKS control plane version only"
            invoke-AKSDeployment
        }
        elseif ($AKS_AUTO_SCALING_MAXCOUNT -ne $existingAutoScalingMaxCount -or $AKS_AUTO_SCALING_MINCOUNT -ne $existingAutoScalingMinCount) {
            $AKS_AUTO_SCALING_MAXCOUNT = $existingAutoScalingMaxCount
            $AKS_AUTO_SCALING_MINCOUNT = $existingAutoScalingMinCount
            $SecondDeploymentRequired = $true
            Write-AtlasOutput -LogLevel "WARN" -Message "Updating Kubernetes version and agent node scaling are mutually exclusive operations.Separate each operation type in two AKS deployments."
            Write-AtlasOutput -LogLevel "INFO" -Message "Start upgrading the AKS control plane version only"
            invoke-AKSDeployment
        }
        else {
            $SecondDeploymentRequired = $false
            #Existing AKS requires control plane upgrade only
            invoke-AKSDeployment
        }
        if ($SecondDeploymentRequired -and !$multipleNodePool) {
            $AKS_AGENT_COUNT = $Save_New_Count
            $AKS_AUTO_SCALING_MAXCOUNT = $Save_AKS_AUTO_SCALING_MAXCOUNT
            $AKS_ENABLE_AUTO_SCALING = $Save_AKS_ENABLE_AUTO_SCALING
            $AKS_AUTO_SCALING_MINCOUNT = $Save_AKS_AUTO_SCALING_MINCOUNT
            Write-AtlasOutput -LogLevel "INFO" -Message "Starting the node pool opertaion(s)..."
            invoke-AKSDeployment
        }
    }
    else {
        #Existing AKS does not require control plane upgrade
        invoke-AKSDeployment
    }
}
else {
    invoke-AKSDeployment
}

Write-Verbose "Successfully Deployed AKS Cluster with Full RBAC: $AKS_NAME" -Verbose

#Check if AKS permissions setup is required
Write-Verbose "Check if AKS permissions are applied." -Verbose
Write-Verbose "Get MSI for cluster: $AKS_NAME" -Verbose
$MaxAttempts = 10
$attempts = 0
do {
    $AKS_IDENTITY = Get-AzADServicePrincipal -DisplayName $AKS_NAME
    if ($null -ne $AKS_IDENTITY) {
        break
    }
    ++$attempts
    Start-Sleep -Seconds 5
} while ($attempts -le $MaxAttempts)

if ($null -eq $AKS_IDENTITY) {
    Throw "Not able to determine objectId for managed identity: $AKS_NAME"
}

$callAksSetupRunbook = Check-AtlasAksPermissionsSetupRequired -ResourceGroupName $AKS_RG_NAME `
    -AksServicePrincipalObjectId $AKS_IDENTITY.Id `
    -AppTeamRoleGroupObjectId $APP_TEAM_AD_GROUP_OBJECT_IDS

if ($callAksSetupRunbook) {
    Write-Verbose -Verbose "Aks permissions setup has not yet been completed. Calling self-serve AKS permission setup..."
    # source and run the runbook to setup AKS permissions
    . ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
    $Params = @{"ResourceGroupName"    = $AKS_RG_NAME; `
            "AksServicePrincipalAppId" = $AKS_IDENTITY.AppId; `
            "AppTeamRoleGroupObjectIds" = [array]$APP_TEAM_AD_GROUP_OBJECT_IDS; `
            "SubscriptionName"          = $SUBSCRIPTION_NAME
    }
    Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-AksResourceGroupPermissionsSetup" -Parameters $Params
}

Write-Verbose "AKS Managed Identity RBAC permissions deployment complete" -Verbose

Write-Verbose "Finished AKS Deployment Script" -Verbose
