Write-Verbose "Deploying AKS NGINIX Ingress Mandatory Configuration" -Verbose
#dot sourcing variables script so we can get nginx image variable.
##. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1")

$NGINIX_INGRESS_MANDATORY_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/config/cloud_mandatory.yaml"

# if we're local, write to a .mine copy so we don't need to mess with git
# and inadverdently check in the wrong changes
$NGINIX_INGRESS_MANDATORY_FILE_OUTPUT = $NGINIX_INGRESS_MANDATORY_FILE
if ($env:IsLocal) {
    $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT = $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT.Replace(".yaml", ".mine.yaml")
}

(Get-Content $NGINIX_INGRESS_MANDATORY_FILE) -replace '__NginxImage__', "$NGINX_INGRESS_CONTROLLER_IMAGE_VERSION" | Set-Content $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT
Write-Verbose "NGINIX_INGRESS_MANDATORY_FILE_OUTPUT: $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT" -Verbose

# AKS_SSL_CERT_NAME must be set as it is combined with the string '-tls' in the azuredeployKubeSslCertificateSecret.ps1 script
if ($null -ne $AKS_SSL_CERT_NAME) {
    Write-Verbose "Setting Ingress Controller to use secret '$KUBE_TLS_CERT_SECRET_NAME'" -Verbose
    # Do an in-place token replace of __AksSecretName__ with the variable $KUBE_TLS_CERT_SECRET_NAME
    (Get-Content $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT) -replace '__AksSecretName__', "$INGRESS_CONTROLLER_NAMESPACE/$KUBE_TLS_CERT_SECRET_NAME" | Set-Content $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT
    Write-Verbose "KUBE_TLS_CERT_SECRET_NAME set in file: $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT" -Verbose
}
else {
    Write-Error "Value not defined for 'AKS_SSL_CERT_NAME' veriable. Please see the Atlas troubleshooting guide for steps to adhoc remediate this issue should you choose not to redeploy the entire cluster system." -ErrorAction Stop
}

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $NGINIX_INGRESS_MANDATORY_FILE_OUTPUT 2>$null

Write-Verbose "Successfully Deployed AKS NGINIX Ingress Mandatory Configuration" -Verbose

# *********************************************************************************************

Write-Verbose "Deploying AKS NGINIX Ingress Controller" -Verbose

$NGINIX_INGRESS_CONTROLLER_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/config/cloud_azure_nginx_ingress_controller.yaml"
Write-Verbose "NGINIX_INGRESS_CONTROLLER_FILE: $NGINIX_INGRESS_CONTROLLER_FILE" -Verbose

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $NGINIX_INGRESS_CONTROLLER_FILE

Write-Verbose "Successfully Deployed AKS NGINIX Ingress Controller" -Verbose

# *********************************************************************************************

Write-Verbose "Deploying AKS NGINIX Ingress Controller - Large Header Configuration Patch" -Verbose

$NGINIX_INGRESS_CONTROLLER_CONFIGMAP_PATCH_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/config/ingress-configmap-largeheaders.yaml"
Write-Verbose "NGINIX_INGRESS_CONTROLLER_CONFIGMAP_PATCH_FILE: $NGINIX_INGRESS_CONTROLLER_CONFIGMAP_PATCH_FILE" -Verbose

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $NGINIX_INGRESS_CONTROLLER_CONFIGMAP_PATCH_FILE

Write-Verbose "Successfully Deployed AKS NGINIX Ingress Controller - Large Header Configuration Patch" -Verbose