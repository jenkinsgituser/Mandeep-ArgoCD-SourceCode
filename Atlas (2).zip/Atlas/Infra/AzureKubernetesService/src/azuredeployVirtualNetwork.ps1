. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1") #4> $null

# check if this guy has already been deployed. If so, we're not going to mess with it again.

$vNetList = $(az network vnet list -g $VNET_RG_NAME) | ConvertFrom-Json
$vNetExists = $vNetList.name -match $VNET_NAME

if (!$vNetExists) {

    Write-Verbose "Deploying Virtual Network: $VNET_NAME" -Verbose

    $VNET_TEMPLATE_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksNetwork/azuredeployVirtualNetwork.json"
    Write-Verbose "VNET_TEMPLATE_FILE: $VNET_TEMPLATE_FILE" -Verbose

    $DEPLOYMENT_NAME = "azuredeployVirtualNetwork-$(Get-Date -f yyyyMMddHHmmss)"

    $Action = {
        az deployment group create `
            -g "$VNET_RG_NAME" `
            -n "$DEPLOYMENT_NAME" `
            --template-file "$VNET_TEMPLATE_FILE" `
            --parameters "vnetName=$VNET_NAME" `
            "addressPrefix=$VNET_ADDRESS_PREFIX" `
            "vnetLocation=$VNET_LOCATION" `
            "createdDate=$CREATED_DATE" `
            "TemplateVersion=$TEMPLATE_VERSION"
    }

    # wrap the above in a functional delegate for improved resiliency
    Retry-FunctionalDelegate -Action $Action


    Write-Verbose "Successfully Deployed Virtual Network: $VNET_NAME" -Verbose

    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployPrivateSubnet.ps1")
    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployPublicSubnet.ps1")

    Write-Verbose "Successfully Deployed public and private Subnets" -Verbose

}
else {
    Write-Warning "Vnet will not be re-deployed as it already exists!"
    Write-Warning "Subnets will not be re-deployed as they already exists!"
    # tag templateVersion
    Write-Verbose "Set TemplateVersion tag on vNet: $VNET_NAME" -Verbose
    Set-TagOnAtlasResource -resourceGroup $VNET_RG_NAME -resourceName $VNET_NAME -resourceType "Microsoft.Network/virtualNetworks" -tagName "TemplateVersion" -tagValue $TEMPLATE_VERSION

}
