$ErrorActionPreference = "Stop"
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1") 4> $null

Write-Verbose "Deploying Application Gateway with WAF (v2): $AKS_NAME" -Verbose

$AG_WAF_TEMPLATE_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksNetwork/azuredeployGatewayWAF_v2_ssl.json"
Write-Verbose "AG_WAF_TEMPLATE_FILE: $AG_WAF_TEMPLATE_FILE" -Verbose

$AG_WAF_PARAMETERS_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/azuredeployGatewayWAF_v2_ssl.parameters.json"
Write-Verbose "AG_WAF_PARAMETERS_FILE: $AG_WAF_PARAMETERS_FILE" -Verbose

$JSON_FILE = Test-Path $AG_WAF_PARAMETERS_FILE
If ($JSON_FILE -ne $true) {
  Write-Error "Unable to locate file: $AG_WAF_PARAMETERS_FILE"  -ErrorAction Stop
}

if ($AG_WAF_CLEAR_DISABLED_RULE_GROUPS) {
  Write-Warning "AG_WAF_CLEAR_DISABLED_RULE_GROUPS is set. Any existing disabled rule groups will be removed!"
  $AG_WAF_DISABLED_RULE_GROUPS = "[]"
}
elseif ($null -eq $AG_WAF_DISABLED_RULE_GROUPS) {
  #check to see if gateway exists and if so grab the rules we'd persist
  try {
    Write-Verbose -Verbose "Retrieving existing rule groups to persist..."
    $preExistingRules = az network application-gateway show -g $AG_WAF_RG_NAME -n $AG_WAF_NAME --query "webApplicationFirewallConfiguration.disabledRuleGroups" 2> $null
  }
  catch {
    $preExistingRules = $null
  }

  if ($preExistingRules) {
    # preExisting rules come back as an array of strings. We want to pass it along as one string value
    # so we'll do some manipulation to rejoin the array into on single string
    # then replace single double quotes with single quotes as it serializes to Json without other manipulations
    $preExistingRulesString = ($preExistingRules -Join "").Replace('"', "'")
    Write-Verbose -Verbose "Pre-existing rules to be persisted: $preExistingRulesString "
    $AG_WAF_DISABLED_RULE_GROUPS = $preExistingRulesString
  }
  else {
    $AG_WAF_DISABLED_RULE_GROUPS = "[]"
    Write-Verbose -Verbose "No pre-existing rules to persist."
  }
} #else if we have passed in AG_WAF_DISABLED_RULE_GROUPS and not set AG_WAF_CLEAR_DISABLED_RULE_GROUPS then we'll use the input

$DEPLOYMENT_NAME = "azuredeployGatewayWAF_v2-$(Get-Date -f yyyyMMddHHmmss)"

# Deploy application gateway with WAF to resource group
$Action = {
  #min and max capacity for autoscaling could be set by environment (e.g., 0 for non-prod min, 2 for prod min?)
  az deployment group create `
    -g "$AG_WAF_RG_NAME" `
    -n "$DEPLOYMENT_NAME" `
    --template-file "$AG_WAF_TEMPLATE_FILE" `
    --parameters `@$AG_WAF_PARAMETERS_FILE `
    --parameters "gatewayName=$AG_WAF_NAME" `
    "gatewayLocation=$AG_WAF_LOCATION" `
    "vnetRGName=$VNET_RG_NAME" `
    "vnetName=$VNET_NAME" `
    "subnetName=$SUBNET_PUBLIC_NAME" `
    "enableHttp2=$AG_WAF_ENABLE_HTTP2" `
    "idleTimeout=$AG_WAF_IDLE_TIMEOUT" `
    "domainNameLabel=$AG_WAF_DOMAIN_NAME_LABEL" `
    "backendIPAddress=$AG_WAF_BACKEND_IP_ADDRESS" `
    "enableRequestBodyCheck=$AG_WAF_ENABLE_REQUEST_BODY_CHECK" `
    "httpsSettingsTimeout=$AG_WAF_HTTPS_TIMEOUT" `
    "disabledRuleGroups=$AG_WAF_DISABLED_RULE_GROUPS" `
    "TemplateVersion=$TEMPLATE_VERSION" `
    "createdDate=$CREATED_DATE" `
    "backendhost=$AKS_HOST_IDENTIFIER" `
    "autoscaleMinCapacity=$AG_WAF_MIN_CAPACITY" `
    "autoscaleMaxCapacity=$AG_WAF_MAX_CAPACITY"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Application Gateway with WAF (v2): $AG_WAF_NAME" -Verbose

$gatewayInfo = $(az network application-gateway show --name "$AG_WAF_NAME" --resource-group "$VNET_RG_NAME") | ConvertFrom-Json
$ipAddress = $(az network public-ip show --ids $gatewayInfo.frontendIpConfigurations.publicIpAddress.id --query "ipAddress" -o tsv)

Write-Verbose "Gateway listening at IP address: https://$ipAddress !!!!!!!!" -Verbose
