
# source these last as i'm certain aks-utilities has functions which
# supercede those above
#todo: get this out of here too

. ("$INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1") *> $null

# dump the verbose output -- you already have this further above in the build
#. ("$INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1") *> $null

. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1") 4> $null
