param
(
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup,

  [Parameter(Mandatory = $false)]
  [array] $rgResources = $null
)


Describe "Atlas dynatrace Deployment Tests" {
  BeforeAll {

    #source the _include file
    . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")
    # AKS Environment Setup
    . ("$INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
    . ("$INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/dynatraceVariables-v2.ps1")
    

    Write-Verbose "Tested Resource Group: $resourceGroup." -Verbose
    $aksName = ($rgResources | Where-Object { $_.type -match "Microsoft.ContainerService/managedClusters" }).name
    $tempErrorActionPreference = $ErrorActionPreference
    try {
      $ErrorActionPreference = "Stop"
      az aks get-credentials -g "$resourceGroup" -n "$aksName" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
    }
    catch {
      $currentException = $_
      Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
      if ($($currentException.Exception.Message).Contains("as current context in")) {
        Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
      }
      else {
        Write-Verbose "Exception is unexpected. The script will end now" -Verbose
        throw $currentException.Exception.Message
      }
    }

    $ErrorActionPreference = $tempErrorActionPreference

    # Get Dyantrace namespace from the AKS
    $namespace = (kubectl get namespace -n dynatrace -o json | ConvertFrom-Json).Items | Where-Object { $_.Metadata.Name -eq 'dynatrace' }
    # Get Dyantrace Pod Status as running
    $podExist = (kubectl get pods -n dynatrace -o json | ConvertFrom-Json).Items | Where-Object { $_.Status.phase -eq 'Running' }
    $podStatus = (kubectl get pods -n dynatrace -o json | ConvertFrom-Json).items.status.phase
    # Get the service account for the dynatrace
    $serviceAccount = kubectl get sa dynatrace-kubernetes-monitoring -n dynatrace
    # Get cluster role
    $clusterRole = $(kubectl get clusterroles -o json) | ConvertFrom-Json
    $clusterRoleValue = $clusterRole.items.metadata.name | Where-Object { $_ -match "dynatrace-kubernetes-monitoring" }
    # cluster role binding
    $clusterRoleBinding = $(kubectl get clusterrolebindings -o json) | ConvertFrom-Json
    $clusterRoleBindingValue = $clusterRoleBinding.items.metadata.name | Where-Object { $_ -match "dynatrace-kubernetes-monitoring" }
    
    #Get the bearer token for later use
    #Remove if check once aks version is above 1.23
    if ($env:AKS_KUBERNETES_VERSION -eq "1.23")
    {
      $theToken = kubectl get secret $(kubectl get sa dynatrace-kubernetes-monitoring -o jsonpath='{.secrets[0].name}' -n dynatrace) -o jsonpath='{.data.token}' -n dynatrace
    }
    else{
      $theToken = kubectl get secret dynatrace-kubernetes-monitoring -o jsonpath='{.data.token}' -n dynatrace | base64 --decode
    }
  }

  It "dynatrace namespace does exist" {
    $namespace | Should -Not -BeNullOrEmpty
  }
  It "dynatrace pod does exist" {
    $podExist | Should -Not -BeNullOrEmpty
  }

  It "dynatrace pod status is running" {
    foreach ($podstat in $podStatus) {
      $podstat | Should -Be 'Running'
    }
  }

  It "service account does exist" {
    $serviceAccount | Should -Not -BeNullOrEmpty
    $clusterRoleValue | Should -Not -BeNullOrEmpty
    $clusterRoleBindingValue | Should -Not -BeNullOrEmpty
  }

  It "Kubenet bearer token does exist" {
    $theToken | Should -Not -BeNullOrEmpty
  }
}