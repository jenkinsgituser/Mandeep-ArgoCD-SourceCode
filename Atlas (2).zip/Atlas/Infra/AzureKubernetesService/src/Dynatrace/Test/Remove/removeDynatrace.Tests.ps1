param
(
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup,

  [Parameter(Mandatory = $false)]
  [array] $rgResources = $null
)

# source the _include file
. ("$INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/Test/_includes.tests.ps1")

. ("$INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/dynatraceVariables-v2.ps1")

Describe "Atlas dynatrace Removal Tests" {

  Write-Verbose "Tested Resource Group: $resourceGroup." -Verbose
  $aksName = ($rgResources | Where-Object { $_.type -match "Microsoft.ContainerService/managedClusters" }).name

  $tempErrorActionPreference = $ErrorActionPreference
  try {
    $ErrorActionPreference = "Stop"
    az aks get-credentials -g "$resourceGroup" -n "$aksName" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
  }
  catch {
    $currentException = $_
    Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
    if ($($currentException.Exception.Message).Contains("as current context in")) {
      Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
    }
    else {
      Write-Verbose "Exception is unexpected. The script will end now" -Verbose
      throw $currentException.Exception.Message
    }
  }
  $ErrorActionPreference = $tempErrorActionPreference
  # Get Dyantrace namespace from the AKS
  $namespace = (kubectl get namespace -n dynatrace -o json | ConvertFrom-Json).Items | Where-Object { $_.Metadata.Name -eq 'dynatrace' }
  # Get Dyantrace Pod
  $podExist = (kubectl get pods -n dynatrace -o json | ConvertFrom-Json).items
  # Gethe service account for the dynatrace
  $serviceAccount = kubectl get sa dynatrace-kubernetes-monitoring -n dynatrace
  # Get cluster role
  $clusterRole = $(kubectl get clusterroles -o json) | ConvertFrom-Json
  $clusterRoleValue = $clusterRole.items.metadata.name | Where-Object { $_ -match "dynatrace-kubernetes-monitoring" }
  # cluster role binding
  $clusterRoleBinding = $(kubectl get clusterrolebindings -o json) | ConvertFrom-Json
  $clusterRoleBindingValue = $clusterRoleBinding.items.metadata.name | Where-Object { $_ -match "dynatrace-kubernetes-monitoring" }
  #Get the bearer token for later use
  $theToken = kubectl get secret $(kubectl get sa dynatrace-kubernetes-monitoring -o jsonpath='{.secrets[0].name}' -n dynatrace) -o jsonpath='{.data.token}' -n dynatrace

  It "dynatrace namespace does not exist" {
    $namespace | Should -BeNullOrEmpty
  }
  It "dynatrace pod does not exist" {
    $podExist | Should -BeNullOrEmpty
  }
  It "service account does not exist" {
    $serviceAccount | Should -BeNullOrEmpty
    $clusterRoleValue | Should -BeNullOrEmpty
    $clusterRoleBindingValue | Should -BeNullOrEmpty
  }
  It "Kubernet bearer token does not exist" {
    $theToken | Should -BeNullOrEmpty
  }


}

