#**********************************************************
# Remove the Dynatrace from the AKS Cluster
#**********************************************************
$ErrorActionPreference = "Stop"

Write-Verbose "Getting the credential." -Verbose
try {
  az aks get-credentials -g "$env:AKS_RG_NAME" -n "$env:AKS_NAME" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
}
catch {
  $currentException = $_
  Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
  if ($($currentException.Exception.Message).Contains("as current context in")) {
    Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
  }
  else {
    Write-Verbose "Exception is unexpected. The script will end now" -Verbose
    throw $currentException.Exception.Message
  }
}

Write-Verbose "Credential successfully retrieved." -Verbose

$namespace = kubectl get namespace dynatrace
If (!$namespace) {
  Write-Verbose "Dynatrace namespace does not exist in the AKS Cluster." -Verbose

}
else {
  Write-Verbose "Dynatrace namespace found in the AKS Cluster." -Verbose

  Write-Verbose "Checking if DynaKube exists ..." -Verbose
  $DynaKubeCheck = kubectl -n dynatrace get DynaKube
  If (!$DynaKubeCheck) {
    Write-Verbose "DynaKube does not exist in the AKS Cluster."
    #Remove the dyntrace and dynatrace namespace from the AKS cluster.
    Write-Verbose "Removing the service account of the Dynatrace from the AKS Cluster." -Verbose
    kubectl delete -f $DYNATRACE_API_MONITORING_FILE  -n dynatrace
    Write-Verbose "Removing Dynatrace and namespace from the AKS Cluster." -Verbose
    kubectl delete -f $DYNATRACE_DEPLOY_MANIFEST_FILE -n dynatrace
    Write-Verbose "Successfully removed Dynatrace from the AKS Cluster." -Verbose
    
  } 
  else { 
    Write-Verbose "DynaKube found in the AKS Cluster." -Verbose 
    #Remove the Dynatrace SA and DynaKube namespace from the AKS cluster.
    Write-Verbose "Removing the service account of the Dynatrace from the AKS Cluster." -Verbose
    kubectl delete -f $DYNATRACE_API_MONITORING_FILE  -n dynatrace
    Write-Verbose "Removing DynaKube and namespace from the AKS Cluster." -Verbose
    kubectl delete -f $DYNATRACE_DYNAKUBE_MANIFEST_FILE -n dynatrace
    Write-Verbose "Successfully removed DynaKube from the AKS Cluster." -Verbose
    kubectl delete -f https://github.com/Dynatrace/dynatrace-operator/releases/latest/download/kubernetes.yaml
    Write-Verbose "Successfully removed Dynatrace Operator from the AKS Cluster." -Verbose
  }

  # Delete namespace if it still exists
  kubectl delete namespace dynatrace
  Write-Verbose "Successfully removed Dynatrace namespace from the AKS Cluster." -Verbose
}

