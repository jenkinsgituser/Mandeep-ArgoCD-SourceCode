
#Setup dynatrace Api URL secret names for prod and nonprod
$apiURLSecretNameNonProd = "DT-LinuxURL-NonProd"
$apiURLSecretNameProd = "DT-LinuxURL-Prod"

#Setup dynatrace Api token secret names for prod and nonprod
$apiTokenSecretNameNonProd = "DT-AKSToken-NonProd"
$apiTokenSecretNameProd = "DT-AKSToken-Prod"
## Bring in Atlas-CommonCode for Get-SubscriptionProperties
. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

#dynatrace portal api token secret names for prod and nonprod
$apiPortalTokenSecretNameNonProd = "DT-PortalConfigToken-NonProd"
$apiPortalTokenSecretNameProd = "DT-PortalConfigToken-Prod"

#Identify the environment for the AKS cluster
$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
$environment = $SubscriptionProperties.environment

# Setup the Api Token and URl based on the environment (Prod,NonProd,Sandbox)
if ($environment -eq "Prod") {
    $dynatraceApiURLSecret = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiURLSecretNameProd).SecretValue
    $dynatraceApiURL = [System.Net.NetworkCredential]::new("", $dynatraceApiURLSecret).Password
    $dynatraceApiTokenSecret = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiTokenSecretNameProd).SecretValue
    $dynatraceApiToken = [System.Net.NetworkCredential]::new("", $dynatraceApiTokenSecret).Password
    $dynatraceApiPortalToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiPortalTokenSecretNameProd).SecretValue
    $dynatraceApiPortalToken = [System.Net.NetworkCredential]::new("", $dynatraceApiPortalToken).Password
}
elseif ($environment -eq "NonProd") {
    $dynatraceApiURL = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiURLSecretNameNonProd).SecretValue
    $dynatraceApiURL = [System.Net.NetworkCredential]::new("", $dynatraceApiURL).Password
    $dynatraceApiToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiTokenSecretNameNonProd).SecretValue
    $dynatraceApiToken = [System.Net.NetworkCredential]::new("", $dynatraceApiToken).Password
    $dynatraceApiPortalToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiPortalTokenSecretNameNonProd).SecretValue
    $dynatraceApiPortalToken = [System.Net.NetworkCredential]::new("", $dynatraceApiPortalToken).Password
}
elseif ($environment -eq "Sandbox") {
    $dynatraceApiURL = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_NP -Name $apiURLSecretNameNonProd).SecretValue
    $dynatraceApiURL = [System.Net.NetworkCredential]::new("", $dynatraceApiURL).Password
    $dynatraceApiToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_NP -Name $apiTokenSecretNameNonProd).SecretValue
    $dynatraceApiToken = [System.Net.NetworkCredential]::new("", $dynatraceApiToken).Password
    $dynatraceApiPortalToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_NP -Name $apiPortalTokenSecretNameNonProd).SecretValue
    $dynatraceApiPortalToken = [System.Net.NetworkCredential]::new("", $dynatraceApiPortalToken).Password
}

if (($environment -eq "NonProd") -or ($environment -eq "Sandbox")) {
    $dynatraceCredUrl = "https://goy71950.live.dynatrace.com/api/config/v1/kubernetes/credentials"
}
else {
    $dynatraceCredUrl = "https://wzj14229.live.dynatrace.com/api/config/v1/kubernetes/credentials"
}

$DYNATRACE_DEPLOY_MANIFEST_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/dynatraceOneAgentDaemonset.yaml")
$DYNATRACE_API_MONITORING_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/dynatraceAPIMonitoring.yaml")
# if we're local, write to a .mine copy so we don't need to mess with git
# and inadverdently check in the wrong changes
$DYNATRACE_DEPLOY_MANIFEST_FILE_OUTPUT = $DYNATRACE_DEPLOY_MANIFEST_FILE
if ($env:IsLocal) {
    $DYNATRACE_DEPLOY_MANIFEST_FILE_OUTPUT = $DYNATRACE_DEPLOY_MANIFEST_FILE.Replace(".yaml", ".mine.yaml")
}

Write-Verbose "Perform API URL replacement for dynatraceOneAgentDaemonset yaml" -Verbose
(Get-Content $DYNATRACE_DEPLOY_MANIFEST_FILE) | ForEach-Object {
    $_ -replace '__dynatraceApiURL__', $dynatraceApiURL `
        -replace '__dynatraceApiToken__', $dynatraceApiToken
} | Set-Content $DYNATRACE_DEPLOY_MANIFEST_FILE_OUTPUT

$existingAksNameinRG = az aks list --resource-group $env:AKS_RG_NAME | ConvertFrom-Json
if ([string]::IsNullOrEmpty($existingAksNameinRG.name)) {
    #Setup the environment code
    Write-Verbose "AKS_SHORT_NAME: $env:AKS_SHORT_NAME" -Verbose

    If ( $environment -eq $CONST_PROD_SUB) {
        $AZENV = "PR1"
    }
    Else {
        $AZENV = "NP1"
    }
    Write-Verbose "AZENV: $AZENV" -Verbose
    $env:AKS_NAME = "AKS-$AZENV-$($env:AKS_SHORT_NAME)"
}
else {
    $env:AKS_NAME = $existingAksNameinRG.name
}
Write-Verbose "AKS name: $env:AKS_NAME" -Verbose
Write-Verbose "RG name: $env:AKS_RG_NAME" -Verbose

# Check if cluster exist
$cluster = $(az aks show -n $env:AKS_NAME -g $env:AKS_RG_NAME 2> $null ) | ConvertFrom-Json
#Get the Kubernetes API URL
$clusterApiUrl = "https://" + $cluster.fqdn

if ($cluster) {
    Write-Verbose "The AKS - $env:AKS_NAME exists in resource group $env:AKS_RG_NAME." -Verbose
}
else {
    $errorMessage = "The specified AKS cluster does not exist. Please verify the AKS cluster name or AKS RG name."
    Write-Verbose $errorMessage -Verbose
    throw $errorMessage
}

$KUBE_CONFIG_PATH = [IO.Path]::Combine($env:TEMP, ".kube", "config")

# Set the environment variable to match the kube_config_path in the event that we fail to
# pass a --kubeconfig flag somewhere
$env:KUBECONFIG = $KUBE_CONFIG_PATH
Write-Verbose "KUBE_CONFIG_PATH: $KUBE_CONFIG_PATH" -Verbose