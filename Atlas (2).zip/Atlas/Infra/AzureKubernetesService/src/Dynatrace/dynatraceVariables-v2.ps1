
#Setup dynatrace Api URL secret names for prod and nonprod
$apiURLSecretNameNonProd = "DT-LinuxURL-NonProd"
$apiURLSecretNameProd = "DT-LinuxURL-Prod"

#Setup dynatrace Api token secret names for prod and nonprod
$apiTokenSecretNameNonProd = "DT-AKSToken-NonProd"
$apiTokenSecretNameProd = "DT-AKSToken-Prod"
## Bring in Atlas-CommonCode for Get-SubscriptionProperties
. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

#dynatrace portal api token secret names for prod and nonprod
$apiPortalTokenSecretNameNonProd = "DT-PortalConfigToken-NonProd"
$apiPortalTokenSecretNameProd = "DT-PortalConfigToken-Prod"

#Identify the environment for the AKS cluster
$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
$environment = $SubscriptionProperties.environment

# Setup the Api Token and URl based on the environment (Prod,NonProd,Sandbox)
if ($environment -eq "Prod") {
    $dynatraceApiURLSecret = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiURLSecretNameProd).SecretValue
    $dynatraceApiURL = [System.Net.NetworkCredential]::new("", $dynatraceApiURLSecret).Password
    $dynatracePaasTokenSecret = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiTokenSecretNameProd).SecretValue
    $dynatracePaasToken = [System.Net.NetworkCredential]::new("", $dynatracePaasTokenSecret).Password
    $dynatraceApiToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiPortalTokenSecretNameProd).SecretValue
    $dynatraceApiToken = [System.Net.NetworkCredential]::new("", $dynatraceApiToken).Password
}
elseif ($environment -eq "NonProd") {
    $dynatraceApiURL = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiURLSecretNameNonProd).SecretValue
    $dynatraceApiURL = [System.Net.NetworkCredential]::new("", $dynatraceApiURL).Password
    $dynatracePaasToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiTokenSecretNameNonProd).SecretValue
    $dynatracePaasToken = [System.Net.NetworkCredential]::new("", $dynatracePaasToken).Password
    $dynatraceApiToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_P -Name $apiPortalTokenSecretNameNonProd).SecretValue
    $dynatraceApiToken = [System.Net.NetworkCredential]::new("", $dynatraceApiToken).Password
}
elseif ($environment -eq "Sandbox") {
    $dynatraceApiURL = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_NP -Name $apiURLSecretNameNonProd).SecretValue
    $dynatraceApiURL = [System.Net.NetworkCredential]::new("", $dynatraceApiURL).Password
    $dynatracePaasToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_NP -Name $apiTokenSecretNameNonProd).SecretValue
    $dynatracePaasToken = [System.Net.NetworkCredential]::new("", $dynatracePaasToken).Password
    $dynatraceApiToken = (Get-AzKeyVaultSecret -VaultName $CONST_KV_SHAREDSVCS_NP -Name $apiPortalTokenSecretNameNonProd).SecretValue
    $dynatraceApiToken = [System.Net.NetworkCredential]::new("", $dynatraceApiToken).Password
}

if (($environment -eq "NonProd") -or ($environment -eq "Sandbox")) {
    $dynatraceCredUrl = "https://goy71950.live.dynatrace.com/api/config/v1/kubernetes/credentials"
}
else {
    $dynatraceCredUrl = "https://wzj14229.live.dynatrace.com/api/config/v1/kubernetes/credentials"
}

$DYNATRACE_DYNAKUBE_MANIFEST_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/classicFullStack.yaml")
#$DYNATRACE_DEPLOY_MANIFEST_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/dynatraceOneAgentDaemonset.yaml")
$DYNATRACE_API_MONITORING_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/dynatraceAPIMonitoring.yaml")
$DYNATRACE_TOKENSECRET_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/token-secret.yaml")

# $DYNATRACE_OPERATOR_MANIFEST = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/DT-Kubernetes_custom.yaml")
# $DYNATRACE_BASH = ("$env:INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/DT-Kubernetes-Install_custom.sh")

# if we're local, write to a .mine copy so we don't need to mess with git
# and inadverdently check in the wrong changes
#$DYNATRACE_DEPLOY_MANIFEST_FILE_OUTPUT = $DYNATRACE_DEPLOY_MANIFEST_FILE
#if ($env:IsLocal) {
#    $DYNATRACE_DEPLOY_MANIFEST_FILE_OUTPUT = $DYNATRACE_DEPLOY_MANIFEST_FILE.Replace(".yaml", ".mine.yaml")
#}
$DYNATRACE_DYNAKUBE_MANIFEST_FILE_OUTPUT = $DYNATRACE_DYNAKUBE_MANIFEST_FILE
if ($env:IsLocal) {
    $DYNATRACE_DYNAKUBE_MANIFEST_FILE_OUTPUT = $DYNATRACE_DYNAKUBE_MANIFEST_FILE.Replace(".yaml", ".mine.yaml")
}



#Write-Verbose "Perform API URL replacement for dynatraceOneAgentDaemonset yaml" -Verbose
Write-Verbose "Perform API URL replacement for classicFullStack yaml" -Verbose
#(Get-Content $DYNATRACE_DEPLOY_MANIFEST_FILE) | ForEach-Object {
#    $_ -replace '__dynatraceApiURL__', $dynatraceApiURL `
#        -replace '__dynatraceApiToken__', $dynatraceApiToken
#} | Set-Content $DYNATRACE_DEPLOY_MANIFEST_FILE_OUTPUT

$existingAksNameinRG = az aks list --resource-group $env:AKS_RG_NAME | ConvertFrom-Json
if ([string]::IsNullOrEmpty($existingAksNameinRG.name)) {
    #Setup the environment code
    Write-Verbose "AKS_SHORT_NAME: $env:AKS_SHORT_NAME" -Verbose

    If ( $environment -eq $CONST_PROD_SUB) {
        $AZENV = "PR1"
    }
    Else {
        $AZENV = "NP1"
    }
    Write-Verbose "AZENV: $AZENV" -Verbose
    $env:AKS_NAME = "AKS-$AZENV-$($env:AKS_SHORT_NAME)"
}
else {
    $env:AKS_NAME = $existingAksNameinRG.name
}
Write-Verbose "AKS name: $env:AKS_NAME" -Verbose
Write-Verbose "RG name: $env:AKS_RG_NAME" -Verbose

# Get short API URL
$DT_API_URL = $dynatraceApiURL.Substring(0,($dynatraceApiURL.IndexOf("/v1")))
Write-Verbose "API URL: $DT_API_URL" -Verbose
Write-Verbose "hostGroup: $env:AKS_NAME" -Verbose
(Get-Content $DYNATRACE_DYNAKUBE_MANIFEST_FILE) | ForEach-Object {
    $_ -replace '__dynatraceApiURL__', $DT_API_URL `
        -replace '__hostGroup__', $env:AKS_NAME `
        -replace '__ONEAGENT_INSTALLER_DOWNLOAD_TOKEN__', $dynatracePaasToken `
        -replace '__ONEAGENT_INSTALLER_SCRIPT_URL__', $dynatraceApiURL
} | Set-Content $DYNATRACE_DYNAKUBE_MANIFEST_FILE_OUTPUT




# Check if cluster exist
$cluster = $(az aks show -n $env:AKS_NAME -g $env:AKS_RG_NAME 2> $null ) | ConvertFrom-Json
#Get the Kubernetes API URL
$clusterApiUrl = "https://" + $cluster.fqdn

if ($cluster) {
    Write-Verbose "The AKS - $env:AKS_NAME exists in resource group $env:AKS_RG_NAME." -Verbose
}
else {
    $errorMessage = "The specified AKS cluster does not exist. Please verify the AKS cluster name or AKS RG name."
    Write-Verbose $errorMessage -Verbose
    throw $errorMessage
}

$KUBE_CONFIG_PATH = [IO.Path]::Combine($env:TEMP, ".kube", "config")

# Set the environment variable to match the kube_config_path in the event that we fail to
# pass a --kubeconfig flag somewhere
$env:KUBECONFIG = $KUBE_CONFIG_PATH
Write-Verbose "KUBE_CONFIG_PATH: $KUBE_CONFIG_PATH" -Verbose