#**********************************************************
# Deploy the Dynatrace to AKS Cluster
#**********************************************************

$ErrorActionPreference = "SilentlyContinue"

function Set-DynatracePortalConfigForCluster {
  param (
    [string] $clusterName,
    [string] $clusterApiUrl,
    [string] $clusterApiToken,
    [string] $dynatraceApiPortalToken,
    [string] $dynatraceCredUrl,
    [string] $environment
  )

  $eventsFieldSelectors = @()
  $eventsFieldSelectors += [pscustomobject]@{
    'label'         = 'Node events';
    'fieldSelector' = 'involvedObject.kind=Node';
    'active'        = 'true';
  }

  $eventsFieldSelectors += [pscustomobject]@{
    'label'         = 'Pod events';
    'fieldSelector' = 'involvedObject.kind=Pod';
    'active'        = 'true';
  }

  $AKS_Config = @{
    label                      = $clusterName
    endpointUrl                = $clusterApiUrl
    eventsFieldSelectors       = $eventsFieldSelectors
    workloadIntegrationEnabled = 'true'
    eventsIntegrationEnabled   = 'true'
    authToken                  = $clusterApiToken
    active                     = 'true'
    certificateCheckEnabled    = 'false'
  }

  $json = $AKS_Config | ConvertTo-Json
  # Write-Verbose "config submitted to Dynatrace is $json"

  $headers = @{
    'Authorization' = 'API-Token ' + $dynatraceApiPortalToken
    'Content-Type'  = 'application/json'
  }

  $response = Invoke-RestMethod -Uri $dynatraceCredUrl -Method POST -Headers $headers -Body $json

}

function Is-DynatracePortalConfigForCluster {
  param (
    [string] $clusterName,
    [string] $dynatraceApiPortalToken,
    [string] $dynatraceCredUrl,
    [string] $environment
  )

  $headers = @{
    'Authorization' = 'API-Token ' + $dynatraceApiPortalToken
    'Content-Type'  = 'application/json'
  }

  $response = Invoke-WebRequest -Uri $dynatraceCredUrl -Method GET -Headers $headers
  $configExists = ($response.Content | ConvertFrom-Json).values | Where-Object { $_.name -match $clusterName }

  if ($configExists) {
    return $true
  }
  else {
    return $false
  }

}

Write-Verbose "Getting the credential." -Verbose
$tempErrorActionPreference = $ErrorActionPreference
# Get a credential
try {
  $ErrorActionPreference = "Stop"
  az aks get-credentials -g "$env:AKS_RG_NAME" -n "$env:AKS_NAME" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
}
catch {
  $currentException = $_
  Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
  if ($($currentException.Exception.Message).Contains("as current context in")) {
    Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
  }
  else {
    Write-Verbose "Exception is unexpected. The script will end now" -Verbose
    throw $currentException.Exception.Message
  }
}
$ErrorActionPreference = $tempErrorActionPreference
Write-Verbose "Credential successfully retrieved." -Verbose

# Create a dynatrace namespace if it does not exist in the existing AKS cluster
$namespace = kubectl get namespace dynatrace
If (!$namespace) {
  Write-Verbose "Creating a Dynatrace namespace in the existing AKS cluster." -Verbose
  kubectl create namespace dynatrace
}

#Install dynatrace in the dynatrace namespace.
Write-Verbose "Deploying Dynatrace in the AKS cluster." -Verbose
#Create dynatrace under dynatrace namespace
kubectl apply -f   $DYNATRACE_DEPLOY_MANIFEST_FILE_OUTPUT -n dynatrace
#Create a service account and cluster role for accessing the Kubernetes API.
kubectl apply -f   $DYNATRACE_API_MONITORING_FILE -n dynatrace

<#
Notes/commands on how to delete a cluster config from Dynatrace portal if needed
  # get clusters in dynatrace
  $response = Invoke-WebRequest -Uri dynatraceCredUrl -Method GET -Headers $headers
  # get specific clusterId
  $dt_cluster_id = (($response.Content | ConvertFrom-Json).values | Where-Object { $_.name -match "AKS-NP1-z772521" }).id
  # api request to delete cluster config
  Invoke-WebRequest -Uri dynatraceCredUrl/$dt_cluster_id -Method DELETE -Headers $headers
#>

# MDH 2021-07 - Adding RG name in parentheses to cluster name before submitting info to Dynatrace
$clusterName = $env:AKS_NAME
$clusterRG = $env:AKS_RG_NAME
if ($clusterRG.Length -gt 0) {
  $clusterName = $clusterName + ' - ' + $clusterRG
}
Write-Verbose "Dynatrace cluster name (AKS cluster name plus resource group) is $clusterName." -Verbose

# Configure the cluster in the dynatrace portal
if ($environment -ne "Sandbox") {
  # check if dynatrace portal already has this cluster defined, if not add it
  $dynatraceConfigExists = Is-DynatracePortalConfigForCluster -clusterName $clusterName -dynatraceApiPortalToken $dynatraceApiPortalToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment
  if ($dynatraceConfigExists) {
    Write-Verbose "Cluster $clusterName already configured in Dynatrace portal." -Verbose
  }
  else {
    Write-Verbose "Getting cluster API token." -Verbose
    $theToken = kubectl get secret $(kubectl get sa dynatrace-monitoring -o jsonpath='{.secrets[0].name}' -n dynatrace) -o jsonpath='{.data.token}' -n dynatrace
    $clusterApiToken = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($theToken))
    Write-Verbose "Configure cluster $clusterName in Dynatrace portal." -Verbose
    Set-DynatracePortalConfigForCluster -clusterName $clusterName -clusterApiUrl $clusterApiUrl -clusterApiToken $clusterApiToken -dynatraceApiPortalToken $dynatraceApiPortalToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment
  }
}

Write-Verbose "Dynatrace successfully deployed to the AKS cluster." -Verbose
