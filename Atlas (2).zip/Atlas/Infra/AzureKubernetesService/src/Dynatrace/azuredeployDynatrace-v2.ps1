#**********************************************************
# Deploy the Dynatrace OneAgent and DynaKube Resource to AKS Cluster (backend script)
# V2.0
# Team Zoidberg
# This script follows the manual steps outlined in the Dynatrace Support Article:
# https://www.dynatrace.com/support/help/setup-and-configuration/setup-on-container-platforms/kubernetes/set-up-k8s-monitoring
# Steps will be commented where they match the manual step number
#**********************************************************

$ErrorActionPreference = "SilentlyContinue"

# Functions for connecting to the Dynatrace API

function Set-DynatracePortalConfigForCluster {
  param (
    [string] $clusterName,
    [string] $clusterApiUrl,
    [string] $clusterApiToken,
    [string] $dynatraceApiToken,
    [string] $dynatraceCredUrl,
    [string] $environment,
    [string] $update
  )

  $eventsFieldSelectors = @()
  $eventsFieldSelectors += [pscustomobject]@{
    'label'         = 'Node events';
    'fieldSelector' = 'involvedObject.kind=Node';
    'active'        = 'true';
  }

  $eventsFieldSelectors += [pscustomobject]@{
    'label'         = 'Pod events';
    'fieldSelector' = 'involvedObject.kind=Pod';
    'active'        = 'true';
  }

  $AKS_Config = @{
    label                      = $clusterName
    endpointUrl                = $clusterApiUrl
    eventsFieldSelectors       = $eventsFieldSelectors
    workloadIntegrationEnabled = 'true'
    eventsIntegrationEnabled   = 'true'
    authToken                  = $clusterApiToken
    active                     = 'true'
    certificateCheckEnabled    = 'false'
    davisEventsIntegrationEnabled = 'true'
      }

  $json = $AKS_Config | ConvertTo-Json
  # Write-Verbose "config submitted to Dynatrace is $json"

  $headers = @{
    'Authorization' = 'API-Token ' + $dynatraceApiToken
    'Content-Type'  = 'application/json'
  }

  if ($update -eq "new")
  {
  $response = Invoke-RestMethod -Uri $dynatraceCredUrl -Method POST -Headers $headers -Body $json
  }
  else
  {
  $dynatraceUpdateCredUrl = $dynatraceCredUrl + '/' + $update
  $response = Invoke-RestMethod -Uri $dynatraceUpdateCredUrl -Method PUT -Headers $headers -Body $json
  }


}

function Is-DynatracePortalConfigForCluster {
  param (
    [string] $clusterName,
    [string] $dynatraceApiToken,
    [string] $dynatraceCredUrl,
    [string] $environment
  )

  $headers = @{
    'Authorization' = 'API-Token ' + $dynatraceApiToken
    'Content-Type'  = 'application/json'
  }

  $response = Invoke-WebRequest -Uri $dynatraceCredUrl -Method GET -Headers $headers    
  $configExists = ($response.Content | ConvertFrom-Json).values | Where-Object { $_.name -match $clusterName }


  if ($configExists) {
    return $configExists.id
  }
  else {
    return $false
  }

}




Write-Verbose "Getting the credential." -Verbose
$tempErrorActionPreference = $ErrorActionPreference
# Get a credential
try {
  $ErrorActionPreference = "Stop"
  az aks get-credentials -g "$env:AKS_RG_NAME" -n "$env:AKS_NAME" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
}
catch {
  $currentException = $_
  Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
  if ($($currentException.Exception.Message).Contains("as current context in")) {
    Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
  }
  else {
    Write-Verbose "Exception is unexpected. The script will end now" -Verbose
    throw $currentException.Exception.Message
  }
}
$ErrorActionPreference = $tempErrorActionPreference
Write-Verbose "Credential successfully retrieved." -Verbose



# **************************************************************
# STEP 1
# **************************************************************
# Create a dynatrace namespace if it does not exist in the existing AKS cluster
# If it does exist, check for DynaKube and exit out if the resource does not exist since it will be V1
$namespace = kubectl get namespace dynatrace
If (!$namespace) {
  Write-Verbose "Creating a Dynatrace namespace in the existing AKS cluster." -Verbose
  kubectl create namespace dynatrace
}
else
{
  Write-Verbose "Checking if DynaKube exists ..." -Verbose
  $DynaKubeCheck = kubectl -n dynatrace get DynaKube
  If (!$DynaKubeCheck) 
    { Write-Verbose "DynaKube does not exist on this cluster! Please remove the existing Dynatrace Operator before deploying Dynakube (v2). Exiting from script." -Verbose
      Write-Host "##vso[task.logissue type=warning]Remove previous version of Dynatrace before deploying DynaKube (v2)."
      Exit
    } 
    else {Write-Verbose "DynaKube does exist -- continuing redploy..." -Verbose}
  
}

# **************************************************************
# STEP 2
# **************************************************************
# Install dynatrace Operator in the dynatrace namespace.
Write-Verbose "Deploying Dynatrace Operator in the AKS cluster." -Verbose
kubectl apply -f ("$INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/DynatraceOperator.yaml") -n dynatrace

# **************************************************************
# STEP 3
# **************************************************************
# Wait for operator install to be complete.
kubectl -n dynatrace wait pod --for=condition=ready -l internal.dynatrace.com/app=webhook --timeout=300s


# **************************************************************
# STEP 4
# **************************************************************
# Create the dynakube secret holding the API and PaaS tokens for authentication to Dynatrace SaaS
$l_apiToken = 'apiToken=' + $dynatraceApiToken
$l_apiToken = '"' + $l_apiToken + '"'
$l_paasToken = 'paasToken=' + $dynatracePaasToken
$l_paasToken = '"' + $l_paasToken + '"'

# kubectl -n dynatrace create secret generic dynakube --from-literal=$l_apiToken --from-literal=$l_paasToken
kubectl -n dynatrace create secret generic dynakube --from-literal=paasToken=$dynatracePaasToken --from-literal=apiToken=$dynatraceApiToken

# **************************************************************
# STEP 8
# **************************************************************
#Apply the Dynakube custom resource
kubectl apply -f $DYNATRACE_DYNAKUBE_MANIFEST_FILE_OUTPUT -n dynatrace

Write-Verbose "Dynatrace successfully deployed to the AKS cluster." -Verbose

# **********************************
# Connect to the Dynatrace API
# **********************************


<#
Notes/commands on how to delete a cluster config from Dynatrace portal if needed
  # get clusters in dynatrace
  $response = Invoke-WebRequest -Uri dynatraceCredUrl -Method GET -Headers $headers
  # get specific clusterId
  $dt_cluster_id = (($response.Content | ConvertFrom-Json).values | Where-Object { $_.name -match "AKS-NP1-z772521" }).id
  # api request to delete cluster config
  Invoke-WebRequest -Uri dynatraceCredUrl/$dt_cluster_id -Method DELETE -Headers $headers
#>

# MDH 2021-07 - Adding RG name in parentheses to cluster name before submitting info to Dynatrace
$clusterName = $env:AKS_NAME
$clusterRG = $env:AKS_RG_NAME
if ($clusterRG.Length -gt 0) {
  $clusterName = $clusterName + ' - ' + $clusterRG
}
Write-Verbose "Dynatrace cluster name (AKS cluster name plus resource group) is $clusterName." -Verbose

# Configure the cluster in the dynatrace portal
if ($environment -ne "") {

  # Generate Cluster Token based on AKS Version
  

  # If AKS 1.23 run old version, otherwise run new
  # Reference: https://www.dynatrace.com/support/help/setup-and-configuration/setup-on-container-platforms/kubernetes/enable-kubernetes-api-monitoring/connect-your-k8s-clusters#connect
 
  if ($env:AKS_KUBERNETES_VERSION -eq "1.23")
    {
        # AKS 1.23
        Write-Verbose -Verbose "Running Dynatrace Kubernetes 1.23 Install for AKS $($env:AKS_KUBERNETES_VERSION)"
        # check if dynatrace portal already has this cluster defined, if not add it
          $dynatraceConfigExists = Is-DynatracePortalConfigForCluster -clusterName $clusterName -dynatraceApiToken $dynatraceApiToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment
          if ($dynatraceConfigExists) {
            Write-Verbose "Cluster $clusterName already configured in Dynatrace portal -- updating." -Verbose
            kubectl apply -f $DYNATRACE_API_MONITORING_FILE -n dynatrace
          
            Write-Verbose "Getting cluster API token." -Verbose
            $theToken = kubectl get secret $(kubectl get sa dynatrace-monitoring -o jsonpath='{.secrets[0].name}' -n dynatrace) -o jsonpath='{.data.token}' -n dynatrace
            Write-Verbose -Verbose "The token troubleshooting: $($theToken)"
            $clusterApiToken = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($theToken))
            #Write-Verbose -Verbose "The token troubleshooting: $($clusterApiToken)"
            Write-Verbose "Update cluster $clusterName in Dynatrace portal." -Verbose
            Set-DynatracePortalConfigForCluster -clusterName $clusterName -clusterApiUrl $clusterApiUrl -clusterApiToken $clusterApiToken -dynatraceApiToken $dynatraceApiToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment -update $dynatraceConfigExists
          }
          else {
            Write-Verbose "Cluster $clusterName not configured in Dynatrace portal -- creating new connection." -Verbose
            kubectl apply -f $DYNATRACE_API_MONITORING_FILE -n dynatrace

            Write-Verbose "Getting cluster API token." -Verbose
            $theToken = kubectl get secret $(kubectl get sa dynatrace-monitoring -o jsonpath='{.secrets[0].name}' -n dynatrace) -o jsonpath='{.data.token}' -n dynatrace
            $clusterApiToken = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($theToken))
            $CredUpdate = "new"
            Write-Verbose "Configure cluster $clusterName in Dynatrace portal." -Verbose
            Set-DynatracePortalConfigForCluster -clusterName $clusterName -clusterApiUrl $clusterApiUrl -clusterApiToken $clusterApiToken -dynatraceApiToken $dynatraceApiToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment -update "new"
          }
    }
  else
    {
            # AKS 1.24+
            Write-Verbose -Verbose "Running Dynatrace Kubernetes 1.24+ Install for AKS $($env:AKS_KUBERNETES_VERSION)"
            # check if dynatrace portal already has this cluster defined, if not add it
            $dynatraceConfigExists = Is-DynatracePortalConfigForCluster -clusterName $clusterName -dynatraceApiToken $dynatraceApiToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment
            if ($dynatraceConfigExists) 
          {
            Write-Verbose "Cluster $clusterName already configured in Dynatrace portal -- updating." -Verbose
            kubectl apply -f $DYNATRACE_API_MONITORING_FILE -n dynatrace
            kubectl apply -f $DYNATRACE_TOKENSECRET_FILE -n dynatrace
            Write-Verbose "Getting cluster API token." -Verbose
            $clusterApiToken = kubectl get secret dynatrace-kubernetes-monitoring -o jsonpath='{.data.token}' -n dynatrace | base64 --decode
            #Write-Verbose -Verbose "The token troubleshooting: $($clusterApiToken)"
            Write-Verbose "Update cluster $clusterName in Dynatrace portal." -Verbose
            Set-DynatracePortalConfigForCluster -clusterName $clusterName -clusterApiUrl $clusterApiUrl -clusterApiToken $clusterApiToken -dynatraceApiToken $dynatraceApiToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment -update $dynatraceConfigExists
          }
            else 
          {
            Write-Verbose "Cluster $clusterName not configured in Dynatrace portal -- creating new connection." -Verbose
            kubectl apply -f $DYNATRACE_API_MONITORING_FILE -n dynatrace
            kubectl apply -f $DYNATRACE_TOKENSECRET_FILE -n dynatrace
            Write-Verbose "Getting cluster API token." -Verbose
            $clusterApiToken = kubectl get secret dynatrace-kubernetes-monitoring -o jsonpath='{.data.token}' -n dynatrace | base64 --decode
            #Write-Verbose -Verbose "The token troubleshooting: $($clusterApiToken)"
            $CredUpdate = "new"
            Write-Verbose "Configure cluster $clusterName in Dynatrace portal." -Verbose
            Set-DynatracePortalConfigForCluster -clusterName $clusterName -clusterApiUrl $clusterApiUrl -clusterApiToken $clusterApiToken -dynatraceApiToken $dynatraceApiToken -dynatraceCredUrl $dynatraceCredUrl -environment $environment -update "new"
          }
    }



}


