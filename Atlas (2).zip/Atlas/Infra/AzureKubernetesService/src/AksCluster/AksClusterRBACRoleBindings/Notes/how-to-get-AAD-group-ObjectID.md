1. Navigate to https://graphexplorer.azurewebsites.net/#. If you have not previously accessed this application, sign in in the upper right. When prompted, enable the application to access the directory on your behalf. 

2. In the below example graph query, replace R-TeamTitan with your application's support group: 
    <https://graph.windows.net/cunamutual.com/groups?$filter=displayName eq 'R-TeamTitan'>

3. Note the objectId returned within the response for your group - grab that and save as a pipelining variable. Below is a sample response object for the R-TeamTitan group. Note the ObjectId is shown as "ce4e84f5-8464-41a2-96bd-aa6396d2ed33". This is the value required for future use. 

    * "value": [
        {
            "odata.type": "Microsoft.DirectoryServices.Group",
            "objectType": "Group",
            "objectId": "ce4e84f5-8464-41a2-96bd-aa6396d2ed33",
            "deletionTimestamp": null,
            "description": "Grants access for the functions related to Team Titan",
            "dirSyncEnabled": true,
            "displayName": "R-TeamTitan",
            "lastDirSyncTime": "2018-11-06T19:20:42Z",
            "mail": null,
            "mailNickname": "R-TeamTitan",
            "mailEnabled": false,
            "onPremisesDomainName": null,
            "onPremisesNetBiosName": null,
            "onPremisesSamAccountName": null,
            "onPremisesSecurityIdentifier": "S-1-5-21-220523388-261903793-682003330-253549",
            "provisioningErrors": [],
            "proxyAddresses": [],
            "securityEnabled": true
        }
    ]

4. Confirm ObjectId matches expected group. Run the query below, replacing "X" with the objectId returned in the previous query. Confirm the expected role group is returned. 
    https://graph.windows.net/cunamutual.com/groups/ce4e84f5-8464-41a2-96bd-aa6396d2ed33
