1. SP for AKS requires (SP to config and run Cluster): network contributor to a subnet the cluster will be deployed to. 

2. Guest users (federated from separate directory) - unsupported. This means that users of the CMFG Kubernetes service connecting via Kubectl will need to exist within the CMFG tenant.  

3. AAD server ID, server app secret, client app ID and tenant ID necessary to deploy AAD enabled cluster
    * aad-server-app-id: TBD - dynamic or static & shared
    * aad-server-app-secret: TBD - dynamic or static & shared
    * aad-client-app-id: TBD - dynamic or static & shared
    * tenantId: a00452fd-8469-409e-91a8-bb7a008e2da0 (same for all CMFG clusters)

4. Initial role binding run uses a --admin parameter which allows for admin privilege escalation to then execute the necessary role binding
    az aks get-credentials --resource-group myResourceGroup --name myAKSCluster --admin

