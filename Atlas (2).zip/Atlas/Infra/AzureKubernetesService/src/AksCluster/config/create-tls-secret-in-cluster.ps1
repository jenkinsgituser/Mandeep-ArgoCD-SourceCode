##############################################################################################################################################
#This script breaks a PFX with a secret into a .crt and .key file using OpenSSL.
#To correctly function, the script needs to run in an environment which has the openssl client tools installed.

#This script also pull secrets stored in the environment put in place by a key vault. Therefore, as currently written
#the parameter names of twistlockdemo-cmutualm-cert and twistlockdemo-cmutualm-password are rather
#hard coded as those are the names the Azure Key Vault task stores the secrets as upon retrieval.

#Experimentation with nested parameter expansion was attempted unsuccessfully. Future improvements on this front are necessary, however
#the script provided below is still leagues ahead of manual provisioning and only requires an update to reference the correct secret name.

#It's possible the names could be passed as arguments into this script, however I ran out of time in the week to go further down that route.
##############################################################################################################################################

#take the retrieved certificate string and convert into a PFX
$kvSecretBytes = [System.Convert]::FromBase64String("$(twistlockdemo-cmutualm-cert)")
$certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
$certCollection.Import($kvSecretBytes, $null, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)


#write the PFX to the local directory, using the password to secure it
$protectedCertificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, "$(twistlockdemo-cmutualm-password)")
$pfxPath = ".\" + "$(pfxName)"
[System.IO.File]::WriteAllBytes($pfxPath, $protectedCertificateBytes)


#convert the PFX into a .crt and .key (decrypted) files using -passin and -passout parameters to keep each individual file secured every step along the way
openssl pkcs12 -in $(pfxName) -nocerts -out $(keyName) -passin "pass:$("$(twistlockdemo-cmutualm-password)")" -passout "pass:$("$(twistlockdemo-cmutualm-password)")"

openssl pkcs12 -in $(pfxName)  -clcerts -nokeys -out $(crtName) -passin "pass:$("$(twistlockdemo-cmutualm-password)")" -passout "pass:$("$(twistlockdemo-cmutualm-password)")"

openssl rsa -in $(keyName) -out $(decryptedKeyName) -passin "pass:$("$(twistlockdemo-cmutualm-password)")"  -passout "pass:$("$(twistlockdemo-cmutualm-password)")"