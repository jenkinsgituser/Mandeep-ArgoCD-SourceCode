function Clean-KubeConfigFile {
    [CmdletBinding()]
    param($Path)

    if (Test-Path -Path $Path) {
        Write-Verbose "Removing kubectl config file" -Verbose
        Remove-Item -Path "$Path"
        Write-Verbose "kubectl config removed." -Verbose
    }
    else {
        Write-Warning "kubectl config file does not exist" -Verbose
    }
}


function Confirm-Kubectl {
    #perform Kubectl install if necessary
    try {
        $ErrorActionPreference = "Stop"
        $result = Get-Command kubectl
    }
    catch {
        $ErrorActionPreference = "Continue"
        $(az aks install-cli) 2>$null
        $env:PATH = "$($env:USERPROFILE)\.azure-kubectl;" + $env:PATH

        #update the path on the Azure DevOps agent. Updated path persists
        #only for the lifetime of the actual agent.
        Write-Host "##vso[task.setvariable variable=PATH;]$env:PATH"
        $result = Get-Command kubectl
    }
    finally {
        $global:lastExitCode = $null
    }

    if ($null -eq $result) {
        Write-Error "Unable to discover nor install Kubectl on agent. Exiting..."
        Write-Error "Should this error be experienced consistently, it is likely the `
      underlying hosted agents have been updated or the 'az aks install-cli' task is `
      failing to externally retrieve the executable"

        Exit 1
    }

    return $true
}

function Get-AKS-Supported-Latest-K8S-Version {
    param(
        [Parameter(Mandatory = $false)]
        [string] $Version,
        [Parameter(Mandatory = $true)]
        [string] $AKS_Location
    )

    try {
        Write-Verbose -Verbose "Latest allowed version from constants: $Version"
        Write-Verbose -Verbose "Latest allowed version from constants: $CONST_LATEST_ALLOWED_K8S_VERSION"
        if ([string]::IsNullOrEmpty($Version)) {
            $Version = $CONST_LATEST_ALLOWED_K8S_VERSION 
        }
        else {
            $Version = ($Version).ToString().Split('.')[0..1] -Join '.'
        }
        # $LatestVersionDetail = $(az aks get-versions --location $AKS_LOCATION --query "orchestrators[?!isPreview].orchestratorVersion" -o tsv) |`
        #     #NOTE:Temporarily removing the check for preview for testing purposes. Use the commented where statement once AKS 1.25 is GA in EastUS2 
        #     Where-Object { $_ -like "$Version.*" } |`
        #     #Where-Object { $_ -like "$Version.*" -and $_ -notmatch $CONST_PREVIEW_IDENTIFIER } |`
        #     Sort-Object { [version] $_ } | Select-Object -Last 1

        #adding the powershell version of the above command so we dont have to use --query
        $LatestVersionDetail = $(Get-AzAksVersion -location $AKS_LOCATION)|     
            Where-Object { $_.OrchestratorVersion -like "$Version.*" -and $_.IsPreview -notmatch $True} | 
            Sort-Object { [version] $_.OrchestratorVersion } | Select-Object -Last 1
            $LatestVersionDetail = $LatestVersionDetail.OrchestratorVersion
    }
    catch {
        # Write the error and suppress it.
        Write-Verbose "Error while retrieving the latest Kubernetes version supported by AKS/Atlas." -Verbose
        Write-Error "ERROR: $_.Exception" -Verbose
    }
    finally {
        $global:lastExitCode = $null
    }
    return $LatestVersionDetail
}


function Get-AllowedAKSNameByResourceGroup {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $aksShortName,
        [Parameter(Mandatory = $true)]
        [string] $AZENV
    )
    $AKS_NAME = "AKS-$AZENV-$AKS_SHORT_NAME"
    Write-Verbose "AKS NAME: $AKS_NAME" -Verbose
    $clusters = az aks list --resource-group $resourceGroupName | ConvertFrom-Json
    $result = ""
    if ($clusters) {
        $foundCluster = $clusters | Where-Object { $_.name -match $AKS_NAME }
        # Each resource group should only have one AKS cluster.The script fails if the AKS name not match with the existing AKS cluster name.
        if (!$foundCluster) {
            throw "A different AKS cluster - $($clusters.name) already exists in the resource group - $resourceGroupName. It does not match the AKS Name - $AKS_NAME the script is looking for. Each resource group should only have one AKS cluster."
        }
        else {
            $result = $foundCluster.name
        }
    }
    return $result
}


# returns true if redeployment atop the existing cluster is believed to succeed.
# returns false with error message if re-deployment is expected to fail
function Get-AksRedeploymentSupported {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $resourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $aksName
    )
    $tempPreference = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"

    $result = $true
    $errorMessage = $null

    # get the target cluster, which may not yet exist
    # dump errors in the event that it does not exist
    $cluster = $(az aks show -n $aksName -g $resourceGroupName 2> $null) | ConvertFrom-Json

    # case 1 - the cluster doesn't exist
    # deploymentSupported => true, no error message

    # case 2 - the cluster exists and has network policy in place
    # deploymentSupported => true, no error message

    #case 3 - the cluster exists but does not yet have network policy in place
    # deploymentSupported => false, error which indicates why
    #**********************************************************************************************
    # we've always deployed our clusters with networkProfile in place, so there's no valid reason to
    # assume we need to handle the case where it isn't present -- at that point, it's not Atlas anyway
    if ($cluster -and $cluster.networkProfile `
            -and (!$cluster.networkProfile.networkPolicy -or $cluster.networkProfile.networkPolicy -ne "calico")) {
        $result = $false
        $errorMessage = "Target cluster exists and does not have Network Policy in place. Current deployment does not support re-deployment atop target cluster!"
    }

    $ErrorActionPreference = $tempPreference
    return @{deploymentSupported = $result; errorMessage = $errorMessage }
}

function Check-AtlasAksPermissionsSetupRequired {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $AksServicePrincipalObjectId,
        [Parameter(Mandatory = $true)]
        [array] $AppTeamRoleGroupObjectIds
    )
    # default to true
    $aksPermSetupRequired = $true
    $spHasNecessaryPerms = $false
    $groupHasNecessaryPerms = $false

    try {

        $rgScope = (Get-AzResourceGroup -Name $ResourceGroupName).resourceid
    }
    catch {
        Write-Verbose -Verbose "Resource group scope cannot be verified. Account must not have permissions."
        return $true
    }

    $assignments = (az role assignment list --scope $rgScope | ConvertFrom-Json)

    # if either condition below is false, we need to complete setup. Setup is skipped if both conditions are met.

    # start by checking if the SP has necessary permissions the resource group.
    # necessary perms include Network Contributor and ....
    $aksSpAssignments = $assignments | Where-Object { $_.PrincipalId -eq $AksServicePrincipalObjectId }
    $spHasNecessaryPerms = ($aksSpAssignments.roleDefinitionName -eq "Network Contributor")
    if ([string]::IsNullOrEmpty($spHasNecessaryPerms)) {
        Write-Verbose -Verbose "SP does not have necessary perms on target resource group. Permissions setup required!"
        return $true
    }

    foreach ($AppTeamRoleGroupObjectId in $AppTeamRoleGroupObjectIds) {
        $groupAssignments = $assignments | Where-Object { $_.PrincipalId -eq $AppTeamRoleGroupObjectId }
        $groupHasNecessaryPerms = ($groupAssignments.roleDefinitionName -Contains "Reader" `
                -and $groupAssignments.roleDefinitionName -Contains "Azure Kubernetes Service Cluster User Role")
        if ([string]::IsNullOrEmpty($groupHasNecessaryPerms)) {
            Write-Verbose -Verbose "Role group does not have necessary perms on target resource group. Permissions setup required!"
            return $true
        }
    }

    if ($groupHasNecessaryPerms -and $spHasNecessaryPerms) {
        $aksPermSetupRequired = $false
    }

    return $aksPermSetupRequired
}

function Check-AtlasMcGroupPermissions {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $AksCluster,
        [Parameter(Mandatory = $true)]
        [array] $AppTeamRoleGroupObjectIds
    )

    # default to true
    $permissionSetupRequired = $true
    $spHasNecessaryPerms = $false
    $groupHasNecessaryPerms = $false

    $tempErroractionpreference = $ErrorActionPreference
    $ErrorActionPreference = "Stop"

    # if either condition below is false, we need to complete setup. Setup is skipped if both conditions are met.
    # cluster.nodeResourceGroup is the property defining the resource group that contains the nodes
    try {
        $clusterInfo = az aks show -g $ResourceGroupName -n $AksCluster 2> $null | ConvertFrom-Json
        write-verbose -verbose "LASTEXITCODE VALUE is $LASTEXITCODE" 
        If ($LASTEXITCODE -ne 0) {
            throw "AKS Cluster Not Found"
        }
    }
    catch {
        Write-Verbose -Verbose "Cluster cannot be found. Permissions cascade skipped."
        #we are returning false because if the cluster is not found, there is no reason to call the runbook to set permission.
        return $false
    }

    $clusterRG = $clusterInfo.nodeResourceGroup
    Write-Verbose -Verbose "clusterRG: $clusterRG"
    try {

        $rgScope = (Get-AzResourceGroup -Name $clusterRG).resourceid
    }
    catch {
        # This returns true if MC resource group permissions are not found, indicating they need to be cascaded.
        Write-Verbose -Verbose "MC_ resource group scope cannot be found. Permissions cascade required."
        return $true
    }

    $assignments = (az role assignment list --scope $rgScope | ConvertFrom-Json)
    # two checks to perform -- does the active SP have access to the target MC group? If yes, continue to perform second check. If no, return early
    # because we need to cascade the perms

    # TODO: This doesn't work correctly locally, as the local user won't
    # TODO: necessarily get permissions cascaded the same as an SP-RM account...
    if ($env:IsLocal) {
        Write-Verbose -Verbose "Skipping service principal privilege check due to running local..."
        $spHasNecessaryPerms = $true
    }
    else {
        $appId = (az account show --query "user.name" -o tsv)
        $runtimeAccountObjectId = (az ad sp show --id $appId --query "id" -o tsv)
        $rmSpAssignments = $assignments | Where-Object { $_.PrincipalId -eq $runtimeAccountObjectId }
        $spHasNecessaryPerms = ($rmSpAssignments.roleDefinitionName -eq "Contributor")
        if ([string]::IsNullOrEmpty($spHasNecessaryPerms)) {
            Write-Verbose -Verbose "SP does not have necessary perms on target resource group. Permissions setup required!"
            return $true
        }
    }

    # second check - does the target team have perms on the MC group? If not, let's run the script to cascade perms
    foreach ($AppTeamRoleGroupObjectId in $AppTeamRoleGroupObjectIds) {
        $groupAssignments = $assignments | Where-Object { $_.PrincipalId -eq $AppTeamRoleGroupObjectId }
        $groupHasNecessaryPerms = ($groupAssignments.roleDefinitionName -Contains "Reader")
        if ([string]::IsNullOrEmpty($groupHasNecessaryPerms)) {
            Write-Verbose -Verbose "Role group does not have necessary perms on target resource group. Permissions setup required!"
            return $true
        }
    }

    if ($groupHasNecessaryPerms -and $spHasNecessaryPerms) {
        $permissionSetupRequired = $false
    }
    $ErrorActionPreference = $tempErroractionpreference
    return $permissionSetupRequired
}

#Check the user-entered AKS version.It throws an error or warning message based on the user-entered version,
#existing AKS version, and the allowed latest version.
# It will call Validate-InputAKSVersionExist function to check if the user-entered is valid or not.
function Validate-InputAksVersionEnvironmentVariable {
    param
    (
        [Parameter(Mandatory = $false)]
        [string] $ExistingAksVersion,
        [Parameter(Mandatory = $false)]
        [string] $AllowedLatestVersion

    )

    if (![string]::IsNullOrEmpty($env:AKS_KUBERNETES_VERSION)) {
        # Check if the user-provided cluster version is valid or not. The script fails if it's an invalid version.
        Validate-InputAKSVersionExist
        if (![string]::IsNullOrEmpty($ExistingAksVersion)) {
            # Provide a warning message if the user-provided version is lower than the existing cluster version.
            # Will deploy the AKS cluster with the latest version.
            if ([version]$env:AKS_KUBERNETES_VERSION -lt [version]$ExistingAksVersion) {
                Write-Warning "Your entered 'AKS_KUBERNETES_VERSION'- $env:AKS_KUBERNETES_VERSION is lower than the existing cluster version - $ExistingAksVersion."
                Write-Warning "We will deploy the AKS cluster with the latest allowed cluster version $AllowedLatestVersion."
            }
            # Provide a warning message if the existing cluster name is lower than the latest allowed cluster version.
            # Will upgrade the existing cluster to the latest version.
            if ([version]$ExistingAksVersion -lt [version]$AllowedLatestVersion ) {
                Write-Warning "Your current cluster version - $ExistingAksVersion is lower than the latest allowed cluster version - $AllowedLatestVersion. We will upgrade to the latest allowed cluster version."
            }
        }
        else {
            # Provide a warning message if the user provided AKS cluster version (no existing cluster) is lower than the latest allowed cluster version.
            # Will deploy with the user-provided version if it's valid.
            if ([version]$env:AKS_KUBERNETES_VERSION -lt [version]$AllowedLatestVersion) {
                Write-Warning "Your entered 'AKS_KUBERNETES_VERSION'- $env:AKS_KUBERNETES_VERSION is lower than the latest allowed cluster version - $AllowedLatestVersion."
                Write-Warning "We will deploy with your entered cluster version, but you have option to deploy with latest allowed cluster version."
            }
        }
    }
    else {
        if (![string]::IsNullOrEmpty($ExistingAksVersion)) {
            # Provide a warning message if the existing cluster version (No user-entered AKS cluster version) is lower than the latest allowed cluster version.
            if ([version]$ExistingAksVersion -lt [version]$AllowedLatestVersion) {
                Write-Warning "The exsiting cluster version is lower than the latest allowed cluster version - $AllowedLatestVersion."
                Write-Warning "We will deploy with the latest allowed cluster version."
            }
        }
    }
}

function Get-AKSClusterRBACsubjects {
    param
    (
        [Parameter(Mandatory = $true)]
        [array] $AppTeamRoleGroupObjectIds
    )

    # use this variable to build up the list of subjects that will be added to the yaml file
    # !! this variable must be all the way to the left !!
    $subject = @'
- apiGroup: rbac.authorization.k8s.io
  kind: Group
  name: "__developerRoleGroupObjectId__"
'@

    # loop through role group object ids and build the subject multi-line string to return
    foreach ($AppTeamRoleGroupObjectId in $AppTeamRoleGroupObjectIds) {
        $subjects = $subjects + ($subject -replace '__developerRoleGroupObjectId__', "$AppTeamRoleGroupObjectId") + "`r`n"
    }

    return $subjects
}

Function Get-RequiredAKSVersion {
    param(
        [Parameter(Mandatory = $false)]
        [int] $Start = 0,
        [Parameter(Mandatory = $false)]
        [int] $End = 1,
        [Parameter(Mandatory = $true)]
        [version] $AKSVersion
    )
    $AKSVersion = $AKSVersion.ToString().Split('.')[$Start..$End] -Join '.'
    return $AKSVersion
}
Function Validate-AKSVersionWarningMessage {
    param(
        [Parameter(Mandatory = $false)]
        [string] $userProvidedVersion,
        [Parameter(Mandatory = $false)]
        [string] $Current_AKS_Version,
        [Parameter(Mandatory = $false)]
        [string]$latestAllowedVersion
    )
    if (![string]::IsNullOrEmpty($userProvidedVersion)) {
        #Get the build version for user provided version
        $UserProvidedbuildVersion = ([version]$userProvidedVersion).build
        #Get the build version for the latest version
        $LatestBuildVersion = ([version]$latestAllowedVersion).build
        if (![string]::IsNullOrEmpty($Current_AKS_Version)) {
            #Get the build version for the current version
            $currentBuildVersion = ([version]$Current_AKS_Version).build
            if ($UserProvidedbuildVersion -ne "-1") {
                if ($UserProvidedbuildVersion -lt $currentBuildVersion) {
                    if ($currentBuildVersion -lt $LatestBuildVersion ) {
                        Write-Warning "The user-entered AKS cluster version $userProvidedVersion is lower than the latest version $latestAllowedVersion. We will be based on the user-provided major and minor versions to upgrade the AKS cluster with the latest patch version."
                    }
                    else {
                        if ( $UserProvidedbuildVersion -le $currentBuildVersion) {
                            Write-Warning "We will be based on the user-provided major and minor version to upgrade the AKS cluster to the latest patch version if it's not."
                        }
                    }
                }
                elseif ($UserProvidedbuildVersion -eq $currentBuildVersion) {
                    if ($currentBuildVersion -ne $LatestBuildVersion) {
                        Write-Warning "The user-entered AKS cluster version is $userProvidedVersion. We will be based on the user-provided major and minor version to upgrade the AKS cluster with the latest patch version."
                    }
                }
                elseif ($UserProvidedbuildVersion -lt $LatestBuildVersion) {
                    Write-Warning "The user-entered AKS cluster version $userProvidedVersion is lower than the latest version $latestAllowedVersion. We will be based on the user-provided major and minor version to upgrade the AKS cluster with the latest patch version."
                }
                elseif ($UserProvidedbuildVersion -gt $LatestBuildVersion) {
                    Write-Warning "The user-entered AKS custer version is $userProvidedVersion. We will be based on the user-provided major and minor version to deploy the AKS cluster to the latest allowed version $latestAllowedVersion."
                }
                elseif ($UserProvidedbuildVersion -gt $currentBuildVersion) {
                    Write-Warning "We will be based on the user-provided major and minor version to upgrade the AKS cluster to the latest allowed version $latestAllowedVersion."
                }
            }
            else {
                if ($currentBuildVersion -lt $LatestBuildVersion) {
                    Write-Warning "The current AKS cluster version $Current_AKS_Version is lower than the latest version $latestAllowedVersion. We will upgrade the AKS cluster to the latest version."
                }
            }
        }
        else {
            Write-Warning "The user-entered AKS version is $userProvidedVersion. We will be based on the user-provided major and minor version to deploy the AKS cluster with the latest allowed version $latestAllowedVersion."
        }
    }
    else {
        #Get the build version for the latest version
        $LatestBuildVersion = ([version]$latestAllowedVersion).build
        if (![string]::IsNullOrEmpty($Current_AKS_Version)) {
            #Get the build version for the current version
            $currentBuildVersion = ([version]$Current_AKS_Version).build
            if ($currentBuildVersion -lt $LatestBuildVersion ) {
                Write-Warning "Your current version $Current_AKS_Version is lower than the latest version $latestAllowedVersion. We will upgrade the AKS cluster to the latest version."
            }
        }
        else {
            Throw "AKS version is required for a new AKS cluster deployment."
        }
    }
}

#Set the AKS cluster version for AKS cluster deployment
Function Get-AKSClusterDeploymentVersion {
    param(
        [Parameter(Mandatory = $false)]
        [string] $userProvidedVersion,
        [Parameter(Mandatory = $false)]
        [string] $Current_AKS_Version_Detail,
        [Parameter(Mandatory = $true)]
        [string] $AKS_Location
    )
    $Version = [version]$CONST_LATEST_ALLOWED_K8S_VERSION
    Write-Verbose "Version: $Version" -Verbose
    $LatestMinusTwoAKSVersion = [version]::New($Version.Major, $Version.Minor - 2)
    Write-Verbose "LatestMinusTwoAKSVersion: $LatestMinusTwoAKSVersion" -Verbose
    If (![string]::IsNullOrEmpty($userProvidedVersion)) {
        Write-Verbose "userProvidedVersion: $userProvidedVersion" -Verbose
        #Get the major and minor version based on the user-entered version
        $MajorMinorUserVersion = Get-RequiredAKSVersion -AKSVersion $userProvidedVersion
        Write-Verbose "MajorMinorUserVersion : $MajorMinorUserVersion " -Verbose
        if ([version]$MajorMinorUserVersion -lt [version]$CONST_LOWEST_ALLOWED_K8S_VERSION -or [version]$MajorMinorUserVersion -gt [version]$CONST_LATEST_ALLOWED_K8S_VERSION ) {
            #If an existing AKS cluster exists in the RG, the script fails when the AKS cluster is non-supported version by Atlas.
            throw "The user provided AKS cluster version is $userProvidedVersion. It's non-supported AKS cluster version by Atlas."
        }
        if ([string]::IsNullOrEmpty($Current_AKS_Version_Detail)) {
            #done
            Write-Verbose "Current_AKS_Version_Detail: $Current_AKS_Version_Detail" -Verbose
            # Set the AKS cluster version as the user-entered version if no existing AKS cluster is available for the Resource group.
            # The user provided version should not greater than the latest allowed version.
            $latestAllowedVersion = Get-AKS-Supported-Latest-K8S-Version -Version $userProvidedVersion -AKS_Location $AKS_Location
            Write-Verbose "latestAllowedVersion : $latestAllowedVersion " -Verbose
            $AKS_KUBERNETES_VERSION = $latestAllowedVersion
            Validate-AKSVersionWarningMessage -userProvidedVersion $userProvidedVersion -Current_AKS_Version $Current_AKS_Version_Detail -latestAllowedVersion $latestAllowedVersion
        }
        else {
            #Get the major/minor version based on the current AKS version
            $Current_AKS_Version = Get-RequiredAKSVersion -AKSVersion $Current_AKS_Version_Detail
            if ([version]$Current_AKS_Version -lt [version]$CONST_LOWEST_ALLOWED_K8S_VERSION -or [version]$Current_AKS_Version -gt [version]$CONST_LATEST_ALLOWED_K8S_VERSION) {
                #If an existing AKS cluster exists in the RG, the script fails when the AKS cluster is non-supported version by Atlas.
                throw "The existing AKS cluster version is $Current_AKS_Version_Detail which is not supported by Atlas."
            }
            $latestAllowedVersion = Get-AKS-Supported-Latest-K8S-Version -Version $userProvidedVersion -AKS_Location $AKS_Location
            if ($MajorMinorUserVersion -lt [version]$Current_AKS_Version) {
                throw "The user entered version $userProvidedVersion is lower than the existing AKS version $Current_AKS_Version_Detail."
            }
            elseif ($MajorMinorUserVersion -eq [version]$Current_AKS_Version) {
                $AKS_KUBERNETES_VERSION = $latestAllowedVersion
                Validate-AKSVersionWarningMessage -userProvidedVersion $userProvidedVersion -Current_AKS_Version $Current_AKS_Version_Detail -latestAllowedVersion $latestAllowedVersion
            }
            elseif ($MajorMinorUserVersion -gt [version]$Current_AKS_Version) {
                $versionDifference = $MajorMinorUserVersion.Minor - $Current_AKS_Version.minor
                if ( $versionDifference -eq 1) {
                    $AKS_KUBERNETES_VERSION = $latestAllowedVersion
                    Write-Warning "The current AKS cluster version is $Current_AKS_Version_Detail. We will upgrade the AKS cluster version to the latest allowed version of $MajorMinorUserVersion (user-entered version)."
                }
                else {
                    throw "You can't jump two versions or more for AKS upgrade. Please recheck your AKS version and try the deployment again."
                }
            }
        }
    }
    else {
        if ([string]::IsNullOrEmpty($Current_AKS_Version_Detail)) {
            Throw "AKS version is required for a new AKS cluster deployment."
        }
        else {
            if (([version]$Current_AKS_Version_Detail).minor -gt 18) {
                throw "AKS cluster version is required for 1.19+ clusters."
            }
            elseif (([version]$Current_AKS_Version_Detail).minor -lt ([version]$CONST_LOWEST_ALLOWED_K8S_VERSION).minor) {
                throw "The existing AKS cluster is non-support AKS cluster version by Atlas"
            }
            #Upgrade to the latest version for the existing Cluster.
            $latestAllowedVersion = Get-AKS-Supported-Latest-K8S-Version -Version $Current_AKS_Version_Detail -AKS_Location $AKS_Location
            $AKS_KUBERNETES_VERSION = $latestAllowedVersion
            Validate-AKSVersionWarningMessage -userProvidedVersion $userProvidedVersion -Current_AKS_Version $Current_AKS_Version_Detail -latestAllowedVersion $latestAllowedVersion
        }
    }
    return $AKS_KUBERNETES_VERSION
}

Function Validate-InputAKSVersionExist {
    #Check if the user-entered AKS cluster version is valid or not
    if (![string]::IsNullOrEmpty($env:AKS_KUBERNETES_VERSION)) {
        $allVersions = az aks get-versions --location eastus2 | ConvertFrom-Json
        $selectedVersion = $allVersions.orchestrators | Where-Object { $_.orchestratorVersion -eq $env:AKS_KUBERNETES_VERSION }
        if ($null -eq $selectedVersion) {
            #If $validAksVersion is empty, consider it's invalid AKS cluster version. Fail the script.
            throw "The user-entered AKS cluster version - $env:AKS_KUBERNETES_VERSION is invalid. Please provide a valid AKS cluster version and try the deployment again."
        }
    }
}

Function Get-AllPatchVersionBasedonMinorVersion {

    param([Parameter(Mandatory = $true)]

        [string] $MajorMinorVersion

    )


    $AllPatchVersion = $(az aks get-versions --location $AKS_LOCATION --query "orchestrators[?!isPreview].orchestratorVersion" -o tsv) |`

    Where-Object { $_ -like "$MajorMinorVersion.*" -and $_ -notmatch $CONST_PREVIEW_IDENTIFIER } |`

    Sort-Object { [version] $_ }




    return $AllPatchVersion

}
Function Get-DetailPatchVersionBasedonMinorVersion {
    param([Parameter(Mandatory = $true)]
        [array] $AllVersion
    )
    $count = $AllVersion.count
    [version]$LowestVersion = $null
    [version]$LatestVersion = $null
    [version]$HighThanLatest = $null
    [version]$LowerThanLowestVersion = $null
    [version]$MiddleVersion = $null

    switch ($count) {
        1 {
            $LatestVersion = $AllVersion[0];
            $LowestVersion = $AllVersion[0];
            if (($LatestVersion.ToString().Split('.')[2..2] -Join '.') -gt 1) {
                $LowerThanLowestVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor - 1)
            };
            $HighThanLatest = [version]::New($LatestVersion.Major, $LatestVersion.Minor + 1)
        }
        2 {
            $LatestVersion = $AllVersion[1];
            $LowestVersion = $AllVersion[0] ;
            $HighThanLatest = [version]::New($LatestVersion.Major, $LatestVersion.Minor, $LatestVersion.Build + 1);
            if (($LowestVersion.ToString().Split('.')[2..2] -Join '.') -gt 1) {
                $LowerThanLowestVersion = [version]::New($LowestVersion.Major, $LowestVersion.Minor, $LowestVersion.Build - 1)
            }
        }
        { $count -gt 2 } {
            $LatestVersion = $AllVersion[$count - 1];
            $LowestVersion = $AllVersion[0];
            $MiddleVersion = $AllVersion[2] ;
            $HighThanLatest = [version]::New($LatestVersion.Major, $LatestVersion.Minor, $LatestVersion.Build + 1);
            if (($LowestVersion.ToString().Split('.')[2..2] -Join '.') -gt 1) {
                $LowerThanLowestVersion = [version]::New($LowestVersion.Major, $LowestVersion.Minor, $LowestVersion.Build - 1)
            }
        }
    }
    return  @{LowestVersion = $LowestVersion; LatestVersion = $LatestVersion; HighThanLatest = $HighThanLatest; LowerThanLowestVersion = $LowerThanLowestVersion; MiddleVersion = $MiddleVersion }

}


Function Get-AKSMinorVersions {
    param(
        [Parameter(Mandatory = $false)]
        [version] $VersionLatest = [version]$CONST_LATEST_ALLOWED_K8S_VERSION,
        [Parameter(Mandatory = $false)]
        [version] $VersionLowest = [version]$CONST_LOWEST_ALLOWED_K8S_VERSION
    )
    [version]$LatestVersion = $null
    [version]$LowestVersion = $null
    [version]$LatestMinusOneAKSVersion = $null
    [version]$LatestMinusTwoAKSVersion = $null
    [version]$HighThanLatestVersion = $null
    [version]$LowerThanLowestVersion = $null
    $LatestMinorVersion = $VersionLatest.ToString().Split('.')[1..1] -Join '.'
    $LowestMinorVersion = $VersionLowest.ToString().Split('.')[1..1] -Join '.'
    $VersionMinusNum = [int]$LatestMinorVersion - [int]$LowestMinorVersion
    switch ($VersionMinusNum) {
        0 {
            $LatestVersion = $VersionLatest;
            $LowestVersion = $VersionLowest;
            $HighThanLatestVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor + 1);
            $LowerThanLowestVersion = [version]::New($LowestVersion.Major, $LowestVersion.Minor - 1);
        }
        1 {
            $LatestVersion = $VersionLatest;
            $LowestVersion = $VersionLowest;
            $LatestMinusOneAKSVersion = $VersionLowest;
            $HighThanLatestVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor + 1);
            $LowerThanLowestVersion = [version]::New($LowestVersion.Major, $LowestVersion.Minor - 1);
        }
        2 {
            $LatestVersion = $VersionLatest;
            $LowestVersion = $VersionLowest;
            $LatestMinusOneAKSVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor - 1);
            $LatestMinusTwoAKSVersion = $VersionLowest;
            $HighThanLatestVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor + 1);
            $LowerThanLowestVersion = [version]::New($LowestVersion.Major, $LowestVersion.Minor - 1);
        }
        { $VersionMinusNum -gt 2 } {
            $LatestVersion = $VersionLatest;
            $LowestVersion = $VersionLowest;
            $LatestMinusOneAKSVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor - 1);
            $LatestMinusTwoAKSVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor - 2);
            $HighThanLatestVersion = [version]::New($LatestVersion.Major, $LatestVersion.Minor + 1);
            $LowerThanLowestVersion = [version]::New($LowestVersion.Major, $LowestVersion.Minor - 1);
        }
    }
    return  @{LowestVersion = $LowestVersion; LatestVersion = $LatestVersion; HighThanLatestVersion = $HighThanLatestVersion; LowerThanLowestVersion = $LowerThanLowestVersion; LatestMinusOneAKSVersion = $LatestMinusOneAKSVersion; LatestMinusTwoAKSVersion = $LatestMinusTwoAKSVersion; VersionDifferenceNum = $VersionMinusNum }

}
