
Write-Verbose "Deploying Public Subnet: $SUBNET_PUBLIC_NAME" -Verbose

$SUBNET_TEMPLATE_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksNetwork/azuredeploySubnet.json"
Write-Verbose "SUBNET_TEMPLATE_FILE: $SUBNET_TEMPLATE_FILE" -Verbose

$DEPLOYMENT_NAME = "azuredeployPublicSubnet-$(Get-Date -f yyyyMMddHHmmss)"

$Action = {
    az deployment group create `
        -g "$VNET_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$SUBNET_TEMPLATE_FILE" `
        --parameters "existingVNETName=$VNET_NAME" `
        "newSubnetName=$SUBNET_PUBLIC_NAME" `
        "newSubnetAddressPrefix=$SUBNET_PUBLIC_ADDRESS_PREFIX" `
        "nsgRGName=$NSG_RG_NAME" `
        "nsgName=$NSG_PUBLIC_NAME"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Public Subnet: $SUBNET_PUBLIC_NAME" -Verbose
