
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1")  4> $null

Write-Verbose "Deploying Public NSG: $NSG_PUBLIC_NAME" -Verbose

$NSG_PUBLIC_TEMPLATE_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksNetwork/azuredeployPublicNSG.json"
Write-Verbose "NSG_PUBLIC_TEMPLATE_FILE: $NSG_PUBLIC_TEMPLATE_FILE" -Verbose

$DEPLOYMENT_NAME = "azuredeployPublicNSG-$(Get-Date -f yyyyMMddHHmmss)"

$Action = {
    az deployment group create `
        -g "$NSG_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$NSG_PUBLIC_TEMPLATE_FILE" `
        --parameters "nsgName=$NSG_PUBLIC_NAME" `
        "nsgLocation=$NSG_LOCATION" `
        "ApplyDlxAPIMRules=$ALLOW_DLX_APIM_INGRESS" `
        "createdDate=$CREATED_DATE" `
        "TemplateVersion=$TEMPLATE_VERSION"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Public NSG: $NSG_PUBLIC_NAME" -Verbose
