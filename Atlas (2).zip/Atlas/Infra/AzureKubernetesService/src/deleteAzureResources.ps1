Write-Verbose "Deleting Azure AKS Resources" -Verbose

$AG_WAF = Get-Titan-AG-WAF -g "$AKS_RG_NAME" -n "$AG_WAF_NAME"

if ($null -ne $AG_WAF) {
    Write-Verbose "Deleting Application Gateway '$AG_WAF_NAME'" -Verbose
    az network application-gateway delete -g "$AKS_RG_NAME" -n "$AG_WAF_NAME"
    Write-Verbose "Deleted Application Gateway '$AG_WAF_NAME'" -Verbose
}
else {
    Write-Verbose "Application Gateway '$AG_WAF_NAME' does not exist" -Verbose
}

$PUBLIC_IP = Get-Titan-AG-WAF-Public-IP -g "$AKS_RG_NAME" -n "$AG_WAF_NAME"

if ($null -ne $PUBLIC_IP) {
    Write-Verbose "Deleting Application Gateway Public IP Address '$AG_WAF_NAME-IP'" -Verbose
    az network public-ip delete -g "$AKS_RG_NAME" -n "$AG_WAF_NAME-IP"
    Write-Verbose "Deleted Application Gateway Public IP Address '$AG_WAF_NAME-IP'" -Verbose
}
else {
    Write-Verbose "Application Gateway Public IP Address '$AG_WAF_NAME-IP' does not exist" -Verbose
}

$AKS = Get-Titan-AKS -g "$AKS_RG_NAME" -n "$AKS_NAME"

if ($null -ne $AKS) {
    Write-Verbose "Deleting Azure Kubernetes Service '$AKS_NAME'" -Verbose
    az aks delete -g "$AKS_RG_NAME" -n "$AKS_NAME" -y
    Write-Verbose "Deleted Azure Kubernetes Service '$AKS_NAME'" -Verbose
}
else {
    Write-Verbose "Azure Kubernetes Service '$AKS_NAME' does not exist" -Verbose
}

$AKS_AIS = Get-Titan-AIS -g $AKS_RG_NAME -n $AKS_NAME

if ($null -ne $AKS_AIS) {
    Write-Verbose "Deleting AKS Application Insights '$AKS_NAME'" -Verbose
    az resource delete -g $AKS_RG_NAME -n $AKS_NAME --resource-type "Microsoft.Insights/components"
    Write-Verbose "Deleted AKS Application Insights '$AKS_NAME'" -Verbose
}
else {
    Write-Verbose "AKS Application Insights '$AKS_NAME' does not exist" -Verbose
}

$PRIVATE_SUBNET = Get-Titan-Subnet -g "$AKS_RG_NAME" -n "$SUBNET_PRIVATE_NAME" -v "$VNET_NAME"

if ($null -ne $PRIVATE_SUBNET) {
    Write-Verbose "Deleting Private Subnet '$SUBNET_PRIVATE_NAME' in Virtual Network '$VNET_NAME'" -Verbose
    az network vnet subnet delete -g "$AKS_RG_NAME" -n "$SUBNET_PRIVATE_NAME" --vnet-name "$VNET_NAME"
    Write-Verbose "Deleted Private Subnet '$SUBNET_PRIVATE_NAME' in Virtual Network '$VNET_NAME'" -Verbose
}
else {
    Write-Verbose "Private Subnet '$SUBNET_PRIVATE_NAME' in Virtual Network '$VNET_NAME' does not exist" -Verbose
}

$PUBLIC_SUBNET = Get-Titan-Subnet -g "$AKS_RG_NAME" -n "$SUBNET_PUBLIC_NAME" -v "$VNET_NAME"

if ($null -ne $PUBLIC_SUBNET) {
    Write-Verbose "Deleting Public Subnet '$SUBNET_PUBLIC_NAME' in Virtual Network '$VNET_NAME'" -Verbose
    az network vnet subnet delete -g "$AKS_RG_NAME" -n "$SUBNET_PUBLIC_NAME" --vnet-name "$VNET_NAME"
    Write-Verbose "Deleted Public Subnet '$SUBNET_PUBLIC_NAME' in Virtual Network '$VNET_NAME'" -Verbose
}
else {
    Write-Verbose "Private Public '$SUBNET_PUBLIC_NAME' in Virtual Network '$VNET_NAME' does not exist" -Verbose
}

$VNET = Get-Titan-VNet -g "$AKS_RG_NAME" -n "$VNET_NAME"

if ($null -ne $VNET) {
    Write-Verbose "Deleting Virtual Network '$VNET_NAME'" -Verbose
    az network vnet delete -g "$AKS_RG_NAME" -n "$VNET_NAME"
    Write-Verbose "Deleted Virtual Network '$VNET_NAME'" -Verbose
}
else {
    Write-Verbose "Azure Virtual Network '$VNET_NAME' does not exist" -Verbose
}

$PRIVATE_NSG = Get-Titan-NSG -g "$AKS_RG_NAME" -n "$NSG_PRIVATE_NAME"

if ($null -ne $PRIVATE_NSG) {
    Write-Verbose "Deleting Private NSG '$NSG_PRIVATE_NAME'" -Verbose
    az network nsg delete -g "$AKS_RG_NAME" -n "$NSG_PRIVATE_NAME"
    Write-Verbose "Deleted Private NSG '$NSG_PRIVATE_NAME'" -Verbose
}
else {
    Write-Verbose "Azure Private NSG '$NSG_PRIVATE_NAME' does not exist" -Verbose
}

$PUBLIC_NSG = Get-Titan-NSG -g "$AKS_RG_NAME" -n "$NSG_PUBLIC_NAME"

if ($null -ne $PUBLIC_NSG) {
    Write-Verbose "Deleting Public NSG '$NSG_PUBLIC_NAME'" -Verbose
    az network nsg delete -g "$AKS_RG_NAME" -n "$NSG_PUBLIC_NAME"
    Write-Verbose "Deleted Public NSG '$NSG_PUBLIC_NAME'" -Verbose
}
else {
    Write-Verbose "Azure Public NSG '$NSG_PUBLIC_NAME' does not exist" -Verbose
}
