########################################################
#This script needs to be deployed to AKS clusters which
#have AAD RBAC enabled. This script sets up the cluster
#admin group as well as a group with View permissions
########################################################

Write-Verbose "Deploying AKS Admin RBAC Configuration" -Verbose

$RBAC_ADMIN_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/AksClusterRBACRoleBindings/create-cluster-admin-group.yaml"
Write-Verbose "RBAC_ADMIN_FILE: $RBAC_ADMIN_FILE" -Verbose

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $RBAC_ADMIN_FILE

Write-Verbose "Successfully Deployed AKS Admin RBAC Configuration Configuration" -Verbose


Write-Verbose "Deploying AKS Viewer RBAC Configuration" -Verbose

# $env:USE_VIEW_ONLY_PERMISSIONS created to allow testing of production perms in a non-prod environment on-demand
if ($environment -eq "Prod" -or $env:USE_VIEW_ONLY_PERMISSIONS) {
    $RBAC_DEV_TEAM_ROLE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/AksClusterRBACRoleBindings/create-cluster-dev-view-group.yaml"
    Write-Verbose "Deploying Production AKS Dev Team RBAC Configuration" -Verbose
}
else {
    $RBAC_DEV_TEAM_ROLE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/AksClusterRBACRoleBindings/create-cluster-dev-admin-group.yaml"
    Write-Verbose "Deploying Non-Production AKS Dev Team RBAC Configuration" -Verbose
}

# if we're local, write to a .mine copy so we don't need to mess with git
# and inadverdently check in the wrong changes
$RBAC_DEV_TEAM_ROLE_OUTPUT = $RBAC_DEV_TEAM_ROLE
if ($env:IsLocal) {
    $RBAC_DEV_TEAM_ROLE_OUTPUT = $RBAC_DEV_TEAM_ROLE.Replace(".yaml", ".mine.yaml")
}

###########################################################
#set the viewer group to be the Group Object ID ($APP_TEAM_AD_GROUP_OBJECT_IDS)
#in the templated ClusterRole file
###########################################################
Write-Verbose "create subjects for cluster rbac yaml" -Verbose
$subjects = Get-AKSClusterRBACsubjects -AppTeamRoleGroupObjectIds $APP_TEAM_AD_GROUP_OBJECT_IDS

Write-Verbose "perform token replacement for cluster rbac yaml" -Verbose
(Get-Content $RBAC_DEV_TEAM_ROLE) -replace '__subjectsPopulatedOnDemand__', $subjects | Set-Content $RBAC_DEV_TEAM_ROLE_OUTPUT


Write-Verbose "RBAC_DEV_TEAM_ROLE_OUTPUT: $(Get-Content $RBAC_DEV_TEAM_ROLE_OUTPUT)" -Verbose

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $RBAC_DEV_TEAM_ROLE_OUTPUT
Write-Verbose "Successfully Deployed AKS Dev Team RBAC" -Verbose

# deploy atlas-configuration-tester cluster rbac
$RBAC_ATLAS_DIAG_TESTER_ROLE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/AksClusterRBACRoleBindings/create-cluster-atlas-diagnostic-tester-view.yaml"
Write-Verbose "Deploying Atlas-Diagnostic-Tester RBAC Configuration" -Verbose
Write-Verbose "RBAC_ATLAS_DIAG_TESTER_ROLE: $(Get-Content $RBAC_ATLAS_DIAG_TESTER_ROLE)" -Verbose
kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $RBAC_ATLAS_DIAG_TESTER_ROLE
Write-Verbose "Successfully Deployed Atlas-Diagnostic-Tester RBAC" -Verbose
