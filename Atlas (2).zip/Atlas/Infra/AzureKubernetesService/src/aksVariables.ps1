if (!$AKS_ENVIRONMENT_SETUP_COMPLETE) {
    Write-Verbose "**************** Display aksVariables with Values ****************" -Verbose

    ############################################################################################################
    Function Set-AutoScaleParms {
        param(
            [Parameter(mandatory = $true)] [string] $Scale,
            [Parameter(mandatory = $false)] [int] $Min,
            [Parameter(mandatory = $false)] [int] $Max
        )
        if ($Scale -eq "true") {
            $Out_Scale = $true
            # AKS Auto Scaling Max Count is required
            if ($Max) {
                $Out_Max = $Max
            }
            else {
                Write-Error "AKS_AUTO_SCALING_MAXCOUNT value is not found. Exiting..."  -ErrorAction Stop
            }

            #AKS Auto Scaling Min Count is required
            if ($Min) {
                $Out_Min = $Min
            }
            else {
                Write-Error "AKS_AUTO_SCALING_MINCOUNT value is not found. Exiting..."  -ErrorAction Stop
            }

            #if max count gt min count, stop script. If equal, output a warning sign.
            if ($Out_Max -lt $Out_Min ) {
                Write-Error -Message " AKS_AUTO_SCALING_MAXCOUNT: $Out_Max is lesser than AKS_AUTO_SCALING_MINCOUNT : $Out_Min. Exiting " -ErrorAction Stop
            }
            elseif ($Out_Max -eq $Out_Min ) {
                Write-Warning -Message "AKS_AUTO_SCALING_MAXCOUNT: $Out_Max is equal to AKS_AUTO_SCALING_MINCOUNT : $Out_Min" -Verbose
            }
        }
        else {
            $Out_Scale = $false
            $Out_Max = "null"
            $Out_Min = "null"
        }
        Return  @{SCALING = $Out_Scale; MINCOUNT = $Out_Min; MAXCOUNT = $Out_Max }
    }

    # Relative path for kube config file
    ############################################################################################################
    # mdx7683 -- 10/20/2019: Due to reasons unknown and 20 hours debugging, the latest
    # image of Windows 2019 must have the kube config here for kubectl to connect. Modify
    # and test at your own risk.

    # sss5234 -- 10/25/2021: A change to the Azure Hosted agents required us to modify the KUBE_CONFIG_PATH
    # variable construction code from $KUBE_CONFIG_PATH = [IO.Path]::Combine($env:USERPROFILE, ".kube", "config")
    # to what is shown below.  We believe this is because Microsoft has changed the security on the $USERPROFILE directory.
    # The code below will This will write to the temp folder under the user:
    # C:\Users\VSSADM~1\AppData\Local\Temp\.kube\config versus the previous location of
    # C:\Users\VssAdministrator\.kube\config

    $KUBE_CONFIG_PATH = [IO.Path]::Combine($env:TEMP, ".kube", "config")

    # Set the environment variable to match the kube_config_path in the event that we fail to
    # pass a --kubeconfig flag somewhere
    $env:KUBECONFIG = $KUBE_CONFIG_PATH
    Write-Verbose "KUBE_CONFIG_PATH: $KUBE_CONFIG_PATH" -Verbose

    # Get the Subscription Name
    $SUBSCRIPTION_NAME = $(Get-AzContext).Subscription.Name
    Write-Verbose "SUBSCRIPTION_NAME: $SUBSCRIPTION_NAME" -Verbose

    #var simplification work
    #########################################################################
    Write-Verbose "Determine environment (prod vs. nonprod)" -Verbose
    ## Bring in Atlas-CommonCode for Get-SubscriptionProperties

    $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
    $environment = $SubscriptionProperties.environment
    Write-Verbose "Environment: $environment " -Verbose

    If ($null -eq $PORT_NAME) { Write-Error "Unable to discover portfolio. Exiting..."; Exit 1 }
    Write-Verbose "portfolio name: $PORT_NAME" -Verbose
    #########################################################################
    Write-Verbose "Setting subscription variables" -Verbose


    If ($environment -eq $CONST_PROD_SUB) {
        $ATLAS_PORT_VAULT_NAME = "kv-atlas-$PORT_NAME-p"
        $ATLAS_PORT_VAULT_RG_NAME = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
    }
    Else {
        $ATLAS_PORT_VAULT_NAME = "kv-atlas-$PORT_NAME-np"
        $ATLAS_PORT_VAULT_RG_NAME = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
    }


    Write-Verbose "ATLAS_PORT_VAULT_NAME: $ATLAS_PORT_VAULT_NAME" -Verbose
    Write-Verbose "ATLAS_PORT_VAULT_RG_NAME: $ATLAS_PORT_VAULT_RG_NAME" -Verbose
    Write-Verbose "ATLAS_PORT_VAULT_SUBSCRIPTION_NAME: $ATLAS_PORT_VAULT_SUBSCRIPTION_NAME" -Verbose
    ############################################################################################################

    if ($environment -eq $CONST_PROD_SUB) {
        $ATLAS_SHARED_VAULT_NAME = $CONST_KV_SHAREDSVCS_P
        $ATLAS_SHARED_VAULT_RG_NAME = $CONST_KV_SHAREDSVCS_RG_P
        $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME = $CONST_KV_SHAREDSVCS_SUB_P
    }
    elseif ($environment -eq $CONST_SANDBOX_SUB) {
        $ATLAS_SHARED_VAULT_NAME = $CONST_KV_SANDBOX_NP
        $ATLAS_SHARED_VAULT_RG_NAME = $CONST_KV_SANDBOX_RG_NP
        $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME = $CONST_KV_SANDBOX_SUB_NP
    }
    else {
        $ATLAS_SHARED_VAULT_NAME = $CONST_KV_SHAREDSVCS_NP
        $ATLAS_SHARED_VAULT_RG_NAME = $CONST_KV_SHAREDSVCS_RG_NP
        $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME = $CONST_KV_SHAREDSVCS_SUB_NP
    }

    Write-Verbose "ATLAS_SHARED_VAULT_NAME: $ATLAS_SHARED_VAULT_NAME" -Verbose
    Write-Verbose "ATLAS_SHARED_VAULT_RG_NAME: $ATLAS_SHARED_VAULT_RG_NAME" -Verbose
    Write-Verbose "ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME: $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME" -Verbose

    $ATLAS_SHARED_VAULT_SUBSCRIPTION_ID = $(Get-Atlas-Subscription -subscription "$ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME" -queryParam "id")
    Write-Verbose "ATLAS_SHARED_VAULT_SUBSCRIPTION_ID: $ATLAS_SHARED_VAULT_SUBSCRIPTION_ID" -Verbose

    ############################################################################################
    #determine whether the Portfolio vault should be used for SSL certificate retrieval
    $USE_PORT_VAULT_SSL = If ($env:USE_PORT_VAULT_SSL) { [System.Convert]::ToBoolean($env:USE_PORT_VAULT_SSL) } Else { $false }
    Write-Verbose "USE_PORT_VAULT_SSL: $USE_PORT_VAULT_SSL" -Verbose

    #We need a way to process portfolio vaulted certs seperately from a shared vault
    If ($USE_PORT_VAULT_SSL) {
        $ATLAS_SSL_VAULT_ID = "/subscriptions/$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID/resourceGroups/$ATLAS_PORT_VAULT_RG_NAME/providers/Microsoft.KeyVault/vaults/$ATLAS_PORT_VAULT_NAME".ToLower()
    }
    else {
        $ATLAS_SSL_VAULT_ID = "/subscriptions/$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID/resourceGroups/$ATLAS_SHARED_VAULT_RG_NAME/providers/Microsoft.KeyVault/vaults/$ATLAS_SHARED_VAULT_NAME".ToLower()
    }
    Write-Verbose "ATLAS_SSL_VAULT_ID: $ATLAS_SSL_VAULT_ID" -Verbose

    ############################################################################################################
    # Setup Service Principal Info For Testing
    ############################################################################################################
    if ($env:AKS_SP_APP_NAME) {
        Write-Warning "The AKS cluster will be deployed using a System Managed Identity,"
        Write-Warning "Input variable AKS_SP_APP_NAME: $env:AKS_SP_APP_NAME is no longer used and can be removed from your pipeline variables."
    }

    ############################################################################################################
    $AKS_SHORT_NAME = "$env:AKS_SHORT_NAME"

    if (!($AKS_SHORT_NAME)) {
        Write-Error -Message "Missing value for variable called 'AKS_SHORT_NAME'" -ErrorAction Stop
    }
    elseif (($AKS_SHORT_NAME.length -gt 15) -or ($AKS_SHORT_NAME.length -lt 3)) {
        Write-Error -Message "'AKS_SHORT_NAME' variable must be at least 3 character or no more that 8 characters in length" -ErrorAction Stop
    }

    Write-Verbose "AKS_SHORT_NAME: $AKS_SHORT_NAME" -Verbose

    # support current ($env:APP_TEAM_AD_GROUPS) and deprecated ($env:APP_TEAM_AD_GROUP) input variables
    if ($env:APP_TEAM_AD_GROUPS) {
        $APP_TEAM_AD_GROUPS = $env:APP_TEAM_AD_GROUPS
    }
    else {
        $APP_TEAM_AD_GROUPS = $env:APP_TEAM_AD_GROUP  #support for the original variable (not plural)
    }

    if (!($APP_TEAM_AD_GROUPS)) {
        Write-Error -Message "Missing value for variable called 'APP_TEAM_AD_GROUPS'. This is required to proceed." -ErrorAction Stop
    }
    # convert to array
    $APP_TEAM_AD_GROUPS = $APP_TEAM_AD_GROUPS.split(",").Trim(" ")
    Write-Verbose "APP_TEAM_AD_GROUPS: $APP_TEAM_AD_GROUPS" -Verbose

    # build array of object id's for each domain group in $APP_TEAM_AD_GROUPS
    $APP_TEAM_AD_GROUP_OBJECT_IDS = @()
    foreach ($adGroup in $APP_TEAM_AD_GROUPS) {
        #BugFix-1221276 -- "More than one groups match name of 'R-Scrumbirds'
        #BugFix-1525959 -- "Case senstive group lookup"
        $matchingGroups = (az ad group list --display-name "$adGroup") | ConvertFrom-Json
        $APP_TEAM_AD_GROUP_OBJECT_ID = ($matchingGroups | Where-Object { $_.displayName.ToLower() -eq $adGroup.ToLower() }).id
        if (!$APP_TEAM_AD_GROUP_OBJECT_ID) {
            throw "Unable to discover objectId for group $adGroup"
        }
        $APP_TEAM_AD_GROUP_OBJECT_IDS += $APP_TEAM_AD_GROUP_OBJECT_ID
    }
    Write-Verbose "APP_TEAM_AD_GROUP_OBJECT_IDS: $APP_TEAM_AD_GROUP_OBJECT_IDS" -Verbose

    ############################################################################################################
    $ORG = $(If ($env:ORG) { "$env:ORG" } Else { $CONST_CMFG })
    Write-Verbose "ORG: $ORG" -Verbose

    $AZENV = $(If ($env:AZENV) { "$env:AZENV" } Else { If ($environment -eq $CONST_PROD_SUB) { "PR1" } Else { "NP1" } })
    Write-Verbose "AZENV: $AZENV" -Verbose

    ############################################################################################################
    $AKS_RG_NAME = $env:AKS_RG_NAME
    Write-Verbose "AKS_RG_NAME: $AKS_RG_NAME" -Verbose

    # added in support of atlas v1 to v2 migration. will discover existing clusters by short name, despite modified naming convention
    Write-Verbose "Debug: AKS_SHORT_NAME: $AKS_SHORT_NAME" -Verbose
    $existingAksName = Get-AllowedAKSNameByResourceGroup -resourceGroupName $AKS_RG_NAME -aksShortName $AKS_SHORT_NAME -AZENV $AZENV
    $AKS_NAME = $(If ($existingAksName) { "$existingAksName" } Else { "AKS-$AZENV-$AKS_SHORT_NAME" })
    $env:AKS_NAME = $AKS_NAME
    Write-Verbose "AKS_NAME: $AKS_NAME" -Verbose

    if ($existingAksName) {
        $Current_AKS_Version_Detail = (Get-AzAksCluster -ResourceGroupName $env:AKS_RG_NAME -Name $ExistingAksName -ErrorAction SilentlyContinue).KubernetesVersion
        Write-Verbose "Current_AKS_Version_Detail: $Current_AKS_Version_Detail" -Verbose
    }
    else {
        Write-Verbose "Debug: Existing AKS Cluster not found in the $($env:AKS_RG_NAME)" -Verbose
        Write-Verbose "Check if the service principal name already exists. " -Verbose
        $agentpoolIdentity = $env:AKS_NAME + "-agentpool"
        $spList = az ad sp list --display-name $agentpoolIdentity | ConvertFrom-Json
        if (![string]::IsNullOrEmpty($($spList.DisplayName))) {
            $errorMessage = "This service principal $agentpoolIdentity already exists in another resource group.Cluster names will need to be unique and it appears this cluster name is already in use.Please provide a different cluster name then rerun the deployment."
            throw $errorMessage
        }
        Write-Verbose "This service principal is $agentpoolIdentity." -Verbose
    }


    if ($existingAksName) {

        $DefaultProfile  = Get-Azcontext 

        $AKS_LOCATION = (Get-AzAksCluster -ResourceGroupName $AKS_RG_NAME -Name $AKS_NAME -DefaultProfile $DefaultProfile -ErrorAction SilentlyContinue).Location
        #$AKS_LOCATION = (az aks show --name $AKS_NAME --resource-group $AKS_RG_NAME |ConvertFrom-Json).Location
    }
    else {
        $AKS_LOCATION = $(If ($env:AKS_LOCATION) { $env:AKS_LOCATION } `
                ElseIf ($env:ATLAS_DEFAULT_LOCATION) { $env:ATLAS_DEFAULT_LOCATION } `
                Else { $DEFAULT_LOCATION })
    }

    Write-Verbose "AKS_LOCATION: $AKS_LOCATION" -Verbose

    $LOCATION_SHORT_NAME_OVERRIDE = $(If ($env:LOCATION_SHORT_NAME_OVERRIDE) { "$env:LOCATION_SHORT_NAME_OVERRIDE" } Else { "" })
    $REGION = $(If ($AKS_LOCATION -eq "eastus2") { "-EA2" } `
            Else { Get-LocationShortName -Location $AKS_LOCATION -LocationShortNameOverride $LOCATION_SHORT_NAME_OVERRIDE })

    Write-Verbose "REGION: $REGION" -Verbose

    if ($("$AKS_RG_NAME" + "$AKS_NAME").Length -gt 68) {
        #error experienced  -- Choose a shorter resource and resource group name. The combined length of the resource
        #and resource group name is 1 characters too long. RG: RG-CMFG-EA2-NP1-Commercial-RockTumbler-AAD-AKS
        Write-Error "Resource group and AKS Name combined is larger than the 68 character limit. Exiting..."  -ErrorAction Stop
    }
    $tempErrorActionPreference = $ErrorActionPreference

    if ($existingAksName) {
        # Get a credential

        try {
            $ErrorActionPreference = "Stop"
            az aks get-credentials -g "$AKS_RG_NAME" -n "$AKS_NAME" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
        }
        catch {
            $currentException = $_
            Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
            if ($($currentException.Exception.Message).Contains("as current context in")) {
                Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
            }
            else {
                Write-Verbose "Exception is unexpected. The script will end now" -Verbose
                throw $currentException.Exception.Message
            }
        }

        $ErrorActionPreference = $tempErrorActionPreference

        if (Test-Path $KUBE_CONFIG_PATH) {
            Write-Verbose "Kubeconfig file exists..." -Verbose
        }
        else {
            Write-Error "Kubeconfig does not exist!"
        }
    }

    # Get the existing system node pool name if exists, if not, set to agentpool
    $multipleNodePool = $false
    if ($existingAksName) {
        $SysPools = (az aks nodepool list --resource-group $AKS_RG_NAME --cluster-name $AKS_NAME | ConvertFrom-Json)  2>$null | Where-Object { $_.mode -eq "system" }
        if (($SysPools | Measure-Object).Count -gt 1) {
            $AKS_SYSTEMPOOL_NAME = Get-AKSActiveSystemNodePoolName
            $multipleNodePool = $true
        }
        else {
            $AKS_SYSTEMPOOL_NAME = $SysPools.name
            $multipleNodePool = $false
        }
    }
    else {
        # force the name of the system pool name to 'agentpool'
        $AKS_SYSTEMPOOL_NAME = "agentpool"
    }
    Write-Verbose "AKS_SYSTEMPOOL_NAME: $AKS_SYSTEMPOOL_NAME" -Verbose

    # check if app insights resource already exists, if so we need to use that location for app insights
    $appInsights = Get-AzApplicationInsights -ResourceGroupName $AKS_RG_NAME -Name $AKS_NAME -ErrorAction SilentlyContinue
    if ($null -ne $appInsights) {
        $AKS_AIS_LOCATION = $appInsights.Location
        Write-Verbose "AppInsights already exists, using existing location for AKS_AIS_LOCATION: $AKS_AIS_LOCATION" -Verbose
    }
    else {
        $AKS_AIS_LOCATION = $(If ($env:AKS_AIS_LOCATION) { "$env:AKS_AIS_LOCATION" } Else { $AKS_LOCATION })
        Write-Verbose "AKS_AIS_LOCATION: $AKS_AIS_LOCATION" -Verbose
    }

    $AKS_AGENT_VM_SIZE = $(If ($env:AKS_AGENT_VM_SIZE) { "$env:AKS_AGENT_VM_SIZE" } Else { If ($environment -eq $CONST_PROD_SUB) { "Standard_D4as_v4" } Else { "Standard_D4as_v4" } })
    Write-Verbose "AKS_AGENT_VM_SIZE: $AKS_AGENT_VM_SIZE" -Verbose

    $AKS_MAX_PODS_INT = $null
    # Max Pods
    [INT]$DEFAULT_MAX_PODS = 250
    # Min Pods
    [INT]$DEFAULT_Min_PODS = 10
    $AKS_MAX_PODS_INT = [int]$env:AKS_MAX_PODS
    if ([string]::IsNullOrEmpty($env:AKS_MAX_PODS)) {
        $AKS_MAX_PODS = "110"
    }
    else {
        if ($AKS_MAX_PODS_INT -lt $DEFAULT_Min_PODS -or $AKS_MAX_PODS_INT -gt $DEFAULT_MAX_PODS) {
            Write-Error -Message "AKS_MAX_PODS value passed in is invalid. The AKS_MAX_PODS value should be between 10 and 250." -ErrorAction Stop
        }
        else {
            $AKS_MAX_PODS = $env:AKS_MAX_PODS
        }
    }
    Write-Verbose "AKS_MAX_PODS: $AKS_MAX_PODS" -Verbose

    # Check if need to upgrade control plane only and not the system node pool
    $AKS_UPGRADE_CONTROL_PLANE_ONLY = $(If ($env:AKS_UPGRADE_CONTROL_PLANE_ONLY) { "$env:AKS_UPGRADE_CONTROL_PLANE_ONLY" } Else { "true" } )
    Write-Verbose "AKS_UPGRADE_CONTROL_PLANE_ONLY: $AKS_UPGRADE_CONTROL_PLANE_ONLY" -Verbose

    # system Node Pool Autoscaling
    $AKS_ENABLE_AUTO_SCALING = $(If ($env:AKS_ENABLE_AUTO_SCALING) { "$env:AKS_ENABLE_AUTO_SCALING" } Else { "false" } )
    Write-Verbose "AKS_ENABLE_AUTO_SCALING: $AKS_ENABLE_AUTO_SCALING" -Verbose
    # If more than one systm node pool found, skip changing the auto scale settings.
    if ($existingAksName) {
        # If more than one systm node pool found, skip changing the auto scale settings.
        if (($SysPools | Measure-Object).Count -gt 1) {
            Write-Verbose "*****************************************************************************************************" -Verbose
            Write-Verbose "More that one System Node Pool found" -Verbose
            Write-Verbose "`t You will need to run the deployAKSNodePool.ps1 to change the system node pool auto scaling options" -Verbose
            Write-Verbose "*****************************************************************************************************" -Verbose
        }
        else {
            $AutoScaleData = Set-AutoScaleParms -Scale $AKS_ENABLE_AUTO_SCALING -Min $env:AKS_AUTO_SCALING_MINCOUNT -Max $env:AKS_AUTO_SCALING_MAXCOUNT
            $AKS_ENABLE_AUTO_SCALING = $AutoScaleData.SCALING
            $AKS_AUTO_SCALING_MINCOUNT = $AutoScaleData.MINCOUNT
            $AKS_AUTO_SCALING_MAXCOUNT = $AutoScaleData.MAXCOUNT
            Write-Verbose "AKS_ENABLE_AUTO_SCALING: $AKS_ENABLE_AUTO_SCALING" -Verbose
            Write-Verbose "AKS_AUTO_SCALING_MAXCOUNT: $AKS_AUTO_SCALING_MAXCOUNT" -Verbose
            Write-Verbose "AKS_AUTO_SCALING_MINCOUNT: $AKS_AUTO_SCALING_MINCOUNT" -Verbose
        }
    }
    else {
        # Set-AutoScaleParms
        $AutoScaleData = Set-AutoScaleParms -Scale $AKS_ENABLE_AUTO_SCALING -Min $env:AKS_AUTO_SCALING_MINCOUNT -Max $env:AKS_AUTO_SCALING_MAXCOUNT
        $AKS_ENABLE_AUTO_SCALING = $AutoScaleData.SCALING
        $AKS_AUTO_SCALING_MINCOUNT = $AutoScaleData.MINCOUNT
        $AKS_AUTO_SCALING_MAXCOUNT = $AutoScaleData.MAXCOUNT
        Write-Verbose "AKS_ENABLE_AUTO_SCALING: $AKS_ENABLE_AUTO_SCALING" -Verbose
        Write-Verbose "AKS_AUTO_SCALING_MAXCOUNT: $AKS_AUTO_SCALING_MAXCOUNT" -Verbose
        Write-Verbose "AKS_AUTO_SCALING_MINCOUNT: $AKS_AUTO_SCALING_MINCOUNT" -Verbose
    }

    if ($existingAksName) {
        [array]$existingNodePoolList = (az aks nodepool list --cluster-name $AKS_NAME --resource-group $AKS_RG_NAME | ConvertFrom-Json) | Where-Object { $_.name -eq $AKS_SYSTEMPOOL_NAME }
        Write-Verbose "AKS_SYSTEMPOOL_NAME: $AKS_SYSTEMPOOL_NAME already exists" -Verbose
        #check if current max pods is same as input max pods.
        Write-Verbose "AKS_SYSTEMPOOL_NAME: $AKS_SYSTEMPOOL_NAME currently has AKS_MAX_PODS: $($existingNodePoolList.maxPods) " -Verbose
        if ($AKS_MAX_PODS -ne $($existingNodePoolList.maxPods)) {
            Write-Error -Message "Node Pool $AKS_SYSTEMPOOL_NAME cannot be deployed with the input AKS_MAX_PODS: $AKS_MAX_PODS, currently has: $($existingNodePoolList.maxPods) max pods" -ErrorAction  Stop
        }
        #checking current agent count
        $existingAksAgentCount = $($existingNodePoolList).count
        $existingAutoScalingSetting = if ([string]::IsNullOrEmpty($($existingNodePoolList.enableAutoScaling))) { $false } Else { $($existingNodePoolList.enableAutoScaling) }
        $existingAutoScalingMaxCount = if ([string]::IsNullOrEmpty($($existingNodePoolList.maxCount))) { "null" } Else { $($existingNodePoolList.maxCount) }
        $existingAutoScalingMinCount = if ([string]::IsNullOrEmpty($($existingNodePoolList.minCount))) { "null" } Else { $($existingNodePoolList.minCount) }
        Write-Warning -Message "Existing AKS_SYSTEMPOOL_NAME: $AKS_SYSTEMPOOL_NAME currently has AKS_AGENT_COUNT: $existingAksAgentCount" -Verbose
        $AKS_AGENT_COUNT = $(If ($env:AKS_AGENT_COUNT) { "$env:AKS_AGENT_COUNT" } Else { $existingAksAgentCount })
        Write-Verbose -Message "AKS_AGENT_COUNT set to current node count: $existingAksAgentCount" -Verbose
    }
    else {
        if ($AKS_ENABLE_AUTO_SCALING) {
            $AKS_AGENT_COUNT = $(If ($env:AKS_AGENT_COUNT) { "$env:AKS_AGENT_COUNT" } Else { $AKS_AUTO_SCALING_MINCOUNT })
        }
        else {
            $AKS_AGENT_COUNT = $(If ($env:AKS_AGENT_COUNT) { "$env:AKS_AGENT_COUNT" } Else { If ($environment -eq $CONST_PROD_SUB) { "3" } Else { "1" } })
        }
    }
    Write-Verbose "AKS_AGENT_COUNT: $AKS_AGENT_COUNT" -Verbose

    $AKS_DISK_SIZE_GB = $(If ($env:AKS_DISK_SIZE_GB) { "$env:AKS_DISK_SIZE_GB" } Else { "512" })
    Write-Verbose "AKS_DISK_SIZE_GB: $AKS_DISK_SIZE_GB" -Verbose

    #Set the AKS cluster version for AKS cluster deployment
    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $env:AKS_KUBERNETES_VERSION -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_LOCATION
    $Aks_Version_Changing = $false
    if ($existingAksName) {
        if ($AKS_KUBERNETES_VERSION -ne $Current_AKS_Version_Detail) {
            $Aks_Version_Changing = $true
        }
    }
    Write-Verbose "AKS_KUBERNETES_VERSION: $AKS_KUBERNETES_VERSION" -Verbose
    ###########################################################################################################
    #TODO: Remove code for AKS versions lower than supported
    # Setting Nginx image to the new version from AKS 1.22 and higher
    if ([version]$AKS_KUBERNETES_VERSION -ge [version]1.22) {
        $NGINX_INGRESS_CONTROLLER_IMAGE_VERSION = "acrcmfgmaster.azurecr.io/cuna/nginx-ingress-controller:1.5.1"
    }
    else {
        $NGINX_INGRESS_CONTROLLER_IMAGE_VERSION = "acrcmfgmaster.azurecr.io/cuna/nginx-ingress-controller:0.33.0"
    }
    Write-Verbose "NGINX_INGRESS_CONTROLLER_IMAGE_VERSION: $NGINX_INGRESS_CONTROLLER_IMAGE_VERSION" -Verbose

    ############################################################################################################
    #need this for local testing
    $AKS_SSL_CERT_IDENTIFIER = if ($env:AKS_SSL_CERT_IDENTIFIER) { "$env:AKS_SSL_CERT_IDENTIFIER" } else { "wildcard-atlasbeta-cunamutual" }

    Write-Verbose "Determine AKS cert keyvault secret names" -Verbose

    $AKS_SSL_CERT_NAME = $AKS_SSL_CERT_IDENTIFIER + '-cert'
    $AKS_SSL_CERT_PWD_SECRET_NAME = $AKS_SSL_CERT_IDENTIFIER + '-cert-password'
    $AKS_SSL_CERT_SECRET_NAME = $AKS_SSL_CERT_IDENTIFIER + '-cert-secret'

    #Write-Verbose "AKS_AUTH_CERT_SECRET_NAME: $AKS_AUTH_CERT_SECRET_NAME" -Verbose
    Write-Verbose "AKS_SSL_CERT_NAME: $AKS_SSL_CERT_NAME" -Verbose
    Write-Verbose "AKS_SSL_CERT_PWD_SECRET_NAME: $AKS_SSL_CERT_PWD_SECRET_NAME" -Verbose
    Write-Verbose "AKS_SSL_CERT_SECRET_NAME: $AKS_SSL_CERT_SECRET_NAME" -Verbose

    ############################################################################################################
    #Creating a variable to use in AGWAFv2 deployment Json file.
    #This is the value that will be used for host in resources, probe and httpsbackend.
    #We need to gather the CN name in the cert.
    #to do change the vault name to $ATLAS_PORT_VAULT_NAME
    $CertSubjects = (az keyvault certificate show --vault-name $ATLAS_PORT_VAULT_NAME --name $AKS_SSL_CERT_NAME | ConvertFrom-Json).policy.x509CertificateProperties.subject.split(",").trim()
    foreach ($CertSubject in $CertSubjects) { if ($CertSubject.contains("CN=")) { $CertCN = $CertSubject } }
    #replacing the * with the word wildcard, so that the host value can be used in backendHttpSttings of AGWaf
    #TODO Not sure why we have two of these "$AKS_HOST_IDENTIFIER = "
    $AKS_HOST_IDENTIFIER = $CertCN.Replace("*", "wildcard").Split("=")[1]
    $AKS_HOST_IDENTIFIER = (az keyvault certificate show --vault-name $ATLAS_PORT_VAULT_NAME --name $AKS_SSL_CERT_NAME | ConvertFrom-Json).policy.x509CertificateProperties.subject.Split(",")[0].Replace("*", "wildcard").Split("=")[1]
    Write-Verbose "The host value  AKS_HOST_IDENTIFIER : $AKS_HOST_IDENTIFIER" -Verbose

    ############################################################################################################
    # get the OMS resource group name and Log Analytics environment
    Write-Verbose "Determine Log Analytics resource group name" -Verbose
    If ($env:OMS_WORKSPACE_RG_NAME -and $env:OMS_WORKSPACE_NAME) {
        $OMS_WORKSPACE_RG_NAME = "$env:OMS_WORKSPACE_RG_NAME"
        $OMS_WORKSPACE_NAME = "$env:OMS_WORKSPACE_NAME"
    }
    Else {
        $OMS_WORKSPACE_NAME = $SubscriptionProperties.omsWorkspace
        $OMS_WORKSPACE_RG_NAME = (Get-AzResource -Name $OMS_WORKSPACE_NAME -ResourceType "Microsoft.OperationalInsights/workspaces").ResourceGroupName
    }

    Write-Verbose "OMS_WORKSPACE_RG_NAME: $OMS_WORKSPACE_RG_NAME" -Verbose
    Write-Verbose "OMS_WORKSPACE_NAME: $OMS_WORKSPACE_NAME" -Verbose

    $NSG_RG_NAME = $AKS_RG_NAME
    Write-Verbose "NSG_RG_NAME: $NSG_RG_NAME" -Verbose

    $NSG_LOCATION = $AKS_LOCATION
    Write-Verbose "NSG_LOCATION: $NSG_LOCATION" -Verbose

    $NSG_PRIVATE_NAME = "NSG-$ORG$REGION-$AZENV-$AKS_SHORT_NAME-Private"
    Write-Verbose "NSG_PRIVATE_NAME: $NSG_PRIVATE_NAME" -Verbose

    $NSG_PUBLIC_NAME = "NSG-$ORG$REGION-$AZENV-$AKS_SHORT_NAME-Public"
    Write-Verbose "NSG_PUBLIC_NAME: $NSG_PUBLIC_NAME" -Verbose

    $ALLOW_DLX_APIM_INGRESS = $(If ($env:ALLOW_DLX_APIM_INGRESS) { [System.Convert]::ToBoolean($env:ALLOW_DLX_APIM_INGRESS) } Else { $false })
    Write-Verbose "ALLOW_DLX_APIM_INGRESS: $ALLOW_DLX_APIM_INGRESS" -Verbose

    $VNET_LOCATION = $AKS_LOCATION
    Write-Verbose "VNET_LOCATION: $VNET_LOCATION" -Verbose

    $VNET_RG_NAME = $AKS_RG_NAME
    Write-Verbose "VNET_RG_NAME: $VNET_RG_NAME" -Verbose

    $VNET_NAME = "VNet-$ORG$REGION-$AZENV-$AKS_SHORT_NAME"
    Write-Verbose "VNET_NAME: $VNET_NAME" -Verbose

    $VNET_ADDRESS_PREFIX = $(If ($env:VNET_ADDRESS_PREFIX) { "$env:VNET_ADDRESS_PREFIX" } Else { "10.0.0.0/16" })
    Write-Verbose "VNET_ADDRESS_PREFIX: $VNET_ADDRESS_PREFIX" -Verbose

    $SUBNET_PRIVATE_NAME = "$AKS_SHORT_NAME-private-subnet".ToLower()
    Write-Verbose "SUBNET_PRIVATE_NAME: $SUBNET_PRIVATE_NAME" -Verbose

    $SUBNET_PRIVATE_ADDRESS_PREFIX = $(If ($env:SUBNET_PRIVATE_ADDRESS_PREFIX) { "$env:SUBNET_PRIVATE_ADDRESS_PREFIX" } Else { "10.0.1.0/24" })
    Write-Verbose "SUBNET_PRIVATE_ADDRESS_PREFIX: $SUBNET_PRIVATE_ADDRESS_PREFIX" -Verbose

    $SUBNET_PUBLIC_NAME = "$AKS_SHORT_NAME-public-subnet".ToLower()
    Write-Verbose "SUBNET_PUBLIC_NAME: $SUBNET_PUBLIC_NAME" -Verbose

    $SUBNET_PUBLIC_ADDRESS_PREFIX = $(If ($env:SUBNET_PUBLIC_ADDRESS_PREFIX) { "$env:SUBNET_PUBLIC_ADDRESS_PREFIX" } Else { "10.0.0.0/24" })
    Write-Verbose "SUBNET_PUBLIC_ADDRESS_PREFIX: $SUBNET_PUBLIC_ADDRESS_PREFIX" -Verbose

    $AG_WAF_NAME = "AGWAF-$ORG$REGION-$AZENV-$AKS_SHORT_NAME"
    Write-Verbose "AG_WAF_NAME: $AG_WAF_NAME" -Verbose

    $AG_WAF_RG_NAME = $AKS_RG_NAME
    Write-Verbose "AG_WAF_RG_NAME: $AG_WAF_RG_NAME" -Verbose

    $AG_WAF_LOCATION = $AKS_LOCATION
    Write-Verbose "AG_WAF_LOCATION: $AG_WAF_LOCATION" -Verbose

    # set agwaf min/max per environment variables
    $AG_WAF_MIN_CAPACITY = $(If ($env:AG_WAF_MIN_CAPACITY) { "$env:AG_WAF_MIN_CAPACITY" } Else { "0" })
    $AG_WAF_MAX_CAPACITY = $(If ($env:AG_WAF_MAX_CAPACITY) { "$env:AG_WAF_MAX_CAPACITY" } Else { "20" }) # Azure default is 20, matching that.
    if ($existingAksName -and ($null -eq $env:AG_WAF_MIN_CAPACITY) -and ($null -eq $env:AG_WAF_MAX_CAPACITY)) {
        # cluster exists and user hasn't specified agwaf min/max autoscale config, check if agwaf autoscale is configured
        $appGw = Get-AzApplicationGateway -Name $AG_WAF_NAME -ResourceGroupName $AG_WAF_RG_NAME
        if ($null -eq $appGw.AutoscaleConfiguration) {
            # appgw autoscale is not configured, we'll enable autoscale and set min and max
            Write-Verbose "AGWAF autoscale will be enabled using default values for min and max" -Verbose
            $AG_WAF_MIN_CAPACITY = $appGw.sku.Capacity
            $AG_WAF_MAX_CAPACITY = "20" # Azure default is 20, matching that.
        }
        else {
            # agwaf exists and already has autoscale enabled. use existing values since min/max environment variables weren't provided
            Write-Verbose "AGWAF autoscale is already enabled, using existing min and max values" -Verbose
            $AG_WAF_MIN_CAPACITY = $appGw.AutoscaleConfiguration.MinCapacity
            $AG_WAF_MAX_CAPACITY = $appGw.AutoscaleConfiguration.MaxCapacity
        }
    }
    Write-Verbose "AG_WAF_MIN_CAPACITY: $AG_WAF_MIN_CAPACITY" -Verbose
    Write-Verbose "AG_WAF_MAX_CAPACITY: $AG_WAF_MAX_CAPACITY" -Verbose

    $AG_WAF_ENABLE_HTTP2 = "true"
    Write-Verbose "AG_WAF_ENABLE_HTTP2: $AG_WAF_ENABLE_HTTP2" -Verbose

    $AG_WAF_IDLE_TIMEOUT = $(If ($env:AG_WAF_IDLE_TIMEOUT) { "$env:AG_WAF_IDLE_TIMEOUT" } Else { "4" })
    Write-Verbose "AG_WAF_IDLE_TIMEOUT: $AG_WAF_IDLE_TIMEOUT" -Verbose

    $AG_WAF_HTTPS_TIMEOUT = $(If ($env:AG_WAF_HTTPS_TIMEOUT -gt 900) { Write-Error "HTTPS Timeout cannot be set over 15 minutes" } elseif (-not ([string]::IsNullOrEmpty($env:AG_WAF_HTTPS_TIMEOUT)) -and $env:AG_WAF_HTTPS_TIMEOUT -le 900) { "$env:AG_WAF_HTTPS_TIMEOUT" } Else { "20" })
    Write-Verbose "AG_WAF_HTTPS_TIMEOUT: $AG_WAF_HTTPS_TIMEOUT" -Verbose

    try {
        # Try to get an existing domain name label. This may not exist so trap the error and continue
        # Updated the following to search for the AGWAF PIP, now that we have two (NAT) in the secure cloud cluster
        $PIPName = (Get-AzResource -ResourceGroupName $AKS_RG_Name -ResourceType "Microsoft.Network/publicIPAddresses").Name | Where-Object { $_ -match "AGWAF-CMFG" }
        $DNSLabel = ((Get-AzPublicIpAddress -ResourceGroupName $AKS_RG_NAME -Name $PIPName).DnsSettings.DomainNameLabel)

        if ($DNSLabel) {
            # The AG WAF domain name label exists so get the index of the last dash character and remove all characters after that.
            # This is required due to a bug introduced with the region agnostic region names which had a dash in the region abbreviation
            $index = $DNSLabel.lastIndexOf("-")
            $DNSLabel_Modified = $DNSLabel.substring(0, $index)
            $AG_WAF_DOMAIN_NAME_LABEL = $DNSLabel_Modified
        }
    }
    catch {
        # Continue since an existing domain name label was not found so it will be created.
        Write-Verbose "Existing DNS Domain Label Not Found...creating new label" -Verbose
    }

    # DNSLabel was not set so this is new. Create it using the dash format
    if (!$DNSLabel) {
        $New_Region = $REGION.Replace("-", "")
        $AG_WAF_DOMAIN_NAME_LABEL_TEMP = "acg" + "$ORG" + "$New_Region" + "$AZENV" + "$AKS_SHORT_NAME"
        $AG_WAF_DOMAIN_NAME_LABEL = "$AG_WAF_DOMAIN_NAME_LABEL_TEMP".ToLower()
    }

    Write-Verbose "AG_WAF_DOMAIN_NAME_LABEL: $AG_WAF_DOMAIN_NAME_LABEL" -Verbose

    $AG_WAF_BACKEND_IP_ADDRESS = $(If ($env:AG_WAF_BACKEND_IP_ADDRESS) { "$env:AG_WAF_BACKEND_IP_ADDRESS" } Else { "10.0.1.254" })
    Write-Verbose "AG_WAF_BACKEND_IP_ADDRESS: $AG_WAF_BACKEND_IP_ADDRESS" -Verbose

    $AG_WAF_ENABLE_REQUEST_BODY_CHECK = $(If ($env:AG_WAF_ENABLE_REQUEST_BODY_CHECK) { [System.Convert]::ToBoolean($env:AG_WAF_ENABLE_REQUEST_BODY_CHECK) } Else { $true })
    Write-Verbose "AG_WAF_ENABLE_REQUEST_BODY_CHECK: $AG_WAF_ENABLE_REQUEST_BODY_CHECK" -Verbose

    # model definition for disabled rule groups: https://docs.microsoft.com/en-us/rest/api/application-gateway/applicationgateways/createorupdate#applicationgatewayfirewalldisabledrulegroup
    $AG_WAF_DISABLED_RULE_GROUPS = $(If ($env:AG_WAF_DISABLED_RULE_GROUPS) { $env:AG_WAF_DISABLED_RULE_GROUPS } Else { $null })
    Write-Verbose "AG_WAF_DISABLED_RULE_GROUPS: $AG_WAF_DISABLED_RULE_GROUPS" -Verbose

    #TODO!! Add some validation on the input json to save people the time iterating their typos

    $AG_WAF_CLEAR_DISABLED_RULE_GROUPS = $(If ($env:AG_WAF_CLEAR_DISABLED_RULE_GROUPS) { [System.Convert]::ToBoolean($env:AG_WAF_CLEAR_DISABLED_RULE_GROUPS) } Else { $false })
    Write-Verbose "AG_WAF_CLEAR_DISABLED_RULE_GROUPS: $AG_WAF_CLEAR_DISABLED_RULE_GROUPS" -Verbose

    $INGRESS_CONTROLLER_NAMESPACE = "ingress-nginx"
    Write-Verbose "INGRESS_CONTROLLER_NAMESPACE: $INGRESS_CONTROLLER_NAMESPACE" -Verbose

    $TITAN_PROD_MASTER_ACR_RG_NAME = "RG-CMFG-NC1-P01-Master-ACR"
    Write-Verbose "TITAN_PROD_MASTER_ACR_RG_NAME: $TITAN_PROD_MASTER_ACR_RG_NAME" -Verbose

    $TITAN_PROD_MASTER_ACR_NAME = "acrcmfgmaster"
    Write-Verbose "TITAN_PROD_MASTER_ACR_NAME: $TITAN_PROD_MASTER_ACR_NAME" -Verbose

    $TITAN_PROD_SUBSCRIPTION_ID = "94f0eebc-4d31-4d69-bc92-dfc97103744a"
    Write-Verbose "TITAN_PROD_SUBSCRIPTION_ID: $TITAN_PROD_SUBSCRIPTION_ID" -Verbose

    $ERROR_FILE = "$ATLAS_REPO_ROOT/errors.log"
    Write-Verbose "Log File: $ERROR_FILE" -Verbose

    #attempt to de-dupe executions
    $AKS_ENVIRONMENT_SETUP_COMPLETE = $true
}
