$ErrorActionPreference = "Stop"

. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1") 4> $null

#**********************************************************
# Deploy the Deny All App Network Policy
#**********************************************************

try {
    Write-Verbose "Deploying App Network Policy - Deny All Traffic Into Default Namespace" -Verbose

    # Get K8s manifest file path
    $NETWORK_POLICY_DENY_ALL_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/AksClusterNetworkPolicies/create-default-namespace-network-policies.yaml"
    Write-Verbose "NETWORK_POLICY_DENY_ALL_FILE: $NETWORK_POLICY_DENY_ALL_FILE" -Verbose

    # Show the the manifest file contents
    Write-Verbose "Contents of $NETWORK_POLICY_DENY_ALL_FILE :" -Verbose
    Write-Verbose (Get-Content -Path $NETWORK_POLICY_DENY_ALL_FILE | Out-String) -Verbose

    kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $NETWORK_POLICY_DENY_ALL_FILE

    Write-Verbose "Successfully Deployed App Network Policy - Deny All Traffic Into Default Namespace" -Verbose
}
catch {
    $ERROR_MESSAGE = $_.Exception.Message
    Write-Verbose "Error while deploying App Network Policy - Deny All Traffic Into Default Namespace: " -Verbose
    Write-Error -Message "ERROR: $ERROR_MESSAGE" -ErrorAction Stop
}