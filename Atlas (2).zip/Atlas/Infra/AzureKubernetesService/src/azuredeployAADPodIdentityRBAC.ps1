#**********************************************************
# Deploy the AAD Pod Identity Service to AKS Cluster
#**********************************************************

# first half is cleanup whatever is already there (intended for atlas v1 to v2 upgrade)
$tempErrorActionPref = $ErrorActionPreference
$ErrorActionPreference = "SilentlyContinue"
$v1Found = $false
try {

    $checkNmiSvcAcct = kubectl get serviceaccount aad-pod-id-nmi-service-account --kubeconfig "$KUBE_CONFIG_PATH" 2>$null
    if ($checkNmiSvcAcct) {
        kubectl delete serviceaccount aad-pod-id-nmi-service-account --kubeconfig "$KUBE_CONFIG_PATH"
        $v1Found = $true
    }

    $checkNmi = kubectl get ds nmi --kubeconfig "$KUBE_CONFIG_PATH" 2>$null
    if ($checkNmi) {
        kubectl delete ds nmi --kubeconfig "$KUBE_CONFIG_PATH"
        $v1Found = $true
    }

    $checkMicSvcAcct = kubectl get serviceaccount aad-pod-id-mic-service-account --kubeconfig "$KUBE_CONFIG_PATH" 2>$null
    if ($checkMicSvcAcct) {
        kubectl delete serviceaccount aad-pod-id-mic-service-account --kubeconfig "$KUBE_CONFIG_PATH"
        $v1Found = $true
    }

    $checkDeployment = kubectl get deployment mic --kubeconfig "$KUBE_CONFIG_PATH" 2>$null
    if ($checkDeployment) {
        kubectl delete deployment mic --kubeconfig "$KUBE_CONFIG_PATH"
        $v1Found = $true
    }

    if ($v1Found) {
        Write-Verbose "Attempt to cleanup atlas v1 AAD POD Identity is complete, we will deploy atlas v2 AAD POD Identity" -verbose
    }

}
catch {
    $ERROR_MESSAGE = $_.Exception.Message
    Write-Verbose "Error while deploying AAD Pod Identity Service to AKS Cluster: " -Verbose
    Write-Error -Message "ERROR: $ERROR_MESSAGE" -ErrorAction Stop
}
finally {
    $ErrorActionPreference = $tempErrorActionPref
}


try {
    Write-Verbose "Deploying AAD Pod Identity Service to AKS Cluster" -Verbose

    $AKS_PODIDENTITY_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/config/aad-pod-identity-rbac.yaml")
    Write-Verbose "AKS_PODIDENTITY_FILE: $AKS_PODIDENTITY_FILE" -Verbose

    kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f "$AKS_PODIDENTITY_FILE"
    Write-Verbose "Successfully Deployed AAD Pod Identity Service to AKS Cluster" -Verbose

    Write-Verbose "Deploying AAD Pod Identity Exception to AKS Cluster" -Verbose

    $AKS_PODIDENTITY_EXCEPTION_FILE = ("$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/config/aad-pod-identity-exception-rbac.yaml")
    Write-Verbose "AKS_PODIDENTITY_EXCEPTION_FILE: $AKS_PODIDENTITY_EXCEPTION_FILE" -Verbose

    kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f "$AKS_PODIDENTITY_EXCEPTION_FILE"
    Write-Verbose "Successfully Deployed AAD Pod Identity Exception to AKS Cluster" -Verbose

}
catch {
    $ERROR_MESSAGE = $_.Exception.Message
    Write-Verbose "Error while deploying AAD Pod Identity Service to AKS Cluster: " -Verbose
    Write-Error -Message "ERROR: $ERROR_MESSAGE" -ErrorAction Stop
}

<#
Output should look like the following:

VERBOSE: AKS_DEPLOY_APP_FILE: C:\data\TitanRepos\SCE-SampleWebAadPodIdentity\SampleWebAadPodIdentity\Kubernetes\aad-pod-identity-rbac.yaml
serviceaccount "aad-pod-id-nmi-service-account" created
customresourcedefinition.apiextensions.k8s.io "azureassignedidentities.aadpodidentity.k8s.io" created
customresourcedefinition.apiextensions.k8s.io "azureidentitybindings.aadpodidentity.k8s.io" created
customresourcedefinition.apiextensions.k8s.io "azureidentities.aadpodidentity.k8s.io" created
clusterrole.rbac.authorization.k8s.io "aad-pod-id-nmi-role" created
clusterrolebinding.rbac.authorization.k8s.io "aad-pod-id-nmi-binding" created
daemonset.extensions "nmi" created
serviceaccount "aad-pod-id-mic-service-account" created
clusterrole.rbac.authorization.k8s.io "aad-pod-id-mic-role" created
clusterrolebinding.rbac.authorization.k8s.io "aad-pod-id-mic-binding" created
deployment.extensions "mic" created
VERBOSE: Successfully Deployed AAD Pod Identity Service to AKS Cluster
#>