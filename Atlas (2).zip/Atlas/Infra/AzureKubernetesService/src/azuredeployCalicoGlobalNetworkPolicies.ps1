########################################################
# This script needs to be deployed to AKS clusters which
# to set up the cluster Calico Global Network Policies
########################################################

Write-Verbose "Deploying Calico Global Network Policies" -Verbose

$NETWORK_POLICIES_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/AksClusterGlobalNetworkPolicies/create-calico-global-network-policies.yaml"
Write-Verbose "NETWORK_POLICIES_FILE: $NETWORK_POLICIES_FILE" -Verbose

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f "$NETWORK_POLICIES_FILE"

Write-Verbose "Successfully Deployed Calico Global Network Policies Configuration" -Verbose