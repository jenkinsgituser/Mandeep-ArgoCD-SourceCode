# https://8gwifi.org/docs/kube-dash.jsp

Write-Verbose "Deploying Kube Dashboard Fix for RBAC Enabled AKS Cluster" -Verbose

$KUBE_DASH_RBAC_FIX_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/config/dashboard-admin.yaml"
Write-Verbose "KUBE_DASH_RBAC_FIX_FILE: $KUBE_DASH_RBAC_FIX_FILE" -Verbose

kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $KUBE_DASH_RBAC_FIX_FILE

Write-Verbose "Successfully Deployed Kube Dashboard Fix for RBAC Enabled AKS Cluster" -Verbose
