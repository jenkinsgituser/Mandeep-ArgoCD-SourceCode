
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
. ("$env:INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1") 4> $null

Write-Verbose "Deploying Private NSG: $NSG_PRIVATE_NAME" -Verbose
$NSG_PRIVATE_TEMPLATE_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksNetwork/azuredeployPrivateNSG.json"
Write-Verbose "NSG_PRIVATE_TEMPLATE_FILE: $NSG_PRIVATE_TEMPLATE_FILE" -Verbose

$DEPLOYMENT_NAME = "azuredeployPrivateNSG-$(Get-Date -f yyyyMMddHHmmss)"

$Action = {
    az deployment group create `
        -g "$NSG_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$NSG_PRIVATE_TEMPLATE_FILE" `
        --parameters "nsgName=$NSG_PRIVATE_NAME" `
        "nsgLocation=$NSG_LOCATION" `
        "createdDate=$CREATED_DATE" `
        "TemplateVersion=$TEMPLATE_VERSION"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Private NSG: $NSG_PRIVATE_NAME" -Verbose
