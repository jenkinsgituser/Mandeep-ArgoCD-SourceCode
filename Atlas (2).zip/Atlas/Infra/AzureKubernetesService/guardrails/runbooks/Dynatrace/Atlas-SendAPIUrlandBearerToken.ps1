####################################################################################
# Send the API url and bearer token to David,Gallay if any new dyntrace get created.
# so He can add AKS cluster to dynatrace.
# Note: This email is temporary. It can stop once the automation process is setup.
####################################################################################

param
(
  [Parameter(Mandatory = $true)]
  [string]  $AKS_RG_NAME,
  [Parameter(Mandatory = $true)]
  [string] $AKS_NAME,
  [Parameter(Mandatory = $true)]
  [string]  $kubernetsAPIUrl,
  [Parameter(Mandatory = $true)]
  [string]  $kubernetsBearerToken
)

$VerbosePreference = "SilentlyContinue"

if ($env:IsLocal -or $env:AGENT_ID) {
  Write-Verbose -Verbose "Running in a local or build context!"
  . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1
}
else {
  #sourcing on the AA is slightly different than sourcing locally
  . ./Atlas-CommonCode.ps1
}

try {
  # do the import in the silenced block
  Import-Module Az.Automation -Force | Out-Null
  Import-Module Az.Resources -Force | Out-Null
  Import-Module Az.KeyVault -Force | Out-Null
}
catch {
  Write-AtlasOutput -LogLevel "WARN" -Message "Error importing required modules. $($_.Exception.Message)"
}

Azure-Connect
$runbookDetail = Get-RunbookCurrentContext
$VerbosePreference = "Continue"
$emailTo = @("David.Gallay@cunamutual.com", "TeamTitan@cunamutual.com")
$emailSubject = "Atlas Info - please add AKS cluster to Dynatrace"
$emailFrom = "TitanAtlasInstall@cunamutual.com"
$emailBody = " Here are the Kubernetes API URL and bearer token for the new dynatrace in $($AKS_NAME) cluster of $($AKS_RG_NAME): `r `r"
$emailBody += " Kubernetes API URL: $kubernetsAPIUrl `r `r"
$emailBody += " Bearer Token: $kubernetsBearerToken `r `r"
$emailBody += "`r `r `r Executed from $($runbookDetail.AutomationAccountName), Runbook is $($runbookDetail.RunbookName)."
$EmailbodyData = $emailBody | Out-String
try {
  Send-TeamTitanEmailAlert -emailFrom $emailFrom -emailTo $emailTo -emailSubject $emailSubject -EmailbodyData $EmailbodyData -ErrorAction stop
  Write-AtlasOutput -LogLevel "INFO" -Message "Email has been sent"
}
catch {
  $errorMessage = "ERROR: Failed to send email."
  throw $errorMessage
}
Write-AtlasOutput -LogLevel "INFO" -Message "Runbook complete"