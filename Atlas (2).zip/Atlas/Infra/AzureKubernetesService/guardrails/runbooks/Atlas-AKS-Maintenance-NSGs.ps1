param
(
    [Parameter (Mandatory = $false)]
    [PsObject] $WebhookData,
    [Parameter (Mandatory = $false)]
    [string] $TargetSubscription = [string]::Empty,
    [Parameter (Mandatory = $false)]
    [string] $TargetAtlasAksRG = [string]::Empty
)

$CONST_ATLAS_TEST_BUILD_Sandbox_T = "RG-CMFG-T01-Atlas-Test"

function New-AtlasNSGRulesObj {
    New-Object PSObject -Property @{
        Name                                 = $null
        Description                          = $null
        SourceAddressPrefixCount             = $null
        SourceAddressPrefixValue             = $null
        SourceApplicationSecurityGroups      = $null
        SourcePortRange                      = $null
        DestinationPortRangeCount            = $null
        DestinationPortRangeValue            = $null
        DestinationAddressPrefixCount        = $null
        DestinationAddressPrefixValue        = $null
        DestinationApplicationSecurityGroup  = $null
        DestinationApplicationSecurityGroups = $null
        Access                               = $null
        Priority                             = $null
        Protocol                             = $null
        Direction                            = $null
        Optional                             = $false
    }
}

function Is-NsgAtlas {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$nsgResourceName,
        [parameter(Mandatory = $true)][PsObject]$DefaultProfile
    )

    $nsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $resourceGroup -Name $NsgResourceName -DefaultProfile $DefaultProfile
    $NsgIsAtlas = $false

    if ($nsgResource `
            -and $nsgResource.Tag `
            -and (($nsgResource.Tag.templateVersion -match $CONST_ATLAS_TAG_IDENTIFIER) `
                -or ($nsgResource.Tag.TemplateVersion -match $CONST_ATLAS_TAG_IDENTIFIER))) {

        if ($nsgResource.Tag.templateVersion -and $nsgResource.Tag.templateVersion -notmatch "Titan-Atlas-v[\d]-Atlantis") {
            $NsgIsAtlas = $true
        }
        else {
            if ($nsgResource.Tag.TemplateVersion -and $nsgResource.Tag.TemplateVersion -notmatch "Titan-Atlas-v[\d]-Atlantis") {
                $NsgIsAtlas = $true
            }
        }
    }
    return $NsgIsAtlas

}


#################################################################
# Validate an input NSG resource against an expected NSG rule
#################################################################
function Validate-NsgResourceAgainstExpectedRule {
    param
    (
        [Parameter(Mandatory = $true)][PsObject]$NsgResource,
        [parameter(Mandatory = $true)][PsObject]$ExpectedRule
    )

    [bool]  $isValidRule = $false

    # Declare the following variables as boolean and initialize them to false to avoid issues
    # with the contains logic below.  Testing has revealed not declaring a variable type used in an equal
    # statement can result in the variable being populated with other values than $true or $false.

    [bool]  $isValidPrefixValue = $false
    [bool]  $isValidSourceappSecurityGroups = $false
    [bool]  $isValidSourcePortRangeValue = $false
    [bool]  $isValidDestPortRangeCount = $false
    [bool]  $isValidDestPortRangeValue = $false
    [bool]  $isValidDestAddressPrefixCount = $false
    [bool]  $isValidDestAddressPrefixValue = $false
    [bool]  $isValidDestAppSecurityGroup = $false
    [bool]  $isValidAccess = $false
    [bool]  $isValidPriority = $false
    [bool]  $isValidDirection = $false
    [bool]  $isValidProtocol = $false
    [bool]  $isValidDescription = $false

    # Check that the expected rule is present in the Nsg
    $isValidName = ($NsgResource.SecurityRules.Name -Contains $($ExpectedRule.Name))

    # Get the specific Nsg rule and compare it to the expected rule of the same name

    if ($isValidName) {
        foreach ($ruleToCheck in $nsgresource.securityrules) {
            if ($ruleToCheck.name -match $ExpectedRule.Name) {
                Write-AtlasOutput -LogLevel "INFO" -Message "Validating NSG rule - $($ruleToCheck.Name)...."
                $isValidPrefixCount = ($ruleToCheck.SourceAddressPrefix.Count -eq $ExpectedRule.SourceAddressPrefixCount)

                $is_ObjectEqual = Compare-Object -ReferenceObject $ruleToCheck.SourceAddressPrefix -DifferenceObject $ExpectedRule.SourceAddressPrefixValue -PassThru

                if (!$is_ObjectEqual) {
                    # The value of is_ObjectEqual is $null so there are no differences found.
                    $isValidPrefixValue = $true
                }
                else {
                    # The value of is_ObjectEqual is not $null so there was a difference found.
                    $isValidPrefixValue = $false
                }

                $isValidDescription = ($ruleToCheck.Description -eq $ExpectedRule.Description)
                $isValidSourceAppSecurityGroups = ($ruleToCheck.SourceApplicationSecurityGroups.count -eq $ExpectedRule.SourceApplicationSecurityGroups.count)
                $isValidSourcePortRangeValue = ($ruleToCheck.SourcePortRange[0] -eq $ExpectedRule.SourcePortRange)
                $isValidDestPortRangeCount = ($ruleToCheck.DestinationPortRange.Count -eq $ExpectedRule.DestinationPortRangeCount)
                $isValidDestPortRangeValue = ($ruleToCheck.DestinationPortRange[0] -eq $ExpectedRule.DestinationPortRangeValue)
                $isValidDestAddressPrefixCount = ($ruleToCheck.DestinationAddressPrefix.Count -eq $ExpectedRule.DestinationAddressPrefixCount)
                $isValidDestAddressPrefixValue = ($ruleToCheck.DestinationAddressPrefix[0] -eq $ExpectedRule.DestinationAddressPrefixValue)
                $isValidDestAppSecurityGroup = ($ruleToCheck.DestinationApplicationSecurityGroups.Count -eq $ExpectedRule.DestinationApplicationSecurityGroups.Count)
                $isValidAccess = ($ruleToCheck.Access -eq $ExpectedRule.Access)
                $isValidPriority = ($ruleToCheck.Priority -eq $ExpectedRule.Priority)
                $isValidDirection = ($ruleToCheck.Direction -eq $ExpectedRule.Direction)
                $isValidProtocol = ($ruleToCheck.Protocol -eq $ExpectedRule.Protocol)

                $vals = @($isValidPrefixCount, `
                        $isValidPrefixValue, `
                        $isValidDescription, `
                        $isValidSourceappSecurityGroups, `
                        $isValidSourcePortRangeValue, `
                        $isValidDestPortRangeCount, `
                        $isValidDestPortRangeValue, `
                        $isValidDestAddressPrefixCount, `
                        $isValidDestAddressPrefixValue, `
                        $isValidDestAppSecurityGroup, `
                        $isValidAccess, `
                        $isValidPriority, `
                        $isValidDirection, `
                        $isValidProtocol)

                if ($vals -notcontains $false) {
                    # All rules passed so set to true
                    $isValidRule = $true

                }
            }
        }
    }
    else {
        # Expected rule was not found in NSG so if it is optional we must flag it as valid so it doesn't get added
        if ($ExpectedRule.Optional -eq $true) {
            $isValidRule = $true
        }

    }
    return $isValidRule
}

function Build-ErrorMessage {
    param
    (
        [parameter(Mandatory = $true)][PsObject] $NsgResource,
        [parameter(Mandatory = $true)][PsObject] $FailedRules,
        [parameter(Mandatory = $true)][PsObject] $DesiredAction
    )


    $message = [string]::Empty
    foreach ($failedRule in $FailedRules) {
        if ($NsgResource.ResourceGroupName -notmatch $CONST_ATLAS_TEST_BUILD_Sandbox_T) {
            $message += "`nRule $failedRule failed validation for NSG $($NsgResource.Name) in resource group $($NsgResource.ResourceGroupName)"

            if ($DesiredAction -eq "Enforce") {
                $message += "`nAction to enforce the invalid rules has been performed. If you encounter adverse network impacts, please open an appropriate priority Cherwell incident."
            }
        }
    }
    return $message
}


#################################################################
# Pull the contact info off the resource group and notify the
# appropriate authorities of the transgression
#################################################################
function Inform-ResourceGroupContacts {
    param
    (
        [parameter(Mandatory = $true)][PsObject] $ResourceGroupName,
        [parameter(Mandatory = $true)][PsObject] $DefaultProfile,
        [parameter(Mandatory = $true)][string] $Message,
        [parameter(Mandatory = $false)][string] $emailTo = "TeamTitan@cunamutual.com"
    )

    # write some code that notifies us and the people tagged on the resource group
    # that action was taken (or needs to be taken/will be taken)

    # Check if we are running locally. If so, determine the username from USERNAME environment variable and email
    # the local user directly rather than spamming the entire team.
    if ($env:IsLocal) {
        $emailTo = $env:USERNAME + "@cmutual.com"
    }

    $emailFrom = "Atlas-AKS-Maintenance-NSGs@teamtitan.com"
    $emailSubject = "Atlas AKS NSG Rule Validation Failure"

    $emailBody = "Atlas AKS NSG Rule violation. : `r `r"
    $emailBody += "$Message `r `r"
    $emailBody += "InfraMgmt-Az Automation Account, Runbook is Atlas-AKS-Maintenance-NSGs"
    $EmailbodyData = $emailBody | Out-String

    Write-AtlasOutput -LogLevel "INFO" -Message "Sending email to Resource Group contacts"
    if (!$env:IsLocal) {
        Send-TeamTitanEmailAlert -emailTo $emailTo -emailFrom $emailFrom -emailSubject $emailSubject -EmailbodyData $EmailbodyData
    }


    Write-AtlasOutput -LogLevel "INFO" -Message "Email has been sent"
    Write-AtlasOutput -LogLevel "INFO" -Message "`r `r"
}

#################################################################
# Returns Public, Private, Unidentified
#################################################################
function Get-AtlasNsgType {
    param
    (
        [Parameter(Mandatory = $true)][PsObject] $NsgResource,
        [parameter(Mandatory = $true)][PsObject] $DefaultProfile
    )
    $nsgType = "Unidentified"

    if ($NsgResource.Name.ToLower() -match "-public") {
        $nsgType = "Public"
    }
    elseif ($NsgResource.Name.ToLower() -match "-private") {
        $nsgType = "Private"
    }
    else {
        throw "Input NSG did not match either 'Public' or 'Private' type!"
    }

    return $nsgType
}


#######################################################################
# Attempts to update the NSG rule and throw errors to calling function
#######################################################################
function Set-NSGRule {
    param
    (
        [Parameter(Mandatory = $true)][PsObject] $NsgResource,
        [Parameter(Mandatory = $true)][PsObject] $ExpectedRule
    )

    # To do - Add logic for handling trying to create a rule that already has the same Priority and Direction
    # The error Rules cannot have the same Priority and Direction.
    # Try to set the values of the NSG Rule to desired state.  Catch error and rethrow to caller.
    try {
        Set-AzNetworkSecurityRuleConfig -Name $ExpectedRule.Name `
            -NetworkSecurityGroup $NsgResource `
            -SourceAddressPrefix $ExpectedRule.SourceAddressPrefixValue `
            -SourcePortRange $ExpectedRule.SourcePortRange `
            -SourceApplicationSecurityGroup $ExpectedRule.SourceApplicationSecurityGroups `
            -DestinationPortRange $ExpectedRule.DestinationPortRangeValue `
            -DestinationAddressPrefix $ExpectedRule.DestinationAddressPrefixValue `
            -DestinationApplicationSecurityGroup $ExpectedRule.DestinationApplicationSecurityGroups `
            -Priority $ExpectedRule.Priority `
            -Protocol $ExpectedRule.Protocol `
            -Access $ExpectedRule.Access `
            -Direction $ExpectedRule.Direction `
            -Description $ExpectedRule.Description
        $NsgResource | Set-AzNetworkSecurityGroup

    }
    catch {
        # We encountered an error trying to set the NSG rule so catch and rethrow to calling function to report
        Throw
    }
}
#######################################################################
# Attempts to update the NSG rule and throw errors to calling function
#######################################################################
function Add-NSGRule {
    param
    (
        [Parameter(Mandatory = $true)][PsObject] $NsgResource,
        [Parameter(Mandatory = $true)][PsObject] $ExpectedRule
    )

    # Try to set the values of the NSG Rule to desired state.  Catch error and rethrow to caller.
    try {
        Add-AzNetworkSecurityRuleConfig -Name $rule.Name `
            -NetworkSecurityGroup $NsgResource `
            -SourceAddressPrefix $rule.SourceAddressPrefixValue `
            -SourcePortRange $rule.SourcePortRange `
            -SourceApplicationSecurityGroup $rule.SourceApplicationSecurityGroups `
            -DestinationPortRange $rule.DestinationPortRangeValue `
            -DestinationAddressPrefix $rule.DestinationAddressPrefixValue `
            -DestinationApplicationSecurityGroup $rule.DestinationApplicationSecurityGroups `
            -Access $rule.Access `
            -Priority $rule.Priority `
            -Protocol $rule.Protocol `
            -Direction $rule.Direction `
            -Description $rule.Description
        $NsgResource | Set-AzNetworkSecurityGroup

    }
    catch {
        # We encountered an error trying to add the NSG rule so catch and rethrow to calling function to report
        Throw
    }
}

function Do-ProcessAtlasPrivateNsg {
    param
    (
        [parameter(Mandatory = $true)][PsObject] $NsgResource,
        [parameter(Mandatory = $false)][string] $DesiredAction = "Audit",
        [parameter(Mandatory = $true)][PsObject] $DefaultProfile
    )

    Write-AtlasOutput -LogLevel "INFO" -Message "Loading Atlas private NSG rules into collection...."
    # Load the expected Private NSG rule set into a collection.  Focusing on inbound rules to start simply to maximize value
    # versus the security risk

    #To do - Move the object declaration into a function
    $AtlasPrivateNSGRulesColl = New-Object System.Collections.ArrayList

    $AtlasPrivateNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPrivateNSGRulesObj.Name = "Intra_vNet_Inbound_Udp"
    $AtlasPrivateNSGRulesObj.Description = "Resources within vnet can communicate inbound using Udp"
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixValue = "VirtualNetwork"
    $AtlasPrivateNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.SourcePortRange = "*"
    $AtlasPrivateNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPrivateNSGRulesObj.DestinationPortRangeValue = "*"
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixValue = "VirtualNetwork"
    $AtlasPrivateNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.Access = "Allow"
    $AtlasPrivateNSGRulesObj.Priority = 3970
    $AtlasPrivateNSGRulesObj.Protocol = "Udp"
    $AtlasPrivateNSGRulesObj.Direction = "Inbound"
    $AtlasPrivateNSGRulesColl.Add($AtlasPrivateNSGRulesObj) | Out-Null

    $AtlasPrivateNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPrivateNSGRulesObj.Name = "Intra_vNet_Inbound_Tcp"
    $AtlasPrivateNSGRulesObj.Description = "Resources within vnet can communicate inbound using Tcp"
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixValue = "VirtualNetwork"
    $AtlasPrivateNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.SourcePortRange = "*"
    $AtlasPrivateNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPrivateNSGRulesObj.DestinationPortRangeValue = "*"
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixValue = "VirtualNetwork"
    $AtlasPrivateNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.Access = "Allow"
    $AtlasPrivateNSGRulesObj.Priority = 3980
    $AtlasPrivateNSGRulesObj.Protocol = "Tcp"
    $AtlasPrivateNSGRulesObj.Direction = "Inbound"
    $AtlasPrivateNSGRulesColl.Add($AtlasPrivateNSGRulesObj) | Out-Null

    $AtlasPrivateNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPrivateNSGRulesObj.Name = "AllowAzureLB"
    $AtlasPrivateNSGRulesObj.Description = "Permits load balancing above the deny-all rule."
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixValue = "AzureLoadBalancer"
    $AtlasPrivateNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.SourcePortRange = "*"
    $AtlasPrivateNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPrivateNSGRulesObj.DestinationPortRangeValue = "*"
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPrivateNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.Access = "Allow"
    $AtlasPrivateNSGRulesObj.Priority = 3990
    $AtlasPrivateNSGRulesObj.Protocol = "*"
    $AtlasPrivateNSGRulesObj.Direction = "Inbound"
    $AtlasPrivateNSGRulesColl.Add($AtlasPrivateNSGRulesObj) | Out-Null

    $AtlasPrivateNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPrivateNSGRulesObj.Name = "DenyAllRuleInbound"
    $AtlasPrivateNSGRulesObj.Description = "Deny-all above permissive default rules - necessary traffic must be permitted above"
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.SourceAddressPrefixValue = "*"
    $AtlasPrivateNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.SourcePortRange = "*"
    $AtlasPrivateNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPrivateNSGRulesObj.DestinationPortRangeValue = "*"
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPrivateNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPrivateNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPrivateNSGRulesObj.Access = "Deny"
    $AtlasPrivateNSGRulesObj.Priority = 4000
    $AtlasPrivateNSGRulesObj.Protocol = "*"
    $AtlasPrivateNSGRulesObj.Direction = "Inbound"
    $AtlasPrivateNSGRulesColl.Add($AtlasPrivateNSGRulesObj) | Out-Null

    Write-AtlasOutput -LogLevel "INFO" -Message "Completed loading Atlas Private NSG rules into collection."

    Write-AtlasOutput -LogLevel "INFO" -Message "Validating NSG is bound to Private subnet...."
    # Check if bound to the private-subnet and only to the private-subnet
    $actionRequired = $false
    $failedRules = @()

    $subnetRuleName = "Attached Subnet Check - NSG is Attached to Private-Subnet"
    if ($null -eq $NsgResource.Subnets `
            -or $NsgResource.Subnets.Count -ne 1 `
            -or $NsgResource.Subnets.Id -notmatch "-private-subnet") {
        Write-AtlasOutput -LogLevel "WARN" -Message "--- RULE FAILED--- NSG $($NsgResource.name) is NOT bound to Private subnet"

        # Only require action if the subnet deployment exists and was successful (trying to avoid notices for intial deployments where NSG is created before subnets)
        if ((DoesSubnetDeploymentExist -NsgResource $NsgResource -DeploymentName "azuredeployPrivateSubnet" -DefaultProfile $DefaultProfile)) {
            $actionRequired = $true
        }

        $failedRules += $subnetRuleName
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "Confirmed NSG is bound to Private subnet"
    }

    # smartly track the rules that are invalid so that when we need to enforce
    # the rule update, we can do so in a targeted manner below
    #######################################################################################

    foreach ($rule in $AtlasPrivateNSGRulesColl) {

        # Expect true if the rule is good, false if invalid
        $resultIsValid = Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $rule
        if (!$resultIsValid) {
            Write-AtlasOutput -LogLevel "WARN" -Message "--- RULE FAILED--- Rule $($rule.Name) failed validation for NSG $($NsgResource.Name)"
            $actionRequired = $true
            $failedRules += $rule.Name
            # Check DesiredAction value and process Enforce or Audit actions.
            if ($DesiredAction -eq "Enforce") {
                # reset bad rules
                Write-AtlasOutput -LogLevel "WARN" -Message "--- ENFORCEMENT ACTION ENABLED --- The following rules will be enforced: $($rule.Name)"

                Write-AtlasOutput -LogLevel "INFO" -Message "Enforcing rule $($rule.Name)"

                $ruleIsFound = $false
                foreach ($existingRule in $NsgResource.SecurityRules) {
                    if ($existingRule.Name -match $rule.Name) {
                        $ruleIsFound = $true
                        try {
                            Set-NSGRule -NsgResource $NsgResource -ExpectedRule $rule
                            Write-AtlasOutput -LogLevel "INFO" -Message "Desired state rule applied to $($rule.Name)."
                        }
                        catch {
                            $Message = "Update failed for $($rule.Name). $($_.Exception.Message)"
                            Write-AtlasOutput -LogLevel "WARN" -Message "$($Message)."
                        }
                    }
                }
                if (!$ruleIsFound) {
                    try {
                        Add-NSGRule -NsgResource $NsgResource -ExpectedRule $rule
                        Write-AtlasOutput -LogLevel "INFO" -Message "Desired state rule added for $($rule.Name)."
                    }
                    catch {
                        $Message = "Add failed for $($rule.Name). $($_.Exception.Message)"
                        Write-AtlasOutput -LogLevel "WARN" -Message "$($Message)."
                    }
                }

            }
            else {
                # AUDIT CASE
                Write-AtlasOutput -LogLevel "WARN" -Message "Auditing rule $($rule.Name) failed validation for NSG $($NsgResource.Name) in resource group $($NsgResource.ResourceGroupName)"
            }
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "Rule $($rule.Name) passed validation for NSG $($NsgResource.Name)"
        }
    }
    if ($actionRequired) {
        $message = Build-ErrorMessage -NsgResource $NsgResource -FailedRules $failedRules -DesiredAction $DesiredAction
        Write-AtlasOutput -LogLevel "WARN" -Message "Informing contacts of failed rules..."

        if (!$env:IsLocal) {
            Inform-ResourceGroupContacts `
                -ResourceGroupName $NsgResource.ResourceGroupName `
                -DefaultProfile $DefaultProfile `
                -Message $message `
                -emailto "TeamTitan@cunamutual.com"
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message $message
        }
    }
}
function Do-ProcessAtlasPublicNsg {
    param
    (
        [parameter(Mandatory = $true)][PsObject] $NsgResource,
        [parameter(Mandatory = $false)][string] $DesiredAction = "Audit",
        [parameter(Mandatory = $true)][PsObject] $DefaultProfile
    )

    # Loading the expected public NSG rule set into a collection. Focusing on inbound rules to start simply to maximize value
    # versus the security risk

    Write-AtlasOutput -LogLevel "INFO" -Message "Loading Atlas public NSG rules into collection"
    # To do - Move the object load into its own function.
    $AtlasPublicNSGRulesColl = New-Object System.Collections.ArrayList

    # DLX API Management Rules
    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "DLX_API_Management_Prod_443"
    $AtlasPublicNSGRulesObj.Description = "Connect from known Prod DLX APIM IP Addresses"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 3
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('20.190.242.89/32', '40.65.226.7/32', '104.208.242.166/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 102
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesObj.Optional = $true
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "DLX_API_Management_NonProd_443"
    $AtlasPublicNSGRulesObj.Description = "Connect from known NonProd DLX APIM IP Addresses"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 4
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('20.186.37.25/32', '52.167.238.193/32', '52.167.159.89/32', '20.75.98.153/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 103
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesObj.Optional = $true
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    # CMFG Public IP Rules
    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "CMFG_Internal_Servers_Madison_443"
    $AtlasPublicNSGRulesObj.Description = "Connection from CMFG internal servers in Madison"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('208.91.239.30/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = "1"
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 115
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Madison_User_Network_443"
    $AtlasPublicNSGRulesObj.Description = "Connection from Madison CMFG VDIs"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 2
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('208.91.239.10/32', '208.91.239.11/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 116
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "CMFG_Internal_Servers_Ashburn_443"
    $AtlasPublicNSGRulesObj.Description = "Connection from CMFG internal servers in Ashburn"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('208.91.237.190/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 117
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Ashburn_User_Network_443"
    $AtlasPublicNSGRulesObj.Description = "Connection from Ashburn CMFG VDIs"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 2
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('208.91.237.161/32', '208.91.237.162/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 118
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    # Azure APIC 2018 Rules
    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Cloud_APIC_2018_NonProd_443"
    $AtlasPublicNSGRulesObj.Description = "Connect from known NonProd APIC 2018 IP Addresses"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 7
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('52.162.245.1/32', '52.173.255.48/32', '168.61.220.200/32', '52.173.246.220/32', '23.100.79.154/32', '157.55.160.165/32', '40.79.22.44/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 150
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Cloud_APIC_2018_Prod_443"
    $AtlasPublicNSGRulesObj.Description = "Connect from known Prod APIC 2018 IP Addresses"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 6
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('65.52.56.146/32', '40.78.153.75/32', '157.55.141.125/32', '40.122.145.129/32', '40.75.97.37/32', '52.177.124.194/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 160
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null
    # Azure APIM Rules
    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Cloud_API_Manager_NonProd"
    $AtlasPublicNSGRulesObj.Description = "Connect from known Azure API Manager"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 2
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('20.10.12.58/32', '20.69.247.37/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 170
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Cloud_API_Manager_Prod"
    $AtlasPublicNSGRulesObj.Description = "Connect from known Azure API Manager"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 2
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('20.14.169.227/32', '20.230.78.63/32')
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 180
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    # Application Insights Availability Monitor Rule
    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Allow_AppGateway_Internal"
    $AtlasPublicNSGRulesObj.Description = "Allowing Microsoft internal App Gateway communications"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "65200-65535"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 2000
    $AtlasPublicNSGRulesObj.Protocol = "*"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    # Traffic Manager Rule
    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Allow_Traffic_Manager"
    $AtlasPublicNSGRulesObj.Description = "Traffic Manager allowed via Service Tag over TCP only"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "AzureTrafficManager"
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 2010
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesObj.Optional = $true
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    # Application Insights Availability Monitor Rule
    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Allow_AppInsights_Availability"
    $AtlasPublicNSGRulesObj.Description = "App Insights Availability allowed via Service Tag over TCP only"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "ApplicationInsightsAvailability"
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = @('443')
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 2020
    $AtlasPublicNSGRulesObj.Protocol = "Tcp"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesObj.Optional = $true
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "Intra_Subnet_Inbound"
    $AtlasPublicNSGRulesObj.Description = "Resources within subnet can communicate freely"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "VirtualNetwork"
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "*"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "VirtualNetwork"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 3980
    $AtlasPublicNSGRulesObj.Protocol = "*"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "AllowAzureLB"
    $AtlasPublicNSGRulesObj.Description = "Permits load balancing above the deny-all rule"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "AzureLoadBalancer"
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "*"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Allow"
    $AtlasPublicNSGRulesObj.Priority = 3990
    $AtlasPublicNSGRulesObj.Protocol = "*"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
    $AtlasPublicNSGRulesObj.Name = "DenyAllRuleInbound"
    $AtlasPublicNSGRulesObj.Description = "Deny-all above permissive default rules - necessary traffic must be permitted above"
    $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.SourcePortRange = "*"
    $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
    $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "*"
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
    $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
    $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
    $AtlasPublicNSGRulesObj.Access = "Deny"
    $AtlasPublicNSGRulesObj.Priority = 4000
    $AtlasPublicNSGRulesObj.Protocol = "*"
    $AtlasPublicNSGRulesObj.Direction = "Inbound"
    $AtlasPublicNSGRulesColl.Add($AtlasPublicNSGRulesObj) | Out-Null

    # Check if bound to the public-subnet and only the public-subnet
    Write-AtlasOutput -LogLevel "INFO" -Message "Validating NSG is bound to Public subnet...."

    # Initialize flags
    $actionRequired = $false
    $failedRules = @()

    $subnetRuleName = "Attached Subnet Check - Nsg is Attached to Public subnet"
    if ($null -eq $NsgResource.Subnets `
            -or $NsgResource.Subnets.Count -ne 1 `
            -or $NsgResource.Subnets.Id -notmatch "-public-subnet") {
        Write-AtlasOutput -LogLevel "WARN" -Message "--- RULE FAILED --- Confirmed NSG $($NsgResource.Name) is not bound to Public subnet"

        # Only require action if the subnet deployment exists and was successful (trying to avoid notices for intial deployments where NSG is created before subnets)
        if ((DoesSubnetDeploymentExist -NsgResource $NsgResource -DeploymentName "azuredeployPublicSubnet" -DefaultProfile $DefaultProfile)) {
            $actionRequired = $true
        }

        $failedRules += $subnetRuleName
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "Confirmed NSG is bound to to Public subnet"
    }

    # smartly track the rules that are invalid so that when we need to enforce
    # the rule update, we can do so in a targeted manner below
    #######################################################################################

    foreach ($rule in $AtlasPublicNSGRulesColl) {

        # Expect true if the rule is good, false if invalid
        $resultIsValid = Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $rule
        if (!$resultIsValid) {
            Write-AtlasOutput -LogLevel "WARN" -Message "--- RULE FAILED --- Rule $($rule.Name) failed validation for Nsg $($NsgResource.Name)"
            $actionRequired = $true
            $failedRules += $rule.Name

            if ($DesiredAction -eq "Enforce") {
                # reset bad rules
                Write-AtlasOutput -LogLevel "WARN" -Message "--- ENFORCEMENT ACTION ENABLED--- The following rules will be enforced: $failedRules"

                Write-AtlasOutput -LogLevel "INFO" -Message "Enforcing rule $($rule.Name)"

                #Set the nsgresource to the value of the expected rule and apply
                $ruleIsFound = $false
                foreach ($existingRule in $NsgResource.SecurityRules) {
                    if ($existingRule.Name -match $rule.Name) {
                        $ruleIsFound = $true
                        try {
                            Set-NSGRule -NsgResource $NsgResource -ExpectedRule $rule
                            Write-AtlasOutput -LogLevel "INFO" -Message "Desired state rule applied to $($rule.Name)."
                        }
                        catch {
                            $Message = "Update failed for $($rule.Name). $($_.Exception.Message)"
                            Write-AtlasOutput -LogLevel "WARN" -Message "$($Message)."
                        }
                    }
                }
                if (!$ruleIsFound) {
                    try {
                        Add-NSGRule -NsgResource $NsgResource -ExpectedRule $rule
                        Write-AtlasOutput -LogLevel "INFO" -Message "Desired state rule added for $($rule.Name)."
                    }
                    catch {
                        $Message = "Add failed for $($rule.Name). $($_.Exception.Message)"
                        Write-AtlasOutput -LogLevel "WARN" -Message "$($Message)."
                    }
                }
            }
            else {
                # AUDIT CASE
                Write-AtlasOutput -LogLevel "WARN" -Message "Rule $($rule.Name) failed validation for NSG $($NsgResource.Name) in resource group $($NsgResource.ResourceGroupName)"
            }
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "Rule $($rule.Name) passed validation for NSG $($NsgResource.Name)"
        }
    }

    if ($actionRequired) {
        $message = Build-ErrorMessage -NsgResource $NsgResource -FailedRules $failedRules -DesiredAction $DesiredAction
        Write-AtlasOutput -LogLevel "WARN" -Message "Informing contacts of failed rules..."

        # Bypass email since we are running locally
        if (!$env:IsLocal) {
            Inform-ResourceGroupContacts `
                -ResourceGroupName $NsgResource.ResourceGroupName `
                -DefaultProfile $DefaultProfile `
                -Message $message `
                -emailto "TeamTitan@cunamutual.com"
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message $message
        }
    }
}
function DoesRGStillExist {
    param
    (
        [Parameter(Mandatory = $true)][string] $resourcegroup,
        [parameter(Mandatory = $true)][PsObject] $DefaultProfile
    )

    $rgStillExists = $true
    try {
        $rgStillExists = Get-AzResourceGroup -Name $resourcegroup -DefaultProfile $DefaultProfile
    }
    catch {
        $rgStillExists = $false
    }
    return $rgStillExists
}

#################################################################
# Figure out if we have work to do, and perform the appropriate
# type of work if we do have work
#################################################################
function Do-ProcessAksNsgResource {
    param
    (
        [Parameter(Mandatory = $true)][string] $TargetAtlasAksRG,
        [Parameter(Mandatory = $true)][string] $TargetNsgResource,
        [parameter(Mandatory = $true)][PsObject] $DefaultProfile
    )
    #check if rg is atlas, if not atlas skip

    $doesRGStillExist = DoesRGStillExist -resourcegroup $TargetAtlasAksRG -DefaultProfile $DefaultProfile
    if ($doesRGStillExist) {
        $isAtlasResourceGroup = Is-RGAtlas-Runbook -resourceGroup $TargetAtlasAksRG -Context $DefaultProfile
        if ($isAtlasResourceGroup) {
            # NSGs that aren't explicitly tagged Atlas have the potential to whack
            # something else if a shared RG is tagged Atlas. So we're going to handle this case too...
            # Just audit Atlas 1.0 do not process(enforce)

            $isAtlasNsg = Is-NsgAtlas -resourceGroup $TargetAtlasAksRG -nsgResourceName $TargetNsgResource -DefaultProfile $DefaultProfile

            # Check if NSG is tagged with an Atlas tag
            if ($isAtlasNsg) {

                Write-AtlasOutput -LogLevel "INFO" -Message "Confirmed Atlas tagged resource group and network security group. Processing..."

                $nsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $TargetAtlasAksRG -Name $TargetNsgResource -DefaultProfile $DefaultProfile
                # Determine if NSG is Public or Private
                $nsgType = Get-AtlasNsgType -NsgResource $nsgResource -DefaultProfile $DefaultProfile

                if ($nsgType -eq "Public") {

                    Write-AtlasOutput -LogLevel "INFO" -Message "Processing Public NSG Resource..."
                    Do-ProcessAtlasPublicNsg -NsgResource $NsgResource -DefaultProfile $DefaultProfile -DesiredAction "Audit"

                }
                elseif ($nsgType -eq "Private") {

                    Write-AtlasOutput -LogLevel "INFO" -Message "Processing Private NSG Resource..."
                    Do-ProcessAtlasPrivateNsg -NsgResource $nsgResource -DefaultProfile $DefaultProfile -DesiredAction "Audit"

                }
                else {
                    throw "$($TargetNsgResource) has an unidentified type and is tagged Atlas. Validation cannot be performed!"
                }
            }
            else {
                Write-AtlasOutput -LogLevel "WARN" -Message "NSG exists in Atlas tagged resource group but is not tagged Atlas itself. Avoiding rule reset..."
            }
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "$($TargetNsgResource) is not an Atlas resource, skipping...."
        }
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "$($TargetNsgResource) no longer exists, skipping...."
    }
}

function DoesSubnetDeploymentExist {
    param
    (
        [parameter(Mandatory = $true)][PsObject] $NsgResource,
        [parameter(Mandatory = $true)][PsObject] $DeploymentName,
        [parameter(Mandatory = $true)][PsObject] $DefaultProfile
    )

    # If the subnet is not found to be attached, check whether subnet deployments occurred before requiring enforcement
    $rgDeployments = Get-AzResourceGroupDeployment -ResourceGroupName $($NsgResource.ResourceGroupName) -DefaultProfile $DefaultProfile
    foreach ($deployment in $rgDeployments) {
        if ($deployment.DeploymentName -like $DeploymentName -and $deployment.ProvisioningState -eq "Succeeded") {
            Write-AtlasOutput -LogLevel "WARN" -Message "$DeploymentName deployment $($deployment.DeploymentName) was found, requiring further action"
            return $true
        }
    }
    Write-AtlasOutput -LogLevel "WARN" -Message "$DeploymentName deployment not found, not requiring further action"
    return $false
}
#-----------------------------------------------------------------------------------------------------
#MAIN
#-----------------------------------------------------------------------------------------------------

# wrapping to enable dot sourcing and unit testing of above functions
if (!$env:IsTest) {

    $CONST_RUNBOOK_NAME = "Atlas-AKS-Maintenance-NSGs"
    $CONST_ATLAS_TAG_IDENTIFIER = "Titan-Atlas"

    $VerbosePreference = "SilentlyContinue"
    try {
        # do the import in the silenced block
        Import-Module Az.Accounts | Out-Null
        Import-Module Az.Automation | Out-Null
        Import-Module Az.Network | Out-Null
        Import-Module Az.Resources | Out-Null
    }
    catch {
        Write-Warning "Error importing required modules. $($_.Exception.Message)"
    }
    $VerbosePreference = "Continue"

    Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
    if ($env:IsLocal -or $env:AGENT_ID) {
        Write-Verbose -Verbose "Running in a local or build context!"
        . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1
    }
    else {
        #sourcing on the AA is slightly different than sourcing locally
        . ./Atlas-CommonCode.ps1
        Azure-Connect
        Write-Verbose "Azure-Connect complete." -Verbose
    }

    $ErrorActionPreference = "Stop"


    if ($WebhookData) {
        # If we are running locally WebhookData will be a string so convert to object before processing
        if ($env:IsLocal) {
            $WebhookData = $WebhookData | ConvertFrom-Json
            $WebhookBody = ConvertFrom-Json -InputObject $WebhookData.RequestBody
        }
        else {
            $WebhookBody = ConvertFrom-Json -InputObject $WebhookData.RequestBody
        }

        $subscriptionId = $WebhookBody.subject.Split("/")[2]

        # if we have webhook data, the following vari$ables will be overwritten if also passed in
        $TargetSubscription = (Get-AzSubscription -SubscriptionId $subscriptionId).Name
        $TargetAtlasAksRG = $WebhookBody.subject.Split("/")[4]
        $TargetNsgResource = $WebhookBody.subject.Split("/")[8]

        Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $TargetSubscription"
        $DefaultProfile = Set-AzContext -Subscription $TargetSubscription

        # check the appId that resulted in the alert firing.  If it was our runbook runas account, don't call the runbook again.
        # if the alert that called this runbook was generated via a change from the web logging runbook, we don't need/want to call the runbook again.
        $callerAppId = $WebhookBody.data.claims.appid
        if (((Check-CallerIsTrustedAtlasIdentity -callerAppId $callerAppId) -eq $false) `
                -and $null -ne $WebhookBody.subject) {
            Write-AtlasOutput -LogLevel "INFO" -Message "Processing $($TargetNsgResource) : $TargetSubscription"
            Do-ProcessAksNsgResource -TargetAtlasAksRG $TargetAtlasAksRG -TargetNsgResource $TargetNsgResource -DefaultProfile $DefaultProfile
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "This alert was generated via a change from trusted source $callerAppId, so no action taken."
            Write-AtlasOutput -LogLevel "INFO" -Message "  TargetSubscription:  $TargetSubscription"
            Write-AtlasOutput -LogLevel "INFO" -Message "  TargetAtlasAksRG:  $TargetAtlasAksRG"
            Write-AtlasOutput -LogLevel "INFO" -Message "  TargetNsgResource:  $TargetNsgResource"
        }

    }
    elseif ($TargetSubscription -and $TargetAtlasAksRG) {
        # this case exists for manual triggering of the runbook
        Write-AtlasOutput -LogLevel "INFO" -Message "TargetSubscription:  $TargetSubscription"
        Write-AtlasOutput -LogLevel "INFO" -Message "TargetAtlasAksRG:  $TargetAtlasAksRG"
        $subFound = Get-AzSubscription | Where-Object { $_.name -eq $TargetSubscription }
        $DefaultProfile = Set-AzContext -Subscription $TargetSubscription

        if ($subFound) {
            Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $TargetSubscription"
            $discoveredNsgs = Get-AzNetworkSecurityGroup -ResourceGroupName $TargetAtlasAksRG
            foreach ($nsg in $discoveredNsgs) {
                Write-AtlasOutput -LogLevel "INFO" -Message "Processing $($nsg.name) in resource group $($TargetAtlasAksRG)"
                Do-ProcessAksNsgResource -TargetAtlasAksRG $TargetAtlasAksRG -TargetNsgResource $nsg.name -DefaultProfile $DefaultProfile
            }
            if (!$discoveredNsgs) {
                Write-AtlasOutput -LogLevel "WARN" -Message "Invalid TargetAtlasAksRG: $TargetAtlasAksRG TargetNsgResource: $TargetNsgResource"
            }
        }
        else {
            Write-AtlasOutput -LogLevel "WARN" -Message "Invalid TargetSubscription: $TargetSubscription"
        }
    }
    else {
        Write-AtlasOutput -LogLevel "ERROR" -Message "No valid inputs provided for processing."
    }

    Write-AtlasOutput -LogLevel "INFO" -Message "Job Complete"
}