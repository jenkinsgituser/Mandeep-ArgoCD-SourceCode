######################################################################
# This script is deployed to an AKS cluster as part of AKS Build
# validation to ensure apps deploy and function as expected
######################################################################

Write-Verbose "Deploying WebAPI Test App" -Verbose

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")


# AKS Environment Setup
#****************************************************
. ("$INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
. ("$INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1")
$AKS_ENVIRONMENT_SETUP_COMPLETE = $false
. ("$INFRA_FOLDER/AzureKubernetesService/src/NodePools/aksNodePoolVariables.ps1")

$DEPLOYMENT_FILE = "$env:INFRA_FOLDER/AzureKubernetesService/test-functional/CalicoFunctionalTests/DeployWebAPI.yaml"

Write-Verbose "DEPLOYMENT_FILE: $DEPLOYMENT_FILE" -Verbose

$DEPLOYMENT_FILE_OUTPUT = $DEPLOYMENT_FILE
if ($env:IsLocal) {
    $DEPLOYMENT_FILE_OUTPUT = $DEPLOYMENT_FILE_OUTPUT.Replace(".yaml", ".mine.yaml")
}

# Do an in-place token replace

(Get-Content $DEPLOYMENT_FILE) -replace '__AtlasEnvironment__', "$environment" -replace '__AKSNODEPOOLNAME__', "$AKS_NODE_POOL_NAME" | Set-Content $DEPLOYMENT_FILE_OUTPUT
# kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f "$DEPLOYMENT_FILE_OUTPUT"
kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f "$DEPLOYMENT_FILE_OUTPUT" 2>$null
Write-Verbose "Deploying WebAPI Test App" -Verbose