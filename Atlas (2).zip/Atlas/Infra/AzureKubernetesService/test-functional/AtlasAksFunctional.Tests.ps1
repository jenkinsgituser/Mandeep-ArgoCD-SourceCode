param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "Atlas AKS Functional Tests" {
    BeforeAll {
        # source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")

        $CONST_NSG_EXCEPTION = "EXCEPTION-Temp-Testing-Inbound-Allow-DevOps"

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        # for the moment we're only doing this locally, idaelly we'll do it from the hosted agents at a future time...
        if (!$env:IsLocal -or $env:TEST_NSG_OVERRIDE) {
            # note that this is purely for testing purposes and is not intended for use in a normal
            # non-production nor production environment
            # if we're not local, then we need to open the NSG, wait a few seconds to ensure the change it appropriately picked up, then test
            az network nsg rule create --name $CONST_NSG_EXCEPTION `
                --nsg-name $NSG_PUBLIC_NAME `
                --priority 200 `
                --resource-group $env:AKS_RG_NAME `
                --access "Allow" `
                --description "Inbound Allow rule created to enable hosted DevOps agents ingress to application gateway" `
                --destination-port-ranges "443" `
                --direction "Inbound" `
                --protocol "Tcp" `
                --source-address-prefixes $(Get-MyIP) `
                --source-port-ranges "*"
            Start-Sleep -Seconds 30
        }
    }

    Context "Validations of Cluster HTTP Behavior - healthchecks" {
        BeforeAll {
            Write-Verbose -Verbose "AG WAF is $AG_WAF_NAME"
            $gatewayInfo = $(az network application-gateway show --name "$AG_WAF_NAME" --resource-group "$env:AKS_RG_NAME") | ConvertFrom-Json
            $ipAddress = $(az network public-ip show --ids $gatewayInfo.frontendIpConfigurations.publicIpAddress.id --query "ipAddress" -o tsv)
        }
        It "Cluster returns expected HTTP code" {
            Write-Verbose -Verbose "Address inside It block is $ipAddress"
            # we expect a 404 or a 200, but should not be a 403 or a 502
            $result = Invoke-AtlasWebClient -Uri "https://$($ipAddress)/"

            # we'll try one more time if the first 500's with a sleep just in case
            if ($result.StatusCode -eq "500") {
                Start-Sleep -Seconds 10
                Write-Host "First attempt failed with result: $($result.Body)"
                $result = Invoke-AtlasWebClient -Uri "https://$($ipAddress)/"
            }

            Write-Host "Final Result: $($result.Body)"
            $result.StatusCode | Should -BeIn @(200, 404, 502)
        }
    }
    Context "Validation of DNS, AAD Pod Identity and Calico Checks" {
        BeforeAll {
            $gatewayInfo = $(az network application-gateway show --name "$AG_WAF_NAME" --resource-group "$env:AKS_RG_NAME") | ConvertFrom-Json
            $ipAddress = $(az network public-ip show --ids $gatewayInfo.frontendIpConfigurations.publicIpAddress.id --query "ipAddress" -o tsv)

            Write-Verbose -Verbose "ip is $ipAddress"
            $result = Invoke-AtlasWebClient -Uri "https://$($ipAddress)/atlas/healthchecks"
            try {
                $payload = $result.Body | ConvertFrom-Json
            }
            catch {
                Write-Verbose "could not convert result to json: Status: $($result.StatusCode) Body: $($result.body)" -Verbose
                $payload = $null
            }
        }

        It "All DNS Checks Pass" {
            if ($result.StatusCode -ne "502") {
                # all defined checks should be true
                $($payload | Where-Object { $_.k8sHealthChecktype -eq "DNS" } ).success | ForEach-Object { $_ | Should -Be $true }
            }
        }

        It "AAD Pod Identity check Passes" {
            write-verbose -verbose "result.statuscode is $($result.StatusCode)" 
            if ($result.StatusCode -ne "502") {
                $($payload | Where-Object { $_.k8sHealthChecktype -eq "AAD_POD_IDENTITY" } ).success | ForEach-Object { $_ | Should -Be $true }
            }
        }

        It "Calico Check Passes" -Skip {
            if ($result.StatusCode -ne "502") {
                $($payload | Where-Object { $_.k8sHealthChecktype -eq "CALICO" } ).success | Should -Be $true
            }
        }
    }

    Context "Validations of Cluster HTTP Behavior - Diagnostics" {
        BeforeAll {
            $gatewayInfo = $(az network application-gateway show --name "$AG_WAF_NAME" --resource-group "$env:AKS_RG_NAME") | ConvertFrom-Json
            $ipAddress = $(az network public-ip show --ids $gatewayInfo.frontendIpConfigurations.publicIpAddress.id --query "ipAddress" -o tsv)

            $result = Invoke-AtlasWebClient -Uri "https://$($ipAddress)/atlas/diagnostics"
            # we'll try one more time if the first 500's with a sleep just in case
            if ($result.StatusCode -eq "500") {
                Start-Sleep -Seconds 30
                Write-Host "First attempt failed with result: $($result.Body)"
                $result = Invoke-AtlasWebClient -Uri "https://$($ipAddress)/"
            }


            It "App using Managed Identity check Passes" {
                if ($result.StatusCode -ne "502") {

                    try {
                        $payload = $result.Body | ConvertFrom-Json
                    }
                    catch {
                        Write-Verbose "could not convert result to json: Status: $($result.StatusCode) Body: $($result.body)" -Verbose
                        $payload = $null
                    }

                    # all defined checks should be true
                    $($payload | Where-Object { $_.azureDiagnosticType -eq "MSI" } ).success | ForEach-Object { $_ | Should -Be $true }
                }
            }
        }
    }

    Context "Test Calico Namespace Permissions" {
        BeforeAll {
            $gatewayInfo = $(az network application-gateway show --name "$AG_WAF_NAME" --resource-group "$env:AKS_RG_NAME") | ConvertFrom-Json
            $ipAddress = $(az network public-ip show --ids $gatewayInfo.frontendIpConfigurations.publicIpAddress.id --query "ipAddress" -o tsv)
            $destination_namespace = "calico-api-dvlp"
        }

        It "Calico Default Network Policy is Deny All" {
            $network_policy_deny_all_destination_namespace = "calico-api-dvlp-deny-all"

            # Check for deny all network policy
            $response = kubectl get networkpolicy $network_policy_deny_all_destination_namespace -n $destination_namespace
            $response | Should -Not -Be $null
        }

        It "Calico Harness should fail with default deny all rule" {
            $harnessResult = Invoke-AtlasWebClient -Uri "https://$($ipAddress)/calico-ui-dvlp/Home/WeatherForecast"
            $harnessResult.StatusCode | Should -Be 500
        }

        It "Calico Harness should work after adding calico namespace allow rule" {

            $destination_namespace = "calico-api-dvlp"
            $policyToAdd = "$env:INFRA_FOLDER/AzureKubernetesService/test-functional/CalicoFunctionalTests/calico-ui-dvlp_calico-api-dvlp_policy.yaml"
            kubectl create -f $policyToAdd -n $destination_namespace
            # after creating rule we might need to try a few times before the rule is in effect
            $i = 1
            do {
                Start-Sleep -Seconds 3
                Write-Verbose "calico api test #$i" -Verbose
                $harnessResult = Invoke-AtlasWebClient -Uri "https://$($ipAddress)/calico-ui-dvlp/Home/WeatherForecast"
                Write-Verbose "calico api test response: $($harnessResult.StatusCode)" -Verbose
                $i++
            } while (($harnessResult.StatusCode -ne 200) -and ($i -le 15))

            $harnessResult.StatusCode | Should -Be 200
        }
    }

    AfterAll {
        #let's delete the rule so we are back to our standard config, not a big deal for builds but when local testing this is helpful for retests
        $networkPolicyUIAllowAPI = "calico-ui-dvlp-allow-calico-api-dvlp"
        $destination_namespace = "calico-api-dvlp"
        kubectl delete networkpolicy $networkPolicyUIAllowAPI -n $destination_namespace

        if (!$env:IsLocal -or $env:TEST_NSG_OVERRIDE) {
            az network nsg rule delete --name $CONST_NSG_EXCEPTION `
                --nsg-name $NSG_PUBLIC_NAME `
                --resource-group $env:AKS_RG_NAME
        }
    }
}
