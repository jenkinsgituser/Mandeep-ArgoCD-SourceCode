param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "Application Gateway with WAF" {
    BeforeAll{
            # Source the _include file
            . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")
            # Source the variables file
            . ("$INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1")

            # Define expected results for assertions
            $AG_AZURE_TYPE = "Microsoft.Network/applicationGateways"
            $EXPECTED_AG_COUNT = 1
            $EXPECTED_OPERATION_STATE = "Running"
            $EXPECTED_LOCATION = $AKS_LOCATION
            $EXPECTED_WAF_STATE = "true"
            $EXPECTED_WAF_MODE = "Prevention"
            $EXPECTED_WAF_RULESET = "OWASP"
            $EXPECTED_WAF_RULESET_VERSION = "3.0"
            $Expected_WAF_MIN_CAPACITY_Default_Value = 0
            $Expected_WAF_MAX_CAPACITY_Default_Value = 20
            $Expected_WAF_TIER = "WAF_V2"

            $EXPECTED_WAF_DISABLED_RULES = "[{'ruleGroupName': 'REQUEST-920-PROTOCOL-ENFORCEMENT','rules': [920420]},{'ruleGroupName': 'REQUEST-931-APPLICATION-ATTACK-RFI','rules': [931130]},{'ruleGroupName': 'REQUEST-942-APPLICATION-ATTACK-SQLI','rules': [942440]}]"

            # Get the application gateway resource result from the resource group
            $AG_Infer_Resource = [string]::Empty
            if ($rgResources -eq $null) {
                $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
            }
            $AG_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $AG_AZURE_TYPE })

            #get the application gateway object from the resource result
            $AG_WAF_NAME = $($AG_Infer_Resource).name
            Write-Verbose "AG Name: $AG_WAF_NAME" -Verbose

            $agJson = $(az network application-gateway show -g $resourceGroup -n $AG_WAF_NAME) | ConvertFrom-Json
    }
    ######################################################

    It "Resource Group variable is set" {
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        $resourceGroup | Should -Not -Be $null
    }

    It "Application Gateway Inferred from Resource Group" {
        $($AG_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_AG_COUNT
        $AG_Infer_Resource | Should -Not -Be $null
    }

    It "Has Retrievable Configuration" {
        $agJson | Should -Not -Be $null
    }

    It "Is Operational" {
        $agJson.operationalState | Should -Be $EXPECTED_OPERATION_STATE
    }

    It "Is in the Correct Location" {
        $agJson.location | Should -Be $EXPECTED_LOCATION
    }

    It "Is in the Correct tier" {
        $agJson.autoscaleConfiguration.minCapacity | Should -Be $Expected_WAF_MIN_CAPACITY_Default_Value
        $agJson.autoscaleConfiguration.maxCapacity | Should -Be $Expected_WAF_MAX_CAPACITY_Default_Value
        $agJson.sku.tier | Should -Be $Expected_WAF_TIER
    }

    It "Has Expected Frontend Configuration" {
        $agJson.frontendIpConfigurations | Should -Not -Be $null
        $agJson.frontendPorts | Should -Not -Be $null
        $agJson.httpListeners | Should -Not -Be $null
    }

    It "Has Expected Backend Configuration" {
        $agJson.backendAddressPools | Should -Not -Be $null
        $agJson.backendHttpSettingsCollection | Should -Not -Be $null
    }

    It "Has Expected SSL Configuration" {
        $agJson.trustedRootCertificates | Should -Not -Be $null
        $agJson.sslCertificates | Should -Not -Be $null
        $agJson.sslPolicy | Should -Not -Be $null
    }

    It "Has Expected WAF Configuration" {
        $agJson.webApplicationFirewallConfiguration | Should -Not -Be $null
        $agJson.webApplicationFirewallConfiguration.enabled | Should -Be $EXPECTED_WAF_STATE
        $agJson.webApplicationFirewallConfiguration.firewallMode | Should -Be $EXPECTED_WAF_MODE
        $agJson.webApplicationFirewallConfiguration.ruleSetType | Should -Be $EXPECTED_WAF_RULESET
        $agJson.webApplicationFirewallConfiguration.ruleSetVersion | Should -Be $EXPECTED_WAF_RULESET_VERSION
    }
    AfterAll {
        if ($AG_WAF_ENABLE_REQUEST_BODY_CHECK) {
            Write-Verbose -Verbose "request body check option is enabled as `$env:AG_WAF_ENABLE_REQUEST_BODY_CHECK is set to true"
            $agJson.webApplicationFirewallConfiguration.requestBodyCheck | Should -Be $true
        }
        else {
            Write-Verbose -Verbose "request body check option is disabled as `$env:AG_WAF_ENABLE_REQUEST_BODY_CHECK is set to false"
            $agJson.webApplicationFirewallConfiguration.requestBodyCheck | Should -Be $false
        }

        Write-Verbose -Verbose "AG WAF TIMEOUT SET to $AG_WAF_HTTPS_TIMEOUT"

        if ($AG_WAF_HTTPS_TIMEOUT) {
            Write-Verbose -Verbose "WAF HTTPS settings timeout is set and is expected as `$env:AG_WAF_HTTPS_TIMEOUT"
            $agJson.backendHttpSettingsCollection.requestTimeout | Should -BeLessOrEqual 900
        }
        else {
            Write-Verbose -Verbose "Default WAF HTTPS settings timeout is not set"
            $agJson.backendHttpSettingsCollection.requestTimeout | Should -Be 20
        }

        if ($env:AG_WAF_CLEAR_DISABLED_RULE_GROUPS) {
            Write-Verbose -Verbose "No disabled rules expected as `$env:AG_WAF_CLEAR_DISABLED_RULE_GROUPS set"
            $agJson.webApplicationFirewallConfiguration.disabledRuleGroups.ruleGroupName | Should -Be $null
            $agJson.webApplicationFirewallConfiguration.disabledRuleGroups.rules | Should -Be $null
        }
        elseif ($env:AG_WAF_DISABLED_RULE_GROUPS) {
            Write-Verbose -Verbose "Disabled rules expected as `$env:AG_WAF_DISABLED_RULE_GROUPS set"
            # Get the disabled rules off the resource and validate
            # "[{'ruleGroupName': 'REQUEST-920-PROTOCOL-ENFORCEMENT','rules': [920420]},
            #   {'ruleGroupName': 'REQUEST-931-APPLICATION-ATTACK-RFI','rules': [931130]},
            #   {'ruleGroupName': 'REQUEST-942-APPLICATION-ATTACK-SQLI','rules': [942440]}]"
            $expectedValues = $EXPECTED_WAF_DISABLED_RULES | ConvertFrom-Json
            $agJson.webApplicationFirewallConfiguration.disabledRuleGroups.ruleGroupName | Should -Be $expectedValues.ruleGroupName
            $agJson.webApplicationFirewallConfiguration.disabledRuleGroups.rules | Should -Be $expectedValues.rules
        }
    }
}