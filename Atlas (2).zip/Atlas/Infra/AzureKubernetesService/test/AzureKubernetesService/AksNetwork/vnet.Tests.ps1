param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "Virtual Network Validation Tests" {
    BeforeAll {

        # Source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")

        # Define expected results for assertions
        $VNET_AZURE_TYPE = "Microsoft.Network/virtualNetworks"
        $EXPECTED_ADDRESS_PREFIX = "10.0.0.0/16"
        $EXPECTED_VNET_COUNT = 1
        $EXPECTED_SUBNET_COUNT = 2

        $EXPECTED_SERVICE_ENDPOINT_COUNT = 14

        $EXPECTED_PRIVATE_SUBNET_COUNT = 1
        $EXPECTED_PRIVATE_ADDRESSING = "10.0.1.0/24"

        $EXPECTED_PUBLIC_SUBNET_COUNT = 1
        $EXPECTED_PUBLIC_ADDRESSING = "10.0.0.0/24"

        $PRIVATE_SUBNET_FILTER = "*private*"
        $PUBLIC_SUBNET_FILTER = "*public*"

        # Get the resource result from the resource group
        $VNET_Infer_Resource = [string]::Empty
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }
        $VNET_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $VNET_AZURE_TYPE })

        # Get the application gateway object from the resource result
        $VNET_NAME = $($VNET_Infer_Resource).name
        Write-Verbose "vNet Name: $VNET_NAME" -Verbose

        $vnetJson = $(az network vnet show -g $resourceGroup -n $VNET_NAME) | ConvertFrom-Json

        ######################################################
    }

    It "Resource Group variable is set" {
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        $resourceGroup | Should -Not -Be $null
    }

    It "vNet Inferred from Resource Group" {
        $($VNET_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_VNET_COUNT
        $VNET_Infer_Resource | Should -Not -Be $null
    }

    It "Has Retrievable Configuration" {
        $vnetJson | Should -Not -Be $null
    }

    It "Has Two Subnets" {
        $vnetJson.subnets.Count | Should -Be $EXPECTED_SUBNET_COUNT
    }

    It "Has a Public and Private Subnet" {
        $private = $($vnetJson.subnets.name | Where-Object { $_ -like $PUBLIC_SUBNET_FILTER })
        $private.Count | Should -Be $EXPECTED_PRIVATE_SUBNET_COUNT

        $public = $($vnetJson.subnets.name | Where-Object { $_ -like $PRIVATE_SUBNET_FILTER })
        $public.Count | Should -Be $EXPECTED_PUBLIC_SUBNET_COUNT
    }

    It "Uses Expected IP Ranges" {
        $vnetJson.addressSpace.addressPrefixes | Should -Be $EXPECTED_ADDRESS_PREFIX
    }

    It "Is Not Peered to another Network" {
        [string]::IsNullOrEmpty($vnetJson.virtualNetworkPeerings) | Should -Be $True
    }

    It "vNet Has Correct Service Endpoint Connections" {
        $vnetJson.subnets.serviceEndpoints.Count | Should -Be $EXPECTED_SERVICE_ENDPOINT_COUNT
    }

    # Pubilc Subnet Tests
    Context "Public Subnet Tests" {
        BeforeAll {
            $publicSubnetJSON = $vnetJson.subnets | Where-Object { $_.name -like $PUBLIC_SUBNET_FILTER }
        }
        It "Has a Public NSG attached" {
            $publicSubnetJSON.networkSecurityGroup | Should -Not -Be $null
            $publicSubnetJSON.networkSecurityGroup.id | Should -BeLike $PUBLIC_SUBNET_FILTER
        }

        It "Uses expected network addressing" {
            $publicSubnetJSON.addressPrefix | Should -Be $EXPECTED_PUBLIC_ADDRESSING
        }
    }

    # Private Subnet Tests
    Context "Public Subnet Tests" {
        BeforeAll {
            $privateSubnetJSON = $vnetJson.subnets | Where-Object { $_.name -like $PRIVATE_SUBNET_FILTER }
        }
        It "Has a Private NSG attached" {
            $privateSubnetJSON.networkSecurityGroup | Should -Not -Be $null
            $privateSubnetJSON.networkSecurityGroup.id | Should -BeLike $PRIVATE_SUBNET_FILTER
        }

        It "Uses expected network addressing" {
            $privateSubnetJSON.addressPrefix | Should -Be $EXPECTED_PRIVATE_ADDRESSING
        }
    }
}