param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "Private NSG Validation Tests" {
    BeforeAll {
        # Source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")

        #define expected results for assertions
        $NSG_AZURE_TYPE = "Microsoft.Network/networkSecurityGroups"
        $EXPECTED_NSG_COUNT = 1

        $NSG_IDENTIFIER = "Private"
        ######################################################

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        # Get the application gateway resource result from the resource group
        $NSG_Infer_Resource = [string]::Empty
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }
        $NSG_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $NSG_AZURE_TYPE })
        # At this point we have both the public and private NSG. Get the one we need for this test suite and evaluate from there....
        $NSG_Infer_Resource = $NSG_Infer_Resource | Where-Object { $_.name -like "*$NSG_IDENTIFIER" }
        # Now we have the NSG we want to test

        # Get the application gateway object from the resource result
        $NSG_NAME = $($NSG_Infer_Resource).name
        Write-Verbose "NSG Name: $NSG_NAME" -Verbose

        $nsgJson = $(az network nsg show -g $resourceGroup -n $NSG_NAME) | ConvertFrom-Json
    }
    #######################################################
    It "Resource Group variable is set" {
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        $resourceGroup | Should -Not -Be $null
    }

    It "$NSG_IDENTIFIER NSG Inferred from Resource Group" {
        $($NSG_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_NSG_COUNT
        $NSG_Infer_Resource | Should -Not -Be $null
    }

    It "Has Retrievable Configuration" {
        $nsgJson | Should -Not -Be $null
    }

    It "Is only attached to one subnet" {
        $nsgJson.subnets.count | Should -Be 1
    }

}