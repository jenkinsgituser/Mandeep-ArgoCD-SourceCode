param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "Public NSG Validation Tests" {
    BeforeAll{
        # Source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")

        # Define expected results for assertions
        $NSG_AZURE_TYPE = "Microsoft.Network/networkSecurityGroups"
        $EXPECTED_NSG_COUNT = 1

        $NSG_IDENTIFIER = "Public"

        $EXPECTED_CLOUD_APIC_2018_PIPS = @(
            "52.162.245.1/32",
            "52.173.255.48/32",
            "23.100.79.154/32",
            "40.79.22.44/32",
            "52.173.246.220/32",
            "157.55.160.165/32",
            "168.61.220.200/32"
            "40.75.97.37/32",
            "40.78.153.75/32",
            "40.122.145.129/32",
            "52.177.124.194/32",
            "65.52.56.146/32",
            "157.55.141.125/32")

        $EXPECTED_DLX_APIM_PIPS = @("1.1.1.1/32", "47.34.60.253/32")
        ######################################################

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        # Get the application gateway resource result from the resource group
        $NSG_Infer_Resource = [string]::Empty
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
         }
        $NSG_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $NSG_AZURE_TYPE })
        # At this point we have both the public and private NSG. Get the one we need for this test suite and evaluate from there....
        $NSG_Infer_Resource = $NSG_Infer_Resource | Where-Object { $_.name -like "*$NSG_IDENTIFIER" }
        # Now we have the NSG we want to test

        # Get the application gateway object from the resource result
        $NSG_NAME = $($NSG_Infer_Resource).name
        Write-Verbose "NSG Name: $NSG_NAME" -Verbose

        $nsgJson = $(az network nsg show -g $resourceGroup -n $NSG_NAME) | ConvertFrom-Json
    }
    #######################################################

    It "Resource Group variable is set" {
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        $resourceGroup | Should -Not -Be $null
    }

    It "$NSG_IDENTIFIER NSG Inferred from Resource Group" {
        $($NSG_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_NSG_COUNT
        $NSG_Infer_Resource | Should -Not -Be $null
    }

    It "Has Retrievable Configuration" {
        $nsgJson | Should -Not -Be $null
    }

    It "Is only attached to one subnet" {
        $nsgJson.subnets.count | Should -Be 1
    }

    It "Has CMFG PAT Addresses allowed inbound on 443" {
        $targetRules = $nsgJson.securityRules | Where-Object { $_.Name -in @("CMFG_Internal_Servers_Madison_443", "Madison_User_Network_443", "CMFG_Internal_Servers_Ashburn_443", "Ashburn_User_Network_443") }

        # Server zone PAT
        ('208.91.239.30/32', '208.91.237.190/32') | Should -BeIn $targetRules.sourceAddressPrefix
        # User network PATH
        ('208.91.239.10/32', '208.91.239.11/32', '208.91.237.161/32', '208.91.237.162/32') | Should -BeIn $targetRules.sourceAddressPrefixes

        $targetRules.destinationPortRange | ForEach-Object { $_ | Should -Be "443" }
    }

    It "Has Allowed Cloud APIC 2018 Ingress" {
        $targetRules = $nsgJson.securityRules | Where-Object { $_.Name -in @("Cloud_APIC_2018_NonProd_443", "Cloud_APIC_2018_Prod_443") }
        $EXPECTED_CLOUD_APIC_2018_PIPS | Should -BeIn $targetRules.sourceAddressPrefixes
        $targetRules.destinationPortRange | ForEach-Object { $_ | Should -Be "443" }
    }

    # Verify that the APIC IPs map to public IP resources in the CMFG Prod or NonProd Azure subscription
    # 8/14/2020 jyo6427 - added this test, but cannot run it because the Sandbox RM account does not have access to read prod/nonprod resources
    # It "Cloud APIC 2018 Ingress IPs Exist" {
    #     $apicSubscriptions = @("CMFG Production", "CMFG NonProduction")
    #     foreach ( $apicSubscription in $apicSubscriptions ) {
    #         $cmfgAzurePips += (Get-AzPublicIpAddress -DefaultProfile (Set-AzContext -SubscriptionName $apicSubscription)).IpAddress
    #     }
    #     foreach ($apicIp in $EXPECTED_CLOUD_APIC_2018_PIPS) {
    #         $apicIp.TrimEnd("/32") | Should -BeIn $cmfgAzurePips
    #     }
    # }

    It "Has App Insights alllowed inbound on 443" {
        $targetRule = $nsgJson.securityRules | Where-Object { $_.Name -eq "Allow_AppInsights_Availability" }
        $targetRule | Should -Not -Be $null
        $targetRule.sourceAddressPrefix | Should -Be "ApplicationInsightsAvailability"
        $targetRule.destinationPortRange | Should -Be "443"
    }

    It "Has Traffic Manager alllowed inbound on 443" {
        $targetRule = $nsgJson.securityRules | Where-Object { $_.Name -eq "Allow_Traffic_Manager" }
        $targetRule | Should -Not -Be $null
        $targetRule.sourceAddressPrefix | Should -Be "AzureTrafficManager"
        $targetRule.destinationPortRange | Should -Be "443"
    }

    If ($env:ALLOW_DLX_APIM_INGRESS -eq $true) {
        It "Has Allowed DLX APIM Ingress -- `$env:ALLOW_DLX_APIM_INGRESS == `$true" {
            $EXPECTED_DLX_APIM_PIPS | Should -BeIn $nsgJson.securityRules.sourceAddressPrefixes
        }
    }
    Else {
        It "Does Not Have Allowed DLX APIM Ingress -- `$env:ALLOW_DLX_APIM_INGRESS == `$false" {
            $EXPECTED_DLX_APIM_PIPS | Should -Not -BeIn $nsgJson.securityRules.sourceAddressPrefixes
        }
    }
}