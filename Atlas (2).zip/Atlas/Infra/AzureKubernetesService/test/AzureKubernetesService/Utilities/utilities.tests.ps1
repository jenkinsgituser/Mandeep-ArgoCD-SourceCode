param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "Testing AKS Utilities" {
    BeforeAll {
        $userProvidedVersion = $env:AKS_KUBERNETES_VERSION
        # Source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")
        $tmpPath = [System.IO.Path]::GetTempPath()
        $tmpFilePath = $tmpPath + "tmpFile.txt"

        Write-Verbose "get aks msi objId for $AKS_NAME" -Verbose
        $AKS_MSI_OBJID = (Get-AzADServicePrincipal -DisplayName $AKS_NAME).Id
        # Set the test data
        $MinorVersionResult = Get-AKSMinorVersions

        $LatestMinusTwoAKSVersion = $MinorVersionResult.LatestMinusTwoAKSVersion
        $LatestMinusOneAKSVersion = $MinorVersionResult.LatestMinusOneAKSVersion
        $LowerThanSupportedAKSVersion = $MinorVersionResult.LowerThanLowestVersion
        $HigherThanSupportedAKSVersion = $MinorVersionResult.HighThanLatestVersion
        $VersionDifferenceNum = $MinorVersionResult.VersionDifferenceNum

        $AllPatchVersion_LatestVersion = Get-AllPatchVersionBasedonMinorVersion -MajorMinorVersion $CONST_LATEST_ALLOWED_K8S_VERSION
        $LatestPatchVersionDetail = Get-DetailPatchVersionBasedonMinorVersion -AllVersion $AllPatchVersion_LatestVersion
        $AllPatchVersion_LatestVersionCount = $AllPatchVersion_LatestVersion.count
        if ($VersionDifferenceNum -ge 1) {
            $AllPatchVersion_LatestMinusOneVersion = Get-AllPatchVersionBasedonMinorVersion -MajorMinorVersion $LatestMinusOneAKSVersion
            $AllPatchVersion_LatestMinusOneVersionCount = $AllPatchVersion_LatestMinusOneVersion.count
            $LatestMinusOnePatchVersionDetail = Get-DetailPatchVersionBasedonMinorVersion -AllVersion $AllPatchVersion_LatestMinusOneVersion
        }
        if ($VersionDifferenceNum -gt 1) {
            $AllPatchVersion_LatestMinusTwoVersion = Get-AllPatchVersionBasedonMinorVersion -MajorMinorVersion $LatestMinusTwoAKSVersion
            $AllPatchVersion_LatestMinusTwoVersionCount = $AllPatchVersion_LatestMinusTwoVersion.count
            $LatestMinusTwoPatchVersionDetail = Get-DetailPatchVersionBasedonMinorVersion -AllVersion  $AllPatchVersion_LatestMinusTwoVersion
        }

    }

    Context "Self Serve Request Functions" {

        It "Check-AtlasAksPermissionsSetupRequired -- Existing Cluster" {
            $callAksSetupRunbook = Check-AtlasAksPermissionsSetupRequired -ResourceGroupName $resourceGroup `
                -AksServicePrincipalObjectId $AKS_MSI_OBJID `
                -AppTeamRoleGroupObjectIds $APP_TEAM_AD_GROUP_OBJECT_IDS
            $callAksSetupRunbook | Should -Be $false
        }

        It "Check-AtlasAksPermissionsSetupRequired -- Existing Cluster = Multiple AppTeam Role Groups" {
            $APP_TEAM_AD_GROUP_OBJECT_IDS += "22222-22222-22222"
            $callAksSetupRunbook = Check-AtlasAksPermissionsSetupRequired -ResourceGroupName $resourceGroup `
                -AksServicePrincipalObjectId $AKS_MSI_OBJID `
                -AppTeamRoleGroupObjectIds $APP_TEAM_AD_GROUP_OBJECT_IDS
            $callAksSetupRunbook | Should -Be $true
        }

        It "Check-AtlasAksPermissionsSetupRequired -- Made up Group" {
            $callAksSetupRunbook = Check-AtlasAksPermissionsSetupRequired -ResourceGroupName $resourceGroup `
                -AksServicePrincipalObjectId $AKS_MSI_OBJID `
                -AppTeamRoleGroupObjectIds "11111-1111-11111" 2> $null
            $callAksSetupRunbook | Should -Be $true
        }

        It "Check-AtlasAksPermissionsSetupRequired -- Made up RG" {
            $callAksSetupRunbook = Check-AtlasAksPermissionsSetupRequired -ResourceGroupName "This-is-made-up-874" `
                -AksServicePrincipalObjectId $AKS_MSI_OBJID `
                -AppTeamRoleGroupObjectIds "11111-1111-11111" 2> $null
            $callAksSetupRunbook | Should -Be $true
        }

        It "Check-AtlasMcGroupPermissions -- Already Cascaded" {
            $cascadeMcGroupPermissions = Check-AtlasMcGroupPermissions -ResourceGroupName $resourceGroup `
                -AksCluster $AKS_NAME `
                -AppTeamRoleGroupObjectIds $APP_TEAM_AD_GROUP_OBJECT_IDS
            $cascadeMcGroupPermissions | Should -Be $false
        }

        It "Check-AtlasMcGroupPermissions -- Made up Group" {
            $cascadeMcGroupPermissions = Check-AtlasMcGroupPermissions -ResourceGroupName $resourceGroup `
                -AksCluster $AKS_NAME `
                -AppTeamRoleGroupObjectIds "11111-1111-11111" 2> $null
            $cascadeMcGroupPermissions | Should -Be $true
        }

        It "Check-AtlasMcGroupPermissions -- Made up RG" {
            $cascadeMcGroupPermissions = Check-AtlasMcGroupPermissions -ResourceGroupName "This-is-made-up-874" `
                -AksCluster $AKS_NAME `
                -AppTeamRoleGroupObjectIds "11111-1111-11111" 2> $null
            $cascadeMcGroupPermissions | Should -Be $false
        }
    }

    Context "AKS utilities Functions" {

        It "Get-AKSClusterRBACsubjects function tests" {

            # Leave this left justified
            $expectedResult = @"
- apiGroup: rbac.authorization.k8s.io
  kind: Group
  name: "1111"
- apiGroup: rbac.authorization.k8s.io
  kind: Group
  name: "2222"
"@
            $expectedResult = $expectedResult + "`n"

            $multipleGroups = @()
            $multipleGroups += "1111"
            $multipleGroups += "2222"
            $result = Get-AKSClusterRBACsubjects -AppTeamRoleGroupObjectIds $multipleGroups
            if ($result -eq $expectedResult) {
                Write-Output "true"
            }

            # Remove CR/LF becuase it wouldn't work otherwise
            $resultFlattend = $result.Replace("`n", "").Replace("`r", "")
            $expectedResultFlattened = $expectedResult.Replace("`n", "").Replace("`r", "")
            $resultFlattend | Should -Be $expectedResultFlattened
        }

    }

    Context "Validate-InputAksVersionEnvironmentVariable function tests for $CONST_LATEST_ALLOWED_K8S_VERSION" {

        It "Throw an error if the user-provided version is not supported by Atlas" {
            $env:AKS_KUBERNETES_VERSION = $LowerThanSupportedAKSVersion
            { Validate-InputAksVersionEnvironmentVariable } | Should -Throw
            $env:AKS_KUBERNETES_VERSION = $HigherThanSupportedAKSVersion
            { Validate-InputAksVersionEnvironmentVariable } | Should -Throw
        }
        It "Throw an error if the user-provided version greater than the latest version of $CONST_LATEST_ALLOWED_K8S_VERSION" {
            $env:AKS_KUBERNETES_VERSION = $LatestPatchVersionDetail.HighThanLatest
            $latestAllowedVersion = $LatestPatchVersionDetail.latestversion
            $ExistingAksVersion = $null
            { Validate-InputAksVersionEnvironmentVariable -AllowedLatestVersion $latestAllowedVersion } | Should -Throw
        }
        It "Expect a warning message if user-provided version lower than the existing AKS cluster version" {
            $env:AKS_KUBERNETES_VERSION = $LatestPatchVersionDetail.LowestVersion
            $latestAllowedVersion = $LatestPatchVersionDetail.LatestVersion
            $ExistingAksVersion = $LatestPatchVersionDetail.LatestVersion
            Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
            Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
            Remove-Item $tmpFilePath
        }
        It "Expect a warning message if existing cluster version lower than the latest allowed cluster version " {
            if ($AllPatchVersion_LatestVersionCount -gt 1) {
                $env:AKS_KUBERNETES_VERSION = $LatestPatchVersionDetail.LowestVersion
                # Get the latest allowed version
                $latestAllowedVersion = $LatestPatchVersionDetail.LatestVersion
                $ExistingAksVersion = $LatestPatchVersionDetail.LowestVersion
                Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                Remove-Item $tmpFilePath
            }
        }
        It "Expect a warning message if user-provided version (no existing cluster) lower than the latest allowed cluster version" {
            if ($AllPatchVersion_LatestVersionCount -gt 1) {
                $env:AKS_KUBERNETES_VERSION = $LatestPatchVersionDetail.LowestVersion
                $latestAllowedVersion = $LatestPatchVersionDetail.LatestVersion
                $ExistingAksVersion = $null
                Validate-InputAksVersionEnvironmentVariable -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                Remove-Item $tmpFilePath
            }
        }
        It "Expect a warning message if existing cluster version (no user provided version) lower than the allowed cluster version" {
            if ($AllPatchVersion_LatestVersionCount -gt 1) {
                $env:AKS_KUBERNETES_VERSION = $null
                $latestAllowedVersion = $LatestPatchVersionDetail.LatestVersion
                $ExistingAksVersion = $LatestPatchVersionDetail.LowestVersion
                Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                Remove-Item $tmpFilePath
            }
        }
    }
    Context "Validate-InputAksVersionEnvironmentVariable function tests for $LatestMinusOneAKSVersion" {
        It "Throw an error if the user-provided version greater than the latest version of $LatestMinusOneAKSVersion" {
            if ($VersionDifferenceNum -eq 1) {
                $env:AKS_KUBERNETES_VERSION = $LatestMinusOnePatchVersionDetail.HighThanLatest
                    $latestAllowedVersion = $LatestMinusOnePatchVersionDetail.latestversion
                    $ExistingAksVersion = $null
                    { Validate-InputAksVersionEnvironmentVariable -AllowedLatestVersion $latestAllowedVersion } | Should -Throw
                }
            }
        It "Expect a warning message if user-provided version lower than the existing AKS cluster version" {
            if ($VersionDifferenceNum -eq 1) {
                $env:AKS_KUBERNETES_VERSION = $LatestMinusOnePatchVersionDetail.LowestVersion
                $latestAllowedVersion = $LatestMinusOnePatchVersionDetail.LatestVersion
                $ExistingAksVersion = $LatestMinusOnePatchVersionDetail.LatestVersion
                Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                Remove-Item $tmpFilePath
            }
        }
        It "Expect a warning message if existing cluster version lower than the latest allowed cluster version " {
            if ($VersionDifferenceNum -eq 1) {
                if ($AllPatchVersion_LatestVersionCount -gt 1) {
                    $env:AKS_KUBERNETES_VERSION = $LatestMinusOnePatchVersionDetail.LowestVersion
                    # Get the latest allowed version
                    $latestAllowedVersion = $LatestMinusOnePatchVersionDetail.LatestVersion
                    $ExistingAksVersion = $LatestMinusOnePatchVersionDetail.LowestVersion
                    Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                    Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                    Remove-Item $tmpFilePath
                }
            }
        }
        It "Expect a warning message if user-provided version (no existing cluster) lower than the latest allowed cluster version" {
            if ($AllPatchVersion_LatestVersionCount -gt 1) {
                if ($VersionDifferenceNum -eq 1) {
                    $env:AKS_KUBERNETES_VERSION = $LatestMinusOnePatchVersionDetail.LowestVersion
                    $latestAllowedVersion = $LatestMinusOnePatchVersionDetail.LatestVersion
                    $ExistingAksVersion = $null
                    Validate-InputAksVersionEnvironmentVariable -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                    Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                    Remove-Item $tmpFilePath
                }
            }
        }
        It "Expect a warning message if existing cluster version (no user provided version) lower than the allowed cluster version" {
            if ($VersionDifferenceNum -eq 1) {
                if ($AllPatchVersion_LatestVersionCount -gt 1) {
                    $env:AKS_KUBERNETES_VERSION = $null
                    $latestAllowedVersion = $LatestMinusOnePatchVersionDetail.LatestVersion
                    $ExistingAksVersion = $LatestMinusOnePatchVersionDetail.LowestVersion
                    Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                    Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                    Remove-Item $tmpFilePath
                }
            }
        }

    }

    Context "Validate-InputAksVersionEnvironmentVariable function tests for $LatestMinusTwoAKSVersion" {
        It "Throw an error if the user-provided version greater than the latest version of $LatestMinusTwoAKSVersion" {
            if ($VersionDifferenceNum -gt 1) {
                $env:AKS_KUBERNETES_VERSION = $LatestMinusTwoPatchVersionDetail.HighThanLatest
                $latestAllowedVersion = $LatestMinusTwoPatchVersionDetail.latestversion
                $ExistingAksVersion = $null
                { Validate-InputAksVersionEnvironmentVariable -AllowedLatestVersion $latestAllowedVersion } | Should -Throw
            }
        }
        It "Expect a warning message if the user-provided version lower than the existing AKS cluster version" {
            if ($VersionDifferenceNum -gt 1) {
                $env:AKS_KUBERNETES_VERSION = $LatestMinusTwoPatchVersionDetail.LowestVersion
                $latestAllowedVersion = $LatestMinusTwoPatchVersionDetail.LatestVersion
                $ExistingAksVersion = $LatestMinusTwoPatchVersionDetail.LatestVersion
                Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                Remove-Item $tmpFilePath
            }
        }
        It "Expect a warning message if the existing cluster version lower than the latest allowed cluster version " {
            if ($VersionDifferenceNum -gt 1) {
                if ($AllPatchVersion_LatestVersionCount -gt 1){
                    $env:AKS_KUBERNETES_VERSION = $LatestMinusTwoPatchVersionDetail.LowestVersion
                    # Get the latest allowed version
                    $latestAllowedVersion = $LatestMinusTwoPatchVersionDetail.LatestVersion
                    $ExistingAksVersion = $LatestMinusTwoPatchVersionDetail.LowestVersion
                    Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                    Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                    Remove-Item $tmpFilePath
                }
            }
        }
        It "Expect a warning message if the user-provided version (no existing cluster) lower than the latest allowed cluster version" {
            if ($VersionDifferenceNum -gt 1) {
                if ($AllPatchVersion_LatestVersionCount -gt 1){
                    $env:AKS_KUBERNETES_VERSION = $LatestMinusTwoPatchVersionDetail.LowestVersion
                    $latestAllowedVersion = $LatestMinusTwoPatchVersionDetail.LatestVersion
                    $ExistingAksVersion = $null
                    Validate-InputAksVersionEnvironmentVariable -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                    Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                    Remove-Item $tmpFilePath
                }
            }
        }
        It "Expect a warning message if the existing cluster version (no user provided version) lower than the allowed cluster version" {
            if ($VersionDifferenceNum -gt 1) {
                if ($AllPatchVersion_LatestVersionCount -gt 1){
                    $env:AKS_KUBERNETES_VERSION = $null
                    $latestAllowedVersion = $LatestMinusTwoPatchVersionDetail.LatestVersion
                    $ExistingAksVersion = $LatestMinusTwoPatchVersionDetail.LowestVersion
                    Validate-InputAksVersionEnvironmentVariable -ExistingAksVersion $ExistingAksVersion -AllowedLatestVersion $latestAllowedVersion 3> $tmpFilePath
                    Get-Content -Path $tmpFilePath | Should -Not -BeNullOrEmpty
                    Remove-Item $tmpFilePath
                }
            }
        }
    }
    Context "Validate-InputAKSVersionExist function tests" {
        It "Throw an error if the user-provided version is invalid" {
            $env:AKS_KUBERNETES_VERSION = $LatestPatchVersionDetail.HighThanLatest
            { Validate-InputAKSVersionExist } | Should -Throw
            if ($LatestPatchVersionDetail.LowerThanLowestVersion -ne $null) {
                $env:AKS_KUBERNETES_VERSION = $LatestPatchVersionDetail.LowerThanLowestVersion
                { Validate-InputAKSVersionExist } | Should -Throw
            }
        }
    }

    Context "Get-AKSClusterDeploymentVersion function tests" {
        It "Throw an error when the user doesn't provide the AKS cluster version for a new deployment" {
            $userProvidedVersion = $null
            $Current_AKS_Version_Detail = $null
            $AKS_Location = "eastus2"
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw
        }
        It "Throw an error when the user-provided AKS cluster version is not supported by Atlas" {
            $userProvidedVersion = $LowerThanSupportedAKSVersion
            $Current_AKS_Version_Detail = $null
            $AKS_Location = "eastus2"
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw

            $userProvidedVersion = $HigherThanAllowedAKSVersion
            $Current_AKS_Version_Detail = $null
            $AKS_Location = "eastus2"
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw
        }
        It "Throw an error when the current AKS version is not supported by Atlas" {
            $AKS_Location = "eastus2"

            $userProvidedVersion = $null
            $Current_AKS_Version_Detail = "1.17.16"
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw

            $userProvidedVersion = $LatestMinusOneAKSVersion
            $Current_AKS_Version_Detail = $HigherThanSupportedAKSVersion
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw

        }
        It "Throw an error when the minor verion of the user provdied AKS version is lower than the current AKS minor version" {
            $userProvidedVersion = $LatestMinusOneAKSVersion
            $Current_AKS_Version_Detail = $CONST_LATEST_ALLOWED_K8S_VERSION
            $AKS_Location = "eastus2"
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw

            $userProvidedVersion = $LowerThanSupportedAKSVersion
            $Current_AKS_Version_Detail = $CONST_LOWEST_ALLOWED_K8S_VERSION
            $AKS_Location = "eastus2"
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw
        }
        It "Validate the AKS cluster version when the user doesn't provide the AKS version for redeployment" {
            $AKS_Location = "eastus2"
            $userProvidedVersion = $null
            $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LowestVersion
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw

            $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LatestVersion
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw

            $Current_AKS_Version_Detail = $LatestMinusOnePatchVersionDetail.latestversion
            { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw
        }

        It "Validate the AKS cluster version for a new deployment for $LatestMinusTwoAKSVersion"  -skip {
            if ($VersionDifferenceNum -eq 1) {
                $AKS_Location = "eastus2"

                $userProvidedVersion = $LatestMinusTwoAKSVersion
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion
                if ($LatestMinusTwoPatchVersionDetail.LowerThanLowestVersion -ne $null) {
                    $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.LowerThanLowestVersion
                    $Current_AKS_Version_Detail = $null
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be  $LatestMinusTwoPatchVersionDetail.LatestVersion
                }
                $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.LowestVersion
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.HighThanLatest
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion
                if ($AllPatchVersion_LatestMinusOneVersionCount -gt 2) {
                    $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    $Current_AKS_Version_Detail = $null
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion
                }
            }
        }
        It "Validate the AKS cluster version for a new deployment for $LatestMinusOneAKSVersion" {
            if ($VersionDifferenceNum -ge 1) {
                $AKS_Location = "eastus2"
                $userProvidedVersion = $LatestMinusOneAKSVersion
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion
                if ($LatestMinusOnePatchVersionDetail.LowerThanLowestVersion -ne $null) {
                    $userProvidedVersion = $LatestMinusOnePatchVersionDetail.LowerThanLowestVersion
                    $Current_AKS_Version_Detail = $null
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion
                }
                $userProvidedVersion = $LatestMinusOnePatchVersionDetail.LowestVersion
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion
                $userProvidedVersion = $LatestMinusOnePatchVersionDetail.HighThanLatest
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion

                if ( $AllPatchVersion_LatestMinusTwoVersionCount -gt 2) {
                    $userProvidedVersion = $LatestMinusOnePatchVersionDetail.MiddleVersion
                    $Current_AKS_Version_Detail = $null
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion
                }
            }
        }
        It "Validate the AKS cluster version for a new deployment for $CONST_LATEST_ALLOWED_K8S_VERSION" {
            $AKS_Location = "eastus2"

            $userProvidedVersion = $CONST_LATEST_ALLOWED_K8S_VERSION
            $Current_AKS_Version_Detail = $null
            $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
            $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion
            if ($LatestPatchVersionDetail.LowerThanLowestVersion -ne $null) {
                $userProvidedVersion = $LatestPatchVersionDetail.LowerThanLowestVersion
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion
            }
            $userProvidedVersion = $LatestPatchVersionDetail.LowestVersion
            $Current_AKS_Version_Detail = $null
            $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
            $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

            $userProvidedVersion = $LatestPatchVersionDetail.HighThanLatest
            $Current_AKS_Version_Detail = $null
            $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
            $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

            if ( $AllPatchVersion_LatestVersionCount -gt 2) {
                $userProvidedVersion = $LatestPatchVersionDetail.MiddleVersion
                $Current_AKS_Version_Detail = $null
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion
            }
        }
        It "Validate the AKS cluster version when the user provides a version for an existing AKS cluster" {
            $AKS_Location = "eastus2"
            if ($VersionDifferenceNum -eq 0) {
                $userProvidedVersion = $LatestPatchVersionDetail.HighThanLatest
                $Current_AKS_Version_Detail = $LatestPatchVersionDetail.LowestVersion
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

                $userProvidedVersion = $LatestPatchVersionDetail.LowestVersion
                $Current_AKS_Version_Detail = $LatestPatchVersionDetail.LatestVersion
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

                $userProvidedVersion = $LatestPatchVersionDetail.LatestVersion
                $Current_AKS_Version_Detail = $LatestPatchVersionDetail.LatestVersion
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

                $userProvidedVersion = $LatestPatchVersionDetail.LowerThanLowestVersion
                $Current_AKS_Version_Detail = $LatestPatchVersionDetail.LowestVersion
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

            }
            if ($VersionDifferenceNum -eq 1) {
                $userProvidedVersion = $LatestPatchVersionDetail.LowestVersion
                $Current_AKS_Version_Detail = $LatestMinusOnePatchVersionDetail.LowestVersion
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

                $userProvidedVersion = $LatestPatchVersionDetail.HighThanLatest
                $Current_AKS_Version_Detail = $LatestMinusOnePatchVersionDetail.LatestVersion
                $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion

                if ($LatestMinusOnePatchVersionDetail.LowerThanLowestVersion -ne $null) {
                    $userProvidedVersion = $LatestPatchVersionDetail.LowerThanLowestVersion
                    $Current_AKS_Version_Detail = $LatestMinusOnePatchVersionDetail.LowestVersion
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestPatchVersionDetail.LatestVersion
                }
            }
            if ($VersionDifferenceNum -eq 2) {
                if ($AllPatchVersion_LatestMinusTwoVersionCount -eq 2) {
                    $userProvidedVersion = $LatestMinusTwoAKSVersion
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LowestVersion
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion
                    if ($LatestMinusTwoPatchVersionDetail.LowerThanLowestVersion -ne $null) {
                        $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.LowerThanLowestVersion
                        $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LowestVersion
                        $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                        $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                        $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.LatestVersion
                        $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LowestVersion
                        $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                        $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                        $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.HighThanLatest
                        $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LatestVersion
                        $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                        $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                        $userProvidedVersion = $LatestMinusOneAKSVersion
                        $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LatestVersion
                        $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                        $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion

                        $userProvidedVersion = $LatestMinusOnePatchVersionDetail.LowestVersion
                        $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LowestVersion
                        $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                        $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion

                        $userProvidedVersion = $LatestMinusOnePatchVersionDetail.LatestVersion
                        $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LowestVersion
                        $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                        $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusOnePatchVersionDetail.LatestVersion
                    }
                    $userProvidedVersion = $CONST_LATEST_ALLOWED_K8S_VERSION
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.LatestVersion
                    { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw
                }
                if ($AllPatchVersion_LatestMinusTwoVersionCount -gt 2) {
                    $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.HighThanLatest
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                    $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.LatestVersion
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                    $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.HighThanLatest
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                    $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.LowestVersion
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                    $userProvidedVersion = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    $AKS_KUBERNETES_VERSION = Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location
                    $AKS_KUBERNETES_VERSION | Should -Be $LatestMinusTwoPatchVersionDetail.LatestVersion

                    $userProvidedVersion = $CONST_LATEST_ALLOWED_K8S_VERSION
                    $Current_AKS_Version_Detail = $LatestMinusTwoPatchVersionDetail.MiddleVersion
                    { Get-AKSClusterDeploymentVersion -userProvidedVersion $userProvidedVersion -Current_AKS_Version_Detail $Current_AKS_Version_Detail -AKS_Location $AKS_Location } | Should -Throw
                }
            }
        }
    }
    AfterAll {
        $env:AKS_KUBERNETES_VERSION = $userProvidedVersion
    }
}