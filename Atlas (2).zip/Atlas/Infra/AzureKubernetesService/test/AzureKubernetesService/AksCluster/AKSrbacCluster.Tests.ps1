param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "AKS Cluster" {
    BeforeAll {


        # Source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")

        # Define expected results for assertions
        $AKS_AZURE_TYPE = "Microsoft.ContainerService/managedClusters"
        $EXPECTED_NODE_COUNT = if ($env:AKS_AGENT_COUNT) { $env:AKS_AGENT_COUNT } else { 1 }
        $EXPECTED_LOCATION = $AKS_LOCATION
        $EXPECTED_OMS_STATE = "true"
        $EXPECTED_TAGS_FILTER = "Titan-Atlas*"

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        # Get the AKS cluster (Should only be one) resource result from the resource group
        $AKS_Inferred_Resource = [string]::Empty
         if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
            }

        $AKS_Inferred_Resource = $($rgResources | Where-Object { $_.type -eq $AKS_AZURE_TYPE -and $_.name -eq $env:AKS_NAME })

        # Get the AKS cluster object from the resource result
        $AKS_NAME = $($AKS_Inferred_Resource).name
        Write-Verbose "AKS Cluster Name: $AKS_NAME" -Verbose

        $clusterJson = $(az aks show -g $resourceGroup -n $AKS_NAME) | ConvertFrom-Json
    }
    ######################################################
    It "Resource Group variable is set" {
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        $resourceGroup | Should -Not -Be $null
    }


    It "AKS Cluster Inferred from Resource Group" {
        # Fail if there's more than one resource
        $AKS_Inferred_Resource | Should -Not -Be $null
    }


    It "Cluster name variable is set" {
        $AKS_NAME | Should -Not -Be $null
    }

    It "Has Retrievable Configuration" {
        $clusterJson | Should -Not -Be $null
    }

    It "Has Valid AAD configuration" {
        $clusterJson.aadProfile | Should -Not -Be $null
        $clusterJson.aadProfile.managed | Should -Not -Be $null
        $clusterJson.aadProfile.adminGroupObjectIds | Should -Not -Be $null
        $clusterJson.aadProfile.tenantId | Should -Not -Be $null
        $clusterJson.identity.type | Should -Be "SystemAssigned"
        $clusterJson.servicePrincipalProfile.clientId | Should -Be "msi"
        $clusterJson.sku.tier | Should -Be "Free"
    }

    It "Has Correct Tags Present" {
        $clusterJson.tags.TemplateVersion | Should -BeLike $EXPECTED_TAGS_FILTER
        $clusterJson.tags.createdOn | Should -Not -Be $null
    }

    It "Is In Correct Location" {
        $clusterJson.location | Should -Be $EXPECTED_LOCATION
    }

     # Removed OMS agent for local deploys due to permissions
     if (!$env:IsLocal) {
        It "Has OMS Enabled" {
            $clusterJson.addonProfiles.omsagent.enabled | Should -Be $EXPECTED_OMS_STATE
        }
    }

    It "Has Correct K8S Version Number" {
        $clusterJson.kubernetesVersion | Should -Match $env:AKS_KUBERNETES_VERSION
    }

    #It "Has Correct Node Count" {
    # This is done the way it is to account for the need to select a property named "count" rather than execute "count" on the agentPoolProfiles object
    # ($clusterJson.agentPoolProfiles | Select-Object count).count | Should -Be $EXPECTED_NODE_COUNT
    #}

    Context "Kubenet - Route Table Tests" {
        # Skipping this test for now, was not running because required parm missing --vhub-name
        #  This is been happening on Azure hosted agents but the pester tests did not faile
        #  Self Hosted agents, this cause an error.
        It "Cluster has Route Table associated with private subnet" -Skip {
            az config set extension.use_dynamic_install=yes_without_prompt
            $MC_RESOURCE_GROUP = $(az aks show --resource-group $resourceGroup --name $AKS_NAME --query nodeResourceGroup -o tsv)
            $ROUTE_TABLE = $(az network vhub route-table list -g $MC_RESOURCE_GROUP) | ConvertFrom-Json

            if (!$ROUTE_TABLE) {
                # Test results were inconsistent due to occasional inability to discover Route table on target MC_ group for up to ~15 minutes.
                # Given this situation, we opted to explicitly record the test as skipped rather than fail the build, but if the Route table
                # was discovered we would log the test as successful. This allows us to track this specific test result over time to see
                # whether the issue continues to recur.
                Set-ItResult -Skipped -Because "Route table not found in RG, likely due to delay after deployment of cluster. Skipping test."
            }
            else {
                $ROUTE_TABLE.subnets.resourceGroup | Should -Be $resourceGroup
                $ROUTE_TABLE.subnets.id | Should -Not -Be $null
                $ROUTE_TABLE.subnets.id | Should -Match "private"
            }
        }
    }
}