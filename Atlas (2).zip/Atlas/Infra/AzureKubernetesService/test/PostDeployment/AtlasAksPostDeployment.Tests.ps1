param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "Atlas AKS Post Deployment Tests" {
    BeforeAll {
        # Source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")


        $CONST_NSG_EXCEPTION = "EXCEPTION-Temp-Testing-Inbound-Allow-DevOps"

        # Source ip addresses which enable the testing of the Atlas endpoint
        $ALLOWED_HOST_IPS = @("208.91.239.30", "208.91.239.10", "208.91.239.11", "208.91.237.190", "208.91.237.161", "208.91.237.162")

        $EXPECTED_RESOURCE_TYPES = @("Microsoft.ContainerService/managedClusters", `
            "Microsoft.Network/applicationGateways", `
            "Microsoft.Network/networkSecurityGroups", `
            "Microsoft.Network/publicIPAddresses", `
            "Microsoft.Network/virtualNetworks")
        # Yashaswini Enjeti: Added "Microsoft.Insights/actiongroups" to the list as the actiongroup is showing up  in the resourcegroup as a part of MC Application insight updates.
        # Get the real template version.
        $EXPECTED_TEMPLATE_VERSION = Get-AtlasVersionNumber

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

    }

    It "Resource Group variable is set" {
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        $resourceGroup | Should -Not -Be $null
    }

    if ($rgResources -eq $null) {
        $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
    }

    It "Resource Group Has Retrievable Configuration" {
        $rgResources | Should -Not -Be $null
    }

    It "Has Correct Resources in Expected Quantities" {

        # Confirm 2 NSGs
        $($rgResources | Where-Object { $_.type -eq "Microsoft.Network/networkSecurityGroups" } | Measure-Object).Count | Should -Be 2

        # Confirm 1 vnet
        $($rgResources | Where-Object { $_.type -eq "Microsoft.Network/virtualNetworks" } | Measure-Object).Count | Should -Be 1

        # Confirm only 1 AG
        $($rgResources | Where-Object { $_.type -eq "Microsoft.Network/applicationGateways" } | Measure-Object).Count | Should -Be 1

        # Confirm only 1 AKS cluster
        $($rgResources | Where-Object { $_.type -eq "Microsoft.ContainerService/managedClusters" } | Measure-Object).Count | Should -Be 1

        # Confirm only 1 AKS cluster
        $($rgResources | Where-Object { $_.type -eq "Microsoft.Network/publicIPAddresses" } | Measure-Object).Count | Should -Be 1
    }

    Context "Permissions Validation" {
        BeforeAll {

            # $AKS_SP_APP_ID_URI = "http://$env:AKS_SP_APP_NAME"
            # $SUBSCRIPTION_ID = $(az account show --query id -o tsv)
            $TITAN_GROUP = "R-TeamTitan-LSA"

            $assignments = Get-AzRoleAssignment -ResourceGroupName $resourceGroup | Where-Object { $_.Scope -match "$($resourceGroup)" }
            $spAssignments = $assignments | Where-Object { $_.DisplayName -eq $env:AKS_NAME }
            $AQUA_SP_APP_ID = $(if ($environment -eq $CONST_SANDBOX_SUB) { "SP-Aqua-Provisioning-NP" } else { "SP-Aqua-Provisioning-P" })
            $AquaSpAssignments = $assignments | Where-Object { $_.DisplayName -eq $AQUA_SP_APP_ID }

            $APP_TEAM_AD_GROUPS = $APP_TEAM_AD_GROUPS.split(",").Trim(" ")  # convert to array
            # Get ad group assignements for each group
            foreach ($group in $APP_TEAM_AD_GROUPS) {
                $applicationADGroupAssignments += $assignments | Where-Object { $_.DisplayName -eq $group }
            }

            Write-Output $applicationADGroupAssignments.DisplayName
            $titanGroupAssignments = $assignments | Where-Object { $_.DisplayName -eq $TITAN_GROUP }
        }

        It "Cluster Managed Identity is 'Network Contributor' on Resource Group" {
            $spAssignments | Where-Object { $_.roleDefinitionName -eq "Network Contributor" } | Should -Not -Be $null
        }

        It "Cluster Managed Identity is in AD group 'Atlas AKS Managed Identities'" {
            $grp = Get-AzADGroup -SearchString "Atlas AKS Managed Identities"
            $grpMember = Get-AzADGroupMember -GroupObjectId $grp.id | Where-Object { $_.DisplayName -match $($AKS_NAME + "-agentpool") }
            
            # cli version failing with cli 2.38 switching to Powershell
            # $grpMembers = $(az ad group member list --group "Atlas AKS Managed Identities") | ConvertFrom-Json
            # $grpMember = $grpMembers | Where-Object { $_.displayName -match $($AKS_NAME + "-agentpool") }

            $grpMember | Should -Not -Be $null
        }

        It "Cluster omsagent Managed Identity is in AD group 'Atlas SPs CMFG-Sandbox'" {
            $grp = Get-AzADGroup -SearchString "Atlas SPs CMFG-Sandbox"
            $grpMember = Get-AzADGroupMember -GroupObjectId $grp.id | Where-Object { $_.DisplayName -match $( "omsagent-" + $AKS_NAME) }
            
            # cli version failing with cli 2.38 switching to Powershell
            # $grpMembers = $(az ad group member list --group $grp.id) | ConvertFrom-Json
            # $grpMembers = $(az ad group member list --group 'Atlas SPs CMFG-Sandbox') | ConvertFrom-Json -Depth 10
            # $grpMember = $grpMembers | Where-Object { $_.DisplayName -match $( "omsagent-" + $AKS_NAME) }
            $grpMember | Should -Not -Be $null
        }

        It "Cluster agentpool Managed Identity is in AD group 'Atlas SPs CMFG-Sandbox'" {
            $grp = Get-AzADGroup -SearchString "Atlas SPs CMFG-Sandbox"
            $grpMember = Get-AzADGroupMember -GroupObjectId $grp.id | Where-Object { $_.DisplayName -match $($AKS_NAME + "-agentpool") }
            
            # cli version failing with cli 2.38 switching to Powershell
            #$grpMembers = $(az ad group member list --group $grp.id) | ConvertFrom-Json
            # $grpMembers = $(az ad group member list --group "Atlas SPs CMFG-Sandbox") | ConvertFrom-Json
            # $grpMember = $grpMembers | Where-Object { $_.displayName -match $($AKS_NAME + "-agentpool") }
            $grpMember | Should -Not -Be $null
        }

        It "Aqua Provisioning SP is 'Reader' on Resource Group" {
            $AquaSpAssignments | Where-Object { $_.roleDefinitionName -eq "Reader" } | Should -Not -Be $null
        }

        It "Aqua Provisioning SP is 'Azure Kubernetes Service Cluster Admin Role' on Resource Group" {
            $AquaSpAssignments | Where-Object { $_.roleDefinitionName -eq "Azure Kubernetes Service Cluster Admin Role" } | Should -Not -Be $null
        }

        It "Application AD Group is not null" {
            $APP_TEAM_AD_GROUPS | Should -Not -Be $null
        }

        It "Application AD Group is 'Reader' on Resource Group" {
            foreach ($group in $APP_TEAM_AD_GROUPS) {
                $groupAssignmentsForGroup = $applicationADGroupAssignments | Where-Object { $_.DisplayName -eq $group }
                $readerFound = $null
                foreach ($groupAssignment in $groupAssignmentsForGroup) {
                    $readerFound = $groupAssignment | Where-Object { $_.roleDefinitionName -eq "Reader" }
                    if ($readerFound) { break } #once we find it, exit the loop
                }
                $readerFound | Should -Not -Be $null
            }
        }

        It "Application AD Group is 'Azure Kubernetes Service Cluster User Role' on Resource Group" {
            foreach ($group in $APP_TEAM_AD_GROUPS) {
                $groupAssignmentsForGroup = $applicationADGroupAssignments | Where-Object { $_.DisplayName -eq $group }
                $clusterUserRole = $null
                foreach ($groupAssignment in $groupAssignmentsForGroup) {
                    $clusterUserRole = $groupAssignment | Where-Object { $_.roleDefinitionName -eq "Azure Kubernetes Service Cluster User Role" }
                    if ($clusterUserRole) { break } # Once we find it, exit the loop
                }
                $clusterUserRole | Should -Not -Be $null
            }
        }

        It "R-TeamTitan-LSA is 'Reader' on Resource Group" {
            $titanGroupAssignments | Where-Object { $_.roleDefinitionName -eq "Reader" } | Should -Not -Be $null
        }

        It "R-TeamTitan-LSA is 'Azure Kubernetes Service Cluster User Role' on Resource Group" {
            $titanGroupAssignments | Where-Object { $_.roleDefinitionName -eq "Azure Kubernetes Service Cluster User Role" } | Should -Not -Be $null
        }

        It "Titan Atlas Version Number is set into the RG tags" {
            # The Template Version should not be empty or null/defaulted to "Unknown" or "Titan-Atlas-Beta"
            $rgResources.Count | Should -BeGreaterThan 0

            $rgResources | Where-Object { $EXPECTED_RESOURCE_TYPES -Contains $_.type } | ForEach-Object {
                $_.tags.TemplateVersion | Should -Not -Be $null
                $_.tags.TemplateVersion | Should -Not -Be "Unknown"
                $_.tags.TemplateVersion | Should -Not -Be "Titan-Atlas-Beta"

                $_.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION
            }
        }
    }

    Context "Evaluate Mine Files For Local Dev Use Cases" {
        BeforeAll {
            # Get all current mine files in the project directory
            $mineFiles = Get-ChildItem $env:ATLAS_REPO_ROOT -Recurse "*.mine.*"

            # Local testing
            if ($env:IsLocal) {
                $EXPECTED_MINE_FILES = @("create-cluster-dev-admin-group.mine.yaml", "azuredeployKubernetesServiceRBAC.mine.json", `
                        "cloud_mandatory.mine.yaml", "atlas-diagnostic-tester.mine.yaml")
            }
            else {
                # No mine files should exist on build/release agents
                $EXPECTED_MINE_FILES = @()
            }
        }
        if ($env:IsLocal) {
            It "Has Necessary Mine Files -- Is a Local Execution" {
                $mineFiles | Should -Not -Be $null
                $EXPECTED_MINE_FILES | ForEach-Object { $_ | Should -BeIn $mineFiles.Name }
                }
        }
        else {
            It "Has No Mine Files -- Not a Local Execution" {
               $mineFiles | Should -Be $null
            }
        }
    }

}