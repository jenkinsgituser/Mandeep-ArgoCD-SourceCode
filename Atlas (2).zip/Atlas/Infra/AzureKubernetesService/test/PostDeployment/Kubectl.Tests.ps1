
Describe "Atlas Cluster Validation" {
    BeforeAll {
        # Source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")

        # Define expected results for assertions
        $EXPECTED_RUNNING = "*Running*"
        $EXPECTED_INGRESS_IP = $(If ($env:AG_WAF_BACKEND_IP_ADDRESS) { "$env:AG_WAF_BACKEND_IP_ADDRESS" } Else { "10.0.1.254" })
        $EXPECTED_INGRESS_IP = "*$EXPECTED_INGRESS_IP*" # Append asterisks for a "like" comparison
        $EXPECTED_AAD_POD_1 = "mic"
        $EXPECTED_AAD_POD_2 = "nmi"
        $AAD_POD_DEPLOYMENT_NMI = "nmi"
        $AAD_POD_DEPLOYMENT_mic = "mic"
        $EXPECTED_CLUSTER_ROLE = "cluster-dev-admin"
        $EXPECTED_CLUSTER_ROLEBINDING = "dev-admin-global"
        $AAD_POD_IDENTITY_NAMESPACE = "aad-pod-identity"
        $DEFAULT_NAMESPACE = "default"
        $NETWORK_POLICY_DENY_ALL_DEFAULT_NAMESPACE = "default-namespace-deny-all"

        $EXPECTED_DEV_ADMIN_ROLE_RESOURCES = @("pods", "services", "deployments", "configmaps", "namespaces", "pods/log", "azureidentitybindings", "azureidentities", "azurepodidentityexceptions", `
                "azureassignedidentities", "replicasets", "daemonsets", "endpoints", "events", "networkpolicies", "ingresses", "horizontalpodautoscalers", `
                "persistentvolumeclaims", "persistentvolumes", "poddisruptionbudgets", "serviceaccounts", "nodes", "cronjobs", "jobs", "limitranges", "resourcequotas", "statefulsets", "endpointslices")
        $EXPECTED_DEV_ADMIN_ROLE_APIGROUPS = @("extensions", "apps", "batch", "apiextensions.k8s.io", "aadpodidentity.k8s.io", "", "autoscaling", "networking.k8s.io", "metrics.k8s.io", "discovery.k8s.io")
        $EXPECTED_DEV_ADMIN_ROLE_VERBS = @("get", "list", "watch", "describe", "delete", "logs")
        $EXPECTED_DEV_VIEW_ROLE_VERBS = @("get", "list", "watch", "describe", "logs")

        $TARGET_LARGE_CLIENT_BUFFER_STRING = "large-client-header-buffers"
        $TARGET_LARGE_CLIENT_BUFFER_SIZE = "4 24k"

        # The KUBE CONFIG stuff below shouldn't be necessary but here we are...
        #*********************************************************************
        # Relative path for kube config file
        $KUBE_CONFIG_PATH = [IO.Path]::Combine($env:ATLAS_REPO_ROOT, ".kube", "config")
        # Set the environment variable to match the kube_config_path in the event that we fail to
        # pass a --kubeconfig flag somewhere
        $env:KUBECONFIG = $KUBE_CONFIG_PATH
        Write-Verbose "KUBE_CONFIG_PATH: $KUBE_CONFIG_PATH" -Verbose


        $initialErrorActionPreference = $ErrorActionPreference
        $ErrorActionPreference = "SilentlyContinue"

        # Setup KUBECONFIG for AKS cluster in question
        # Need to be contributor on RG to connect as Admin, which
        # precludes execution from local machines
        ######################################################
    }


    # ######################################################

    It "Appropriate Variables are set" {
        $env:AKS_RG_NAME | Should -Not -Be $null
        $env:AKS_NAME | Should -Not -Be $null
    }

    # #*************************************************************************

    # Implies that $env:KUBECONFIG has been set and is available at runtime
    Context "Has a KUBECONFIG File to Connect" {
        BeforeAll {
            # Section below is all to ensure we have a running Kubectl
            #*************************************************************************
            #*************************************************************************
            try {
                $ErrorActionPreference = "Stop"
                az aks get-credentials -g "$env:AKS_RG_NAME" -n "$env:AKS_NAME" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
            }
            catch {
                $currentException = $_
                Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
                if ($($currentException.Exception.Message).Contains("as current context in")) {
                    Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
                }
                else {
                    Write-Verbose "Exception is unexpected. The script will end now" -Verbose
                    throw $currentException.Exception.Message
                }
            }

            $ErrorActionPreference = "SilentlyContinue"

            # Ensure Kubectl is present on the agent, grabbing it if necessary
            $kubectlResult = Confirm-Kubectl

            # Confirm we have kubectl in this session. If not, create an alias to the file that
            # must by on the system given the "Confirm-Kubectl" being run above
            $kubectlExists = Get-Command "kubectl" -ErrorAction SilentlyContinue
            if (!$kubectlExists) {
                Write-Warning "Unable to discover kubectl on path. Falling back to hard coded location!"
                Set-Alias -Name kubectl -Value "$($env:USERPROFILE)\.azure-kubectl\kubectl"
            }
            $kubectlExists = Get-Command "kubectl" -ErrorAction SilentlyContinue
            if (!$kubectlExists) {
                Write-Host "Unable to discover kubectl executable. Exiting..."
                Exit 10
            }

            Write-Host "env:KUBECONFIG -- $($env:KUBECONFIG)"
            Write-Host "env:Path: $($env:PATH)" -Verbose
            #*************************************************************************
            #*************************************************************************

            $config = Get-Content "$KUBE_CONFIG_PATH"
            $config | Should -Not -Be $null
        }

        It "Agent has kubectl" {
            $kubectlResult | Should -Not -Be $null
        }

        It "Path contains kubectl" {
            $kubectlExists = Get-Command "kubectl"
            $kubectlExists | Should -Not -Be $null

            $kubectlResponse = kubectl
            $kubectlResponse | Should -Not -Be $null
        }

        It "Agent can pull kubectl version info" {
            Write-Verbose "KUBE_CONFIG_PATH: $KUBE_CONFIG_PATH" -Verbose
            Write-Verbose "env:KUBECONFIG: $env:KUBECONFIG" -Verbose

            $versionResult = $(kubectl version --kubeconfig "$KUBE_CONFIG_PATH")
            $versionResult | Should -Not -Be $null
        }

        It "Has a Running Ingress Controller in Correct Namespace" {
            $response = kubectl get pods --kubeconfig "$KUBE_CONFIG_PATH" -n ingress-nginx
            $response | Should -Not -Be $null
            $response[1] | Should -BeLike $EXPECTED_RUNNING
        }

        It "Has an Ingress Controller With A Provisioned IP of $EXPECTED_INGRESS_IP" {
            $response = kubectl get services --kubeconfig "$KUBE_CONFIG_PATH" -n ingress-nginx
            $response | Should -Not -Be $null
            if ($response[1].ToLower() -notmatch "pending") {
                $response[1] | Should -BeLike $EXPECTED_INGRESS_IP
            }
        }
    }

    It "Has Deployment no Atlas V1 deployment for AAD Pod Identity" {
        # This test is for Atlas V1 to V2 migration to make sure we clean up original AAD POD Identity
        $checkNmiSvcAcct = kubectl get serviceaccount aad-pod-id-nmi-service-account --kubeconfig "$KUBE_CONFIG_PATH" 2>$null
        $checkNmi = kubectl get ds nmi --kubeconfig "$KUBE_CONFIG_PATH" 2>$null
        $checkMicSvcAcct = kubectl get serviceaccount aad-pod-id-mic-service-account --kubeconfig "$KUBE_CONFIG_PATH" 2>$null
        $checkDeployment = kubectl get deployment mic --kubeconfig "$KUBE_CONFIG_PATH" 2>$null

        $checkNmiSvcAcct | Should -Be $null
        $checkNmi | Should -Be $null
        $checkMicSvcAcct | Should -Be $null
        $checkDeployment | Should -Be $null
    }

    It "Has Deployment for AAD Pod Identity - MIC" {
        $responseMIC = kubectl get deployment $AAD_POD_DEPLOYMENT_MIC --kubeconfig "$KUBE_CONFIG_PATH" -n $AAD_POD_IDENTITY_NAMESPACE
        $responseMIC | Should -Not -Be $null
    }

    It "Has Deployment for AAD Pod Identity - NMI" {
        $responseNMI = kubectl get ds $AAD_POD_DEPLOYMENT_NMI --kubeconfig "$KUBE_CONFIG_PATH" -n $AAD_POD_IDENTITY_NAMESPACE
        $responseNMI | Should -Not -Be $null
    }

    It "Has Running AAD Pod Identity" {
        $response = kubectl get pods --kubeconfig "$KUBE_CONFIG_PATH" -n $AAD_POD_IDENTITY_NAMESPACE
        $response | Should -Not -Be $null
        $response -Match $EXPECTED_AAD_POD_1 | Should -Not -Be $null
        $response -Match $EXPECTED_AAD_POD_2 | Should -Not -Be $null
    }

    It "Has Large Header Values Configured on Ingress Controller" {
        $response = kubectl describe configmap nginx-configuration --kubeconfig "$KUBE_CONFIG_PATH" -n ingress-nginx
        $response | Should -Not -Be $null

        $response | Where-Object { $_ -match $TARGET_LARGE_CLIENT_BUFFER_STRING } | Should -Not -Be $null
        $response | Where-Object { $_ -match $TARGET_LARGE_CLIENT_BUFFER_SIZE } | Should -Not -Be $null
    }

    It "Has Network Policy - Deny All Traffic Into Default Namespace" {
        $response = kubectl get networkpolicy $NETWORK_POLICY_DENY_ALL_DEFAULT_NAMESPACE --kubeconfig "$KUBE_CONFIG_PATH" -n $DEFAULT_NAMESPACE
        $response | Should -Not -Be $null
    }

    It "FlexVol is not deployed" {
        $response = kubectl get ns kv --kubeconfig "$KUBE_CONFIG_PATH" 2> $null
        $response | Should -Be $null
    }

    Context "RBAC Binding Validation" {
        It "Correct Dev Team Cluster Role Exists" {
            $roles = $(kubectl get clusterroles --kubeconfig "$KUBE_CONFIG_PATH" -o json) | ConvertFrom-Json
            $EXPECTED_CLUSTER_ROLE | Should -BeIn $roles.items.metadata.name
        }

        It "Dev Team Cluster Role Has Correct Permissions" {
            $roleInfo = $(kubectl get clusterroles $EXPECTED_CLUSTER_ROLE --kubeconfig "$KUBE_CONFIG_PATH" -o json) | ConvertFrom-Json
            $roleInfo.rules.resources | ForEach-Object { $_ | Should -BeIn $EXPECTED_DEV_ADMIN_ROLE_RESOURCES }
            $roleInfo.rules.apiGroups | ForEach-Object { $_ | Should -BeIn $EXPECTED_DEV_ADMIN_ROLE_APIGROUPS }
            $roleInfo.rules.verbs | ForEach-Object { $_ | Should -BeIn $EXPECTED_DEV_ADMIN_ROLE_VERBS }
        }

        It "Correct Dev Team Cluster RoleBinding Exists" {
            $bindings = $(kubectl get clusterrolebindings --kubeconfig "$KUBE_CONFIG_PATH" -o json) | ConvertFrom-Json
            $EXPECTED_CLUSTER_ROLEBINDING | Should -BeIn $bindings.items.metadata.name
        }

        It "Custom RBAC Role Correctly Bound" {
            $APP_TEAM_AD_GROUP_OBJECT_IDS | Should -Not -Be $null
            $bindingDescription = $(kubectl get clusterrolebinding $EXPECTED_CLUSTER_ROLEBINDING --kubeconfig "$KUBE_CONFIG_PATH" -o json) | ConvertFrom-Json
            foreach ($objId in $APP_TEAM_AD_GROUP_OBJECT_IDS) {
                $bindingDescription.subjects.name | Should -Contain $objId
            }
        }

        It "Correct Application of Prod View RBAC Permissions" {
            # Test Setup #####################################################

            # Cleanup the original permissions
            kubectl delete clusterrolebindings "dev-admin-global" --kubeconfig "$KUBE_CONFIG_PATH"
            kubectl delete clusterrole "cluster-dev-admin" --kubeconfig "$KUBE_CONFIG_PATH"

            # Apply the prod role to the cluster and re-test
            $RBAC_DEV_TEAM_ROLE = "$env:INFRA_FOLDER/AzureKubernetesService/src/AksCluster/AksClusterRBACRoleBindings/create-cluster-dev-view-group.yaml"
            $RBAC_DEV_TEAM_ROLE_OUTPUT = $RBAC_DEV_TEAM_ROLE
            if ($env:IsLocal) {
                $RBAC_DEV_TEAM_ROLE_OUTPUT = $RBAC_DEV_TEAM_ROLE.Replace(".yaml", ".mine.yaml")
            }

            Write-Verbose "create subjects for cluster rbac yaml" -Verbose
            $subjects = Get-AKSClusterRBACsubjects -AppTeamRoleGroupObjectIds $APP_TEAM_AD_GROUP_OBJECT_IDS

            Write-Verbose "perform token replacement for cluster rbac yaml" -Verbose
            (Get-Content $RBAC_DEV_TEAM_ROLE) -replace '__subjectsPopulatedOnDemand__', $subjects | Set-Content $RBAC_DEV_TEAM_ROLE_OUTPUT

            kubectl --kubeconfig "$KUBE_CONFIG_PATH" apply -f $RBAC_DEV_TEAM_ROLE_OUTPUT

            ##################################################################

            $PROD_CLUSTER_ROLE = "cluster-dev-view"
            $PROD_CLUSTER_ROLEBINDING = "dev-view-global"
            $roleInfo = $(kubectl get clusterroles $PROD_CLUSTER_ROLE --kubeconfig "$KUBE_CONFIG_PATH" -o json) | ConvertFrom-Json

            # resources should match non-prod
            $roleInfo.rules.resources | ForEach-Object { $_ | Should -BeIn $EXPECTED_DEV_ADMIN_ROLE_RESOURCES }
            # apiGroups should match non-prod
            $roleInfo.rules.apiGroups | ForEach-Object { $_ | Should -BeIn $EXPECTED_DEV_ADMIN_ROLE_APIGROUPS }
            # verbs should NOT match non-prod
            $roleInfo.rules.verbs | ForEach-Object { $_ | Should -BeIn $EXPECTED_DEV_VIEW_ROLE_VERBS }

            $APP_TEAM_AD_GROUP_OBJECT_IDS | Should -Not -Be $null
            $bindingDescription = $(kubectl get clusterrolebinding $PROD_CLUSTER_ROLEBINDING --kubeconfig "$KUBE_CONFIG_PATH" -o json) | ConvertFrom-Json
            foreach ($objId in $APP_TEAM_AD_GROUP_OBJECT_IDS) {
                $bindingDescription.subjects.name | Should -Contain $objId
            }
        }
    }

    Context "DNS Resolution Validation" {
        # TODO -- Need a test which validates DNS resolution intra-cluster and extra-cluster across multiple nodes.
        # After talking with Ken, we're in agreement that this fits best with the work Dennis is currently pursuing for a
        # general purpose diagnostic container. We'll need an app which tries to resolve DNS both internally (within cluster) and
        # externally and reports back on its results. Additionally, this app will need to run on every node and hit the case where it's
        # resolving its DNS from a node which does not itself host codeDNS pods...

        # OmsAgent doesn't get deployed on a local deployment, so only run this test on build agents
        It "Target Error String Found in Made Up Sample Error" {
            if (!$env:IsLocal) {
                $targetErrorString = "Error resolving host during the onboarding request"
                $sampleMadeUpError = "This is my error intended to replicate Error resolving host during the onboarding request"
                $result = $sampleMadeUpError | Select-String $targetErrorString
                $result.Matches.Success | Should -Be $true
            }
        }

        It "Basic DNS Resolution Check Passes -- OMSAgent Bootstrapping" {
            if (!$env:IsLocal) {
                $targetErrorString = "Error resolving host during the onboarding request"
                $logResults = $(kubectl logs -l component=oms-agent -n kube-system --tail=1000)
                $result = $logResults | Select-String $targetErrorString
                # After seeing a bit of flakiness on this test, we're going to give it a second shot to come up correctly. We've
                # seen that it's somewhat hit or miss on the initial cluster creation and the thought is that there's so much going
                # on at that time that this is playing second fiddle. If it still fails on a second attempt, then we have issues
                if ($result.Matches) {
                    kubectl delete po -l component=oms-agent -n kube-system 2> $null
                    Write-Verbose "Sleeping to allow oms-agent time to come back up..." -Verbose
                    Start-Sleep -Seconds 30
                    $logResults = $(kubectl logs -l component=oms-agent -n kube-system --tail=1000)
                    $result = $logResults | Select-String $targetErrorString
                }
                $result.Matches | Should -Be $null
            }
        }
    }

    AfterAll {
        $ErrorActionPreference = $initialErrorActionPreference
        Write-Host "Dumping errors discovered during execution..."
        Write-Host "$global:ERROR"

        # Cleanup after kubectl test execution
        if (Test-Path -Path "$KUBE_CONFIG_PATH") {
            Write-Verbose "Removing kubectl config file" -Verbose
            Remove-Item -Path "$KUBE_CONFIG_PATH"

            if (Test-Path "$($env:USERPOFILE)/.kube.config") {
                Remove-Item -Path "$($env:USERPOFILE)/.kube.config"
            }
        }
        else {
            Write-Verbose "kubectl config file does not exist" -Verbose
            Exit 11
        }
    }
}