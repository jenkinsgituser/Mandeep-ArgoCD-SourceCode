param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = @()
)

BeforeDiscovery {
    $EXPECTED_SANDBOX_ENVIRONMENTS = @('CMFG-Sandbox')
    $EXPECTED_NON_PROD_ENVIRONMENTS = @('CMFG NonProduction', 'Commercial-NonProd', 'CorporateServices-NonProd', 'DLX-NonProd', 'LAH-NonProd', 'Lending-Nonprod', 'OmniChannel-Nonprod', 'Retirement-NonProd', 'WMGMT-Nonprod')
    $EXPECTED_PROD_ENVIRONMENTS = @('CMFG Production', 'Commercial-Prod', 'CorporateServices-Prod', 'DLX-Prod', 'LAH-Prod', 'Lending-Prod', 'OmniChannel-Prod', 'Retirement-Prod', 'WMGMT-Prod')
}
Describe "Atlas AKS Pre Deployment Tests" {
    BeforeAll {
        # source the _include file
        . ("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")
        $tmpPath = [System.IO.Path]::GetTempPath()
        $tmpErrorFilePath = $tmpPath + "tmpErrorFile.txt"


        #Test inputs and expected results for retrieval of App Team AD Group
        $TEST_APP_TEAM_AD_GROUP_SINGLE_RESULT = "R-TeamTitan"
        $EXPECTED_APP_TEAM_AD_GROUP_SINGLE_OBJID = "ce4e84f5-8464-41a2-96bd-aa6396d2ed33"

        #R-Scrumbirds and R-Scrumbirds-LSA both exist, hence issues on an az ad group show as
        #it'll bomb saying More than one groups match name of 'R-Scrumbirds'
        $TEST_APP_TEAM_AD_GROUP_MULTIPLE_RESULTS = "R-Scrumbirds"
        $EXPECTED_APP_TEAM_AD_GROUP_MULTIPLE_OBJID = "ae50341e-eb85-4a03-aecf-026dd5e73e3a"

        $TEST_APP_TEAM_AD_GROUP_CASE_INSENSITIVE = "R-IntergroupsupportIt" # correct is R-InterGroupSupportIT
        $EXPECTED_APP_TEAM_AD_GROUP_CASE_INSENSITIVE_OBJID = "1a5f8099-41fc-4832-857e-41b84ba0e19b"

    }
    Context "Role Group Variable Value Confirmation" {

        #see utilities for shared version of this code. Note that the explicit function isn't be called just yet
        #as we're shortly turning that into a module, and I'd expect this test to shift right to that module.
        #Function Name: Get-Titan-AD-Group-ObjectId File: utilities.ps1

        It "App Team AD Group is found: <TEST_APP_TEAM_AD_GROUP_SINGLE_RESULT>" {
            $APP_TEAM_AD_GROUPS = $TEST_APP_TEAM_AD_GROUP_SINGLE_RESULT
            $matchingGroups = (az ad group list --display-name "$APP_TEAM_AD_GROUPS") | ConvertFrom-Json
            $AD_Group_objID = ($matchingGroups | Where-Object { $_.displayName.ToLower() -eq $APP_TEAM_AD_GROUPS.ToLower() }).id

            $AD_Group_objID | Should -Not -Be $null
            $AD_Group_objID | Should -Be $EXPECTED_APP_TEAM_AD_GROUP_SINGLE_OBJID
        }

        It "App Team AD Group is found: <TEST_APP_TEAM_AD_GROUP_MULTIPLE_RESULTS>" {
            $APP_TEAM_AD_GROUPS = $TEST_APP_TEAM_AD_GROUP_MULTIPLE_RESULTS
            $matchingGroups = (az ad group list --display-name "$APP_TEAM_AD_GROUPS") | ConvertFrom-Json
            $AD_Group_objID = ($matchingGroups | Where-Object { $_.displayName.ToLower() -eq $APP_TEAM_AD_GROUPS.ToLower() }).id

            $AD_Group_objID | Should -Not -Be $null
            $AD_Group_objID | Should -Be $EXPECTED_APP_TEAM_AD_GROUP_MULTIPLE_OBJID
        }

        It "App Team AD Group is found: <TEST_APP_TEAM_AD_GROUP_CASE_INSENSITIVE>" {
            $APP_TEAM_AD_GROUPS = $TEST_APP_TEAM_AD_GROUP_CASE_INSENSITIVE
            $matchingGroups = (az ad group list --display-name "$APP_TEAM_AD_GROUPS") | ConvertFrom-Json
            $AD_Group_objID = ($matchingGroups | Where-Object { $_.displayName.ToLower() -eq $APP_TEAM_AD_GROUPS.ToLower() }).id

            $AD_Group_objID | Should -Not -Be $null
            $AD_Group_objID | Should -Be $EXPECTED_APP_TEAM_AD_GROUP_CASE_INSENSITIVE_OBJID
        }
    }
    Context "Function Tests -- Get-AKS-Supported-Latest-K8S-Version" {
        BeforeAll {
            #Set the test data
            $MinorVersionResult = Get-AKSMinorVersions
            $LatestMinusTwoAKSVersion = $MinorVersionResult.LatestMinusTwoAKSVersion
            $LatestMinusOneAKSVersion = $MinorVersionResult.LatestMinusOneAKSVersion
            $VersionDifferenceNum = $MinorVersionResult.VersionDifferenceNum
        }

        It "Validate the latest AKS cluster version for $CONST_LATEST_ALLOWED_K8S_VERSION" {
            $location = "eastus2"
            $LatestVersionDetail = (Get-AllPatchVersionBasedonMinorVersion -MajorMinorVersion $CONST_LATEST_ALLOWED_K8S_VERSION) | Select-Object -Last 1
            $latestAKSSupportedVersion = Get-AKS-Supported-Latest-K8S-Version -Version $CONST_LATEST_ALLOWED_K8S_VERSION -AKS_Location $location 4> $tmpErrorFilePath
            $latestAKSSupportedVersion | Should -Not -Be $null
            $latestAKSSupportedVersion | Should -Be $LatestVersionDetail;

            $latestAKSSupportedVersion = Get-AKS-Supported-Latest-K8S-Version -AKS_Location $location 4> $tmpErrorFilePath
            $latestAKSSupportedVersion | Should -Not -Be $null
            $latestAKSSupportedVersion | Should -Be $LatestVersionDetail;
        }
        It "Validate the latest-1 AKS cluster version for <LatestMinusOneAKSVersion>" {
            if ($VersionDifferenceNum -ge 1) {
                $location = "eastus2"
                $LatestVersionDetail = (Get-AllPatchVersionBasedonMinorVersion -MajorMinorVersion $LatestMinusOneAKSVersion) | Select-Object -Last 1
                $latestAKSSupportedVersion = Get-AKS-Supported-Latest-K8S-Version -Version $LatestMinusOneAKSVersion -AKS_Location $location 4> $tmpErrorFilePath
                $latestAKSSupportedVersion | Should -Not -Be $null
                $latestAKSSupportedVersion | Should -Be $LatestVersionDetail;
            }
        }
        It "Validate the latest-2 AKS cluster version for <LatestMinusTwoAKSVersion>" {
            if ($VersionDifferenceNum -gt 1) {
                $location = "eastus2"
                $LatestVersionDetail = (Get-AllPatchVersionBasedonMinorVersion -MajorMinorVersion $LatestMinusTwoAKSVersion) | Select-Object -Last 1
                $latestAKSSupportedVersion = Get-AKS-Supported-Latest-K8S-Version -Version $LatestMinusTwoAKSVersion -AKS_Location $location 4> $tmpErrorFilePath
                $latestAKSSupportedVersion | Should -Not -Be $null
                $latestAKSSupportedVersion | Should -Be $LatestVersionDetail;
            }
        }
    }

    Context "Environment Inferment Confirmation for Sandbox"  -ForEach $EXPECTED_SANDBOX_ENVIRONMENTS {
        BeforeAll {
             $subSand = $_
        }
        It "Sandbox Environment check for <subSand>" {
                $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $subSand
                $environment = $SubscriptionProperties.environment
                $environment | Should -Be "Sandbox"
        }
    }

    Context "Environment Inferment Confirmation for Non Prod"  -ForEach $EXPECTED_NON_PROD_ENVIRONMENTS {
        BeforeAll {
             $subNP = $_
        }
        It "NonProd Environment check for <subNP>" {
            $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $subNP
            $environment = $SubscriptionProperties.environment
            $environment | Should -Be "NonProd"
        }
    }

    Context "Environment Inferment Confirmation for Prod"  -ForEach $EXPECTED_PROD_ENVIRONMENTS {
        BeforeAll {
             $subPR = $_
        }
        It "Prod Environment check for <subPR>"  {
            $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $subPR
            $environment = $SubscriptionProperties.environment
            $environment | Should -Be "Prod"
        }
    }

    Context "Get-AksRedeploymentSupported Tests" {
        It "Mock False Result" {
            Mock Get-AksRedeploymentSupported -ParameterFilter { $aksName -eq "TestData" } { return @{deploymentSupported = $false; errorMessage = "Target cluster exists and does not have Network Policy in place. Current deployment does not support re-deployment atop target cluster!" } }
            $result = Get-AksRedeploymentSupported -aksName "TestData" -resourceGroupName "TestData"
            $result.deploymentSupported | Should -Be $false
            $result.errorMessage | Should -Be "Target cluster exists and does not have Network Policy in place. Current deployment does not support re-deployment atop target cluster!"
        }

        It "Mock Positive Result" {
            Mock Get-AksRedeploymentSupported -ParameterFilter { $aksName -eq "TestData" } { return @{deploymentSupported = $true; errorMessage = $null } }
            $result = Get-AksRedeploymentSupported -aksName "TestData" -resourceGroupName "TestData"
            $result.deploymentSupported | Should -Be $true
            $result.errorMessage | Should -Be $null
        }

    }
}