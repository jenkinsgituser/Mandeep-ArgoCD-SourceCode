Describe "AKS Guardrail Unit Tests" {
    BeforeAll {
        # Set environment variable to get NSG file to dot source
        $env:IsTest = $true
        # Source the NSG
        . ("$env:INFRA_FOLDER/AzureKubernetesService/guardrails/runbooks/Atlas-AKS-Maintenance-NSGs.ps1")

        $DefaultProfile = Get-AzContext
        $TargetAtlasAksRG = "Test"
        $TargetNsgResource = "Test"

        # Declare function in local scope so it's available when called by Is-NsgAtlasOldVersion
        Function Write-AtlasOutput { }

    }

    Context "Is-NSGAtlas Tests" {

        It "Is-NSGAtlas - Mocked Remote Call -- True" {
            Mock Get-AzNetworkSecurityGroup {
                return @{
                    Tag = @{TemplateVersion = "Titan-Atlas-2.0.0" }
                }
            }
            Is-NSGAtlas -resourceGroup "MadeUpCuzMocked" -nsgResourceName "MadeUpCuzMocked" -DefaultProfile $DefaultProfile | Should -Be $true
            Assert-MockCalled Get-AzNetworkSecurityGroup -Times 1
        }

        It "Is-NSGAtlas - Mocked Remote Call -- True" {
            Mock Get-AzNetworkSecurityGroup {
                return @{
                    Tag = @{TemplateVersion = "Titan-Atlas-1.0.0" }
                }
            }
            Is-NSGAtlas -resourceGroup "MadeUpCuzMocked" -nsgResourceName "MadeUpCuzMocked" -DefaultProfile $DefaultProfile | Should -Be $true
            Assert-MockCalled Get-AzNetworkSecurityGroup -Times 1
        }

        It "Is-NSGAtlas - Mocked Remote Call -- Atlantis False" {
            Mock Get-AzNetworkSecurityGroup {
                return @{
                    Tag = @{TemplateVersion = "Titan-Atlas-v1-Atlantis" }
                }
            }
            Is-NSGAtlas -resourceGroup "MadeUpCuzMocked" -nsgResourceName "MadeUpCuzMocked" -DefaultProfile $DefaultProfile | Should -Be $false
            Assert-MockCalled Get-AzNetworkSecurityGroup -Times 1
        }
    }

    Context "Get-AtlasNsgType" {
        It "Matches Public Type" {
            $NsgResource = @{Name = "test-public" }
            Get-AtlasNsgType -NsgResource $NsgResource -DefaultProfile $DefaultProfile | Should -Be "Public"
        }

        It "Matches Public Type-2" {
            $NsgResource = @{Name = "test-Public" }
            Get-AtlasNsgType -NsgResource $NsgResource -DefaultProfile $DefaultProfile | Should -Be "Public"
        }

        It "Matches Private Type" {
            $NsgResource = @{Name = "test-private" }
            Get-AtlasNsgType -NsgResource $NsgResource -DefaultProfile $DefaultProfile | Should -Be "Private"
        }

        It "Matches Private Type-2" {
            $NsgResource = @{Name = "test-Private" }
            Get-AtlasNsgType -NsgResource $NsgResource -DefaultProfile $DefaultProfile | Should -Be "Private"
        }

        It "Doesn't match either defined type" {
            $NsgResource = @{Name = "test-I-Dont-Match-Either-Type" }
            { Get-AtlasNsgType -NsgResource $NsgResource -DefaultProfile $DefaultProfile } | Should -Throw

        }
    }

    # Not mocking the Do- Functions in the guardrail script as they're best covered with integration tests
    Context "AKS Guardrail Integration Tests" {
        BeforeAll {
            # Allow for local execution
            if ($env:IsLocal -and $env:NSG_PRIVATE_NAME -and $env:NSG_PUBLIC_NAME -and $env:AKS_RG_NAME) {
                $NSG_PRIVATE_NAME = $env:NSG_PRIVATE_NAME
                $NSG_PUBLIC_NAME = $env:NSG_PUBLIC_NAME
                $AKS_RG_NAME = $env:AKS_RG_NAME
            }
            else {
                .("$INFRA_FOLDER/AzureKubernetesService/test/_includes.tests.ps1")
            }
        }

        # Look for public NSG from deployment variables
        It "Expected variable exists - Public NSG" {
            $NSG_PUBLIC_NAME | Should -Not -Be $null
        }

        # Run comparison...
        It "Is-NsgAtlas - Public NSG" {
            $result = Is-NsgAtlas -resourceGroup $AKS_RG_NAME -nsgResourceName $NSG_PUBLIC_NAME -DefaultProfile $DefaultProfile
            $result | Should -BeTrue
        }

        # $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PUBLIC_NAME
        It "Validate Sample Expected Rules -- Public NSG - Sample 1" {
            $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PUBLIC_NAME

            $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
            $AtlasPublicNSGRulesObj.Name = "Madison_User_Network_443"
            $AtlasPublicNSGRulesObj.Description = "Connection from Madison CMFG VDIs"
            $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 2
            $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('208.91.239.10/32', '208.91.239.11/32')
            $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.SourcePortRange = "*"
            $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
            $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
            $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.Access = "Allow"
            $AtlasPublicNSGRulesObj.Priority = 116
            $AtlasPublicNSGRulesObj.Protocol = "Tcp"
            $AtlasPublicNSGRulesObj.Direction = "Inbound"

            Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $AtlasPublicNSGRulesObj | Should -Be $True
        }

        It "Validate Sample Expected Rules -- Public NSG - Sample 2" {
            $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PUBLIC_NAME

            $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
            $AtlasPublicNSGRulesObj.Name = "Allow_AppGateway_Internal"
            $AtlasPublicNSGRulesObj.Description = "Allowing Microsoft internal App Gateway communications"
            $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
            $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "*"
            $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.SourcePortRange = "*"
            $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
            $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "65200-65535"
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
            $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.Access = "Allow"
            $AtlasPublicNSGRulesObj.Priority = 2000
            $AtlasPublicNSGRulesObj.Protocol = "*"
            $AtlasPublicNSGRulesObj.Direction = "Inbound"

            Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $AtlasPublicNSGRulesObj | Should -Be $True
        }

        It "Validate Sample Expected Rules -- Public NSG - Sample 3" {
            $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PUBLIC_NAME

            $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
            $AtlasPublicNSGRulesObj.Name = "Allow_Traffic_Manager"
            $AtlasPublicNSGRulesObj.Description = "Traffic Manager allowed via Service Tag over TCP only"
            $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
            $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = "AzureTrafficManager"
            $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.SourcePortRange = "*"
            $AtlasPublicNSGRulesObj.DestinationPortRangeCount = 1
            $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
            $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.Access = "Allow"
            $AtlasPublicNSGRulesObj.Priority = 2010
            $AtlasPublicNSGRulesObj.Protocol = "Tcp"
            $AtlasPublicNSGRulesObj.Direction = "Inbound"
            $AtlasPublicNSGRulesObj.Optional = $true

            Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $AtlasPublicNSGRulesObj | Should -Be $True
        }

        It "Validate Sample Expected Rules -- Public NSG - Sample 4" {
            $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PUBLIC_NAME

            $AtlasPublicNSGRulesObj = New-AtlasNSGRulesObj
            $AtlasPublicNSGRulesObj.Name = "CMFG_Internal_Servers_Madison_443"
            $AtlasPublicNSGRulesObj.Description = "Connection from CMFG internal servers in Madison"
            $AtlasPublicNSGRulesObj.SourceAddressPrefixCount = 1
            $AtlasPublicNSGRulesObj.SourceAddressPrefixValue = @('208.91.239.30/32')
            $AtlasPublicNSGRulesObj.SourceApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.SourcePortRange = "*"
            $AtlasPublicNSGRulesObj.DestinationPortRangeCount = "1"
            $AtlasPublicNSGRulesObj.DestinationPortRangeValue = "443"
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixCount = 1
            $AtlasPublicNSGRulesObj.DestinationAddressPrefixValue = "*"
            $AtlasPublicNSGRulesObj.DestinationApplicationSecurityGroups = @()
            $AtlasPublicNSGRulesObj.Access = "Allow"
            $AtlasPublicNSGRulesObj.Priority = 115
            $AtlasPublicNSGRulesObj.Protocol = "Tcp"
            $AtlasPublicNSGRulesObj.Direction = "Inbound"

            Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $AtlasPublicNSGRulesObj | Should -Be $True
        }


        # Look for private NSG from deployment variables
        It "Expected variable exists - Private NSG" {
            $NSG_PRIVATE_NAME | Should -Not -Be $null
        }

        It "Is-NsgAtlas - Private NSG" {
            $result = Is-NsgAtlas -resourceGroup $AKS_RG_NAME -nsgResourceName $NSG_PRIVATE_NAME -DefaultProfile $DefaultProfile
            $result | Should -BeTrue
        }

        It "Validate Sample Expected Rules -- Private NSG - Sample 1" {
            $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PRIVATE_NAME

            $AtlasPrivateNSGRulesObj = New-AtlasNSGRulesObj
            $AtlasPrivateNSGRulesObj.Name = "Intra_vNet_Inbound_Udp"
            $AtlasPrivateNSGRulesObj.Description = "Resources within vnet can communicate inbound using Udp"
            $AtlasPrivateNSGRulesObj.SourceAddressPrefixCount = 1
            $AtlasPrivateNSGRulesObj.SourceAddressPrefixValue = "VirtualNetwork"
            $AtlasPrivateNSGRulesObj.SourceApplicationSecurityGroups = @()
            $AtlasPrivateNSGRulesObj.SourcePortRange = "*"
            $AtlasPrivateNSGRulesObj.DestinationPortRangeCount = 1
            $AtlasPrivateNSGRulesObj.DestinationPortRangeValue = "*"
            $AtlasPrivateNSGRulesObj.DestinationAddressPrefixCount = 1
            $AtlasPrivateNSGRulesObj.DestinationAddressPrefixValue = "VirtualNetwork"
            $AtlasPrivateNSGRulesObj.DestinationApplicationSecurityGroups = @()
            $AtlasPrivateNSGRulesObj.Access = "Allow"
            $AtlasPrivateNSGRulesObj.Priority = 3970
            $AtlasPrivateNSGRulesObj.Protocol = "Udp"
            $AtlasPrivateNSGRulesObj.Direction = "Inbound"

            Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $AtlasPrivateNSGRulesObj | Should -Be $True
        }

        It "Validate Sample Expected Rules -- Private NSG - Sample 2" {
            $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PRIVATE_NAME

            $AtlasPrivateNSGRulesObj = New-AtlasNSGRulesObj
            $AtlasPrivateNSGRulesObj.Name = "Intra_vNet_Inbound_Tcp"
            $AtlasPrivateNSGRulesObj.Description = "Resources within vnet can communicate inbound using Tcp"
            $AtlasPrivateNSGRulesObj.SourceAddressPrefixCount = 1
            $AtlasPrivateNSGRulesObj.SourceAddressPrefixValue = "VirtualNetwork"
            $AtlasPrivateNSGRulesObj.SourceApplicationSecurityGroups = @()
            $AtlasPrivateNSGRulesObj.SourcePortRange = "*"
            $AtlasPrivateNSGRulesObj.DestinationPortRangeCount = 1
            $AtlasPrivateNSGRulesObj.DestinationPortRangeValue = "*"
            $AtlasPrivateNSGRulesObj.DestinationAddressPrefixCount = 1
            $AtlasPrivateNSGRulesObj.DestinationAddressPrefixValue = "VirtualNetwork"
            $AtlasPrivateNSGRulesObj.DestinationApplicationSecurityGroups = @()
            $AtlasPrivateNSGRulesObj.Access = "Allow"
            $AtlasPrivateNSGRulesObj.Priority = 3980
            $AtlasPrivateNSGRulesObj.Protocol = "Tcp"
            $AtlasPrivateNSGRulesObj.Direction = "Inbound"

            Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $AtlasPrivateNSGRulesObj | Should -Be $True
        }

        It "Validate Sample Expected Rules -- Private NSG - Sample 3" {
            $NsgResource = Get-AzNetworkSecurityGroup -ResourceGroupName $AKS_RG_NAME -Name $NSG_PRIVATE_NAME

            $AtlasPrivateNSGRulesObj = New-AtlasNSGRulesObj
            $AtlasPrivateNSGRulesObj.Name = "DenyAllRuleInbound"
            $AtlasPrivateNSGRulesObj.Description = "Deny-all above permissive default rules - necessary traffic must be permitted above"
            $AtlasPrivateNSGRulesObj.SourceAddressPrefixCount = 1
            $AtlasPrivateNSGRulesObj.SourceAddressPrefixValue = "*"
            $AtlasPrivateNSGRulesObj.SourceApplicationSecurityGroups = @()
            $AtlasPrivateNSGRulesObj.SourcePortRange = "*"
            $AtlasPrivateNSGRulesObj.DestinationPortRangeCount = 1
            $AtlasPrivateNSGRulesObj.DestinationPortRangeValue = "*"
            $AtlasPrivateNSGRulesObj.DestinationAddressPrefixCount = 1
            $AtlasPrivateNSGRulesObj.DestinationAddressPrefixValue = "*"
            $AtlasPrivateNSGRulesObj.DestinationApplicationSecurityGroups = @()
            $AtlasPrivateNSGRulesObj.Access = "Deny"
            $AtlasPrivateNSGRulesObj.Priority = 4000
            $AtlasPrivateNSGRulesObj.Protocol = "*"
            $AtlasPrivateNSGRulesObj.Direction = "Inbound"

            Validate-NsgResourceAgainstExpectedRule -NsgResource $NsgResource -ExpectedRule $AtlasPrivateNSGRulesObj | Should -Be $True
        }
    }
}
