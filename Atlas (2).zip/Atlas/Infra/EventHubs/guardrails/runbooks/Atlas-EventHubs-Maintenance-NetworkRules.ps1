param
(
    [Parameter (Mandatory = $false)]
    [PsObject] $WebhookData,

    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false,

    <#
    The two parameters below exist to run the script ad-hoc against a specific EH instance.
    #>
    [Parameter (Mandatory = $false)]
    [string] $TargetSubscription = [string]::Empty,

    [Parameter (Mandatory = $false)]
    [string] $TargetEhNamespaceRG = [string]::Empty,

    [Parameter (Mandatory = $false)]
    [string] $TargetEhNamespace = [string]::Empty
)

# Function to determine if a resource group is atlas.
#################################################################
function Is-RGAtlas {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [parameter(Mandatory = $true)][PsObject]$Context
    )

    $tags = $(Get-AzResourceGroup -Name $resourceGroup -DefaultProfile $Context).Tags

    $RGIsAtlas = $false
    $version = $tags.TemplateVersion
    If (($null -ne $version) -and ($version.Contains($CONST_ATLAS_RG_TAG_IDENTIFIER))) {
        $RGIsAtlas = $true
    }#else ignore

    return $RGIsAtlas
}


# Function to check for network exception tag
#################################################################
function Check-AtlasNetworkException {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$ehNamespace,
        [parameter(Mandatory = $true)][PsObject]$Context
    )

    $networkExceptionExists = $true

    $ehObj = Get-AzEventHub -ResourceGroupName $resourceGroup -Namespace $ehNamespace -DefaultProfile $Context

    if (($null -ne $ehObj.Tags.AtlasExceptions) -and ($ehObj.Tags.AtlasExceptions.Contains("Network"))) {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t Event Hub Namespace $($ehNamespace) contains a Network Exception tag, skipping firewall rule validation."
    }
    else {
        $networkExceptionExists = $false
    }

    return $networkExceptionExists
}

function Get-AccessToken {
    param(
        [Parameter(Mandatory = $true)][guid] $tenantId
    )
    $azProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azProfile)
    $token = $profileClient.AcquireAccessToken($tenantId)
    $token.AccessToken
}

function Get-EventHubNamespaceNetworkRules {
    param(
        [Parameter(Mandatory = $true)][string] $resourceGroupName,
        [Parameter(Mandatory = $true)][string] $namespaceName,
        [parameter(Mandatory = $true)][PsObject]$Context
    )
    $subscriptionId = $Context.Subscription.Id
    $accessToken = Get-AccessToken -tenantId $Context.Tenant.TenantId

    $headers = @{
        "Authorization" = "Bearer $accessToken"
    }

    $url = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.EventHub/namespaces/$namespaceName/networkRuleSets?api-version=2017-04-01"

    $response = Invoke-RestMethod -Uri $url -Headers $headers
    $response.value
}

function Set-EventHubNamespaceNetworkRules {
    param(
        [Parameter(Mandatory = $true)][string] $resourceGroupName,
        [Parameter(Mandatory = $true)][string] $namespaceName,
        [parameter(Mandatory = $true)][PsObject]$Context,
        [parameter(Mandatory = $true)][Object[]]$networkRules
    )

    $subscriptionId = $Context.Subscription.Id
    $accessToken = Get-AccessToken -tenantId $Context.Tenant.TenantId

    $headers = @{
        "Authorization" = "Bearer $accessToken"
    }

    $url = "https://management.azure.com/subscriptions/$subscriptionId/resourceGroups/$resourceGroupName/providers/Microsoft.EventHub/namespaces/$namespaceName/networkRuleSets/default?api-version=2017-04-01"

    $payload = $networkRules | ConvertTo-Json -Depth 4

    Invoke-RestMethod -Uri $url -Headers $headers -Method Put -Body $payload | Out-Null
}

# Function to check Event Hubs vNet rules
#################################################################
function Check-EventHubNetworkRules {
    param(
        [Parameter(Mandatory = $true)][string] $ehNamespaceRG,
        [Parameter(Mandatory = $true)][string] $ehNamespace,
        [parameter(Mandatory = $true)][PsObject]$Context
    )

    $networkRules = Get-EventHubNamespaceNetworkRules -resourceGroupName $ehNamespaceRG -namespaceName $ehNamespace -Context $Context
    $updateRules = $false

    # check default action
    $defaultAction = $networkRules.properties.defaultAction
    if ($defaultAction -ne "Deny") {

        Write-AtlasOutput -LogLevel "WARN" -Message "WARNING: Default action is set to $defaultAction"

        Write-AtlasOutput -LogLevel "INFO" -Message "`r reset default action to Deny!"

        $networkRules.properties.defaultAction = "Deny"
        $updateRules = $true
    }

    # process virtual network rules for Atlas compliance status
    for ($i = 0; $i -lt $networkRules.properties.virtualNetworkRules.Count; $i++) {

        $vnetRule = $networkRules.properties.virtualNetworkRules[$i]
        $subnetId = $vnetRule.subnet.id
        $stringSplit = $subnetId -split "/"
        $vnetName = $stringSplit[8]
        $subnetName = $stringSplit[10]

        # consumes function sourced from Atlas-CommonCode.ps1
        # null check for the vNet result is handled in this function, providing benefit of the doubt in
        # cases where the Azure API is not responding
        if ((Validate-NetworkLocationIsAtlasAllowed -subnetResourceId $subnetId -context $Context) -eq $false) {

            Write-AtlasOutput -LogLevel "WARN" -Message "WARNING: Non-Titan VNet found: $vnetName"

            # Remove the vnet rule from the Event Hubs namespace if the vnet does not have Atlas tags
            Write-AtlasOutput -LogLevel "INFO" -Message "`r remove vNet rule '$vNetName' $subnetName due to failing Atlas compliance check!"

            $networkRules.properties.virtualNetworkRules[$i] = $null
            $updateRules = $true
        }
    }

    $ipAddressRules = Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }

    # check IP rules
    for ($i = 0; $i -lt $networkRules.properties.ipRules.Count; $i++) {

        $ipRule = $networkRules.properties.ipRules[$i]

        # remove non-compliant IP rules
        if (!($ipAddressRules | Where-Object { $_.value -eq $ipRule.ipMask })) {

            Write-AtlasOutput -LogLevel "WARN" -Message "WARNING: IP address $($ipRule.ipMask) is not on the list of allowed addresses"

            Write-AtlasOutput -LogLevel "INFO" -Message "`r remove allowed IP rule for $($ipRule.ipMask)!"

            $networkRules.properties.ipRules[$i] = $null
            $updateRules = $true
        }
    }

    # add any missing allowed IP rules
    foreach ($allowedIpRule in $ipAddressRules) {
        if (!($networkRules.properties.ipRules | Where-Object { $_.ipMask -eq $allowedIpRule.value })) {

            Write-AtlasOutput -LogLevel "WARN" -Message "WARNING: IP address rule missing for $($allowedIpRule.name): $($allowedIpRule.value)"

            Write-AtlasOutput -LogLevel "INFO" -Message "`r add allowed IP rule for $($allowedIpRule.value)!"

            $networkRules.properties.ipRules += @{ipMask = $allowedIpRule.value; action = "Allow" }
            $updateRules = $true
        }
    }

    if ($updateRules) {
        Set-EventHubNamespaceNetworkRules -resourceGroupName $ehNamespaceRG -namespaceName $ehNamespace -Context $Context -networkRules $networkRules
    }
}

function Do-ProcessEventHubResource {
    param
    (
        [Parameter(Mandatory = $true)][string] $ehNamespaceRG,
        [Parameter(Mandatory = $true)][string] $ehNamespace,
        [parameter(Mandatory = $true)][PsObject] $Context
    )
    #check if rg is atlas, if not atlas skip
    $isAtlasResourceGroup = Is-RGAtlas -resourceGroup $ehNamespaceRG -Context $Context
    if ($isAtlasResourceGroup) {
        $networkException = Check-AtlasNetworkException -resourceGroup $ehNamespaceRG -ehNamespace $ehNamespace -Context $Context
        if (!$networkException) {
            Write-AtlasOutput -LogLevel "INFO" -Message "No network exception tag, check firewall rules."
            Check-EventHubNetworkRules -ehNamespaceRG $ehNamespaceRG -ehNamespace $ehNamespace -Context $Context
        }
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "$ehNamespace not Atlas resource, skipping...."
    }
}


#MAIN
#-----------------------------------------------------------------------------------------------------

$ErrorActionPreference = "Stop"
$VerbosePreference = "SilentlyContinue"

#https://docs.microsoft.com/en-us/azure/automation/automation-runbook-execution#working-with-multiple-subscriptions
Disable-AzContextAutosave -Scope Process | Out-Null

try {
    # do the import in the silenced block
    Import-Module Az.Accounts | Out-Null
    Import-Module Az.Network | Out-Null
    Import-Module Az.Resources | Out-Null
    Import-Module Az.EventHub | Out-Null
}
catch {
    Write-AtlasOutput -LogLevel WARN "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"

Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
# if i'm local or i'm running on a build agent, source the file by location
# rather than relying on its presence within the AA
if ($env:IsLocal -or $env:AGENT_ID) {
    . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1
}
else {
    #sourcing on the AA is slightly different than sourcing locally
    . ./Atlas-CommonCode.ps1
    Azure-Connect
}
Write-AtlasOutput -Message " "

$CONST_AUTOMATION_ACCOUNT_NAME = "AA-CMFG-P01-InfraMgmt-AZ"
$CONST_AUTOMATION_ACCOUNT_NAME_NP = "AA-CMFG-D01-InfraMgmt-AZ"

$CONST_RUNBOOK_NAME = "Atlas-EventHubs-Maintenance-NetworkRules"
$CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas"


if ($WebhookData) {
    $WebhookBody = $WebhookData.RequestBody | ConvertFrom-Json
    $subscriptionId = $WebhookBody.subject.Split("/")[2]

    # if we have webhook data, the following variables will be overwritten if also passed in
    $TargetSubscription = (Get-AzSubscription -SubscriptionId $subscriptionId).Name
    $TargetEhNamespaceRG = $WebhookBody.subject.Split("/")[4]
    $TargetEhNamespace = $WebhookBody.subject.Split("/")[8]

    Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $TargetSubscription"
    $Context = Set-AzContext -Subscription $TargetSubscription

    # check the appId that resulted in the alert fireing.  If it was our runbook runas account, don't call the runbook again.
    # if the alert that called this runnbook was generated via a change from the web logging runbook, we don't need/want
    # to call the runbook again.
    # these appids are for the service principals that are the runas accounts for our runbook
    #   SP-AA-InfraMgmt-Az-D   6e5ed314-7154-4254-84b0-e43f1c638615
    #   SP-AA-InfraMgmt-Az-P   aed58b11-d650-4e8f-b740-30704654d758
    $callerAppId = $WebhookBody.data.claims.appid
    if (((Check-CallerIsTrustedAtlasIdentity -callerAppId $callerAppId) -eq $false) `
            -and $null -ne $WebhookBody.subject) {
        try {
            Do-ProcessEventHubResource -ehNamespaceRG $TargetEhNamespaceRG -ehNamespace $TargetEhNamespace -Context $Context
        }
        catch {
            if ($_.Exception.Message.Contains("Operation returned an invalid status code 'NotFound'")) {
                Write-AtlasOutput -LogLevel "WARN" -Message "$TargetEhNamespace was unable to be found. This resource is believed to have been deleted during processing."
            }
            else {
                throw $_
            }
        }
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "This alert was generated via a change from trusted source $callerAppId, so no action taken."
        Write-AtlasOutput -LogLevel "INFO" -Message "  TargetSubscription:  $TargetSubscription"
        Write-AtlasOutput -LogLevel "INFO" -Message "  TargetEhNamespaceRG:  $TargetEhNamespaceRG"
        Write-AtlasOutput -LogLevel "INFO" -Message "  TargetEhNamespace:  $TargetEhNamespace"
    }

}
elseif ($TargetSubscription -and $TargetEhNamespaceRG -and $TargetEhNamespace) {
    # this case exists for manual triggering of the runbook
    Write-AtlasOutput -LogLevel "INFO" -Message "TargetSubscription:  $TargetSubscription"
    Write-AtlasOutput -LogLevel "INFO" -Message "TargetEhNamespaceRG:  $TargetEhNamespaceRG"
    Write-AtlasOutput -LogLevel "INFO" -Message "TargetEhNamespace:  $TargetEhNamespace"
    $subFound = Get-AzSubscription | Where-Object { $_.name -eq $TargetSubscription }
    $Context = Set-AzContext -Subscription $TargetSubscription

    if ($subFound) {
        Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $TargetSubscription"
        $Context = Set-AzContext -Subscription $TargetSubscription
        $ehFound = Get-AzEventHubNamespace -ResourceGroupName $TargetEhNamespaceRG -Namespace $TargetEhNamespace -ErrorAction SilentlyContinue -DefaultProfile $Context
        if ($ehFound) {
            try {
                Do-ProcessEventHubResource -ehNamespaceRG $TargetEhNamespaceRG -ehNamespace $TargetEhNamespace -Context $Context
            }
            catch {
                if ($_.Exception.Message.Contains("Operation returned an invalid status code 'NotFound'")) {
                    Write-AtlasOutput -LogLevel "WARN" -Message "$TargetEhNamespace was unable to be found. This resource is believed to have been deleted during processing."
                }
                else {
                    throw $_
                }
            }
        }
        else {
            Write-AtlasOutput -LogLevel "WARN" -Message "Invalid TargetEhNamespaceRG: $TargetEhNamespaceRG TargetEhNamespace: $TargetEhNamespace"
        }
    }
    else {
        Write-AtlasOutput -LogLevel "WARN" -Message "Invalid TargetSubscription: $TargetSubscription"
    }
}
else {
    Write-AtlasOutput -LogLevel "ERROR" -Message "No valid inputs provided for processing."
}

Write-AtlasOutput -LogLevel "INFO" -Message "Job Complete"

