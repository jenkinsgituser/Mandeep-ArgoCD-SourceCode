
$CONST_ATLAS_EXCEPTIONS_TAG = "AtlasExceptions"
$CONST_KEY_ROTATION_EXCEPTION_VALUE = "KeyRotationException"
$CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas"

#Function to rotate SAS keys for Event Hub
function Invoke-AtlasEventHub-EnforceSASPolicies {
    param(
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,
        [Parameter(Mandatory = $true)]
        [string] $namespaceName,
        [Parameter(Mandatory = $true)]
        [psObject] $Context
    )

    $ErrorActionPreference = "Continue"
    $CONST_ROOT_KEY = "RootManageSharedAccessKey"

    $authRules = Get-AzEventHubAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $namespaceName
    foreach ($authRule in $authRules) {

        $ruleName = $authRule.name
        if ($ruleName -eq $CONST_ROOT_KEY) {
            #do for both Primary and Secondary
            @('PrimaryKey', 'SecondaryKey') | ForEach-Object {
                New-AzEventHubKey -ResourceGroupName $ResourceGroup -Namespace $namespaceName -Name $ruleName -RegenerateKey $_ | Out-Null
                Write-Verbose -Verbose "`t `t `t Rotated key $($_) for SAS $ruleName on namespace $namespaceName"
            }
        }
        else {
            Remove-AzEventHubAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $namespaceName -Name $ruleName -Force
            Write-Verbose -Verbose "`t `t `t Removed authorization rule for SAS $ruleName on namespace $namespaceName"
        }
    }

    #delete any SAS configured on Event Hubs -- we're not using them
    #######################################################################
    Get-AzEventHub -ResourceGroupName $ResourceGroup -Namespace $namespaceName | ForEach-Object {
        $eventHubName = $_.Name
        Get-AzEventHubAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $namespaceName -EventHubName $eventHubName | ForEach-Object {
            Remove-AzEventHubAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $namespaceName -EventHubName $eventHubName -Name $_.Name -Force
            Write-Verbose -Verbose "Removed rule $($_.Name) for Event Hub $eventHubName on namespace $namespaceName"
        }
    }
}

#Function to identify the Atlas resource groups from ALL groups
#################################################################
function Get-AllAtlasEventHubs {
    param
    (
        [Parameter(Mandatory = $true)]
        [psObject] $Context
    )
    return Get-AzResource -ResourceType "Microsoft.EventHub/namespaces" -DefaultProfile $Context | Where-Object { $_.tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER }
}

#Main
#################################################################

# wrap in an IsTest variable check to enable unit testing of functions in this script
if ($env:IsTest -ne $true) {

    $VerbosePreference = "SilentlyContinue"
    Import-Module Az.Accounts | Out-Null
    Import-Module Az.Network | Out-Null
    Import-Module Az.Resources | Out-Null
    Import-Module Az.EventHub | Out-Null
    $VerbosePreference = "Continue"

    #https://docs.microsoft.com/en-us/azure/automation/automation-runbook-execution#working-with-multiple-subscriptions
    Disable-AzContextAutosave -Scope Process | Out-Null

    # Connect via Azure Automation RunAs account
    try {
        Write-Output "Connecting to Automation Account"
        $spConnection = Get-AutomationConnection -Name "AzureRunAsConnection"
        Write-Output "Logging in to Azure with Automation Account..."

        $Info = Connect-AzAccount `
            -ServicePrincipal `
            -TenantId $spConnection.TenantId `
            -ApplicationId $spConnection.ApplicationId `
            -CertificateThumbprint $spConnection.CertificateThumbprint

        Write-Output "Connected as Automation Account: $($spConnection.ApplicationId)."
    }
    catch {
        if (!$spConnection) {
            $ErrorMessage = "AzureRunAsConnection not found."
            throw $ErrorMessage
        }
        else {
            Write-Error -Message $_.Exception
            throw $_.Exception
        }
    }

    Write-Output "Start Time: $(Get-Date)"
    Write-Output "`r"


    #process each subscription for Event Hub
    $subscriptions = Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object name
    foreach ($sub in $subscriptions) {
        Write-Output "`t Processing subscription $($sub.Name)..."
        $Context = Set-AzContext -Subscription $sub
        $AtlasEventHubs = Get-AllAtlasEventHubs -Context $Context
        foreach ($AtlasEventHub in $AtlasEventHubs) {
            Write-Output "`t `t Processing Event Hub Namespace: $($AtlasEventHub.Name)"
            # if the Event Hub namespace isn't tagged as an KeyRotation exception, rotate the keys
            if ($AtlasEventHub.Tags.$CONST_ATLAS_EXCEPTIONS_TAG -notmatch $CONST_KEY_ROTATION_EXCEPTION_VALUE) {
                Invoke-AtlasEventHub-EnforceSASPolicies -ResourceGroup $AtlasEventHub.ResourceGroupName -namespaceName $AtlasEventHub.Name -Context $Context
            }
            else {
                # else it is tagged as an exception, so warn that this is so and move onwards
                Write-Warning "Event Hub Namespace '$($AtlasEventHub.Name)' will not have its keys rotated due to being tagged with a KeyRotation exception."
            }

            Write-Output "`t `t $($AtlasEventHub.ResourceGroupName) processed."
        }
        Write-Output "`t $($sub.Name) processed."
    }

    Write-Output "End Time: $(Get-Date)"
    Write-Output "`r"

    Write-Output "Job complete."
}