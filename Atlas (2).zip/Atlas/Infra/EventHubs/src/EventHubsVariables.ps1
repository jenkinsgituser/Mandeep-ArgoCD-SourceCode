#########################################################################
$SUBSCRIPTION_NAME = $(az account show --query name -o tsv)
Write-Verbose "SUBSCRIPTION_NAME: $SUBSCRIPTION_NAME" -Verbose

Write-Verbose "Determine environment (prod vs. nonprod)" -Verbose
$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "$SUBSCRIPTION_NAME"
$environment = $SubscriptionProperties.environment
Write-Verbose "Environment: $environment " -Verbose
#########################################################################

$DEPLOYMENT_NAME = "azuredeployEventHubsNamespace-$(Get-Date -f yyyyMMddHHmmss)"
Write-Verbose "DEPLOYMENT_NAME: $DEPLOYMENT_NAME" -Verbose

$EH_RG_NAME = $(If ($env:EH_RG_NAME) { "$env:EH_RG_NAME" } Else { Write-Error "EH_RG_NAME: Resource Group must be set as an environment variable."; Exit 1 })
Write-Verbose "EH_RG_NAME: $EH_RG_NAME" -Verbose

# Set the Event Hub location
if ($env:EH_LOCATION) {
  $EH_LOCATION = $env:EH_LOCATION
  Write-Verbose "EH_LOCATION was passed in and will be used" -Verbose
}
elseif ($env:ATLAS_DEFAULT_LOCATION) {
  $EH_LOCATION = $env:ATLAS_DEFAULT_LOCATION
  Write-Verbose "ATLAS_DEFAULT_LOCATION was passed in and will be used" -Verbose
}
else {
  $EH_LOCATION = $DEFAULT_LOCATION
  Write-Verbose "Location was NOT passed in and will be using the default location" -Verbose
}
## Bring in Atlas-CommonCode for Get-AtlasAllowedNetworkRules
. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

# get list of Atlas allowed ip Addresses
$ipAddressRules = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
$ipRules = @()
foreach ($ipAddressRule in $ipAddressRules) {
  $property = @{"ipMask" = $ipAddressRule; "action" = "allow" }
  $ipRules += New-Object pscustomobject -Property $property
}

# format ip list as json for arm template
$ipRules = $ipRules | ConvertTo-Json -Compress -Depth 50
#$ipRules = $ipRules.Replace('"', '\"')
Write-Verbose "IP Network Rules being added to event hub name space:" -Verbose
Write-Verbose "$ipRules" -Verbose

$EH_LOCATION = $EH_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "EH_LOCATION: $EH_LOCATION" -Verbose

#note that the namespace needs to be unique
#https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-create-namespace-portal
$EH_NAMESPACE = $(If ($env:EH_NAMESPACE) { "$env:EH_NAMESPACE" } Else { Write-Error "EH_NAMESPACE: Event Hubs namespace must be set as an environment variable."; Exit 1 })
Write-Verbose "EH_NAMESPACE: $EH_NAMESPACE" -Verbose

#only premium tier supported due to newtorking requirements
$EH_SKU = "Standard"
Write-Verbose "EH_SKU: $EH_SKU" -Verbose

$CREATED_DATE = Get-Date -Format "yyyy-MM-dd"
Write-Verbose "CREATED_DATE: $CREATED_DATE" -Verbose
