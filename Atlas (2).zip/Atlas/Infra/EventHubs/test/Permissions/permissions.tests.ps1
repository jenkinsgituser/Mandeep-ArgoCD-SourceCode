param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)



Describe "Permission Validation Tests" {
    BeforeAll {
        # source the _include file
        . ("$INFRA_FOLDER/EventHubs/test/_includes.tests.ps1")

        if ($env:IsLocal) {
            Write-Verbose "Skipping permissions tests when running local, no access to test" -Verbose
            exit
        }

        $EXPECTED_PERM_IDENTIFIER = "R-TeamTitan-LSA"
        $EXPECTED_ROLE_EH = "Azure Event Hubs Data Owner"

        . ("$env:DEPLOY_FOLDER/EventHubs/operations/addAccessPolicy.ps1") -namespaceName $($env:EH_NAMESPACE) -resourceGroupName $resourceGroup -identity $EXPECTED_PERM_IDENTIFIER -Permissions $EXPECTED_ROLE_EH

    }


    It "Permissions Assigned to Namespace" {
        $rgResources = $(az resource list -g $resourceGroup -n $env:EH_NAMESPACE) | ConvertFrom-Json
        $ehResource = $rgResources | Where-Object { $_.type -eq "Microsoft.EventHub/namespaces" -and $_.name -eq $env:EH_NAMESPACE }
        $roles = $(az role assignment list --scope $ehResource.Id) | ConvertFrom-Json
        $roles | Should -Not -Be $null
        $roles | Where-Object { $_.principalName -eq $EXPECTED_PERM_IDENTIFIER } | Should -Not -Be $null
        $($roles | Where-Object { $_.principalName -eq $EXPECTED_PERM_IDENTIFIER }).roleDefinitionName | Should -Be $EXPECTED_ROLE_EH
    }
}