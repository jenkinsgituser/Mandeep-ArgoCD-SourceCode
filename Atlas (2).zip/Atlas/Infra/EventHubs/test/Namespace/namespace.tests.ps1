param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)



Describe "Namespace Deployment Tests" {

    BeforeAll {
        # source the _include file
        . ("$INFRA_FOLDER/EventHubs/test/_includes.tests.ps1")

        #expect this list of resources to evolve as our usage evolves...
        $EXPECTED_RESOURCE_TYPES = @("Microsoft.EventHub/namespaces")

        # Set the Event Hub location based on user input
        if ($env:EH_LOCATION) {
            $EXPECTED_LOCATION = $env:EH_LOCATION
            Write-Verbose "EH_LOCATION was passed in and will be used" -Verbose
        }
        elseif ($env:ATLAS_DEFAULT_LOCATION) {
            $EXPECTED_LOCATION = $env:ATLAS_DEFAULT_LOCATION
            Write-Verbose "ATLAS_DEFAULT_LOCATION was passed in and will be used" -Verbose
        }
        else {
            $EXPECTED_LOCATION = $DEFAULT_LOCATION
            Write-Verbose "Location was NOT passed in and will be using the default location" -Verbose
        }

        $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()
        $EXPECTED_TEMPLATE_VERSION = Get-AtlasVersionNumber

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }
    }

    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }



    It "Resource Group Has Retrievable Configuration" {
        $rgResources | Should -Not -Be $null
    }

    It "Has Expected Location" {
        $ehResource = $rgResources | Where-Object { $_.type -eq $EXPECTED_RESOURCE_TYPES -and $_.name -eq $env:EH_NAMESPACE }
        $ehResource.location | Should -Be $EXPECTED_LOCATION
    }

    It "Titan Atlas Version Number is set in the RG tags" {
        $ehResource = $rgResources | Where-Object { $_.type -eq $EXPECTED_RESOURCE_TYPES -and $_.name -eq $env:EH_NAMESPACE }
        $ehResource.tags.TemplateVersion | Should -Not -Be $null
        $ehResource.tags.TemplateVersion | Should -Not -Be "Unknown"
        $ehResource.tags.TemplateVersion | Should -Not -Be "Titan-Atlas"

        # Validate that the expected value was set into the RG tags
        $ehResource.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION
    }

    Describe "Namespace Verification Tests" {
        It "Invalid Namespace Fails" {
            $result = $(az eventhubs namespace exists --name "Test") | ConvertFrom-Json
            $result.nameAvailable | Should -Be $false
        }

    }
}