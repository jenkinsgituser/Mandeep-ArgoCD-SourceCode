
Describe "Unit Test - Namespace IP Rule Tests" {

    BeforeAll {
        # source the _include file
       . ("$INFRA_FOLDER/EventHubs/test/_includes.tests.ps1")
       #expect this list of resources to evolve as our usage evolves...
       $EXPECTED_IP_RULES = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
       Write-Host "EventHub namespace is $env:EH_NAMESPACE"
       Write-Host "Eventhub Resource Group is $env:EH_RG_NAME"
       $ActualIPs = (Get-AzEventHubNetworkRuleSet -ResourceGroupName $env:EH_RG_NAME -Namespace $env:EH_NAMESPACE).iprule.ipmask
       Write-Host "Actual IPs are $ActualIPs"
       Write-Host "Expected IP rules are $EXPECTED_IP_RULES"
   }

    It "IP Rules are set" {
        $ActualIPs | Should -Not -Be $null
    }
    It "Has only CMFG Corporate PAT Addresses" {
        $ActualIPs | Should -BeIn $EXPECTED_IP_RULES
    }
    It "Has CMFG Corporate PAT Addresses Allowed" {
        $EXPECTED_IP_RULES | Should -BeIn $ActualIPs
    }
}