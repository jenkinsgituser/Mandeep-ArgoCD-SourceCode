param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "Exception Tag Addition Tests" {

    BeforeAll {
        # source the _include file
        . ("$INFRA_FOLDER/EventHubs/test/_includes.tests.ps1")

        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }

        $EHResource = $rgResources | Where-Object { $_.type -eq "Microsoft.EventHub/namespaces" -and $_.name -eq $env:EH_NAMESPACE }
    }

    It "Event Hub Resource found" {
        $EHResource | Should -Not -Be $null
    }

    It "Exception Tag Added" {

        . ("$DEPLOY_FOLDER/EventHubs/operations/modify/azureAddKeyRotationException.ps1") -resourceGroup $resourceGroup -namespaceName $EHResource.name

        $ehNamespace = $(az eventhubs namespace show -n $EHResource.name -g $resourceGroup) | ConvertFrom-Json

        $ehNamespace.tags.$CONST_ATLAS_EXCEPTIONS_TAG | Should -Not -Be $null
        $ehNamespace.tags.$CONST_ATLAS_EXCEPTIONS_TAG | Should -Match $CONST_KEY_ROTATION_EXCEPTION_VALUE
    }
}

Describe "Exception Tag Removal Tests" {

    It "Exception Tag Removed" {
        . ("$DEPLOY_FOLDER/EventHubs/operations/delete/azureDeleteKeyRotationException.ps1") -resourceGroup $resourceGroup -namespaceName $EHResource.name

        $ehNamespace = $(az eventhubs namespace show -n $EHResource.name -g $resourceGroup) | ConvertFrom-Json
        $ehNamespace.tags.$CONST_ATLAS_EXCEPTIONS_TAG | Should -Not -Match $CONST_KEY_ROTATION_EXCEPTION_VALUE
    }
}