
param
(
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup,

  [Parameter(Mandatory = $false)]
  [array] $rgResources = $null
)


Context "Network Rules Tests" {

  BeforeAll {
    # source the _include file
    . ("$INFRA_FOLDER/EventHubs/test/_includes.tests.ps1")

    $EXPECTED_IP_RULES = @("8.36.116.204", "208.91.239.30", "208.91.239.10", "208.91.239.11", "208.91.237.190", "208.91.237.161", "208.91.237.162")
    $CONST_PROBLEM_IP = "1.1.1.1"

    #sandbox specific
    $KNOWN_GOOD_VNET_ID = if ($env:KNOWN_GOOD_VNET_ID) { $env:KNOWN_GOOD_VNET_ID } else { "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-RP-Test/subnets/rp-test-private-subnet" }
    $KNOWN_BAD_VNET_ID = if ($env:KNOWN_BAD_VNET_ID) { $env:KNOWN_BAD_VNET_ID } else { "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/test-nonatlas-eastus2/subnets/default" }
  }

  It "Removes Invalid IP Addresses" {
    # setup some invalid network rules, IP based
    az eventhubs namespace network-rule add --namespace-name $env:EH_NAMESPACE --resource-group $resourceGroup --ip-address $CONST_PROBLEM_IP

    # run the network rules runbook, confirm the rules match expectations
    . "$env:INFRA_FOLDER/EventHubs/guardrails/runbooks/Atlas-EventHubs-Maintenance-NetworkRules.ps1" `
      -TargetSubscription $SUBSCRIPTION_NAME `
      -TargetEhNamespaceRG $resourceGroup `
      -TargetEhNamespace $env:EH_NAMESPACE

    # validate results
    $existingRules = az eventhubs namespace network-rule list --namespace-name $env:EH_NAMESPACE --resource-group $resourceGroup | ConvertFrom-Json
    $existingRules.ipRules.ipMask | Should -Not -Contain $CONST_PROBLEM_IP

    # validate all expected IPs are present
    $EXPECTED_IP_RULES | ForEach-Object {
      $existingRules.ipRules.ipMask | Should -Contain $_
    }
  }
  # Remove skip once AZ.EventHub version 1.91 is included in Windows-2019 image
  It "Removes Invalid Virtual Network Subnet Id" -Skip {

    # setup some invalid network rules, Virtual Network based
    az eventhubs namespace network-rule add --namespace-name $env:EH_NAMESPACE `
      --resource-group $resourceGroup `
      --subnet $KNOWN_BAD_VNET_ID

    az eventhubs namespace network-rule add --namespace-name $env:EH_NAMESPACE `
      --resource-group $resourceGroup `
      --subnet $KNOWN_GOOD_VNET_ID

    # run the network rules runbook, confirm the rules match expectations
    . "$env:INFRA_FOLDER/EventHubs/guardrails/runbooks/Atlas-EventHubs-Maintenance-NetworkRules.ps1" `
      -TargetSubscription $SUBSCRIPTION_NAME `
      -TargetEhNamespaceRG $resourceGroup `
      -TargetEhNamespace $env:EH_NAMESPACE

    # validate results
    $existingRules = az eventhubs namespace network-rule list --namespace-name $env:EH_NAMESPACE --resource-group $resourceGroup | ConvertFrom-Json

    $existingRules.virtualNetworkRules.subnet.id | Should -Contain $KNOWN_GOOD_VNET_ID
    $existingRules.virtualNetworkRules.subnet.id | Should -Not -Contain $KNOWN_BAD_VNET_ID
  }

  # if the bad ID is added first, certain cases can pass even though
  # they will fail when the good ID is added first. So we'll test both orders
  It "Removes Invalid Virtual Network Subnet Id -- Opposite Order of Operations" {

    az eventhubs namespace network-rule add --namespace-name $env:EH_NAMESPACE `
      --resource-group $resourceGroup `
      --subnet $KNOWN_GOOD_VNET_ID

    # setup some invalid network rules, Virtual Network based
    az eventhubs namespace network-rule add --namespace-name $env:EH_NAMESPACE `
      --resource-group $resourceGroup `
      --subnet $KNOWN_BAD_VNET_ID

    # run the network rules runbook, confirm the rules match expectations
    . "$env:INFRA_FOLDER/EventHubs/guardrails/runbooks/Atlas-EventHubs-Maintenance-NetworkRules.ps1" `
      -TargetSubscription $SUBSCRIPTION_NAME `
      -TargetEhNamespaceRG $resourceGroup `
      -TargetEhNamespace $env:EH_NAMESPACE

    # validate results
    $existingRules = az eventhubs namespace network-rule list --namespace-name $env:EH_NAMESPACE --resource-group $resourceGroup | ConvertFrom-Json

    $existingRules.virtualNetworkRules.subnet.id | Should -Contain $KNOWN_GOOD_VNET_ID
    $existingRules.virtualNetworkRules.subnet.id | Should -Not -Contain $KNOWN_BAD_VNET_ID
  }
}