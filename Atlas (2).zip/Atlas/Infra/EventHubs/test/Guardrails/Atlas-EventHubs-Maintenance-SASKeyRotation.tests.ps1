param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Context "SAS Key Rotation Tests" {
    BeforeAll {

        # source the _include file
        . ("$INFRA_FOLDER/EventHubs/test/_includes.tests.ps1")

        # set to true to ensure the below runbook doesn't run fully, allowing us to source the functions
        $env:IsTest = $true
        . "$env:INFRA_FOLDER/EventHubs/guardrails/runbooks/Atlas-EventHubs-Maintenance-SASKeyRotation.ps1"

        $originalKeys = az eventhubs namespace authorization-rule keys list --name "RootManageSharedAccessKey" `
        --namespace-name $env:EH_NAMESPACE `
        --resource-group $resourceGroup | ConvertFrom-Json

    }


    # get the inital key values
    It "Fetched Initial Values" {
        $originalKeys.primaryKey | Should -Not -Be $null
        $originalKeys.secondaryKey | Should -Not -Be $null
    }

     # Remove skip once AZ.EventHub version 1.91 is included in Windows-2019 image
    It "Rotated All Keys" -Skip {
        # run the script against the target event hub namespace
        Invoke-AtlasEventHub-EnforceSASPolicies -ResourceGroup $resourceGroup -namespaceName $env:EH_NAMESPACE -Context (Get-AzContext)

        $updatedKeys = az eventhubs namespace authorization-rule keys list --name "RootManageSharedAccessKey" `
            --namespace-name $env:EH_NAMESPACE `
            --resource-group $resourceGroup | ConvertFrom-Json
        # get the final key values and confirm they're different
        $updatedKeys.primaryKey | Should -Not -Be $originalKeys.primaryKey
        $updatedKeys.secondaryKey | Should -Not -Be $originalKeys.secondaryKey
    }

}