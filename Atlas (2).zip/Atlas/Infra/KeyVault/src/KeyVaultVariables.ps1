#**********************************************************
# App Service KV variables
#**********************************************************
$KV_CREATE_NEW = $(If ($env:KV_CREATE_NEW) { [System.Convert]::ToBoolean($env:KV_CREATE_NEW) } Else { $true })
Write-Verbose "KV_CREATE_NEW: $KV_CREATE_NEW" -Verbose

$KV_NAME = Set-ValidateResourceNameVariable -variableName "KV_NAME" -variableValue $env:KV_NAME -variablePrefix $CONST_KV_PREFIX
#https://docs.microsoft.com/en-us/azure/architecture/best-practices/naming-conventions#naming-rules-and-restrictions
if ($KV_NAME.length -lt 1 -or $KV_NAME.length -gt 24) {
    Write-Error "Key Vault name must be passed in. It should be between 1 to 24 characters in length." -ErrorAction Stop
}
Write-Verbose "KV_NAME: $KV_NAME" -Verbose
$KV_RG_NAME = $(If ($env:KV_RG_NAME) { "$env:KV_RG_NAME" } Else { Write-Error "KV_RG_NAME: Resource Group must be set as an environment variable."; Exit 1 })
Write-Verbose "KV_RG_NAME: $KV_RG_NAME" -Verbose

if ($env:KV_LOCATION) {
    $KV_LOCATION = $env:KV_LOCATION
}
else {
    $KV_LOCATION = $(If ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { $DEFAULT_LOCATION })
}

Write-Verbose "KV_LOCATION: $KV_LOCATION" -Verbose

$KV_SKU = $(If ($env:KV_SKU) { "$env:KV_SKU" } Else { $CONST_KV_SKU_DEFAULT })
Write-Verbose "KV_SKU: $KV_SKU" -Verbose

$AA_SP_PROVISIONING_SP = Get-ProvisioningObjectId
Write-Verbose "AA_SP_PROVISIONING_SP: $AA_SP_PROVISIONING_SP" -Verbose
## Bring in Atlas-CommonCode for Get-SubscriptionProperties
. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
$ATLAS_ENVIRONMENT = $SubscriptionProperties.environment

Write-Verbose "Atlas Environment: $ATLAS_ENVIRONMENT" -Verbose

##############################################################################
#Generate Array of Objects for vnet firewall rules
$AKS_RGS = $(If ($env:AKS_RGS) { "$env:AKS_RGS" } Else { $null })
$VNETS = $(If ($env:VNETS) { "$env:VNETS" } Else { $null })
$SUBNETS = $(If ($env:SUBNETS) { "$env:SUBNETS" } Else { $null })

if ($AKS_RGS) {
    Write-Verbose "RGs: $AKS_RGS" -Verbose
    [array]$AKS_RGS = ($AKS_RGS.Replace(' ', '')).Split(',')
}
if ($VNETS) {
    Write-Verbose "VNETS: $VNETS" -Verbose
    [array]$VNETS = ($VNETS.Replace(' ', '')).Split(',')
}
if ($SUBNETS) {
    Write-Verbose "SUBNETS: $SUBNETS" -Verbose
    [array]$SUBNETS = ($SUBNETS.Replace(' ', '')).Split(',')
}

# get list of Atlas allowed ip Addresses
$ipAddressRules = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
$ipRules = @()
foreach ($ipAddressRule in $ipAddressRules) {
    $property = @{"value" = $ipAddressRule; "action" = "allow" }
    $ipRules += New-Object pscustomobject -Property $property
}

# format ip list as json for arm template
$ipRules = $ipRules | ConvertTo-Json -Compress -Depth 50
#$ipRules = $ipRules.Replace('"', '\"')

Write-Verbose "IP Network Rules being added to keyvault:" -Verbose
Write-Verbose "$ipRules" -Verbose

#only execute if we have inputs to process
if ($AKS_RGS) {
    $NETWORKRULES = $(Set-NetworkRulesJSON -resourceGroups $AKS_RGS -vNets $VNETS -subnetNames $SUBNETS)
    Write-Verbose "NETWORKRULES: $NETWORKRULES" -Verbose
}
else {
    $NETWORKRULES = '[]'
    Write-Verbose "Network Rules Resource Groups were not passed." -Verbose
}
##############################################################################