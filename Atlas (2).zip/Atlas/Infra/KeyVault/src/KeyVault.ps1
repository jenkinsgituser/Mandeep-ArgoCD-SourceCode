. ("$INFRA_FOLDER/KeyVault/src/KeyVaultVariables.ps1")
#adding this code to check if RG location same as KV Location
#The line below with get-azresourcegroup is performing the same action as the command with az group show, except it is PS command
#The reason why it is left here and commented ut is, if cli command fails to work, we can try using this PS command.
#$Context = Set-AzContext -SubscriptionName $SUBSCRIPTION_NAME -ErrorAction SilentlyContinue
#$KV_RG_Location = (Get-AzResourceGroup -Name $KV_RG_NAME -DefaultProfile $Context).Location
$KV_RG_LOCATION = (az group show --resource-group $KV_RG_NAME --subscription $SUBSCRIPTION_NAME | ConvertFrom-Json).Location
if ($KV_RG_Location -ne $KV_LOCATION) {
    Write-Warning -Message "The KeyVault deployment Location: $KV_LOCATION is not the same as The Resource group: $KV_RG_NAME , location: $KV_RG_Location" -Verbose
}

Write-Verbose "Deploying Key Vault..." -Verbose

$KV_TEMPLATE_FILE = "$INFRA_FOLDER/KeyVault/src/KeyVault.json"
Write-Verbose "KV_TEMPLATE_FILE: $KV_TEMPLATE_FILE" -Verbose

$DEPLOYMENT_NAME = "deployKeyVault-$(Get-Date -f yyyyMMddHHmmss)"
Write-Verbose "DEPLOYMENT_NAME: $DEPLOYMENT_NAME" -Verbose

$Action = {
    az deployment group create `
        -g "$KV_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$KV_TEMPLATE_FILE" `
        --parameters "createdDate=$CREATED_DATE" `
        "keyVaultName=$KV_NAME" `
        "portfolioRMObjectId=$RUNNING_ACCOUNT_OBJECT_ID" `
        "provisioningObjectId=$AA_SP_PROVISIONING_SP" `
        "location=$KV_LOCATION" `
        "sku=$KV_SKU" `
        "ipRules=$ipRules" `
        "allowedSubNetIds=$NETWORKRULES" `
        "enableSoftDelete=$ENABLE_SOFT_DELETE" `
        "TemplateVersion=$TEMPLATE_VERSION"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Key Vault: $KV_NAME" -Verbose

