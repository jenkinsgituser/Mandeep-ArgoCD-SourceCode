param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "Key Vault Deployment Tests" {
    #sourcing KeyVault variable files, to get the location
    . ("$INFRA_FOLDER/KeyVault/src/KeyVaultVariables.ps1")
    $EXPECTED_LOCATION = $KV_LOCATION 

    ## Bring in Atlas-CommonCode
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

    BeforeAll {
        . ("$INFRA_FOLDER/KeyVault/src/KeyVaultVariables.ps1")
        . ("$env:COMMON_FOLDER/utilities.ps1")

        $EXPECTED_LOCATION = $KV_LOCATION 

        # Expect this list of resources to evolve as our usage evolves...
        $EXPECTED_RESOURCE_TYPE = "Microsoft.KeyVault/vaults"
        $EXPECTED_LOCATION = $KV_LOCATION 
        $EXPECTED_TEMPLATE_VERSION = Get-AtlasVersionNumber 

        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }
    
        $kvResource = $rgResources | Where-Object { $_.type -eq $EXPECTED_RESOURCE_TYPE }
        $kv = az keyvault show --name $kvResource.name | ConvertFrom-Json
    }

    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    It "Resource Group Has Retrievable Configuration" {
        $rgResources | Should -Not -Be $null
    }

    It "Has Correct Resources in Expected Quantities" {
        $kvResource.type | Should -Be $EXPECTED_RESOURCE_TYPE
        $($kvResource | Where-Object { $_.type -eq $EXPECTED_RESOURCE_TYPE } | Measure-Object).Count | Should -Be 1
    }

    It "Has Expected Location" {
        $kvResource.location | Should -Be $EXPECTED_LOCATION
    }

    It "Titan Atlas Version Number is set into the RG tags" {
        $rgResources | ForEach-Object {
            # Ignore the default Failure Anomalies cluster Alerts as the version number is not set on it.
            if ($_.type -eq $EXPECTED_RESOURCE_TYPE) {
                $_.tags.TemplateVersion | Should -Not -Be $null
                $_.tags.TemplateVersion | Should -Not -Be "Unknown"
                $_.tags.TemplateVersion | Should -Not -Be "Titan-Atlas"

                # Validate that the expected value was set into the RG tags
                $_.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION
            }
        }
    }

    if ($env:AKS_RGs) {
        foreach ($rg in $env:AKS_RGs.Replace(' ', '').Split(',')) {
            It "Has Expected Network Rules" {
                $allowedVNet = az keyvault network-rule list --name $kvResource.name | ConvertFrom-Json
                $allowedVNet | Should -Not -Be $null
                $allowedVNet.ipRules | Should -Not -Be $null
                $allowedVNet.virtualNetworkRules | Should -Not -Be $null
                $allowedVNet.virtualNetworkRules | Should -Match $rg
            }
        }
    }
    $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
    $ATLAS_ENVIRONMENT = $SubscriptionProperties.environment

    # $kv = az keyvault show --name $kvResource.name | ConvertFrom-Json
    It "Has Soft Delete Enabled" {
        $kv.properties.enableSoftDelete | Should -Be $true
        }
   }