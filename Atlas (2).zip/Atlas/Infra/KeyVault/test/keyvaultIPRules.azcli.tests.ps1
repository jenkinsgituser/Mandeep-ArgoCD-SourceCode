Describe "Unit Test - Namespace IP Rule Tests" {
    # Source Atlas-CommonCode
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

    BeforeAll {
        . ("$INFRA_FOLDER/KeyVault/src/KeyVaultVariables.ps1")
        $EXPECTED_LOCATION = $KV_LOCATION 

        # Expect this list of resources to evolve as our usage evolves...
        $EXPECTED_IP_RULES = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value

        # Get keyvault ipRules
        $kvNetworkRules = az keyvault network-rule list --name $KV_NAME | ConvertFrom-Json
        $IPRulesToBeTested = ($kvNetworkRules.ipRules).value -replace "/32"
    }

    It "Bypass rule is set" {
        $kvNetworkRules.bypass | Should -Be "AzureServices"
    }
    
    It "IP Rules are set" {
        $IPRulesToBeTested | Should -Not -Be $null
    }

    It "Has an Expected IP Rule" {
        ForEach ($IP in $IPRulesToBeTested) {
            Write-Verbose "Tested IP Rule: $IP" -Verbose
            $IP | Should -BeIn $EXPECTED_IP_RULES
        }
    }
}