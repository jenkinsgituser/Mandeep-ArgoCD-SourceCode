﻿<#
 This script processes Atlas Key Vaults to validate Network Rules fall into one of a few categories
 --- if the Key Vault has a "AtlasExceptions" tag which matches "Network", no immediate validation is performed. Processing is deferred until a future time after which
       this tag has been removed by a bi-daily job which has a sole puprose of validating these tags.
 --- if the Key Vault has an "AtlasPurpose" tag which matches $CONST_ATLAS_FUNCTION_APP_PURPOSE, it will be evaluated using logic in support of Atlas Function Apps
 --- if the Key Vault does not match either of the above, it will be evaluated as a generic Atlas Key Vault, which
       enforces the existence of only the CMFG PAT addresses as our desired state.
#>

param
(
    [Parameter(Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)
$CONST_ATLAS_IDENTIFIER = "Titan-Atlas"
$CONST_FUNCTION_RESOURCE_TYPE = "Microsoft.Web/sites"
$CONST_FUNCTION_APP_TYPE = "functionapp"
$CONST_ATLAS_FUNCTION_APP_PURPOSE = "Atlas-FunctionApp"


function Get-AtlasResourceConfiguration {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $ResourceName,

        [Parameter(Mandatory = $true)]
        [AtlasResourceType] $AtlasResourceType,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken
    )

    $subscriptionID = (Get-AzContext).Subscription.id

    switch ($AtlasResourceType) {
        KeyVault { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.KeyVault/vaults/$($ResourceName)?api-version=2018-02-14" }
        default {
            $errorMsg = "Unable to determine appropriate ARM resource URI."
            Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        }
    }

    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -Uri $uri -Headers $headers -Method 'GET' -UseBasicParsing
    Return $($response.Content | ConvertFrom-Json)
}


function Set-AtlasResourceConfiguration {
    [CmdletBinding(DefaultParameterSetName = "PowerShellObject")]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $ResourceName,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [PSObject] $RulesObj,

        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $JsonBody,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [AtlasResourceType] $AtlasResourceType,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $AccessToken
    )

    if ($RulesObj) {
        #if the object has any Members other than "properties", remove them
        #this allows us to test by passing in objects retrieved from prior calls with minimal
        #modification necessary on our end
        $RulesObj.PSObject.Properties | Where-Object { $_.Name -ne "properties" } | ForEach-Object { $RulesObj.PSObject.Properties.Remove($_.Name) }
        $JsonBody = $RulesObj | ConvertTo-Json -Depth 10
        $JsonBody
    }

    $subscriptionID = (Get-AzContext).Subscription.id
    switch ($AtlasResourceType) {
        KeyVault { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.KeyVault/vaults/$($ResourceName)?api-version=2018-02-14" }
        default {
            $errorMsg = "Unable to determine appropriate ARM resource URI."
            Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        }
    }

    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -Uri $uri -Headers $headers -Method 'PUT' -Body $JsonBody -UseBasicParsing -ContentType "application/json"

    #Write-AtlasOutput -LogLevel "DEBUG" -Message "`t `t response status code: $($response.StatusCode) "
    Return $($response.Content | ConvertFrom-Json)
}

#############################################################################################
#Get Atlas keyvaults with AtlasPurpose tag of Atlas-KeyVault-Generic or Atlas-FunctionApp
#############################################################################################
function Get-AtlasKeyVaults {
    param
    (
        [Parameter(Mandatory = $true)]
        [psobject] $Context
    )

    # only retrieve key vaults tagged for titan-atlas
    Return $(Get-AzKeyVault -DefaultProfile $Context | Where-Object { $_.Tags.TemplateVersion -match $CONST_ATLAS_IDENTIFIER })
}


#validate storage account network acl's
#################################################################
function Get-AtlasFunApp-Outbound-IPs {
    param(
        [Parameter(Mandatory = $true)][psobject]$Context
    )

    [array]$OutBoundIPs = $null

    $AtlasFunApps = Get-AzResource -ResourceType $CONST_FUNCTION_RESOURCE_TYPE -DefaultProfile $Context | `
        Where-Object { ($_.kind -eq $CONST_FUNCTION_APP_TYPE) `
            -and ($_.Tags.TemplateVersion -match $CONST_ATLAS_IDENTIFIER) `
            -and ($_.ResourceGroupName -notmatch "RG-CMFG-NP1-Atlas-Test-") }

    foreach ($AtlasFunApp in $AtlasFunApps) {
        $WebAppInfo = Get-AzResource -ResourceType $CONST_FUNCTION_RESOURCE_TYPE `
            -ResourceGroupName $AtlasFunApp.ResourceGroupName `
            -ResourceName $AtlasFunApp.Name `
            -DefaultProfile $Context

        $InboundIp = $WebAppInfo.Properties.inboundIpAddress
        $HoldBoundIPs = $WebAppInfo.Properties.PossibleOutboundIpAddresses.Split(",")

        # Check if inbound IP address is already in the outbound list, if not, add it
        if (!($HoldBoundIPs | Where-Object { $_ -match $InboundIp })) {
            $HoldBoundIPs = $HoldBoundIPs + $InboundIp
        }

        # Need to add the /32 to each IP
        foreach ($i in $HoldBoundIPs) {
            $OutBoundIPs = $OutBoundIPs + ($I + "/32")
        }
    }

    Return ($OutBoundIPs | Sort-Object | Get-Unique)
}

#################################################################
# Get KV outbound IPs
#################################################################
function Process-KeyVaultWithFunctionAppIntegration {
    param
    (

        [Parameter(Mandatory = $true)]
        [string] $KeyVaultResourceId,

        [Parameter(Mandatory = $true)]
        [array] $SubscriptionFunctionAppIps,

        [Parameter(Mandatory = $true)]
        [array] $StandardKVIpRules
    )

    Write-AtlasOutput -LogLevel "INFO" -Message  "`t `t Processing key vault ResourceID: $KeyVaultResourceId"

    $ResourceGroup = $KeyVaultResourceId.Split('/')[4]
    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Processing key vault with RG: $ResourceGroup"

    $keyVaultNm = $KeyVaultResourceId.Split('/')[8]
    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Processing key vault with name:  $keyVaultNm"

    $keyvault = Get-AtlasResourceConfiguration -AccessToken $accessToken -ResourceGroup $ResourceGroup -ResourceName $keyVaultNm -AtlasResourceType KeyVault

    $changesToApply = $false
    $desiredKvIpRules = $StandardKVIpRules

    # prevent duplicate entries on the Key Vault for individually valid rules
    $uniqueIpsToProcess = $($keyvault.properties.networkAcls.ipRules.value | Get-Unique)

    foreach ($KVIP in $uniqueIpsToProcess) {
        # (if the ip is not a standard rule AND if the ip is not a function App IP) OR if we've already added this IP to our list of desired IPs
        If ((!$ATLAS_STANDARD_IP_RULES.Contains($KVIP) `
                    -and !$SubscriptionFunctionAppIps.Contains($KVIP)) `
                -or $desiredKvIpRules.value.Contains($KVip)) {
            # if it's a standard IP, log it out differently
            if ($StandardKVIpRules.value.Contains($KVIP)) {
                Write-AtlasOutput -LogLevel "INFO" -Message "`t `t `t Standard '$($KVip)' remains on $keyVaultNm"
            }
            else {
                Write-AtlasOutput -LogLevel "WARN" -Message "`t `t `t Removing IP rule '$($KVip)' from $keyVaultNm"
                $changesToApply = $true
            }
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "`t `t `t Valid IP rule '$($KVip)' on $keyVaultNm left as-is."
            $property = @{"value" = $KVip; "action" = "allow" }
            $desiredKvIpRules += New-Object pscustomobject -Property $property
        }
    }

    #now verify our standard ip rules are in the list, if any are missing we need to apply the $desiredKvIpRules (which include all the standard ips)
    foreach ($standardIp in $ATLAS_STANDARD_IP_RULES) {
        if ($standardIp -notin $uniqueIpsToProcess) {
            $changesToApply = $true
        }
    }

    if ($changesToApply) {
        $keyvault.properties.networkAcls.ipRules = $desiredKvIpRules

        Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Converting desired state to JSON and posting..."
        $JsonBody = $keyvault | ConvertTo-Json -Depth 10

        $resp = Set-AtlasResourceConfiguration -AccessToken $accessToken -ResourceGroup $ResourceGroup -ResourceName $keyVaultNm -JsonBody $JsonBody -AtlasResourceType KeyVault

        Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Desired state applied to Key Vault: $keyVaultNm "
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t `t `t No changes. Key Vault $keyVaultNm valid."
    }
}

#validate storage account network acl's
#################################################################
function Process-KeyVaultWithAtlasGenericRules {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $KeyVaultResourceId,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken,

        [Parameter(Mandatory = $true)]
        [array] $StandardKVIpRules,

        [Parameter(Mandatory = $true)]
        [psobject]$Context

    )

    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Processing key vault resourceID: $KeyVaultResourceId "

    $ResourceGroup = $KeyVaultResourceId.Split('/')[4]
    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Processing key vault with RG: $ResourceGroup"

    $keyVaultNm = $KeyVaultResourceId.Split('/')[8]
    Write-AtlasOutput -LogLevel "INFO" -Message  "`t `t Processing key vault with name: $keyVaultNm "

    $keyvault = Get-AtlasResourceConfiguration -AccessToken $accessToken -ResourceGroup $ResourceGroup -ResourceName $keyVaultNm -AtlasResourceType KeyVault

    if (($null -eq $keyvault.properties.networkAcls.ipRules.value) -or (Compare-Object $keyvault.properties.networkAcls.ipRules.value $standardKVIpRules.value)) {

        Write-AtlasOutput -LogLevel "WARN" -Message "`t `t ***nonstandard firewall rules found, setting standard ip rules for key vault: $keyVaultNm"
        $keyvault.properties.networkAcls.ipRules = $StandardKVIpRules
        Write-AtlasOutput -LogLevel "INFO" -Message "`t `t standard firewall rules applied for key vault: $keyVaultNm"
        $changesToApply = $true
    }

    #check firewall exceptions to verify Only AzureServices is checked
    #this is split to an array as its a string value processed as an enum, so ordering
    #really doesn't matter
    $bypassConfig = $($keyvault.properties.networkAcls.bypass -Split ',' -Replace ' ')

    #returns true if there are any differences for
    if (Compare-Object $EXPECTED_BYPASS_VALUES $bypassConfig) {
        $keyvault.properties.networkAcls.bypass = $($EXPECTED_BYPASS_VALUES -join ", ")
        Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Key Vault $keyVaultNm firewall exceptions changed from $bypassConfig to standard: $($EXPECTED_BYPASS_VALUES)"
        $changesToApply = $true
    }

    ##NEED TO CHECK IF THE SUBNET IS IN AN ATLAS RG if not - remove it
    if ($null -ne $keyvault.properties.networkAcls.virtualNetworkRules.id) {
        foreach ($vNetId in $keyvault.properties.networkAcls.virtualNetworkRules.id) {

            #split the vnet ID into its name and RG
            $vNetName = $vNetId.split('/')[8]
            $vnetRg = $vNetId.split('/')[4]

            $vnetResource = Get-AzVirtualNetwork -Name $vNetName -ResourceGroup $vnetRg -DefaultProfile $Context

            if ($vnetResource) {
                $vnetTag = $vnetResource.Tag.TemplateVersion
                if ($null -eq $vnetTag -or !($vnetTag.Contains($CONST_ATLAS_IDENTIFIER))) {
                    Write-AtlasOutput -LogLevel "WARN" -Message "`t `t Identified allowed subnet mismatch on Key Vault $keyVaultNm"

                    #remove subnet -- updated to handle that there could be more than one
                    $keyvault.properties.networkAcls.virtualNetworkRules = ($keyvault.properties.networkAcls.virtualnetworkRules | Where-Object { $_.id -ne $vNetId })

                    Write-AtlasOutput -LogLevel "WARN" -Message "`t `t Key Vault $keyVaultNm allowed subnets updated to be none"
                    $changesToApply = $true
                }
            }
            else {
                Write-AtlasOutput -LogLevel "INFO" -Message "`t `t vnet '$vNetName` not found therefore compliance check not removing rule due to prior inconsistencies in Azure results!"
            }
        }
    }

    if ($changesToApply) {
        Write-AtlasOutput -LogLevel "INFO" -Message"`t `t Converting desired state to JSON and posting..."
        $JsonBody = $keyvault | ConvertTo-Json -Depth 10

        Set-AtlasResourceConfiguration -AccessToken $accessToken -ResourceGroup $ResourceGroup -ResourceName $keyVaultNm -JsonBody $JsonBody -AtlasResourceType KeyVault | Out-Null
        Write-AtlasOutput -Loglevel "INFO" -Message "`t `t Desired state applied to Key Vault $keyVaultNm"
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t `t `t No changes. Key Vault $keyVaultNm is valid."
    }

    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Done processing key vault: $keyVaultNm"
}

#################################################################
# Main
#################################################################
$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module Az.Resources | Out-Null
    Import-Module Az.KeyVault | Out-Null
    Import-Module Az.Automation | Out-Null
    Import-Module Az.Network | Out-Null
    Import-Module Az.Websites | Out-Null
}
catch {
    Write-Warning "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"


#############################################################################################
# Source Atlas-CommmonCode runbook must reside in the same as your runbook
#############################################################################################
Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. ./Atlas-CommonCode.ps1
Write-AtlasOutput -Message " "

Azure-Connect -RunHybridWorker $RunAsHybridWorker

#Setup rules needed by all processing
#######################################################

# define standard firewall rules for services to reference
$ATLAS_STANDARD_IP_RULES = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
$ATLAS_STANDARD_IP_RULES = $ATLAS_STANDARD_IP_RULES | ForEach-Object { if ($_ -notmatch "/") { $_ + "/32"} else {$_} }
$EXPECTED_BYPASS_VALUES = @("AzureServices")

$standardKVIpRules = @()
foreach ($ip in $ATLAS_STANDARD_IP_RULES) {
    $property = @{"value" = $ip; "action" = "allow" }
    $standardKVIpRules += New-Object pscustomobject -Property $property
}

$subscriptions = $(Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object name).name

# get access token here once, instead of in the functions
$currentAzureContext = Get-AzContext
$azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile;
$profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile);

foreach ($subscription in $subscriptions) {
    Write-AtlasOutput -LogLevel "INFO" -Message "`t Processing subscription $subscription..."
    $Context = Set-AzContext -Subscription $subscription
    #the the access token per subscription, in the event that a processing occurrence runs longer than the token lifetime
    $accessToken = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId).AccessToken;

    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Getting all Atlas KeyVaults"
    $AtlasKeyVaults = Get-AtlasKeyVaults -Context $Context

    $SubscriptionFunctionAppIps = $null
    foreach ($KVObj in $AtlasKeyVaults) {
        if (($null -ne $KVObj.Tags.AtlasExceptions) -and ($KVObj.Tags.AtlasExceptions.Contains("Network"))) {
            Write-AtlasOutput -LogLevel "INFO" -Message "`t `t `t Key Vault $($KVObj.VaultName) contains a Network Exception will not check for non-standard ip rules"
        }
        else {
            #no network exception
            if ($KVObj.Tags.AtlasPurpose -match $CONST_ATLAS_FUNCTION_APP_PURPOSE) {
                if ($null -eq $SubscriptionFunctionAppIps) {
                    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Get a list of unique IPs from all Function Apps in this subscription..."
                    $SubscriptionFunctionAppIps = Get-AtlasFunApp-Outbound-IPs -Context $Context
                }

                Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Processing Atlas-FunctionApp for Keyvault: $($KVObj.VaultName)"
                Process-KeyVaultWithFunctionAppIntegration -KeyVaultResourceId $KVObj.ResourceId `
                    -SubscriptionFunctionAppIps $SubscriptionFunctionAppIps `
                    -StandardKVIpRules $standardKVIpRules
            }
            else {
                # Do Atlas-KeyVault-Generic
                Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Processing Atlas-KeyVault-Generic for Keyvault: $($KVObj.VaultName)"
                Process-KeyVaultWithAtlasGenericRules -KeyVaultResourceId $KVObj.ResourceId `
                    -AccessToken $accessToken `
                    -StandardKVIpRules $standardKVIpRules `
                    -Context $Context
            }
        }
    }

    Write-AtlasOutput -LogLevel "INFO" -Message "`t $subscription processed."
    Write-AtlasOutput -Message "`r"
}
Write-AtlasOutput -LogLevel "INFO" -Message "Job complete."

