# This script will do the following:

#  1) Get all Storage Accounts with the Tag Name of AtlasPurpose and a value of Atlas-FunctionApp-StorageAccount
#  2) Validate that the firewall IP addresses are set to the list below
#  3) if they are not set correctly, it will reset them back to the standard list of IP addresses.
#  4) The storage account firewall and vnet settings are checked,if allowed all networks is checked, changed to selected networks
#  5) The Storage Account End points are checked. If the tags on Vnet endpoint do not belong to Atlas-sends out an email
#  6) Associated endpoint subnets on the storage account should not be greater than 2 or less than 1
#  7) Validity of the endpoint subnets on the storage account is checked
#  8) The delegations are checked-need to match Microsoft.Web/serverfarms

param
(
    [Parameter (Mandatory = $false)]
    [PsObject] $WebhookData,

    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)

$CONST_RUNBOOK_NAME = "Atlas-FunctionApp-StorageAccount-FirewallRules"
$CONST_ATLASEXCEPTIONS_TAG_NAME = "AtlasExceptions"
$CONST_ATLASEXCEPTIONS_TAG_VALUE = "TestingException"

#function to get only the storage account with the function app tag.
####################################################################
function Get-AtlasFunctionAppStorageAccounts {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject]$Context,

        [Parameter(Mandatory = $true)]
        [PSObject]$ResourceGroupName
    )

    $ATLAS_SA_PURPOSE_IDENTIFIER = "Atlas-FunctionApp-StorageAccount"
    $ATLAS_TAG_IDENTIFIER = "Titan-Atlas"
    return $(Get-AzStorageAccount -DefaultProfile $Context -ResourceGroupName $ResourceGroupName) | Where-Object { ($_.tags.TemplateVersion -match $ATLAS_TAG_IDENTIFIER) -and ($_.tags.AtlasPurpose -match $ATLAS_SA_PURPOSE_IDENTIFIER) }
}

# Function to set the IP address on the storage account
# to the standard list of IP addresses
####################################################################
function Set-AtlasResourceConfiguration {
    [CmdletBinding(DefaultParameterSetName = "PowerShellObject")]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [PSObject]$Context,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $ResourceName,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [PSObject] $RulesObj,

        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $JsonBody,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [AtlasResourceType] $AtlasResourceType,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $AccessToken
    )

    if ($RulesObj) {
        #if the object has any Members other than "properties", remove them
        #this allows us to test by passing in objects retrieved from prior calls with minimal
        #modification necessary on our end
        $RulesObj.PSObject.Properties | Where-Object { $_.Name -ne "properties" } | ForEach-Object { $RulesObj.PSObject.Properties.Remove($_.Name) }
        $JsonBody = $RulesObj | ConvertTo-Json -Depth 10
        $JsonBody
    }

    $subscriptionID = $Context.Subscription.id

    switch ($AtlasResourceType) {
        FunctionApp { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.ServiceBus/namespaces/$ResourceName/networkRuleSets/default?api-version=2017-04-01" }
        StorageAccount { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Storage/storageAccounts/$($ResourceName)?api-version=2021-08-01" }
        default { Write-AtlasOutput -LogLevel "ERROR" -Message "Unable to determine appropriate ARM resource URI." }
    }

    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -Uri $uri -Headers $headers -Method 'PUT' -Body $JsonBody -UseBasicParsing -ContentType "application/json"
    Return $($response.Content | ConvertFrom-Json)
}

# Function to get the storage account configuration,
# used to validate the firewall IP addresses
####################################################################
function Get-AtlasResourceConfiguration {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject]$Context,

        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $ResourceName,

        [Parameter(Mandatory = $true)]
        [AtlasResourceType] $AtlasResourceType,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken
    )

    $subscriptionID = $Context.Subscription.id

    switch ($AtlasResourceType) {
        FunctionApp { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.ServiceBus/namespaces/$ResourceName/networkRuleSets/default?api-version=2017-04-01" }
        StorageAccount { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Storage/storageAccounts/$($ResourceName)?api-version=2021-08-01" }
        default { Write-AtlasOutput -LogLevel "ERROR" -Message "Unable to determine appropriate ARM resource URI." }
    }

    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -Uri $uri -Headers $headers -Method 'GET' -UseBasicParsing
    Return $($response.Content | ConvertFrom-Json)
}

# Function to validate the list of
# firewall IP address is set to the standard list
####################################################################
function Ensure-StorageAccountNetworkRules {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject]$Context,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken,

        [Parameter(Mandatory = $true)]
        [array] $StandardStorageAcctIpRules,

        [Parameter(Mandatory = $false)]
        [AllowNull()]
        [PSObject]$StorageAccount
    )

    $SAInfo = Get-AtlasResourceConfiguration -Context $Context -AccessToken $accessToken -ResourceGroup $StorageAccount.ResourceGroupName -ResourceName $StorageAccount.StorageAccountName -AtlasResourceType StorageAccount

    Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Checking Storage Account Network IP Rules..."
    $RulesGood = $True
    #Check to see if the Access is allowed from "All Networks" or "Selected Networks"
    if ($($SAInfo.properties.networkAcls.defaultAction) -eq "Allow") {
        Write-AtlasOutput -LogLevel "WARN" -Message " `t`t`t***The storage account has network rules that Allow **All Networks**, changing it to *selected networks only*. Setting standard IP rules*** "
        $SAInfo.properties.networkAcls.defaultAction = "Deny"
        $SAInfo.properties.networkAcls.ipRules = $StandardStorageAcctIpRules
        $RulesGood = $false
    }
    #check to see if the IP Rules are empty
    if ($($SAInfo.properties.networkAcls.ipRules.value) -eq $null) {
        Write-AtlasOutput -LogLevel "WARN" -Message " `t`t`t***The storage account IP Rules are empty. Setting standard IP rules*** "
        $SAInfo.properties.networkAcls.ipRules = $StandardStorageAcctIpRules
        $RulesGood = $false
    }
    else {
        #check to see if the IP rules match standard IP rules
        if (Compare-Object $SAInfo.properties.networkAcls.ipRules.value $standardStorageAcctIpRules.value) {

            Write-AtlasOutput -LogLevel "WARN" -Message "`t `t `t ***nonstandard firewall rules found, setting standard ip rules for storage account $($StorageAccount.StorageAccountName)"
            $SAInfo.properties.networkAcls.ipRules = $StandardStorageAcctIpRules
            $RulesGood = $false
        }
    }

    if ($RulesGood) {
        Write-AtlasOutput  -LogLevel "INFO" -Message "`t `t `t Storage Account Network IP Rules are valid"
    }
    #change to desired state
    else {
        Write-AtlasOutput -LogLevel "WARN" -Message "`t `t `t Converting desired state to JSON and posting..."
        $SAInfo.properties.allowBlobPublicAccess = "False" # ensure this is set false otherwise a Tiger policy will prevent the update
        $JsonBody = $SAInfo | ConvertTo-Json -Depth 10
        Set-AtlasResourceConfiguration -Context $Context -AccessToken $accessToken -ResourceGroup $StorageAccount.ResourceGroupName -ResourceName $StorageAccount.StorageAccountName -JsonBody $JsonBody -AtlasResourceType StorageAccount | Out-Null

        $ErrorMessage = "`t `t Desired state IP Addresses applied to Storage Account: $($StorageAccount.StorageAccountName)"
        Write-AtlasOutput -LogLevel "WARN" -Message $ErrorMessage
        $emailMessageString += "$ErrorMessage `r"
        $sendEmailAlert = $true
    }
    Write-AtlasOutput  -LogLevel "INFO" -Message $("`t `t `t Done checking the IP Rules for the storage account: " + $($StorageAccount.StorageAccountName) )

    ######################## Subnet Endpoint Validations ########################
    # Validating the vnet tag for the storage account endpoint. To make sure that the functionapp accessing the storage account is from a valid vnet.
    #Getting the network rules information and parsing through it to collect variable values.
    Write-AtlasOutput -LogLevel "INFO" -Message $("`t Checking virtual Network rules for storage account: " + $StorageAccount.StorageAccountName)
    $StorageAccount_VirtualNetworkRules = $($(Get-AzStorageAccountNetworkRuleSet  -ResourceGroupName $StorageAccount.resourceGroupName -AccountName $StorageAccount.StorageAccountName -DefaultProfile $Context).VirtualNetworkRules).VirtualNetworkResourceId

    if ($StorageAccount_VirtualNetworkRules.count -eq 0) {
        Write-AtlasOutput -LogLevel "WARN" -Message "The Virtual network rules set of the storage account:'$($StorageAccount.StorageAccountName)', is empty. No subnet has yet been joined..."
    }
    else {
        foreach ($StorageAccountNetwork in $StorageAccount_VirtualNetworkRules) {
            Write-AtlasOutput -LogLevel "INFO" -Message "Evaluating subnet $($StorageAccountNetwork)"
            if ((Validate-NetworkLocationIsAtlasAllowed -subnetResourceId $StorageAccountNetwork -context $Context) -eq $false) {
                Write-AtlasOutput -LogLevel "ERROR" -Message "Disallowed Service Endpoint found. Sending email alert!"
                $sendEmailAlert = $true
                $ErrorMessage = "Subscription '$subscriptionName', resource group '$resourceGroupName', Storage Account '$($StorageAccount.StorageAccountName)'. Storage account contains an untrusted subnet service endpoint: $StorageAccountNetwork!"
                $emailMessageString += "$ErrorMessage `r"
            }

            Write-AtlasOutput -LogLevel "INFO" -Message "`t `t Done confirming service endpoint: $StorageAccountNetwork"
        }
    }
    return @{sendEmailAlert = $sendEmailAlert; emailMessageString = $emailMessageString }
}


####################################################################
# MAIN Procedure
####################################################################

# skip the main and just source the functions if IsTest is set
if ($env:IsTest -ne $true) {

    Write-Verbose -Verbose  "Importing modules...."
    $VerbosePreference = "SilentlyContinue"
    try {
        # do the import in the silenced block
        Import-Module Az.Accounts | Out-Null
        Import-Module Az.Network | Out-Null
        Import-Module Az.Resources | Out-Null
        Import-Module Az.Storage | Out-Null
        Import-Module Az.Automation | Out-Null
        Import-Module Az.KeyVault | Out-Null
    }
    catch {
        Write-Warning "Error importing required modules. $($_.Exception.Message)"
    }
    $VerbosePreference = "Continue"

    Write-Verbose -Verbose "Linking to Atlas-CommonCode Runbook..."
    if ($env:IsLocal -or $env:AGENT_ID) {
        . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
    }
    else {
        . ./Atlas-CommonCode.ps1
        Azure-Connect
    }

    # define standard firewall rules for services to reference
    $ATLAS_STANDARD_IP_RULES = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value

    $standardStorageAcctIpRules = @()
    foreach ($ip in $ATLAS_STANDARD_IP_RULES) {
        $property = @{"value" = $ip; "action" = "allow" }
        $standardStorageAcctIpRules += New-Object pscustomobject -Property $property
    }

    $sendEmailAlert = $false
    $emailMessageString = [string]::empty

    if ($WebhookData) {

        $WebhookBody = $WebhookData.RequestBody | ConvertFrom-Json
        $callerAppId = $WebhookBody.data.claims.appid

        if (((Check-CallerIsTrustedAtlasIdentity -callerAppId $callerAppId) -eq $false) `
                -and $null -ne $WebhookBody.subject) {

            # break down the event data into component pieces necessary for downstream passthrough
            $subscriptionId = $WebhookBody.subject.Split("/")[2]
            $subscriptionName = (Get-AzSubscription -SubscriptionId $subscriptionId).Name

            # get access token here once, instead of in the functions
            $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile;
            $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile);

            if ($subscriptionName.Count -gt 1) {
                throw "Subject '$($WebhookBody.subject)' was not null, but a single subscription could not be parsed."
            }

            Write-AtlasOutput -LogLevel "INFO" -Message "  Subscription Name:  $subscriptionName"
            Write-AtlasOutput -LogLevel "INFO" -Message " "

            # switch to the subscription that had the Atlantis vNet change
            $Context = Set-AzContext -Subscription $subscriptionName

            # Gather information from the webhook
            $resourceGroupName = $WebhookBody.subject.Split("/")[4]
            $resourceName = $WebhookBody.subject.Split("/")[8]

            #check for RG-Tags need to have Titan-Atlas. -- only process if Atlas SA
            if ((Is-RGAtlas-Runbook -resourceGroup $resourceGroupName -Context $Context)) {

                Write-AtlasOutput -LogLevel "INFO" -Message "The Resource Group has a valid Titan-Atlas Tag. Checking the Storage Accounts"
                #the the access token per subscription, in the event that a processing occurrence runs longer than the token lifetime
                $accessToken = $profileClient.AcquireAccessToken($context.Subscription.TenantId).AccessToken;

                # Get the atlas storage accounts related to the functionapp in the subscription
                $StorageAccounts = Get-AtlasFunctionAppStorageAccounts -Context $context -ResourceGroupName $resourceGroupName

                #$StorageAccount = $StorageAccounts
                if (!$StorageAccounts) {
                    Write-AtlasOutput  -LogLevel "WARN" -Message "`t No Atlas Storage Accounts found in this subscription.."
                }
                else {

                    foreach ($StorageAccount in $StorageAccounts) {

                        # needed a way for the real guardrail to ignore this resource while we test it,
                        # but for the guardrail tests to execute against the resource on-demand.
                        if ($StorageAccount.Tags.$CONST_ATLASEXCEPTIONS_TAG_NAME -and `
                                $StorageAccount.Tags.$CONST_ATLASEXCEPTIONS_TAG_NAME -eq $CONST_ATLASEXCEPTIONS_TAG_VALUE -and `
                            (!$env:IsLocal -and !$env:AGENT_ID)) {
                            # last clause will lead to this condition being skipped locally and on build agents
                            Write-AtlasOutput -LogLevel "INFO" -Message "Additional processing skipped as resource is tagged with AtlasExceptions $CONST_ATLASEXCEPTIONS_TAG_VALUE"

                        }
                        else {
                            Write-AtlasOutput -LogLevel "INFO" -Message $("`t Processing storage account: " + $StorageAccount.StorageAccountName)

                            #validating the network rules and checking the allowed IP RULES
                            $emailResults = Ensure-StorageAccountNetworkRules -Context $context `
                                -AccessToken $accessToken `
                                -StandardStorageAcctIpRules $standardStorageAcctIpRules `
                                -StorageAccount $StorageAccount

                            $sendEmailAlert = $emailResults.sendEmailAlert
                            $emailMessageString = $emailResults.emailMessageString
                        }
                    }
                }
                Write-AtlasOutput -LogLevel "INFO" -Message "Done processing subscription $subscription."
            }
            else {
                Write-AtlasOutput -LogLevel "INFO" -Message "The resource group $resourceGroupName does not have a Titan Atlas tag. Exiting the Runbook: $CONST_RUNBOOK_NAME!!!"
            }
        }
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "The Runbook $CONST_RUNBOOK_NAME was not triggered due to a webhook, it must be a scheduled run."

        $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile;
        $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile);

        $subscriptions = (Get-AzSubscription).Name
        foreach ($subscription in $subscriptions) {
            Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $subscription"
            $Context = Set-AzContext -Subscription $subscription

            # get access token here once per subscription
            $accessToken = $profileClient.AcquireAccessToken($Context.Subscription.TenantId).AccessToken;

            # Get Atlas FunctionApp Storage Accounts in the subscription
            $ATLAS_SA_PURPOSE_IDENTIFIER = "Atlas-FunctionApp-StorageAccount"
            $ATLAS_TAG_IDENTIFIER = "Titan-Atlas"
            $StorageAccounts = Get-AzStorageAccount -DefaultProfile $Context | Where-Object { ($_.tags.TemplateVersion -match $ATLAS_TAG_IDENTIFIER) -and ($_.tags.AtlasPurpose -match $ATLAS_SA_PURPOSE_IDENTIFIER) }

            foreach ($StorageAccount in $StorageAccounts) {
                Write-AtlasOutput -LogLevel "INFO" -Message "---Processing storage account: $($StorageAccount.StorageAccountName)"
                $emailResults = Ensure-StorageAccountNetworkRules -Context $Context `
                        -AccessToken $accessToken `
                        -StandardStorageAcctIpRules $standardStorageAcctIpRules `
                        -StorageAccount $StorageAccount

                if ($emailResults.sendEmailAlert -eq $true) {
                    $sendEmailAlertSubLoop = $emailResults.sendEmailAlert
                    $emailMessageString += $emailResults.emailMessageString
                }
            }
        }
        $sendEmailAlert = $sendEmailAlertSubLoop
    }

    #send alert email
    if ($sendEmailAlert) {
        $runbookDetail = Get-RunbookCurrentContext
        $AutomationJobId = $PSPrivateMetadata.JobId.Guid
        $emailMessageString += "`r `r Automation Account Runbook Execution ID: $AutomationJobId"

        $emailFrom = "$($runbookDetail.RunbookName)@cunamutual.com"
        $emailSubject = "ACTION REQUIRED: $($runbookDetail.RunbookName), Network Validation Alert"

        $emailBody = "Below is a list of invalid FunctionApp StorageAccount instances `r `r"
        $emailBody += $emailMessageString
        $emailBody += "`r `r Executed from $($runbookDetail.AutomationAccountName), Runbook is $($runbookDetail.RunbookName)."
        $messageBody = $emailBody | Out-String
        try {
            Send-TeamTitanEmailAlert -emailFrom $emailFrom -emailSubject $emailSubject -EmailbodyData $messageBody -ErrorAction stop
        }
        catch {
            $errorMessage = "ERROR: Failed to send email."
            throw $errorMessage
        }
    }

    Write-AtlasOutput -LogLevel "INFO" -Message "runbook complete"
}
