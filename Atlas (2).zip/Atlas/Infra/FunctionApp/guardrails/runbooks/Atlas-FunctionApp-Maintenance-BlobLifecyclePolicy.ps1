Param
(
    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)

$ATLAS_FUNCTION_APP_TAG_VALUE = "Atlas-FunctionApp-StorageAccount"

#Function to Enforce a Blob Storage Lifecycle Policy
#################################################################
function Invoke-AtlasStorageAccount-EnforceStorageAccountLifecyclePolicies {
    param
    (
        [string]$ResourceGroup,
        [PsObject]$Context
    )
    $ErrorActionPreference = "Stop"
    $CONST_RULE_NAME = "AtlasFunctionAppStorageAccount"

    #for any storage account in the resource group
    $atlasStorageAccounts = Get-AzStorageAccount -ResourceGroup $ResourceGroup -DefaultProfile $Context | Where-Object { $_.Tags -ne $null -and $_.Tags.AtlasPurpose -eq $ATLAS_FUNCTION_APP_TAG_VALUE }
    foreach ($atlasStorageAccount in $atlasStorageAccounts) {
        Write-AtlasOutput -LogLevel "DEBUG" -Message "Storage Account '$($atlasStorageAccount.StorageAccountName)' was found with Atlas Purpose '$($atlasStorageAccount.Tags.AtlasPurpose)'"

        $policies = Get-AzStorageAccountManagementPolicy -ResourceGroupName $ResourceGroup `
            -StorageAccountName $atlasStorageAccount.StorageAccountName `
            -DefaultProfile $Context -ErrorAction SilentlyContinue
        if (!$policies) {
            Write-AtlasOutput -LogLevel "WARN" -Message "------No policy found for storage account $($atlasStorageAccount.StorageAccountName)"
            $policies = $null
        }

        #if the storage account does not already have the necessary policy, add it
        if ($null -eq $policies `
                -or $null -eq $policies.Rules `
                -or $policies.Rules.Name -notcontains $CONST_RULE_NAME) {

            #Build and apply a storage account lifecycle policy to purge files no more than 2 days after they are created
            try {
                #https://docs.microsoft.com/en-us/azure/storage/blobs/storage-lifecycle-management-concepts#add-or-remove-a-policy
                $action = Add-AzStorageAccountManagementPolicyAction -SnapshotAction Delete -DaysAfterCreationGreaterThan 2 -DefaultProfile $Context
                $action = Add-AzStorageAccountManagementPolicyAction -BaseBlobAction Delete -DaysAfterModificationGreaterThan 2  -InputObject $action -DefaultProfile $Context

                # Create a new filter object
                # PowerShell automatically sets BlobType as “blockblob” because it is the only available option currently
                #mdx7683 - Create filter as an empty object as we don't want to prefix match
                $filter = New-AzStorageAccountManagementPolicyFilter

                #Create a new rule object
                #PowerShell automatically sets Type as “Lifecycle” because it is the only available option currently
                $rule1 = New-AzStorageAccountManagementPolicyRule -Name $CONST_RULE_NAME -Action $action -Filter $filter -DefaultProfile $Context

                #Set the policy
                $policy = Set-AzStorageAccountManagementPolicy -ResourceGroupName $ResourceGroup -StorageAccountName $atlasStorageAccount.StorageAccountName -Rule $rule1 -DefaultProfile $Context

                Write-AtlasOutput -Message "`t `t `t Policy '$CONST_RULE_NAME' added to storage account '$($atlasStorageAccount.StorageAccountName)' in resource group $ResourceGroup"
            }
            catch {
                Write-AtlasOutput -LogLevel "WARN" -Message "`t `t `t Unable to confirm policy '$CONST_RULE_NAME' on storage account '$($atlasStorageAccount.StorageAccountName)' in resource group $ResourceGroup"
            }
        }
        else {
            Write-AtlasOutput -Message "`t `t `t Policy '$CONST_RULE_NAME' exists on storage account '$($atlasStorageAccount.StorageAccountName)' in resource group $ResourceGroup"
        }
    }
}

#Function to identify the Atlas resource groups from ALL groups
#################################################################
function Get-AllAtlasFunctionApps {
    param
    (
        [PsObject]$Context
    )

    $CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas"
    $TYPE = "functionapp"
    $FAs = Get-AzResource -ResourceType "Microsoft.Web/sites" -DefaultProfile $Context | Where-Object { $_.Tags -and $_.Tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER }
    return $FAs | Where-Object { $_.kind -eq $TYPE }
}

#Main
#################################################################

$VerbosePreference = "SilentlyContinue"
#https://docs.microsoft.com/en-us/azure/automation/automation-runbook-execution#working-with-multiple-subscriptions
Disable-AzContextAutosave -Scope Process | Out-Null
Import-Module Az.Resources -ErrorAction SilentlyContinue | Out-Null
Import-Module Az.Accounts -ErrorAction SilentlyContinue | Out-Null
Import-Module Az.Automation -ErrorAction SilentlyContinue | Out-Null
Import-Module Az.Storage -ErrorAction SilentlyContinue | Out-Null
Import-Module Az.Websites -ErrorAction SilentlyContinue | Out-Null
$VerbosePreference = "Continue"

if ($env:IsLocal -or $env:AGENT_ID) {
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
}
else {
    . ./Atlas-CommonCode.ps1
    . ./Atlas-CommonSQLCode.ps1
}

# Connect via Azure Automation RunAs account
Write-AtlasOutput -Message "Start Time: $((Get-Date).AddHours(-5)) `r"

#process each subscription for Service Bus activities
if ($env:IsLocal -or $env:AGENT_ID) {
    Write-AtlasOutput -Message "Running local or on agent. Skipping runbook connect and using CMFG-Sandbox..."
    $subscriptions = @("CMFG-Sandbox")
}
else {
    Azure-Connect
    $subscriptions = $(Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object name).name
}

foreach ($sub in $subscriptions) {
    Write-AtlasOutput -Message "`t Processing subscription $sub..."
    $Context = Set-AzContext -SubscriptionName $sub
    $AtlasFAs = Get-AllAtlasFunctionApps -Context $Context
    $uniqueFunctionResourceGroups = $($AtlasFAs.ResourceGroupName | Get-Unique)
    foreach ($resourceGroup in $uniqueFunctionResourceGroups) {
        Write-AtlasOutput -Message "`t `t Processing resource group: $resourceGroup"
        Invoke-AtlasStorageAccount-EnforceStorageAccountLifecyclePolicies -ResourceGroup $resourceGroup -Context $Context
        Write-AtlasOutput -Message "`t `t $resourceGroup processed."
    }
    Write-AtlasOutput -Message "`t $sub processed."
}

Write-AtlasOutput -Message "End Time: $((Get-Date).AddHours(-5)) `r"

Write-AtlasOutput -Message "Job complete."