#################################################################################################
# Atlas-FunApp-KV-Secret-Rotation (AA-CMFG-P01-InfraMgmt-AZ/Atlas-FunApp-KV-Secret-Rotation)
#
# The purpose of this script is to look for Atlas KV Secrets that have not been changed:
#  1) Look for all Atlas KVs
#  2) Add External IP address to access list of KV
#  3) Look for all secrets that starts with "FunAppWebJobStorageKey-"
#  4) Check the date when the secret was last changed
#  5) If secret changed after $EmailChangePeriod but before $ForceChangePeriod, send email
#  6) If secret changed after $ForceChangePeriod:
#     a) Send necessary information to an existing runbook to force the secret rortation
#        AA Name = AA-CMFG-P01-InfraMgmt-AZ
#        Runbook = Atlas-FunctionApp-RotateStorageAccountKey
#     b) Send email
#  7) Remove External IP address from access list of KV
#################################################################################################

param
(
    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)

######################################################################################
# Source Atlas-CommmonCode runbook must reside in the same as your runbook
######################################################################################
Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. ./Atlas-CommonCode.ps1
Write-AtlasOutput -Message " "


#################################################################################################
# Change peroid is the time when a Secret has not been change.  This is currently in days.
$EmailChangePeriod = 30  # in Days
$ForceChangePeriod = 45  # in Days
$RUNBOOK_NAME = "Atlas-FunApp-KV-Secret-Rotation"
$global:EmailData = $null
$global:SPObjID = $null
$global:HybridWorker = $null
$global:SecretsToRotate = @()
$global:ExternalIP = $null
$global:AASPName = $null


#################################################################################################
# Call a Function App to get the external IP address for this AA
#################################################################################################
function Get-MyIp {
    param(
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )

    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $getMeMyIpSecret = $(Get-AzKeyVaultSecret -VaultName "kv-atlas-SharedSVCs-p" -Name "GetClientIP" -DefaultProfile $SubContext).SecretValue
    $getMeMyIp = [System.Net.NetworkCredential]::new("", $getMeMyIpSecret).Password
    $VerbosePreference = "SilentlyContinue"
    $myIP = Invoke-RestMethod -Method Get -Uri $getMeMyIp
    $VerbosePreference = "Continue"
    return $myIP
}


#################################################################################################
# Standard function to connect as AA
#################################################################################################
function Connect-CMFGAutomationAccount {
    $ConnectionResult = $false

    if ($RunAsHybridWorker) {
        # Attempt to connect to hybrid runbook worker
        try {
            Write-AtlasOutput -Message "Connecting as HybridWork identity..."
            $Context = Connect-AzAccount -Identity
            $ConnectionResult = $true
            $global:SPObjID = "7bba4d1b-aa2d-4e05-9aef-44109a5920fb"
            $global:HybridWorker = (Get-Item Env:computername).value
            Write-AtlasOutput -Message "Hybrid work in use is: $global:HybridWorker"
            $global:AASPName = (Get-Item Env:USERNAME).value
            Write-Verbose "Hybrid user in use is: $global:AASPName" -Verbose
        }
        catch {
            $ErrorMessage = "ERROR: RunAsHybridWorker parameter set to true, but could not connect to hybrid runbook worker."
            Write-Error $ErrorMessage
            throw $ErrorMessage
        }
    }
    else {
        try {
            Write-AtlasOutput -Message "Connecting to Automation Account..."

            $spConnection = Get-AutomationConnection -Name "AzureRunAsConnection"
            $Context = Connect-AzAccount `
                -ServicePrincipal `
                -Tenant $spConnection.TenantID `
                -ApplicationId $spConnection.ApplicationID `
                -CertificateThumbprint $spConnection.CertificateThumbprint
            $global:AASPName = (Get-AzADServicePrincipal -ApplicationId $spConnection.ApplicationID).DisplayName

            $ConnectionResult = $true
            Write-AtlasOutput -Message "Connected as Automation Account Connection $global:AASPName."

            $global:SPObjID = "aed58b11-d650-4e8f-b740-30704654d758"
        }
        catch {
            Write-AtlasOutput -Message $_.Exception.Message -LogLevel "DEBUG"

            if (!$spConnection) {
                $ErrorMessage = "AzureRunAsConnection not found."
                throw $ErrorMessage
            }
            else {
                Write-AtlasOutput -LogLevel "ERROR" -Message $_.Exception
                throw $_.Exception
            }
        }
    }

    if (!$ConnectionResult) {
        Throw "Unable to successfully authenticate. Aborting processing..."
        Exit 99
    }
}

#################################################################################################
# This will get the vNet/Subnet of the hybrid worker VM
#################################################################################################
function get-VMSubnetId {
    param(
        [Parameter(Mandatory = $true)]
        [string]$vmName
    )

    try {
        # get vm
        $vm = Get-AzVM -Name $vmName -DefaultProfile $CMFGProdContext

        # get nic from vm
        $nicId = $vm.NetworkProfile.NetworkInterfaces.id

        # get nic
        $nic = Get-AzNetworkInterface -ResourceId $nicId -DefaultProfile $CMFGProdContext

        # get subnetId from nic
        return $nic.IpConfigurations.subnet.id
    }
    catch {
        Write-AtlasOutput -Message "`t `t `t Pproblem occurred getting vm and subnet. vm: $vmName" "ERROR"
    }
}


#################################################################################################
# Temporarily Modify Network Rule for for KV access.  Hybrid, add vNet.  Azure, add external IP
#################################################################################################
function ModifyKvNetworkRule {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [string]$resourcegroupname,
        [Parameter(Mandatory = $true)]
        [string]$Action,
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )

    #get kv network rules
    $kv = Get-AzKeyVault -VaultName $keyvault -DefaultProfile $SubContext
    $kvVnetRules = $kv.NetworkAcls.VirtualNetworkResourceIds

    if ($RunAsHybridWorker) {
        $hybridWorkerVnetSubnet = get-VMSubnetId -vmname $global:HybridWorker
        if ($Action -eq "Add") {
            if (!($kvVnetRules -Contains $hybridWorkerVnetSubnet)) {
                #if network rule not exists add it
                Write-AtlasOutput -Message "`t `t Adding hybrid worker vNet/subNet network rule to keyvault firewall"
                Add-AzKeyVaultNetworkRule -VaultName $KeyVault -VirtualNetworkResourceId $hybridWorkerVnetSubnet -DefaultProfile $SubContext
                Write-AtlasOutput -Message "`t `t Successfully added hybrid worker vNet/subNet network rule to keyvault firewall"
            }
        }
        elseif ($Action -eq "Remove") {
            if ($kvVnetRules -Contains $hybridWorkerVnetSubnet) {
                #if network rule exists remove it
                Write-AtlasOutput -Message "`t `t Removing hybrid worker vNet/subNet network rule from keyvault firewall"
                Remove-AzKeyVaultNetworkRule -VaultName $KeyVault -VirtualNetworkResourceId $hybridWorkerVnetSubnet -DefaultProfile $SubContext
                Write-AtlasOutput -Message "`t `t Successfully removed hybrid worker vNet/subNet network rule from keyvault firewall"
            }
        }
    }
    else {
        $kvIpRules = $kv.NetworkAcls.IpAddressRanges

        if ($Action -eq "Add") {
            #check if tag network rules
            if (!($kvIpRules -Contains $global:ExternalIP)) {
                #if network rules not exists add it
                Write-AtlasOutput -Message "`t `t Adding External IP: $global:ExternalIP"
                $OutData = Add-AzKeyVaultNetworkRule -VaultName $KeyVault -ResourceGroupName $resourcegroupname -IpAddressRange $global:ExternalIP -DefaultProfile $SubContext
                Write-AtlasOutput -Message "`t `t External IP successfully added"
            }
        }
        elseif ($Action -eq "Remove") {
            #check if tag network rules
            if ($kvIpRules -Contains $global:ExternalIP) {
                #if network rule exists remove it
                Write-AtlasOutput -Message "`t `t Removing External IP: $global:ExternalIP"
                Remove-AzKeyVaultNetworkRule -VaultName $KeyVault -IpAddressRange $global:ExternalIP -DefaultProfile $SubContext
                Write-AtlasOutput -Message "`t `t External IP successfully removed"
            }
        }
    }
}


#################################################################################################
# Function to check current Runbook state
#################################################################################################
function IsJobTerminalState {
    param(
        [Parameter(mandatory = $true)] [string] $status
    )
    return $status -eq "Completed" -or $status -eq "Failed" -or $status -eq "Stopped" -or $status -eq "Suspended"
}


#################################################################################################
# Get all the secret and validate them
#################################################################################################
function Call-Rotate-Secret-Runbook {
    param(
        [Parameter(Mandatory = $true)]
        [array]$secretToRotate,
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )

    Write-AtlasOutput -Message "secretToRotate = $($secretToRotate.secret)"
    $params = @{secretsToRotate = @($secretToRotate); RunAsHybridWorker = $false }
    $OutStrng = ($secretToRotate | Out-String) -split "`n"
    Write-AtlasOutput -Message "params  = $OutStrng"

    Set-AzContext -Subscription "CMFG Production" | Out-Null
    # Call child runbook
    $rotatedSecret = Start-AzAutomationRunbook `
        -AutomationAccountName "AA-CMFG-P01-InfraMgmt-AZ" `
        -Name "Atlas-FunctionApp-RotateStorageAccountKey" `
        -ResourceGroupName "RG-CMFG-NC1-P01-ITInfrastructure" `
        -Parameters $params

    Write-AtlasOutput -Message "    Waiting for AA-CMFG-P01-InfraMgmt-AZ/Atlas-FunctionApp-RotateStorageAccountKey runbook to complete...."
    $pollingSeconds = 5
    $maxTimeout = 10800
    $waitTime = 0
    while ((IsJobTerminalState $rotatedSecret.Status) -eq $false -and $waitTime -lt $maxTimeout) {
        Start-Sleep -Seconds $pollingSeconds
        $waitTime += $pollingSeconds
        $rotatedSecret = $rotatedSecret | Get-AzAutomationJob
        if ($rotatedSecret.Status -eq "New") {
            Write-AtlasOutput -Message "    Job Status: Queued"
        }
        else {
            Write-AtlasOutput -Message "    Job Status: $($rotatedSecret.Status)"
        }
    }
    if ($rotatedSecret.Status -ne "Completed") {
        $global:EmailData += "`t `t **** RUNBOOK TO ROTATE THE KEY FAILED, PLEASE INVESTIGATE. ****`n"
    }
    Write-AtlasOutput -Message "  "
}

#################################################################################################
# Get all the secret and validate them
#################################################################################################
function Get-FunAppName {
    param(
        [Parameter(Mandatory = $true)]
        [Array]$SecretInfo,
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )

    $storageAccountName = ($SecretInfo.name -Split "-")[-1]
    $SAinfo = Get-AzResource -Name $storageAccountName

    # If KV has a secret, but the storage account doesn't exist, then skip further processing on that secret.
    if ($SAinfo) {
        $identifier = $storageAccountName[2..($storageAccountName.length - 1)] -join ''
        $functionApp = Get-AzWebApp -ResourceGroupName $SAinfo.ResourceGroupName -DefaultProfile $SubContext | Where-Object { ($_.Name).replace('-', '') -match $identifier }
        Return $functionApp.Name

    }
    else {
        Write-AtlasOutput -Message "`t `t Skipping $storageAccountName, because it does not exist"
        Return $null
    }
}

#################################################################################################
# Get all the secret and validate them
#################################################################################################
function Get-Secret-And-Validate {
    param(
        [Parameter(Mandatory = $true)]
        [Array]$SecretInfo,
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )
    # Calculate the difference between now and when the Secret was created.
    $TotDays = (New-TimeSpan -Start $SecretInfo.Created -End $Today).Days
    #$$TotHours = (New-TimeSpan -Start $SecretInfo.Created -End $Today).TotalHours
    Write-AtlasOutput -Message "`t `t Processing KV Secret: $($SecretInfo.Name)"
    Write-AtlasOutput -Message "`t `t `t Secret last updated on: $($SecretInfo.Created)"
    Write-AtlasOutput -Message "`t `t `t Current date/time     : $Today"

    # If Totdays greater that EmailChangePeriod, but less than ForceChangePeriod
    #    send warning email
    # If Totdays greater that EmailChangePeriod, AND greater than ForceChangePeriod
    #    send error email and force secret change by calling existing runbook
    if ($TotDays -gt $EmailChangePeriod) {
        If ($TotDays -gt $ForceChangePeriod) {
            $functionApp = Get-FunAppName -SecretInfo $SecretInfo -SubContext $SubContext

            foreach ($funApp in $functionApp) {
                Write-AtlasOutput -Message "`t `t `t **** KEYVAULT SECRET NOT CHANGED IN $TotDays DAYS." "WARN"
                Write-AtlasOutput -Message "`t `t `t **** FORCING A CHANGE OF THE KEYVAULT SECRET NOW" "WARN"
                $global:EmailData += "`t **** KEYVAULT SECRET NOT CHANGED IN $TotDays DAYS. `n"
                $global:EmailData += "`t **** FORCING A CHANGE OF THE KEYVAULT SECRET NOW. `n"
                $global:EmailData += "`t `t  Subscription: `t $($SubContext.Subscription.Name)`n"
                $global:EmailData += "`t `t  KeyVault Name: `t $($SecretInfo.VaultName) `n"
                $global:EmailData += "`t `t  Secret Name: `t $($SecretInfo.Name) `n"
                $global:EmailData += "`t `t  FunctionApp: `t $funApp `n"
                $global:EmailData += "`n"

                # Prepare input data to call runbook to change the secret
                $secretToRotate = @{
                    keyvault      = $SecretInfo.VaultName
                    secret        = $SecretInfo.name;
                    resourceGroup = $ResourceGroupName;
                    subscription  = $SubContext.Subscription.Name;
                    functionApp   = $funApp;
                }
                Write-AtlasOutput -Message "`t `t `t Rotating Key for Function App $funApp" "WARN"

                Call-Rotate-Secret-Runbook -secretToRotate $secretToRotate -SubContext $SubContext
            }

        }
        else {
            Write-AtlasOutput -Message "`t `t `t KeyVault Secret needs to be changed. Last changed $TotDays days ago." "WARN"
            $global:EmailData += "`t KeyVault Secret needs to be changed. It was last changed $TotDays days ago. `n"
            $global:EmailData += "`t `t Subscription: $($SubContext.Subscription.Name)   KeyVault Name: $($SecretInfo.VaultName)   Secret Name: $($SecretInfo.Name) `n"
            $global:EmailData += "`n"
        }
    }
}


#################################################################################################
# Function get all secrets from KV that have tag of FunAppWebJobStorageKey-
#  If one or many found, process each one.
#################################################################################################
function Process-Secret {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [string]$ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )

    $SecretInfo = (Get-AzKeyVaultSecret -VaultName $keyvault -DefaultProfile $SubContext -ErrorAction Stop | Where-Object { $_.Name -match "FunAppWebJobStorageKey-" })
    # if any found
    if ($SecretInfo) {
        # if just one, process it, else multiple, process all of them
        if ($SecretInfo.Count -eq 1) {
            Get-Secret-And-Validate $SecretInfo -SubContext $SubContext
        }
        else {
            $cnt = 0
            do {
                Get-Secret-And-Validate $SecretInfo[$cnt] -SubContext $SubContext
                $cnt++
            }
            while ($cnt -lt $SecretInfo.Count)
        }
    }
}

#################################################################################################
# Function to email a message
#################################################################################################
function Send-TeamTitanEmailAlert {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $EmailbodyData
    )

    $userName = @("TeamTitan@cunamutual.com", "DS-TeamTitanSupport@cunamutual.com")

    $SMTPServer = "smtp.cunamutual.com"
    $kvName = "kv-atlas-ITPortfolio-p"
    $kvId = "TeamTitan-SMTP"

    $emailFrom = "$RUNBOOK_NAME@teamtitan.com"
    $emailTo = $userName
    $emailSubject = "FunctionApp Storage Account KeyVault Key Rotation Report"

    $emailPassword = (Get-AzKeyVaultSecret -VaultName $kvName.trim() -Name $kvId.trim()).SecretValue
    $emailCredential = New-Object System.Management.Automation.PSCredential ($kvId, $emailPassword)

    # Convert the array of strings in the body parameter into a single string with carriage
    # returns between the array values
    $emailBody = "FunctionApp Storage Account KeyVault key rotations needed: `r `r"
    $emailBody += "Warn if Key Vault Secret not changed in $EmailChangePeriod days `r"
    $emailBody += "Force Key Vault Secret rotation if not changed in $ForceChangePeriod days `r `r"

    $emailBody += "$EmailbodyData `r"

    $emailBody += "AA-CMFG-P01-InfraMgmt-AZ / $global:AASPName / $RUNBOOK_NAME"
    $messageBody = $Emailbody | Out-String

    Send-MailMessage -SmtpServer $SMTPServer -Credential $emailCredential -UseSsl `
        -Port 587 -From $emailFrom -To $emailTo -Subject $emailSubject -Body $messageBody
}


#################################################################################################
# Main Procedure
#################################################################################################
$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module -Name Az.Automation
    Import-Module -Name Az.Compute
    Import-Module -Name Az.KeyVault
    Import-Module -Name Az.Network
    Import-Module -Name Az.Resources
    Import-Module -Name Az.Websites
    Disable-AzContextAutosave -Scope Process | Out-Null
}
catch {
    Write-Warning "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"

$context = Connect-CMFGAutomationAccount

# Get CMFG Prod Context, because that is where the hybrid workers live
$CMFGProdContext = Set-AzContext -SubscriptionName "CMFG Production"

# Get current time once:
$Today = Get-Date
Write-AtlasOutput -Message "Start Time (UTC): $Today"

# get the external ip for this process - moved here to get it just ones
$global:ExternalIP = (Get-MyIp -SubContext $CMFGProdContext) + "/32"
$subscriptions = Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object name

foreach ($sub in $subscriptions) {
    # Connect to each sub
    $SubContext = Set-AzContext -SubscriptionName $sub
    Write-AtlasOutput -Message "Processing subscription: $($SubContext.Subscription.Name)"

    # Get all Atlas KVs in the sub
    $AtlasKVs = Get-AzResource -ResourceType "Microsoft.KeyVault/vaults" | Where-Object { $_.Tags.AtlasPurpose -match "Atlas-FunctionApp" }

    Foreach ($AtlasKV in $AtlasKVs) {
        $SubContext = Set-AzContext -SubscriptionName $sub
        Write-AtlasOutput -Message "`t Setting context to subscription: $($SubContext.Subscription.Name)"
        Write-AtlasOutput -Message "`t Processing KeyVault: $($AtlasKV.name)"
        ModifyKvNetworkRule -keyvault $AtlasKV.name -ResourceGroupName $AtlasKV.ResourceGroupName -Action "Add" -SubContext $SubContext

        try {
            # Skip over -DevSandbox RG names
            if ($AtlasKV.ResourceGroupName -notmatch "-DevSandbox") {
                Process-Secret -keyvault $AtlasKV.name -ResourceGroupName $AtlasKV.ResourceGroupName -SubContext $SubContext
            }
        }
        catch {
            Write-AtlasOutput -Message "`t `t Automation Account Service Princpal does not 'List' access to the secrets" "WARN"
            Write-AtlasOutput -Message "`t `t Granting 'List' access to the secrets" "WARN"

            if ($RunAsHybridWorker) {
                Write-AtlasOutput -Message "`t `t `t Setting access for Hybrid Worker" "WARN"
                Set-AzKeyVaultAccessPolicy -VaultName $AtlasKV.name -DefaultProfile $SubContext -ObjectId $global:SPObjID -PermissionsToSecrets List
            }
            else {
                Write-AtlasOutput -Message "`t `t `t Setting access for Service Princpal" "WARN"
                Set-AzKeyVaultAccessPolicy -VaultName $AtlasKV.name -DefaultProfile $SubContext -ServicePrincipalName $global:SPObjID -PermissionsToSecrets List
            }

            # Try again
            Write-AtlasOutput -Message "`t `t Validating the Secret again" "WARN"
            Process-Secret -keyvault $AtlasKV.name $AtlasKV.ResourceGroupName -SubContext $SubContext
        }

        ModifyKvNetworkRule -keyvault $AtlasKV.name -ResourceGroupName $AtlasKV.ResourceGroupName -Action "Remove" -SubContext $SubContext
        Write-AtlasOutput -Message "`t Finished processing KeyVault: $($AtlasKV.name)"
        Write-AtlasOutput -Message " "
    }
    Write-AtlasOutput -Message "Finished processing subscription: $($SubContext.Subscription.Name)"
    Write-AtlasOutput -Message " "
}

if ($global:EmailData) {
    Write-AtlasOutput -Message "Sending Email"
    Send-TeamTitanEmailAlert -Emailbody $global:EmailData
}
else {
    Write-AtlasOutput -Message "No data, no Email"
}

# Get current time once:
$EndTime = Get-Date
Write-AtlasOutput -Message "End Time (UTC): $EndTime"

Write-AtlasOutput -Message "Runbook completed...."

