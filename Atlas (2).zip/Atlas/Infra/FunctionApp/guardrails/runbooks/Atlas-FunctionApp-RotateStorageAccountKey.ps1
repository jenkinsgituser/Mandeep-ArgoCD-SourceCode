param
(
    [Parameter (Mandatory = $true)]
    [array] $secretsToRotate,
    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)

$RUNBOOK_NAME = "Atlas-FunctionApp-RotateStorageAccountKey"
$CONST_ENDPOINT_SUFFIX = "core.windows.net"
Write-Verbose "CONST_ENDPOINT_SUFFIX: $CONST_ENDPOINT_SUFFIX" -Verbose

$CONST_ENDPOINT_PROTOCOL = "https"
Write-Verbose "CONST_ENDPOINT_PROTOCOL: $CONST_ENDPOINT_PROTOCOL" -Verbose

$CONST_MAX_RETRY = 3 #amount of times to try script from the beginning
$CONST_MAX_WAIT_TIME = 5 #amount of time to wait before retry
$CONST_MAX_ATTEMPTS = 12 #amount of attempts to retry key rotation within script

$ErrorActionPreference = "Continue"


#################################################################################################
# This will get the vNet/Subnet of the hybrid worker VM
#################################################################################################
function get-VMSubnetId {
    param(
        [Parameter(Mandatory = $true)]
        [string]$vmName
    )

    try {
        # get vm
        $vm = Get-AzVM -Name $vmName -DefaultProfile $CMFGProdContext

        # get nic from vm
        $nicId = $vm.NetworkProfile.NetworkInterfaces.id

        # get nic
        $nic = Get-AzNetworkInterface -ResourceId $nicId -DefaultProfile $CMFGProdContext

        # get subnetId from nic
        return $nic.IpConfigurations.subnet.id
    }
    catch {
        Write-AtlasOutput -Message "`t `t `t Problem occurred getting vm and subnet. vm: $vmName" "ERROR"
    }
}

#################################################################################################
# Temporarily Modify Network Rule for for KV access.  Hybrid, add vNet.  Azure, add external IP
#################################################################################################
function ModifyKvNetworkRule {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [string]$Action,
        [Parameter(Mandatory = $true)]
        [PSObject]$SubContext
    )

    #get kv network rules
    $kv = Get-AzKeyVault -VaultName $keyvault -DefaultProfile $SubContext
    $kvVnetRules = $kv.NetworkAcls.VirtualNetworkResourceIds

    if ($RunAsHybridWorker) {
        $hybridWorkerVnetSubnet = get-VMSubnetId -vmname $global:HybridWorker
        if ($Action -eq "Add") {
            if (!($kvVnetRules -Contains $hybridWorkerVnetSubnet)) {
                #if network rule not exists add it
                Write-AtlasOutput -Message "`t `t Adding hybrid worker vNet/subNet network rule to keyvault firewall"
                Add-AzKeyVaultNetworkRule -VaultName $KeyVault -VirtualNetworkResourceId $hybridWorkerVnetSubnet
                Write-AtlasOutput -Message "`t `t Successfully added hybrid worker vNet/subNet network rule to keyvault firewall"
            }
        }
        elseif ($Action -eq "Remove") {
            if ($kvVnetRules -Contains $hybridWorkerVnetSubnet) {
                #if network rule exists remove it
                Write-AtlasOutput -Message "`t `t Removing hybrid worker vNet/subNet network rule from keyvault firewall"
                Remove-AzKeyVaultNetworkRule -VaultName $KeyVault -VirtualNetworkResourceId $hybridWorkerVnetSubnet
                Write-AtlasOutput -Message "`t `t Successfully removed hybrid worker vNet/subNet network rule from keyvault firewall"
            }
        }
    }
    else {
        # get the external ip for this process
        $ExternalIP = (Get-MyIp-Runbook) + "/32"
        #Write-AtlasOutput -Message  $ExternalIP
        $kvIpRules = $kv.NetworkAcls.IpAddressRanges

        if ($Action -eq "Add") {
            #check if tag network rules
            if (!($kvIpRules -Contains $ExternalIP)) {
                #if network rules not exists add it
                Write-AtlasOutput -Message "`t `t Adding External IP: $ExternalIP"
                Add-AzKeyVaultNetworkRule -VaultName $KeyVault -IpAddressRange $ExternalIP -DefaultProfile $SubContext
                Write-AtlasOutput -Message "`t `t External IP successfully added"
            }
        }
        elseif ($Action -eq "Remove") {
            #check if tag network rules
            if ($kvIpRules -Contains $ExternalIP) {
                #if network rule exists remove it
                Write-AtlasOutput -Message "`t `t Removing External IP: $ExternalIP"
                Remove-AzKeyVaultNetworkRule -VaultName $KeyVault -IpAddressRange $ExternalIP -DefaultProfile $SubContext
                Write-AtlasOutput -Message "`t `t External IP successfully removed"
            }
        }
    }
}

#################################################################################################
# Function to rotate storage account keys and generate a new connection string
#################################################################################################
function Update-StorageAccountKeys {
    param(
        [Parameter(Mandatory = $true)]
        [string]$storageAccountName,
        [Parameter(Mandatory = $true)]
        [string]$resourceGroup,
        [Parameter(Mandatory = $true)]
        [string]$initialKey,
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )

    $keyRotated = $false
    $count = 0
    while (!$keyRotated -and $count -lt $CONST_MAX_ATTEMPTS) {
        @('key1', 'key2') | ForEach-Object {
            New-AzStorageAccountKey -ResourceGroupName $resourceGroup -Name $storageAccount -KeyName $_ -DefaultProfile $SubContext | Out-Null
            Write-AtlasOutput -Message "`t `t `t Rotated key $_ on storage account $storageAccount"
        }

        $newKey = (Get-AzStorageAccountKey -ResourceGroupName $resourceGroup -Name $storageAccount -DefaultProfile $SubContext).Value[0]
        if ($initialKey -ne $newKey) {
            $keyRotated = $true
        }
        else {
            if ($count -lt $CONST_MAX_ATTEMPTS - 1) {
                Write-AtlasOutput -LogLevel "INFO" -Message "Attempting to rotate key again in $CONST_MAX_WAIT_TIME seconds."
                Start-Sleep -Seconds $CONST_MAX_WAIT_TIME
            }
        }
        $count++
    }
    #get new key
    $newKey = (Get-AzStorageAccountKey -ResourceGroupName $resourceGroup -Name $storageAccount -DefaultProfile $SubContext).Value[0]
    $newConnectionString = "DefaultEndpointsProtocol=$($CONST_ENDPOINT_PROTOCOL);AccountName=$($storageAccount);AccountKey=$($newKey);EndpointSuffix=$($CONST_ENDPOINT_SUFFIX)"
    if ($keyRotated) {
        return $newConnectionString
    }
    else {
        Write-AtlasOutput -LogLevel "ERROR" -Message "Key was not successfully rotated"
        return $null
    }
}


#################################################################################################
### Function to update the app config for web jobs storage
###############################################################################################
function Update-AppConfigWebJobStorage {
    param(
        [Parameter(Mandatory = $true)]
        [string]$storageAccountName,
        [Parameter(Mandatory = $true)]
        [string]$keyvault,
        [Parameter(Mandatory = $true)]
        [string]$secretName,
        [Parameter(Mandatory = $true)]
        [string]$functionName,
        [Parameter(Mandatory = $true)]
        [string]$functionRG,
        [Parameter(Mandatory = $false)]
        [string]$initialURI = [string]::Empty,
        [Parameter(Mandatory = $true)]
        [PSObject] $SubContext
    )

    $AppSettings = $(Get-AzWebApp -ResourceGroupName $functionRG -Name $functionName -DefaultProfile $SubContext).SiteConfig.AppSettings
    Write-AtlasOutput -LogLevel "INFO" -Message "Retrieved app settings about to get secret."

    $ErrorActionPreference = "Stop"
    $secret = $null

    $i = 0
    while ($i -lt $CONST_MAX_ATTEMPTS -and !$secret) {
        try {
            $secret = Get-AzKeyVaultSecret -VaultName $keyvault -Name $secretName -DefaultProfile $SubContext
            Write-AtlasOutput -LogLevel "INFO" -Message "Secret retrieved."
        }
        catch {
            Write-Verbose "Attempt $i failed when getting Key Vault secret"
            if ($i -eq ($CONST_MAX_ATTEMPTS - 1)) {
                Write-Error "Exception '$($_.Exception.Message)'. Failed maximal attempts when executing line $LineNumber"
                Exit 20
            }
            Start-Sleep -Seconds $CONST_MAX_WAIT_TIME
        }
        $i++
    }

    $ErrorActionPreference = "Continue"
    $secretURI = $secret.Id
    if ($secretURI -eq $initialURI) {
        Write-AtlasOutput -LogLevel "WARN" -Message "Secret not successfully updated in $($keyvault)"
        return $false
    }
    $newAppSettings = @{ }
    foreach ($setting in $AppSettings) {
        if ($setting.Name -eq "AzureWebJobsStorage") {
            #Example app setting value
            # @Microsoft.KeyVault(SecretUri=https://kv-atlasbuildtesting.vault.azure.net/secrets/FunAppWebJobStorageKey-saaeacdadc454886/ecca051e7acb4eaf9b7656d30a07a5ab)
            $setting.Value = "@Microsoft.KeyVault(SecretUri=$secretURI)"
        }
        $newAppSettings.Add($setting.Name, $setting.Value)
    }
    #set new settings on app
    # Added -Use32BitWorkerProcess $true per MS until Az.Websites it updated with fix
    Set-AzWebApp -ResourceGroupName $functionRG -Name $functionName -AppSettings $newAppSettings -Use32BitWorkerProcess $true -DefaultProfile $SubContext
    #check to make sure new app setting matches rotated secret
    $newAppSettingsTest = $(Get-AzWebApp -ResourceGroupName $functionRG -Name $functionName -DefaultProfile $SubContext).SiteConfig.AppSettings
    #get initial secret uri
    foreach ($setting in $newAppSettingsTest) {
        if ($setting.Name -eq "AzureWebJobsStorage") {
            #Example app setting value
            # @Microsoft.KeyVault(SecretUri=https://kv-atlasbuildtesting.vault.azure.net/secrets/FunAppWebJobStorageKey-saaeacdadc454886/ecca051e7acb4eaf9b7656d30a07a5ab)
            if ($setting.Value.Contains("Microsoft.KeyVault(SecretUri=https://")) {
                $newSecretURI = ($setting.Value).replace('@Microsoft.KeyVault(SecretUri=', '')
                $newSecretURI = $newSecretURI.replace(')', '')
            }
        }
    }
    if ($newSecretURI -eq $secretURI) {
        Write-AtlasOutput -Message "Updated secret on $($functionName)"
        return $true
    }
    else {
        Write-AtlasOutput -LogLevel "WARN" -Message "Failed to update app settings on $($functionName)"
        return $false
    }
}

#################################################################################################
### Function to retry command
###############################################################################################
function Invoke-CommandWithRetries {
    param(
        [Parameter(Mandatory = $true)]
        [string]$command,
        [Parameter(Mandatory = $false)]
        [int]$LineNumber
    )

    $result = $null
    $i = 0
    while ($i -lt $CONST_MAX_ATTEMPTS -and !$result) {
        try {
            Write-AtlasOutput -LogLevel "INFO" -Message "Attempting to get secret."
            $result = Invoke-Expression -Command $command
        }
        catch {
            Write-Verbose "Attempt $i failed when getting Key Vault secret"
            if ($i -eq ($CONST_MAX_ATTEMPTS - 1)) {
                Write-Error "Exception '$($_.Exception.Message)'. Failed maximal attempts when executing line $LineNumber"
                Exit 20
            }
            Start-Sleep -Seconds $CONST_MAX_WAIT_TIME
        }
        $i++
    }
    Write-AtlasOutput -LogLevel "INFO" -Message "Secret retrieved returning result."
    return $result
}

#################################################################################################
### Function to email a message
#################################################################################################
function Send-TeamTitanEmailAlert {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceString,
        [parameter(mandatory = $true)]
        [PsObject] $SubContext
    )

    # Send Email if any found
    Write-AtlasOutput -Message "Sending email...." -LogLevel "DEBUG"

    $teamTitan = @("TeamTitan@cunamutual.com", "DS-TeamTitanSupport@cunamutual.com")

    $SMTPServer = "smtp.cunamutual.com"
    $kvName = "kv-atlas-ITPortfolio-p"
    $kvId = "TeamTitan-SMTP"

    $emailFrom = "$RUNBOOK_NAME@cunamutual.com"
    $emailTo = $teamTitan
    $emailSubject = "ACTION REQUIRED: Function App Storage Rotation Failed"

    try {
        $ErrorActionPreference = "Stop"
        $VerbosePreference = "SilentlyContinue"
        $emailPassword = (Get-AzKeyVaultSecret -VaultName $kvName.trim() -Name $kvId.trim() -DefaultProfile $SubContext).SecretValue
        $emailCredential = New-Object System.Management.Automation.PSCredential ($kvId, $emailPassword)

        # Convert the array of strings in the body parameter into a single string with carriage
        # returns between the array values
        $emailBody = "Below is a list of Function Apps and Keys that were not properly rotated `r `r"
        $emailBody += $ResourceString
        $emailBody += "`r Executed from AA-CMFG-P01-InfraMgmt-AZ, Runbook is $RUNBOOK_NAME"
        $messageBody = $emailBody | Out-String

        Send-MailMessage -SmtpServer $SMTPServer -Credential $emailCredential -UseSsl `
            -Port 587 -From $emailFrom -To $emailTo -Subject $emailSubject -Body $messageBody

        $VerbosePreference = "Continue"
        Write-AtlasOutput -Message "Email sent!!!" -LogLevel "DEBUG"
    }
    catch {
        Write-AtlasOutput -Message "Unable to send notification email." -LogLevel "WARN"
    }
    finally {
        $VerbosePreference = "Continue"
    }

}

Function Set-AtlasKeyVaultPolicy {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $KeyVault,
        [parameter(mandatory = $true)]
        [PsObject] $SubContext
    )
    $GuidRegex = "^[{(]?[0-9A-F]{8}[-]?(?:[0-9A-F]{4}[-]?){3}[0-9A-F]{12}[)}]?$"
    #add access policy
    $currentAccount = (Get-AzContext).Account.Id
    # if the current id is a guid, it's going to be a service principal
    if ($currentAccount -match $GuidRegex) {
        Set-AzKeyVaultAccessPolicy -VaultName $KeyVault -DefaultProfile $SubContext -ServicePrincipalName $currentAccount -PermissionsToSecrets Get, Set, List
    }
    else {
        $userPrincipal = (Get-AzADUser -UserPrincipalName $currentAccount).UserPrincipalName
        Set-AzKeyVaultAccessPolicy -VaultName $KeyVault -DefaultProfile $SubContext -UserPrincipalName $userPrincipal -PermissionsToSecrets Get, Set, List
    }
}

Function Remove-AtlasKeyVaultPolicy {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $KeyVault,
        [parameter(mandatory = $true)]
        [PsObject] $SubContext
    )
    $GuidRegex = "^[{(]?[0-9A-F]{8}[-]?(?:[0-9A-F]{4}[-]?){3}[0-9A-F]{12}[)}]?$"
    #add access policy
    $currentAccount = (Get-AzContext).Account.Id
    # if the current id is a guid, it's going to be a service principal
    if ($currentAccount -match $GuidRegex) {
        Remove-AzKeyVaultAccessPolicy -VaultName $keyvault -ServicePrincipalName $currentAccount -DefaultProfile $SubContext
    }
    else {
        $userPrincipal = (Get-AzADUser -UserPrincipalName $currentAccount).UserPrincipalName
        Remove-AzKeyVaultAccessPolicy -VaultName $keyvault -UserPrincipalName $userPrincipal -DefaultProfile $SubContext
    }
}

#################################################################################################
### Begin Main
#################################################################################################

Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module Az.Resources | Out-Null
    Import-Module Az.Accounts | Out-Null
    Import-Module Az.Automation | Out-Null
    Import-Module Az.KeyVault | Out-Null
    Import-Module Az.Websites | Out-Null
    Import-Module Az.Storage | Out-Null
}
catch {
    Write-AtlasOutput -LogLevel "WARN" -Message "Error importing required modules. $($_.Exception.Message)"
}

if ($env:IsLocal -or $env:AGENT_ID) {
    Write-Verbose -Verbose "Running in a local or build context!"
    . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1
}
else {
    #sourcing on the AA is slightly different than sourcing locally
    . ./Atlas-CommonCode.ps1
    Azure-Connect
}

$VerbosePreference = "Continue"

#take in array of keyvaults, secret names, resource groups and subscriptions
$sendEmailAlert = $false
$emailResourceString = ""
foreach ($secretToRotate in $secretsToRotate) {
    #for each entry in array
    $counter = 0
    $secretRotated = $false
    while ($counter -lt $CONST_MAX_RETRY -and !$secretRotated) {
        $keyvault = $secretToRotate.keyvault
        $secret = $secretToRotate.secret
        $storageAccount = $secret.Replace('FunAppWebJobStorageKey-', '')
        $resourceGroup = $secretToRotate.resourceGroup
        $subscription = $secretToRotate.subscription
        $functionAppName = [string]::Empty
        $functionAppResourceGroup = [string]::Empty
        $currentSubscription = Get-AzContext

        if ($subscription -ne $currentSubscription.Subscription.Name) {
            $SubContext = Set-AzContext -Subscription $subscription
        }
        else {
            $SubContext = $currentSubscription
        }
        Write-AtlasOutput -LogLevel "INFO" -Message "Working Subscription: $subscription"

        #retrieve storage account (in secret name)
        if (!$secret.StartsWith("FunAppWebJobStorageKey")) {
            Write-AtlasOutput -LogLevel "ERROR" -Message "Invalid secret entered."
        }
        else {
            #open kv networking
            if ($counter -eq 0) {
                #only set on first try
                ModifyKvNetworkRule -keyvault $keyvault -Action "Add" -SubContext $SubContext
                Write-AtlasOutput -LogLevel "INFO" -Message "Setting access policy."
                Set-AtlasKeyVaultPolicy -KeyVault $keyvault -SubContext $SubContext
                Write-AtlasOutput -LogLevel "INFO" -Message "Finished setting policy."
            }
            $identifier = $storageAccount[2..($storageAccount.length - 1)] -join ''
            Write-AtlasOutput -LogLevel "INFO" -Message "Identifier: $identifier"

            $functions = Get-AzWebApp -DefaultProfile $SubContext
            $functionAppName = $functions.Name | Where-Object { $_.replace('-', '') -match $identifier }

            # Check if we found more than one Function App Name, now need to find the right one.
            if ($functionAppName.count -gt 1) {
                Foreach ($FunAppName in $functionAppName) {
                    if ($FunAppName -eq $secretToRotate.functionApp) {
                        $functionAppName = $FunAppName | Where-Object { $_.replace('-', '') -match $identifier }
                    }
                }
            }

            Write-AtlasOutput -LogLevel "INFO" -Message "Function Name: $functionAppName"

            $functionAppResourceGroup = ($functions | Where-Object { $_.Name -eq $functionAppName }).ResourceGroup
            Write-AtlasOutput -LogLevel "INFO" -Message "Function Resource Group: $functionAppResourceGroup"
            #grab initial values
            #get initial key

            $initialStorageKey = (Get-AzStorageAccountKey -ResourceGroupName $functionAppResourceGroup -Name $storageAccount -DefaultProfile $SubContext).Value[0]
            $i = 0
            $result = $null
            $ErrorActionPreference = "Stop"
            #get initial secret
            while (!$result -and $i -lt $CONST_MAX_ATTEMPTS) {
                #and compare secret value
                try {
                    #new secret in key vault
                    Write-AtlasOutput -LogLevel "INFO" -Message "Attempting to get secret."
                    $result = (Get-AzKeyVaultSecret -VaultName $keyvault -Name $secret -DefaultProfile $SubContext).Id
                }
                catch {
                    Write-AtlasOutput -LogLevel "WARN" -Message "Failed to get secret attempt $i. ERROR: $($_.Exception.Message)"
                    if ($i -lt $CONST_MAX_ATTEMPTS - 1) {
                        Write-AtlasOutput -LogLevel "INFO" -Message "Attempting to get secret again in $CONST_MAX_WAIT_TIME seconds."
                        Start-Sleep -Seconds $CONST_MAX_WAIT_TIME
                    }
                }
                $i++
            }
            $ErrorActionPreference = "Continue"
            $initialSecret = $result
            $AppSettings = $(Get-AzWebApp -ResourceGroupName $functionAppResourceGroup -Name $functionAppName -DefaultProfile $SubContext).SiteConfig.AppSettings
            #get initial secret uri
            foreach ($setting in $AppSettings) {
                if ($setting.Name -eq "AzureWebJobsStorage") {
                    #Example app setting value
                    # @Microsoft.KeyVault(SecretUri=https://kv-atlasbuildtesting.vault.azure.net/secrets/FunAppWebJobStorageKey-saaeacdadc454886/ecca051e7acb4eaf9b7656d30a07a5ab)
                    if ($setting.Value.Contains("Microsoft.KeyVault(SecretUri=https://")) {
                        $initialAppSettingURI = ($setting.Value).replace('@Microsoft.KeyVault(SecretUri=', '')
                        $initialAppSettingURI = $initialAppSettingURI.replace(')', '')
                    }
                }
            }

            # use the initial URI else set to be an empty string rather than a Null value
            $initialAppSettingURI = if ($initialAppSettingURI) { $initialAppSettingURI } else { [string]::Empty }

            #rotate key
            $connectionString = Update-StorageAccountKeys -storageAccountName $storageAccount -resourceGroup $functionAppResourceGroup -initialKey $initialStorageKey -SubContext $SubContext
            if ($connectionString) {
                #only continue if key was rotated
                $newSecret = ConvertTo-SecureString -String "$connectionString" -AsPlainText -Force

                $i = 0
                $result = $null
                $ErrorActionPreference = "Stop"
                $secretSet = $false
                while (!$result -and $i -lt $CONST_MAX_ATTEMPTS) {
                    #and compare secret value
                    try {
                        #new secret in key vault
                        Write-AtlasOutput -LogLevel "INFO" -Message "Attempting to set secret."
                        $result = Set-AzKeyVaultSecret -VaultName $keyvault -Name $secret -SecretValue $newSecret -DefaultProfile $SubContext
                        if ($result) {
                            $newURI = (Get-AzKeyVaultSecret -VaultName $keyvault -Name $secret -DefaultProfile $SubContext).Id
                            if ($newURI -ne $initialSecret) {
                                $secretSet = $true
                            }
                        }
                    }
                    catch {
                        Write-AtlasOutput -LogLevel "WARN" -Message "Failed to set secret attempt $i. ERROR: $($_.Exception.Message)"
                        if ($i -lt $CONST_MAX_ATTEMPTS - 1) {
                            Write-AtlasOutput -LogLevel "INFO" -Message "Attempting to set secret again in $CONST_MAX_WAIT_TIME seconds."
                            Start-Sleep -Seconds $CONST_MAX_WAIT_TIME
                        }
                    }
                    $i++
                }

                $ErrorActionPreference = "Continue"
                if ($secretSet) {
                    Write-AtlasOutput -LogLevel "INFO" -Message "Secret has been set calling update app config"
                    #fix app config (should match name or RG of storage account)
                    $success = $false
                    $success = Update-AppConfigWebJobStorage -storageAccountName $storageAccount -keyvault $keyvault -secretName $secret -functionName $functionAppName -functionRG $functionAppResourceGroup -initialURI $initialAppSettingURI -SubContext $SubContext
                    if ($success) {
                        #only remove rules if rotation was successful
                        Write-AtlasOutput -LogLevel "INFO" -Message "Secret successfully rotated.  Removing access to Keyvault"
                        $secretRotated = $true
                    }
                    elseif ($counter -eq ($CONST_MAX_RETRY - 1)) {
                        # else remove rules if this was our last attempt
                        Write-AtlasOutput -LogLevel "WARN" -Message "Secret was NOT successfully rotated.  Removing access to Keyvault"
                    }
                    #remove access policy
                    Remove-AtlasKeyVaultPolicy -KeyVault $keyvault -SubContext $SubContext
                    #close kv networking
                    ModifyKvNetworkRule -keyvault $keyvault -Action "Remove" -SubContext $SubContext
                }
                else {
                    Write-AtlasOutput -LogLevel "WARN" -Message "Failed to set Secret"
                }
            }
            else {
                Write-AtlasOutput -LogLevel "WARN" -Message "Failed to rotate keys on storage account"
            }
        }
        if ($counter -lt $CONST_MAX_RETRY - 1 -and !$secretRotated) {
            Write-AtlasOutput -LogLevel "INFO" -Message "Attempting to rotate secret again in $CONST_MAX_WAIT_TIME seconds."
            Start-Sleep -Seconds $CONST_MAX_WAIT_TIME
        }
        $counter++
    }
    if (!$secretRotated) {
        Write-AtlasOutput -LogLevel "ERROR" -Message "Key was not successfully rotated for Storage Account: $storageAccount"
        #send an email because script is broken
        $sendEmailAlert = $true
        $ErrorMessage = "Name: $functionAppName; Storage: $storageAccount; RG: $functionAppResourceGroup Key Rotation Failed"
        $emailResourceString += "$ErrorMessage `r `r"
    }
}

#send alert email
if ($sendEmailAlert) {
    Send-TeamTitanEmailAlert -ResourceString $emailResourceString -Context $SubContext
}

Write-AtlasOutput -LogLevel "INFO" -Message "runbook complete"