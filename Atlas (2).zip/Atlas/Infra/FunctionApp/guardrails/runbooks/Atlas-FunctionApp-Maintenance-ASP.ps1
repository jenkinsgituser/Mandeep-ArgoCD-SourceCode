param
(
    [Parameter (Mandatory = $false)]
    [PsObject] $WebhookData,

    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)
# tiger team app service logging runbook info
$CONST_DEST_AA_SUBSCRIPTION = "CMFG Production"
$CONST_AUTOMATION_ACCOUNT_NAME = "AA-CMFG-P01-InfraMgmt-AZ"
$CONST_TARGET_RUNBOOK = "Atlas-FunctionApp-Maintenance-ASP"

$CONST_ASP_EXCEPTION_TAG = "AtlasExceptions"
$CONST_ASP_EXCEPTION_VALUE = "AppServicePlanException"

# Start Main
###########################################################
$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module Az.Resources | Out-Null
    Import-Module Az.Automation | Out-Null
    Import-Module Az.KeyVault | Out-Null

}
catch {
    Write-Warning "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"



#############################################################################################
# Source Atlas-CommmonCode runbook must reside in the same as your runbook
#############################################################################################
Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. ./Atlas-CommonCode.ps1
Write-AtlasOutput -Message " "

Azure-Connect
$runbookDetail = Get-RunbookCurrentContext
#Set-AzContext -Subscription $CONST_DEST_AA_SUBSCRIPTION

$VerbosePreference = "Continue"

Write-AtlasOutput -LogLevel "INFO" -Message "  event subject:  $($WebhookBody.subject)"

$isValid = $true

if ($WebhookData) {
    $WebhookBody = $WebhookData.RequestBody | ConvertFrom-Json

    # break down the event data into component pieces necessary for downstream passthrough
    $subscriptionId = $WebhookBody.subject.Split("/")[2]
    $subscriptionName = (Get-AzSubscription -SubscriptionId $subscriptionId).Name
    $resourceRG = $WebhookBody.subject.Split("/")[4]
    $resourcetype0 = $WebhookBody.subject.Split("/")[6]
    $resourcetype1 = $WebhookBody.subject.Split("/")[7]
    $resourcetype = "$resourcetype0/$resourcetype1"
    $resourceName = $WebhookBody.subject.Split("/")[8]

    # check the appId that resulted in the alert fireing.  If it was our runbook runas account, don't call the runbook again.
    # if the alert that called this runnbook was generated via a change from the web logging runbook, we don't need/want
    # to call the runbook again.
    # these appids are for the service principals that are the runas accounts for our runbook
    #   SP-AA-InfraMgmt-Az-D   6e5ed314-7154-4254-84b0-e43f1c638615
    #   SP-AA-InfraMgmt-Az-P   aed58b11-d650-4e8f-b740-30704654d758
    $callerAppId = $WebhookBody.data.claims.appid
    if ($callerAppId -ne "6e5ed314-7154-4254-84b0-e43f1c638615" -and
        $callerAppId -ne "aed58b11-d650-4e8f-b740-30704654d758") {


        #check settings on app or asp

        Write-AtlasOutput -LogLevel "INFO" -Message "  subscriptionName:  $subscriptionName"
        $Context = Set-AzContext -Subscription $subscriptionName
        Write-AtlasOutput -LogLevel "INFO" -Message "  resourceRG:  $resourceRG"

        #check if rg is atlas, if not atlas don't check it
        $checkApp = Is-RGAtlas-Runbook -resourceGroup $resourceRG -Context $Context

        if ($checkApp) {
            Write-AtlasOutput -LogLevel "INFO" -Message "  resourceName:  $resourceName"

            $resource = Get-AzResource -Name $resourceName -ResourceType $resourcetype -ResourceGroupName $resourceRG -DefaultProfile $Context

            #check if the resource has an exception marked, if so don't check it further
            if ($resource.Tags.$CONST_ASP_EXCEPTION_TAG -match $CONST_ASP_EXCEPTION_VALUE) {
                Write-AtlasOutput -LogLevel "WARN" -Message "Resource $resourceName of type $resourcetype is tagged for $CONST_ASP_EXCEPTION_VALUE"
            }
            else {
                if ($resourcetype -eq "Microsoft.Web/sites") {
                    if ($resource.properties.sku -eq "Dynamic") {
                        $isValid = $false
                    }
                    else {
                        Write-AtlasOutput -LogLevel "INFO" -Message "Resource $resourceName of type $resourcetype is valid"
                    }
                }
                elseif ($resourcetype -eq "Microsoft.Web/serverFarms") {
                    if ($resource.sku.tier -eq "Dynamic") {
                        $isValid = $false
                    }
                    else {
                        Write-AtlasOutput -LogLevel "INFO" -Message "Resource $resourceName of type $resourcetype is valid"
                    }
                }
                else {
                    Write-AtlasOutput -LogLevel "WARN" -Message "Resource $resourceName of type $resourcetype is not a valid Resource type for this runbook."
                }
            }

            if (!$isValid) {
                $sendEmailAlert = $true
                $ErrorMessage = "Name: $resourceName; Type: $resourcetype; RG: $resourceRG failed resource validation"
                $emailResourceString += "$ErrorMessage `r `r"
                Write-AtlasOutput -LogLevel "ERROR" -Message $ErrorMessage


                Switch ($resourcetype) {
                    { $_ -eq 'Microsoft.Web/sites' } {
                        Write-AtlasOutput -LogLevel "WARN" -Message "${$resourceName}: remediation for Function App is not yet implemented"
                    }
                    { $_ -eq 'Microsoft.Web/serverFarms' } {
                        Write-AtlasOutput -LogLevel "WARN" -Message "${$resourceName}: remediation for Consumption Plan is not yet implemented"
                    }
                    default {
                        Write-AtlasOutput -LogLevel "WARN" -Message "${$resourceName}: is not a valid resource type($resourcetype)"
                    }
                }

            }
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "  APP:  $resourceName is not Atlas thus verfication not performed."
        }

    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "This alert was generated via a change from runbook $CONST_AUTOMATION_ACCOUNT_NAME/$CONST_TARGET_RUNBOOK, so no action taken."
        Write-AtlasOutput -LogLevel "INFO" -Message "  subscriptionName:  $subscriptionName"
        Write-AtlasOutput -LogLevel "INFO" -Message "  appServiceRG:  $resourceRG"
        Write-AtlasOutput -LogLevel "INFO" -Message "  appServiceName:  $resourceName"
    }
}
else {
    #runbook was not triggered by webhook print warning and exit
    # call the runbook to verify/update the web log config for app service
    Write-AtlasOutput -LogLevel "WARN" -Message "Runbook was not triggered by Webhook. Exiting..."
}

#send alert email
if ($sendEmailAlert) {
    $emailFrom = "$($runbookDetail.RunbookName)@cunamutual.com"
    $emailSubject = "ACTION REQUIRED: Invalid Consumption Plan Alert"

    $emailBody = "Below is an invalid resource using consumption plan `r `r"
    $emailBody += $emailResourceString
    $emailBody += "`r `r `r  Executed from $($runbookDetail.AutomationAccountName), Runbook is $($runbookDetail.RunbookName)."
    $EmailbodyData = $emailBody | Out-String
    try {
        Send-TeamTitanEmailAlert -emailFrom $emailFrom -emailSubject $emailSubject -EmailbodyData $EmailbodyData -ErrorAction stop
    }
    catch {
        $errorMessage = "ERROR: Failed to send email."
        throw $errorMessage
    }
}

Write-AtlasOutput -LogLevel "INFO" -Message "runbook complete"
