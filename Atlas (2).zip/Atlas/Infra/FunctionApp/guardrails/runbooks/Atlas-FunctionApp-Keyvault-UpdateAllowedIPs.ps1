param
(
    [Parameter (Mandatory = $false)]
    [PsObject] $WebhookData,
    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)

# tiger team app service logging runbook info
$CONST_DEST_AA_SUBSCRIPTION = "CMFG Production"
$CONST_AUTOMATION_ACCOUNT_NAME = "AA-CMFG-P01-InfraMgmt-AZ"
$CONST_TARGET_RUNBOOK = "Atlas-FunctionApp-Keyvault-UpdateAllowedIPs"


# Function to add all possible outbound function app ips to the
#   keyvault it uses in its app settings
#################################################################
function Add-FunctionIpsToKeyvault {
    param(
        [Parameter(Mandatory = $true)][string]$functionAppName,
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][psobject]$Context
    )

    #get the inbound ip and all possible outbound ips on function app
    $functionAppIPs = Get-AzResource -ResourceType "Microsoft.Web/sites" `
        -ResourceGroupName $resourceGroup `
        -ResourceName $functionAppName `
        -DefaultProfile $Context

    $InboundIp = $functionAppIPs.Properties.inboundIpAddress
    $possibleOutboundIps = $functionAppIPs.Properties.PossibleOutboundIpAddresses.split(',')

    # Check if inbound IP address is already in the outbound list, if not, add it
    if (!($possibleOutboundIps | Where-Object { $_ -match $InboundIp })) {
        $possibleOutboundIps = $possibleOutboundIps + $InboundIp
    }

    #get key vault in app settings
    $functionApp = Get-AzWebApp -ResourceGroup $resourceGroup -Name $functionAppName -DefaultProfile $Context
    $AppSettings = $functionApp.SiteConfig.AppSettings
    $keyvaultName = ""
    foreach ($setting in $AppSettings) {
        if ($setting.Name -eq "AzureWebJobsStorage") {
            #Example app setting value
            # @Microsoft.KeyVault(SecretUri=https://kv-atlasbuildtesting.vault.azure.net/secrets/FunAppWebJobStorageKey-saaeacdadc454886/ecca051e7acb4eaf9b7656d30a07a5ab)
            if ($setting.Value.Contains("Microsoft.KeyVault(SecretUri=https://")) {
                $keyvaultURL = ($setting.Value).split('/')[2]
                $keyvaultName = $keyvaultURL.split('.')[0]
            }
        }
    }
    if ($keyvaultName -ne "") {
        #then process
        #add network rules
        foreach ($ip in $possibleOutboundIps) {
            Write-AtlasOutput -LogLevel "INFO" -Message "Adding $ip as allowed on $keyvaultName."
            Add-AzKeyVaultNetworkRule -VaultName $keyvaultName -IpAddressRange "$ip/32" -DefaultProfile $Context
            Write-AtlasOutput -LogLevel "INFO" -Message "$ip has been allowed."
        }
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "No Key Vault found for AzureWebJobsStorage thus no keyvault rules set"
    }
}

# Start Main
###########################################################
$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module Az.Automation | Out-Null
}
catch {
    Write-Warning "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"

#############################################################################################
# Source Atlas-CommmonCode runbook must reside in the same as your runbook
#############################################################################################
Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. ./Atlas-CommonCode.ps1
Write-AtlasOutput -Message " "

$VerbosePreference = "SilentlyContinue"
Azure-Connect

if ($WebhookData) {
    $WebhookBody = $WebhookData.RequestBody | ConvertFrom-Json

    # break down the event data into component pieces necessary for downstream passthrough
    $subscriptionId = $WebhookBody.subject.Split("/")[2]
    $subscriptionName = (Get-AzSubscription -SubscriptionId $subscriptionId).Name
    $resourceRG = $WebhookBody.subject.Split("/")[4]
    $resourcetype0 = $WebhookBody.subject.Split("/")[6]
    $resourcetype1 = $WebhookBody.subject.Split("/")[7]
    $resourcetype = "$resourcetype0/$resourcetype1"
    $resourceName = $WebhookBody.subject.Split("/")[8]

    # check the appId that resulted in the alert fireing.  If it was our runbook runas account, don't call the runbook again.
    # if the alert that called this runnbook was generated via a change from the web logging runbook, we don't need/want
    # to call the runbook again.
    # these appids are for the service principals that are the runas accounts for our runbook
    #   SP-AA-InfraMgmt-Az-D   6e5ed314-7154-4254-84b0-e43f1c638615
    #   SP-AA-InfraMgmt-Az-P   aed58b11-d650-4e8f-b740-30704654d758

    # Skip over the Atlas-Test resource groups
    if ($resourceRG -notmatch "Atlas-Test") {
        $callerAppId = $WebhookBody.data.claims.appid
        if ($callerAppId -ne "6e5ed314-7154-4254-84b0-e43f1c638615" -and
            $callerAppId -ne "aed58b11-d650-4e8f-b740-30704654d758") {

            #check settings on app or asp

            Write-AtlasOutput -LogLevel "INFO" -Message "`t Subscription Name: $($subscriptionName)"
            $Context = Set-AzContext -Subscription $subscriptionName
            Write-AtlasOutput -LogLevel "INFO" -Message "`t Resource Group: $($resourceRG)"

            #check if rg is atlas, if not atlas don't check it
            $checkApp = Is-RGAtlas-Runbook -resourceGroup $resourceRG -Context $Context

            if ($checkApp) {
                Write-AtlasOutput -LogLevel "INFO" -Message "`t Resource Name: $($resourceName)"

                if ($resourcetype -eq "Microsoft.Web/sites") {
                    $appService = Get-AzResource -Name $resourceName -ResourceType $resourcetype -ResourceGroupName $resourceRG -DefaultProfile $Context
                    if ($appService.kind -eq "functionapp") {
                        #call function for processing
                        Add-FunctionIpsToKeyvault -resourceGroup $resourceRG -functionAppName $resourceName -Context $Context
                    }
                    else {
                        Write-AtlasOutput -LogLevel "INFO" -Message "APP: $($resourceName) is not a Function App thus not processed."
                    }
                }
                else {
                    Write-AtlasOutput -LogLevel "WARN" -Message "Resource $($resourceName) of type $($resourcetype) is not a valid Resource type for this runbook."
                }
            }
            else {
                Write-AtlasOutput -LogLevel "INFO" -Message "`t APP: $($resourceName) is not Atlas thus not processed."
            }
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "This alert was generated via a change from runbook $CONST_AUTOMATION_ACCOUNT_NAME/$CONST_TARGET_RUNBOOK, so no action taken."
            Write-AtlasOutput -LogLevel "INFO" -Message "`t Subscription Name: $($subscriptionName)"
            Write-AtlasOutput -LogLevel "INFO" -Message "`t FunctionApp Resource Group: $($resourceRG)"
            Write-AtlasOutput -LogLevel "INFO" -Message "`t FunctionApp Name: $($resourceName)"
        }
    } 
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t Atlas test resource group, skipping: $($resourceRG)"
    }
}
else {
    # runbook was not triggered by webhook print warning and exit
    # call the runbook to verify/update the web log config for app service
    Write-AtlasOutput -LogLevel "WARN" -Message "Runbook was not triggered by Webhook. Exiting..."
}

Write-AtlasOutput -LogLevel "INFO" -Message "Runbook complete"