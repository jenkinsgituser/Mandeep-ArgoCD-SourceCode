param
(
    [Parameter (Mandatory = $false)]
    [string] $SubscriptionName,

    [Parameter (Mandatory = $false)]
    [bool] $ProductionDeployment = $true,

    [Parameter (Mandatory = $false)]
    [bool] $DeployAll = $true,

    [Parameter (Mandatory = $false)]
    [string] $TargetRunbookResourceGroupName = "rg-cmfg-nc1-p01-itinfrastructure",

    [Parameter (Mandatory = $false)]
    [string] $TargetRunbookName = "Atlas-FunctionApp-Keyvault-UpdateAllowedIPs",

    [Parameter (Mandatory = $false)]
    [string] $TargetAutomationAccountName = "AA-CMFG-P01-InfraMgmt-AZ",

    [Parameter (Mandatory = $false)]
    [string] $TargetEventSubscriptionTemplateFile = "$env:INFRA_FOLDER/FunctionApp/guardrails/events/eventGridEventSubscrption.json",
    
    [Parameter (Mandatory = $false)]
    [string] $EventSubscriptionName = $TargetRunbookName
)

# Function to handle an Azure deployment
function DeployEventSubscription {
    param
    (
        [Parameter (Mandatory = $true)]
        [psobject] $ParamObj

    )
    $deploymentResult = New-AzDeployment -Name "EventSubscriptionDeployment" `
        -Location "eastus2" `
        -TemplateParameterObject $ParamObj `
        -TemplateFile $TargetEventSubscriptionTemplateFile

    return $deploymentResult
}


# check for target runbook RG and switch subscriptions until found
try {
    Set-AzContext -SubscriptionName "CMFG Production"
    $exists = Get-AzResourceGroup -Name $TargetRunbookResourceGroupName -ErrorAction Stop
}
catch {
    Set-AzContext -SubscriptionName "CMFG NonProduction"
    $exists = Get-AzResourceGroup -Name $TargetRunbookResourceGroupName
}

if (!$exists) {
    Write-Error "Unable to find target runbook in CMFG Production and CMFG NonProduction. Exiting..."
    Exit 10
}

# get current date plus 9 years
# split off the hours and minutes, keep only MM/dd/yyyy

# use part 0
$expiryDate = ((Get-Date).AddYears(9) -f "MM/dd/yyyy" -Split " ")[0]

$webhook = New-AzAutomationWebhook -Name (Get-Date -f "MM-dd-yyyy_HH-mm") `
    -IsEnabled $True `
    -ExpiryTime $expiryDate `
    -RunbookName $TargetRunbookName `
    -ResourceGroup $TargetRunbookResourceGroupName `
    -AutomationAccountName $TargetAutomationAccountName `
    -Force

   
#Set filter array
$advancedFilterValues = @("Microsoft.Web/sites")

# Deteremine which subscriptions to process
############################################
if ($SubscriptionName) {
    #process only a single subscription
    $SubscriptionName = (Get-AzSubscription -SubscriptionName $SubscriptionName -ErrorAction Stop).Name
    $subscriptions = @("$SubscriptionName")
}
elseif ($ProductionDeployment -eq $false) {
    #process non-production subscriptions only
    $subscriptions = $(Get-AzSubscription | Where-Object { ($_.State -eq "Enabled") -and ($_.Name -match "NonProd|Sandbox") } | Select-Object Name).Name
}
elseif ($DeployAll -eq $true) {
    #process all subscriptions
    $subscriptions = $(Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object Name | Select-Object Name).Name
}
elseif ($ProductionDeployment -eq $true) {
    #process all PRODUCTION subscriptions
    $subscriptions = $(Get-AzSubscription | Where-Object { ($_.State -eq "Enabled") -and ($_.Name -match "( Prod|-Prod)") } | Sort-Object Name | Select-Object Name).Name
}
else {
    Write-Error "No matching deployment parameters found. Please review input params!"
}


# Apply event subscription to Azure subscription
###############################################
foreach ($subscription in $subscriptions) {
    $context = Set-AzContext -SubscriptionName $subscription
    $params = @{ eventSubName    = $EventSubscriptionName; `
            endpoint             = $webhook.WebhookURI; `
            advancedFilterValues = $advancedFilterValues
    }

    DeployEventSubscription -ParamObj $params

    # Check if DEFAULT-EVENTGRID RG is tagged, if not tag with cmdbAssetTag
    $targetId = "/subscriptions/$($context.Subscription.id)/resourceGroups/DEFAULT-EVENTGRID"
    $rg = Get-AzResourceGroup -Id $targetId 
    if (!$rg.Tags) {
        $NWTags = @{"cmdbAssetTag" = "000086590" }
        $catch = New-AzTag -ResourceId $targetId -Tag $NWTags
    }
}