# lines included here will run before any other tests within this folder
. ("$COMMON_FOLDER/gateway-utilities.ps1")
. ("$COMMON_FOLDER/Atlantis-utilities.ps1")
. ("$COMMON_FOLDER/azure-utilities.ps1")
. ("$INFRA_FOLDER/FunctionApp/src/functionAppVariables.ps1") 4> $null
. ("$env:COMMON_FOLDER/constants.ps1")
