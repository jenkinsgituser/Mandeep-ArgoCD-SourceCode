. "$env:COMMON_FOLDER/azure-utilities.ps1"
. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
. "$env:INFRA_FOLDER/FunctionApp/src/functionAppVariables.ps1"

Describe "Atlas-FunctionApp-StorageAccount-FirewallRules Tests" {

    BeforeAll {
        $resourceId = az resource show -g $env:SA_RG_NAME -n $env:SA_NAME --resource-type "Microsoft.Storage/storageaccounts" --query id -o tsv

        # note that this introduces coupling with resources expected to exist in Azure
        $GOOD_ENDPOINT_1 = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Testing/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-Atlas-Atlantis/subnets/49cb8034-9bbd-459d-a0d2-930e4f9d58f3-privatefunctions-subnet-v1"
        $GOOD_ENDPOINT_2 = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-RP-Test/subnets/rp-test-private-subnet"
        $BAD_ENDPOINT_1 = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/test-nonatlas-eastus2/subnets/default"

        # setup IsTest to enable sourcing of functions for unit testing
        $env:IsTest = $true
        . "$env:INFRA_FOLDER/FunctionApp/guardrails/runbooks/Atlas-FunctionApp-StorageAccount-FirewallRules.ps1"
        $env:IsTest = $false

        Mock Send-TeamTitanEmailAlert { Write-Host "Send-TeamTitanEmailAlert Called!" }
        Mock Is-RGAtlas-Runbook { return $true }
    }

    Context "Functional Unit Tests" {
        #TODO: Get-AtlasStorageAccounts
        #TODO: Set-AtlasResourceConfiguration
        #TODO: Ensure-AtlasStorageAccountNeworkRules
    }

    # Case 1 - One good endpoint
    # webhook 1
    # mock 1
    # result 1
    It "One Endpoint, Trusted Network" {
        Mock Get-AzStorageAccountNetworkRuleSet { return @{VirtualNetworkRules = @(@{virtualNetworkResourceId = $GOOD_ENDPOINT_1 }) } }

        # setup
        $groupId = "$(New-Guid)".Replace("-", "")
        $mockWebhookBody = @{
            subject = "$resourceId";
            data    = @{
                authorization = @{
                    action   = "Microsoft.Resource.WriteSuccess";
                    evidence = @{
                        principalId = "$groupId"
                    }
                };
                claims        = @{appId = "$groupId"; name = "test"; };
            };
        };
        $mockWebhookDataObj = @{RequestBody = (ConvertTo-Json -Depth 10 $mockWebhookBody) }

        # execute
        . "$env:INFRA_FOLDER/FunctionApp/guardrails/runbooks/Atlas-FunctionApp-StorageAccount-FirewallRules.ps1" -WebHookData $mockWebhookDataObj *> $null

        # assert
        Should -Invoke Send-TeamTitanEmailAlert -Times 0 -Scope It
    }

    # Case 2 - More than one good endpoint
    # webhook 2
    # mock 2
    # result 2
    It "More than one Endpoint, Trusted Networks" {
        Mock Get-AzStorageAccountNetworkRuleSet { return @{VirtualNetworkRules = @(@{virtualNetworkResourceId = $GOOD_ENDPOINT_1 }; @{virtualNetworkResourceId = $GOOD_ENDPOINT_2 }) } }

        # setup
        $groupId = "$(New-Guid)".Replace("-", "")
        $mockWebhookBody = @{
            subject = "$resourceId";
            data    = @{
                authorization = @{
                    action   = "Microsoft.Resource.WriteSuccess";
                    evidence = @{
                        principalId = "$groupId"
                    }
                };
                claims        = @{appId = "$groupId"; name = "test"; };
            };
        };
        $mockWebhookDataObj = @{RequestBody = (ConvertTo-Json -Depth 10 $mockWebhookBody) }

        # execute
        . "$env:INFRA_FOLDER/FunctionApp/guardrails/runbooks/Atlas-FunctionApp-StorageAccount-FirewallRules.ps1" -WebHookData $mockWebhookDataObj *> $null

        # assert
        Should -Invoke Send-TeamTitanEmailAlert -Times 0 -Scope It
    }

    # Case 3 - More than one bad endpoint
    It "More than one Endpoint, one bad" -skip {
        Mock Get-AzStorageAccountNetworkRuleSet { return @{VirtualNetworkRules = @(@{virtualNetworkResourceId = $GOOD_ENDPOINT_1 }; @{virtualNetworkResourceId = $BAD_ENDPOINT_1 }) } }

        # setup
        $groupId = "$(New-Guid)".Replace("-", "")
        $mockWebhookBody = @{
            subject = "$resourceId";
            data    = @{
                authorization = @{
                    action   = "Microsoft.Resource.WriteSuccess";
                    evidence = @{
                        principalId = "$groupId"
                    }
                };
                claims        = @{appId = "$groupId"; name = "test"; };
            };
        };
        $mockWebhookDataObj = @{RequestBody = (ConvertTo-Json -Depth 10 $mockWebhookBody) }

        # execute
        . "$env:INFRA_FOLDER/FunctionApp/guardrails/runbooks/Atlas-FunctionApp-StorageAccount-FirewallRules.ps1" -WebHookData $mockWebhookDataObj *> $null

        # assert
        Should -Invoke Send-TeamTitanEmailAlert -Times 1 -Scope It
    }


    # Case 4 - zero endpoints
    It "No Endpoints joined" {
        Mock Get-AzStorageAccountNetworkRuleSet { return @{ } }

        # setup
        $groupId = "$(New-Guid)".Replace("-", "")
        $mockWebhookBody = @{
            subject = "$resourceId";
            data    = @{
                authorization = @{
                    action   = "Microsoft.Resource.WriteSuccess";
                    evidence = @{
                        principalId = "$groupId"
                    }
                };
                claims        = @{appId = "$groupId"; name = "test"; };
            };
        };
        $mockWebhookDataObj = @{RequestBody = (ConvertTo-Json -Depth 10 $mockWebhookBody) }

        # execute
        . "$env:INFRA_FOLDER/FunctionApp/guardrails/runbooks/Atlas-FunctionApp-StorageAccount-FirewallRules.ps1" -WebHookData $mockWebhookDataObj *> $null

        # assert
        Should -Invoke Send-TeamTitanEmailAlert -Times 0 -Scope It
    }

}