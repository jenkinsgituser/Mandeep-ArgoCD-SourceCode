param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "Function App Tests" {

    BeforeAll {
        . ("$INFRA_FOLDER/FunctionApp/test/_includes.tests.ps1") 4> $null
        $WA_AZURE_TYPE = "Microsoft.Web/sites"
        $PLAN_AZURE_TYPE = "Microsoft.Web/serverFarms"
        $EXPECTED_WA_COUNT = 1
        $EXPECTED_APP_IDENTITIES = Get-AtlasAppServiceIdentities -resourceName $env:APP_NAME -resourceGroupName $env:APP_RG_NAME
        $EXPECTED_LOCATION = $(If ($env:APP_LOCATION) { "$env:APP_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
        $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()

        #get the application gateway resource result from the resource group
        $FA_Infer_Resource = [string]::Empty
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }
        $FA_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $WA_AZURE_TYPE -and $_.name -eq "$env:APP_NAME" })
        $Plan_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $PLAN_AZURE_TYPE -and $_.name -eq "$env:ASP_NAME" })
    }

    It "Utilities Script can be dot sourced" {
        (Get-ChildItem function:/).Name | Should -Contain "Get-AtlasNextAvailableAtlantisSubnet"
        (Get-ChildItem function:/).Name | Should -Contain "Add-GwIpToAppService"
    }

    It "Function App Inferred from Resource Group" {
        $FA_Infer_Resource | Should -Not -Be $null
    }

    It "Plan Inferred from Resource Group" {
        $Plan_Infer_Resource | Should -Not -Be $null
    }

    It "Function App in expected location" {
        $FA_Infer_Resource.location | Should -Be $EXPECTED_LOCATION
    }

    Context "AppSetting Validations" {
        BeforeAll {
            . ("$INFRA_FOLDER/FunctionApp/src/functionAppVariables.ps1")

            $ais = Get-AzApplicationInsights -ResourceGroupName $env:AIS_RG_NAME -Name $env:AIS_NAME
            $env:APPINSIGHTS_INSTRUMENTATIONKEY = $ais.InstrumentationKey

            $SECRET_NAME = "FunAppWebJobStorageKey-$env:SA_NAME"
            $SECRETURI = $(Get-SecretFromAtlasKeyVault -keyvault $env:KV_NAME -secretName $SECRET_NAME -openNetwork $true | ConvertFrom-Json).id

            # reconcile actual appsettings against those defined in functionAppVariables.ps1
            [array] $appSettings = @(
                @{ name = "FUNCTIONS_WORKER_RUNTIME"; value = $APP_RUNTIME_STACK },
                @{ name = "AzureWebJobsStorage"; value = "@Microsoft.KeyVault(SecretUri=$SECRETURI)" },
                @{ name = "FUNCTIONS_EXTENSION_VERSION"; value = $FUNCTIONS_EXTENSION_VERSION },
                @{ name = "WEBSITE_NODE_DEFAULT_VERSION"; value = $WEBSITE_NODE_DEFAULT_VERSION },
                @{ name = "APPINSIGHTS_INSTRUMENTATIONKEY"; value = $env:APPINSIGHTS_INSTRUMENTATIONKEY }
            )
            $actualAppSettings = Get-AzWebApp -ResourceGroupName $resourceGroup -Name $env:APP_NAME -ErrorAction SilentlyContinue
        }

        It "Has Expected App Settings" {
            foreach ($appSetting in $appSettings) {
                Write-Verbose "Check if AppSetting Found - $($appSetting.Name)" -Verbose
                $appSetting.value | Should -BeIn $actualAppSettings.SiteConfig.AppSettings.Value
            }
        }
    }

    Context "Attached Subnet Tests" {
        BeforeAll {
            $attachedSubnet = Get-AtlasAtlantisSubnetByAppServicePlan  -AspName $env:ASP_NAME -AspResourceGroup $env:ASP_RG_NAME
            $EXPECTED_ADDRESS_PREFIX = "25"
            $EXPECTED_PRIVATE_NETWORK_IDENTIFIER = "-privatefunctions-"
        }

        It "Has an attached subnet" {
            $attachedSubnet | Should -Not -Be $null
            $attachedSubnet | Should -Match "Atlantis"
            $attachedSubnet | Should -Match $EXPECTED_PRIVATE_NETWORK_IDENTIFIER
        }

        It "Attached subnet matches spec" {
            $subnet = $(az network vnet subnet show --ids $attachedSubnet) | ConvertFrom-Json
            $subnet.addressPrefix.Split('/')[1] | Should -Be $EXPECTED_ADDRESS_PREFIX
            $subnet.networkSecurityGroup | Should -Not -Be $null
            $subnet.networkSecurityGroup.id | Should -Match $EXPECTED_PRIVATE_NETWORK_IDENTIFIER
            $subnet.serviceEndpoints.service | Should -BeIn @("Microsoft.KeyVault", "Microsoft.ServiceBus", "Microsoft.Web", "Microsoft.Storage", "Microsoft.Sql", "Microsoft.EventHub", "Microsoft.AzureCosmosDB")
        }
    }

    Context "Validate Allowed Network IP Tests" {
        BeforeAll {
            $wAResourceWebConfig = $(az resource show --id "$($FA_Infer_Resource.id)/config/web") | ConvertFrom-Json
        }

        # only run these tests when an AG WAF is associated
        if ($env:AG_WAF_NAME) {
            It "Function App Ip Security Restrictions Retrievable" {
                $wAResourceWebConfig.properties.ipSecurityRestrictions.ipAddress.Count | Should -Be 2
                #index 1 should be the default deny all rule
                $wAResourceWebConfig.properties.ipSecurityRestrictions[1].ipAddress | Should -Contain "Any"
                $wAResourceWebConfig.properties.ipSecurityRestrictions[1].action | Should -Contain "Deny"
            }

            It "Function App IP matches AGWAF IP" {
                $wafIPObj = $(Get-Titan-AG-WAF-Public-IP -g $env:AG_WAF_RG_NAME -n $env:AG_WAF_NAME) | ConvertFrom-Json
                $expectedIP = $wafIPObj.ipAddress
                $expectedIP | Should -Not -Be $null
                $currentIp = $wAResourceWebConfig.properties.ipSecurityRestrictions.ipAddress[0].split("/")[0]
                $currentIP | Should -Be $expectedIP
            }
        }
        else {

            It "Function App Ip Security Restrictions Retrievable" {
                $wAResourceWebConfig.properties.ipSecurityRestrictions.ipAddress[0] | Should -Be "0.0.0.0/0"
                $wAResourceWebConfig.properties.ipSecurityRestrictions.action[0] | Should -Be "Deny"
            }
        }

        Write-Verbose "EXPECTED_APP_IDENTITIES systemIdentity: $($EXPECTED_APP_IDENTITIES.systemIdentity)" -Verbose
        It "System Assigned Identity Successfully Validated" {
            Write-Verbose "systemIdentity: $($EXPECTED_APP_IDENTITIES.systemIdentity)" -Verbose
            $EXPECTED_APP_IDENTITIES.systemIdentity | Should -Not -Be $null
        }

        if ($env:USE_MSI -eq $true) {
            It "User Identity Successfully Validated" {
                Write-Verbose "EXPECTED_APP_IDENTITIES userIdentities: $($EXPECTED_APP_IDENTITIES.userIdentities)" -Verbose
                foreach ($id in $EXPECTED_APP_IDENTITIES.userIdentities) {
                    Write-Verbose "userIdentity: $id" -Verbose
                    $id | Should -Not -Be $null
                }
            }
        }
    }

    Context "Sample App Deployment and Validation" {
        BeforeAll {
            $functionapp = $(az functionapp show --resource-group $resourceGroup --name $FA_Infer_Resource.name) | ConvertFrom-Json
            $functionConfigWebPreOp = $(az resource show --name "$($functionapp.name)/config/web" --resource-group $functionapp.resourceGroup --resource-type "Microsoft.Web/sites/config") | ConvertFrom-Json

            $testSite = "$env:INFRA_FOLDER/FunctionApp/test/SampleFunctionApp.zip"
            try {
                $result = $(az functionapp deployment source config-zip --resource-group $functionapp.resourceGroup --name $functionapp.name --src $testSite 2> $null)
                Write-Verbose "App Deploy Result: $result"
            }
            catch {
                #swallow?
            }
        }

        It "Remove Network Restriction" {
            # is hitting the resource in it's preferred state
            $result = az resource update --name "$($functionapp.name)/config/web" --resource-group $functionapp.resourceGroup --resource-type "Microsoft.Web/sites/config" --set properties.ipSecurityRestrictions="[]"
            $result | Should -Not -Be $null
        }

        It "Returns Expected Web Page" {

            $endpoint = "https://$($functionapp.hostNames[0])/"
            Write-Verbose "Endpoint: $endpoint" -Verbose
            $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
            $acceptHeaderVal = "*/*"
            $headers.Add("Accept", $acceptHeaderVal)

            $i = 0
            $response = $null
            while ($i -lt 5 -and ($response -eq $null)) {
                try {
                    $response = Invoke-WebRequest -Uri $endpoint -UseBasicParsing -Headers $headers
                }
                catch {
                    if ($_.Exception.Message -match "403") {
                        $response = $null
                    }
                }
                Start-Sleep -Seconds 5
                $i += 1
            }

            $response | Should -Not -Be $null
            #Write-Verbose "$($response.Content)" -Verbose
            $response.Content | Should -Match "Azure Function App is up and running"

        }

        It "Restore Network Restriction" {
            if ($env:AG_WAF_NAME) {
                # is hitting the resource in it's preferred state
                $result = Add-GwIpToAppService -appName $functionapp.name -appResourceGroup $functionapp.resourceGroup -appType $CONST_AS_RESOURCE_TYPE_FUNCTION_APP -gwResourceGroup $env:AG_WAF_RG_NAME -gwName $env:AG_WAF_NAME
            }
            else {
                $result = az resource update --name "$($functionapp.name)/config/web" --resource-group $functionapp.resourceGroup --resource-type "Microsoft.Web/sites/config" --set properties.ipSecurityRestrictions="[{'ipAddress':'0.0.0.0/0','action':'Deny','Prioriy':5000}]"
            }
            $result | Should -Not -Be $null
        }
    }

    Context "Associated Key Vault Tests" {

        It "Has Key Vault Variable Setup" {
            $env:KV_NAME | Should -Not -Be $null
        }

        It "App Identites should be greater than zero" {
            $EXPECTED_APP_IDENTITIES.Count | Should -BeGreaterThan 0
        }

        It "Access Policy Exists for Expected Identities" {
            $allIdentities = @()
            $allIdentities += $EXPECTED_APP_IDENTITIES.systemIdentity
            $allIdentities += $EXPECTED_APP_IDENTITIES.userIdentities

            $kvAccessPolicies = $((az keyvault show -n $env:KV_NAME) | ConvertFrom-Json).properties.accessPolicies
            foreach ($id in $allIdentities) {
                Write-Verbose "Access Policy Exists for Identity '$id'" -Verbose
                $id | Should -BeIn $kvAccessPolicies.objectId
            }
        }

        It "Appropriate IP Rules in Key Vault Rules" {
            $keyVaultRules = $(az keyvault network-rule list --name $env:KV_NAME) | ConvertFrom-Json

            $functionConfig = $(az functionapp show -n $env:APP_NAME -g $env:APP_RG_NAME) | ConvertFrom-Json
            $functionIps = $functionConfig.possibleOutboundIpAddresses.Split(',')

            # so this test has been a bit flakey, and my leading theory is that the KV is still processing
            # the rules sequentially, as whenever I follow up it looks fine. So I'm coding in some patience...

            # 13 is the magic number as of 10/25/2019 -- ymmv over time
            $i = 0
            while ($keyVaultRules.iprules.Count -lt 13 -and $i -lt 2) {
                Start-Sleep -Seconds 30
                $i += 1
                $keyVaultRules = $(az keyvault network-rule list --name $env:KV_NAME) | ConvertFrom-Json
            }

            Write-Verbose -Verbose "Function IP List: $functionIps"
            Write-Verbose -Verbose "Key Vault IP List: $($keyVaultRules.iprules.value)"
            $functionIps | ForEach-Object {
                "$($_)/32" | Should -BeIn $keyVaultRules.iprules.value
            }
        }
    }


    # Storage Account Key Rotation processes are being tested by the tests
    # within Infra/SharedSvcs/guardrails/runbooks/Self-Serve/test/RotateFunctionAppStorageKey/Atlas-RotateFunctionAppStorageKey.Tests.ps1

}