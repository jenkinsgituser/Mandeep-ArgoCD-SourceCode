﻿#**********************************************************
# Function App PaaS variables
#**********************************************************

$APP_NAME = Set-ValidateResourceNameVariable -variableName "APP_NAME" -variableValue $env:APP_NAME -variablePrefix $CONST_APP_PREFIX
Write-Verbose "APP_NAME: $APP_NAME" -Verbose

$APP_RG_NAME = $(If ($env:APP_RG_NAME) { "$env:APP_RG_NAME" } Else { Write-Error "ERROR: Missing value for 'APP_RG_NAME'"; Exit 1 })
Write-Verbose "APP_RG_NAME: $APP_RG_NAME" -Verbose

$APP_LOCATION = $(If ($env:APP_LOCATION) { "$env:APP_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
$APP_LOCATION = $APP_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "APP_LOCATION: $APP_LOCATION" -Verbose

$APP_ALWAYS_ON = $(If ($env:APP_ALWAYS_ON) { "$env:APP_ALWAYS_ON" } Else { $CONST_APP_ALWAYS_ON_DEFAULT })
Write-Verbose "APP_ALWAYS_ON: $APP_ALWAYS_ON" -Verbose

# TODO - enforce only dotnet (~2) and node (>), and only specific versions
$APP_RUNTIME_STACK = $(If ($env:APP_RUNTIME_STACK) { "$env:APP_RUNTIME_STACK" } Else { $CONST_APP_RUNTIME_FUNCTIONAPP_STACK_DEFAULT })
Write-Verbose "APP_RUNTIME_STACK: $APP_RUNTIME_STACK" -Verbose

$FUNCTIONS_EXTENSION_VERSION = $(If ($env:FUNCTIONS_EXTENSION_VERSION) { "$env:FUNCTIONS_EXTENSION_VERSION" } Else { $CONST_FUNCTIONS_EXTENSION_VERSION })
Write-Verbose "FUNCTIONS_EXTENSION_VERSION: $FUNCTIONS_EXTENSION_VERSION" -Verbose

$WEBSITE_NODE_DEFAULT_VERSION = $(If ($env:WEBSITE_NODE_DEFAULT_VERSION) { "$env:WEBSITE_NODE_DEFAULT_VERSION" } Else { $CONST_WEBSITE_NODE_DEFAULT_VERSION })
Write-Verbose "WEBSITE_NODE_DEFAULT_VERSION: $WEBSITE_NODE_DEFAULT_VERSION" -Verbose

$CORS_ALLOWED_ORIGINS = $(If ($env:CORS_ALLOWED_ORIGINS) { "$env:CORS_ALLOWED_ORIGINS" } Else { $CONST_CORS_ALLOWED_ORIGINS_DEFAULT })
Write-Verbose "CORS_ALLOWED_ORIGINS: $CORS_ALLOWED_ORIGINS" -Verbose

$env:ATLANTIS_RG_NAME = $(If ($env:ATLANTIS_RG_NAME) { "$env:ATLANTIS_RG_NAME" } Else { $(If ($env:VNET_RG_NAME) { "$env:VNET_RG_NAME" } Else { $null }) })
Write-Verbose "env:ATLANTIS_RG_NAME: $env:ATLANTIS_RG_NAME" -Verbose

$env:MSI_NAME = $(If ($env:MSI_NAME) {
        $env:MSI_NAME
    }
    Elseif ($env:IDENTITY_NAME) {
        $env:IDENTITY_NAME
    }
    else {
        [string]::Empty
    })
Write-Verbose "env:MSI_NAME: $env:MSI_NAME" -Verbose


$env:MSI_RG_NAME = $(If ($env:MSI_RG_NAME) {
        $env:MSI_RG_NAME
    }
    Elseif ($env:IDENTITY_RG_NAME) {
        $env:IDENTITY_RG_NAME
    }
    else {
        [string]::Empty
    })
Write-Verbose "env:MSI_RG_NAME: $env:MSI_RG_NAME" -Verbose


$env:USE_MSI = $(If (($env:MSI_NAME -and $env:MSI_RG_NAME) -or ($env:IDENTITY_NAME -and $env:IDENTITY_RG_NAME))
    { $true } Else { $false })
Write-Verbose "env:USE_MSI: $env:USE_MSI" -Verbose

#*******************************************************
# Storage Account Variables
#*******************************************************

# Name of the Azure Storage Account resource

$env:SA_NAME = $(If ($env:SA_NAME) { "$env:SA_NAME" } Else { $APP_NAME.ToUpper().Replace('AS-', 'sa').Replace('-', '').ToLower() })
$env:SA_NAME = Set-ValidateResourceNameVariable -variableName "SA_NAME" -variableValue $env:SA_NAME -variablePrefix $CONST_SA_PREFIX
if ($env:SA_NAME.Length -gt 24) {
    Write-Error "Built storage account name '$env:SA_NAME' exceeds 24 characters. Provisioning halted. "
    Exit 1
}
Write-Verbose "env:SA_NAME: $env:SA_NAME" -Verbose

$env:SA_RG_NAME = $(If ($env:SA_RG_NAME) { "$env:SA_RG_NAME" } Else { $APP_RG_NAME })
Write-Verbose "env:SA_RG_NAME: $env:SA_RG_NAME" -Verbose

$env:SA_ACCOUNT_TYPE = $(If ($env:SA_ACCOUNT_TYPE) { "$env:SA_ACCOUNT_TYPE" } Else { $CONST_SA_ACCOUNT_TYPE_DEFAULT })
Write-Verbose "env:SA_ACCOUNT_TYPE: $env:SA_ACCOUNT_TYPE" -Verbose

$env:SA_ACCESS_TIER = $(If ($env:SA_ACCESS_TIER) { "$env:SA_ACCESS_TIER" } Else { $CONST_SA_ACCESS_TIER_DEFAULT })
Write-Verbose "env:SA_ACCESS_TIER: $env:SA_ACCESS_TIER" -Verbose

$env:SA_LOCATION = $(If ($env:SA_LOCATION) { "$env:SA_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$APP_LOCATION" })
$env:SA_LOCATION = $env:SA_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "env:SA_LOCATION: $env:SA_LOCATION" -Verbose

$env:SA_PURPOSE = $(If ($env:SA_PURPOSE) { "$env:SA_PURPOSE" } Else { $CONST_SA_PURPOSE_FUNCTION_APP })
Write-Verbose "env:SA_PURPOSE: $env:SA_PURPOSE" -Verbose

#**********************************************************
# App Insights variables
#**********************************************************

$env:AIS_NAME = $(If ($env:AIS_NAME) { "$env:AIS_NAME" } Else { $APP_NAME.ToUpper().Replace('AS-', 'AIS-') })
$env:AIS_NAME = Set-ValidateResourceNameVariable -variableName "AIS_NAME" -variableValue $env:AIS_NAME -variablePrefix $CONST_AIS_PREFIX
Write-Verbose "env:AIS_NAME: $env:AIS_NAME" -Verbose

$env:AIS_RG_NAME = $(If ($env:AIS_RG_NAME) { "$env:AIS_RG_NAME" } Else { $APP_RG_NAME })
Write-Verbose "env:AIS_RG_NAME: $env:AIS_RG_NAME" -Verbose

$env:AIS_LOCATION = $(If ($env:AIS_LOCATION) { "$env:AIS_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$APP_LOCATION" })
$env:AIS_LOCATION = $env:AIS_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "env:AIS_LOCATION: $env:AIS_LOCATION" -Verbose

#**********************************************************
# Key Vault Variables
#**********************************************************

$env:KV_CREATE_NEW = $(If ($env:KV_CREATE_NEW) { [System.Convert]::ToBoolean($env:KV_CREATE_NEW) } Else { $CONST_KV_CREATE_NEW_DEFAULT })
Write-Verbose "env:KV_CREATE_NEW: $env:KV_CREATE_NEW" -Verbose

$env:KV_NAME = $(If ($env:KV_NAME) { "$env:KV_NAME" } Else { $APP_NAME.ToUpper().Replace('AS-', 'kv-').ToLower() })
$env:KV_NAME = Set-ValidateResourceNameVariable -variableName "KV_NAME" -variableValue $env:KV_NAME -variablePrefix $CONST_KV_PREFIX
if ($env:KV_NAME.Length -gt 24) {
    Write-Error "Built storage account name '$env:KV_NAME' exceeds 24 characters. Provisioning halted. "
    Exit 1
}
Write-Verbose "env:KV_NAME: $env:KV_NAME" -Verbose

$env:KV_RG_NAME = $(If ($env:KV_RG_NAME) { "$env:KV_RG_NAME" } Else { $APP_RG_NAME })
Write-Verbose "env:KV_RG_NAME: $env:KV_RG_NAME" -Verbose

$env:KV_LOCATION = $(If ($env:KV_LOCATION) { "$env:KV_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$APP_LOCATION" })
$env:KV_LOCATION = $env:KV_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "env:KV_LOCATION: $env:KV_LOCATION" -Verbose

$env:KV_SKU = $(If ($env:KV_SKU) { "$env:KV_SKU" } Else { $CONST_KV_SKU_DEFAULT })
Write-Verbose "env:KV_SKU: $env:KV_SKU" -Verbose

$env:AA_SP_PROVISIONING_SP = Get-ProvisioningObjectId
Write-Verbose "env:AA_SP_PROVISIONING_SP: $env:AA_SP_PROVISIONING_SP" -Verbose

# Generate Array of Objects for vnet firewall rules
$env:AKS_RGS = $(If ($env:AKS_RGS) { "$env:AKS_RGS" } Else { $null })
$env:VNETS = $(If ($env:VNETS) { "$env:VNETS" } Else { $null })
$env:SUBNETS = $(If ($env:SUBNETS) { "$env:SUBNETS" } Else { $null })

if ($env:AKS_RGS) {
    Write-Verbose "env:AKS_RGs: $env:AKS_RGS" -Verbose
    [array]$env:AKS_RGS = ($env:AKS_RGS.Replace(' ', '')).Split(',')
}
if ($env:VNETS) {
    Write-Verbose "env:VNETS: $env:VNETS" -Verbose
    [array]$env:VNETS = ($env:VNETS.Replace(' ', '')).Split(',')
}
if ($env:SUBNETS) {
    Write-Verbose "env:SUBNETS: $env:SUBNETS" -Verbose
    [array]$env:SUBNETS = ($env:SUBNETS.Replace(' ', '')).Split(',')
}

# Only execute if we have inputs to process
if ($env:AKS_RGS) {
    $env:NETWORKRULES = $(Set-NetworkRulesJSON -resourceGroups $env:AKS_RGS -vNets $env:VNETS -subnetNames $env:SUBNETS)
    Write-Verbose "env:NETWORKRULES: $env:NETWORKRULES" -Verbose
}
else {
    $env:NETWORKRULES = '[]'
    Write-Verbose "Network Rules Resource Groups were not passed." -Verbose
}

#*******************************************************
# Generate Array of Objects for vnet firewall rules
#*******************************************************

$env:AKS_CLUSTER_NAMES = $(if ($env:AKS_CLUSTER_NAMES) { $env:AKS_CLUSTER_NAMES.split(",") }else { "" })
Write-Verbose "env:AKS_CLUSTER_NAMES: $env:AKS_CLUSTER_NAMES" -Verbose

$env:FUNCTION_NAMES = $(if ($env:FUNCTION_NAMES) { $env:FUNCTION_NAMES.split(",") }else { "" })
Write-Verbose "env:FUNCTION_NAMES: $env:FUNCTION_NAMES" -Verbose

$env:ADDITIONAL_SUBNET_IDS = $(if ($env:ADDITIONAL_SUBNET_IDS) { $env:ADDITIONAL_SUBNET_IDS.split(",") }else { "" })
Write-Verbose "env:ADDITIONAL_SUBNET_IDS: $env:ADDITIONAL_SUBNET_IDS" -Verbose

#*******************************************************
# Generate Array of Objects for vnet firewall rules
#*******************************************************

$AG_WAF_NAME = $(If ($env:AG_WAF_NAME) { "$env:AG_WAF_NAME" } Else { $null })
Write-Verbose "AG_WAF_NAME: $AG_WAF_NAME" -Verbose

$AG_WAF_RG_NAME = $(If ($env:AG_WAF_RG_NAME) { "$env:AG_WAF_RG_NAME" } Else { $null })
Write-Verbose "AG_WAF_RG_NAME: $AG_WAF_RG_NAME" -Verbose
