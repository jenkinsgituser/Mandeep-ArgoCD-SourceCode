. ("$INFRA_FOLDER/FunctionApp/src/functionAppVariables.ps1")

# source general app service utilities
. ("$COMMON_FOLDER/appService-utilities.ps1")

# source utils specific to function app
. ("$INFRA_FOLDER/FunctionApp/src/functionapp-utils.ps1")

Write-Verbose "Deploying Azure Function App: $APP_NAME" -Verbose
$FA_TEMPLATE_FILE = ( "$INFRA_FOLDER/FunctionApp/src/FunctionApp.json")
Write-Verbose "FA_TEMPLATE_FILE: $FA_TEMPLATE_FILE" -Verbose

$ErrorActionPreference = "Stop"

$VerbosePreference = "SilentlyContinue"

$DEPLOYMENT_NAME = "deployFunctionApp-$(Get-Date -f yyyyMMddHHmmss)"

[array] $appSettings = @(
    @{ name = "FUNCTIONS_WORKER_RUNTIME"; value = $APP_RUNTIME_STACK },
    @{ name = "AzureWebJobsStorage"; value = "@Microsoft.KeyVault(SecretUri=$SECRETURI)" },
    @{ name = "FUNCTIONS_EXTENSION_VERSION"; value = $FUNCTIONS_EXTENSION_VERSION },
    @{ name = "WEBSITE_NODE_DEFAULT_VERSION"; value = $WEBSITE_NODE_DEFAULT_VERSION },
    @{ name = "APPINSIGHTS_INSTRUMENTATIONKEY"; value = $env:APPINSIGHTS_INSTRUMENTATIONKEY }
)

if ($env:IsLocal) {
    $appSettingsFilePath = $FA_TEMPLATE_FILE -replace ".json", ".appSettings.mine.json"
} else {
    $appSettingsFilePath = $FA_TEMPLATE_FILE -replace ".json", ".appSettings.json"
}

Save-AppSettings -appResourceGroup $APP_RG_NAME -appName $APP_NAME -appSettings $appSettings -filePath $appSettingsFilePath

$Action = {
    az deployment group create `
        -g "$APP_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$FA_TEMPLATE_FILE" `
        --parameters "appName=$APP_NAME" `
        "location=$APP_LOCATION" `
        "planName=$env:ASP_NAME" `
        "planRGName=$env:ASP_RG_NAME" `
        "alwaysOn=$APP_ALWAYS_ON" `
        "subnetRef=$env:ATLANTIS_SUBNET" `
        "useMsi=$env:USE_MSI" `
        "msiName=$env:MSI_NAME" `
        "msiRGName=$env:MSI_RG_NAME" `
        "appSettings=@$appSettingsFilePath" `
        "createdDate=$CREATED_DATE" `
        "TemplateVersion=$TEMPLATE_VERSION"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Function App: $APP_NAME" -Verbose