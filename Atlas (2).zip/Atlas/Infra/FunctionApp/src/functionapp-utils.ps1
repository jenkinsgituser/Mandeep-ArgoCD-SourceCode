function Apply-FunctionAppIPsToKV {
    param(
        [Parameter(Mandatory = $true)]
        [string]$keyvault,

        [Parameter(Mandatory = $true)]
        [string]$appName,

        [Parameter(Mandatory = $true)]
        [string]$appResourceGroup
    )

    $functionApp = Get-AzResource -ResourceType "Microsoft.Web/sites" -ResourceGroupName $appResourceGroup -ResourceName $appName
    $InboundIp = $functionApp.Properties.inboundIpAddress
    $functionIps = $functionApp.Properties.PossibleOutboundIpAddresses.split(',')

    # Check if inbound IP address is already in the outbound list, if not, add it
    if (!($functionIps | Where-Object { $_ -match $InboundIp })) {
        $functionIps = $functionIps + $InboundIp
    }
    $functionIps = $functionIps | ForEach-Object { $_ + "/32" }

    $currentKeyVaultNetworkAcls = (Get-AzKeyVault -VaultName $keyVault).NetworkAcls
    $currentNetworkAclsIpRange = $currentKeyVaultNetworkAcls.IpAddressRanges.ToArray()

    $updatedNetworkAclsIpRange = ($functionIps + $currentNetworkAclsIpRange)

    # if and when we need to remove these IPs, it'll be the same logic but with a filter to remove the FunctionApp Ips
    #$updatedNetworkAclsIpRange = $currentNetworkAclsIpRange | Where-Object {$_ -NotIn $functionIps}

    Write-Verbose "Updated Network IPs for KV: $updatedNetworkAclsIpRange" -Verbose

    # don't lose any virtualNetworkRules if we have them
    if ($currentKeyVaultNetworkAcls.VirtualNetworkResourceIds) {
        $currentNetworkAclsSubNets = $currentKeyVaultNetworkAcls.VirtualNetworkResourceIds.ToArray()
        Write-Verbose "Maintaining allowed network subnets: $currentNetworkAclsSubNets" -Verbose
        Set-NetworkRulesKV -keyvault $keyvault -ipArrayToSet $updatedNetworkAclsIpRange `
            -vNetResourceIdArrayToSet $currentKeyVaultNetworkAcls.VirtualNetworkResourceIds.ToArray()
    }
    else {
        Write-Verbose "No currently allowed Key Vault subnets to maintain..." -Verbose
        Set-NetworkRulesKV -keyvault $keyvault -ipArrayToSet $updatedNetworkAclsIpRange
    }

}