#**********************************************************
# Validate Key Vault is an Atlas product
#**********************************************************

# Double check that KV exists and is Atlas
$KV = $null
$KV = az keyvault show --name $env:KV_NAME | ConvertFrom-Json
$KVIsAtlas = Is-RGAtlas -resourceGroup $KV.resourceGroup

if ($null -ne $KV -and $KVIsAtlas) {
    Write-Verbose "KV_NAME: $env:KV_NAME" -Verbose
}
else {
    # kv is null error out
    Write-Error -Message "ERROR: Enter valid value for 'KV_NAME'.  Key vault must exist and be Atlas" -ErrorAction Stop
    Exit 1
}

#**********************************************************
# Set Key Vault Secret Name for Storage Account Key
#**********************************************************

$SECRET_NAME = "FunAppWebJobStorageKey-$env:SA_NAME"
Write-Verbose "SECRET_NAME: $SECRET_NAME" -Verbose
Write-Host "##vso[task.setvariable variable=SECRET_NAME;]$SECRET_NAME"

#**********************************************************
# Add Storage Account Key to Key Vault Secret
#**********************************************************

Write-Verbose "CONST_ENDPOINT_SUFFIX: $CONST_ENDPOINT_SUFFIX" -Verbose

Write-Verbose "CONST_ENDPOINT_PROTOCOL: $CONST_ENDPOINT_PROTOCOL" -Verbose

# Get storage account key
Write-Verbose "Getting Storage Account Keys" -Verbose
$storageKeys = $(Invoke-CommandWithRetries -Command "az storage account keys list --account-name $env:SA_NAME --resource-group $env:SA_RG_NAME" -LineNumber $MyInvocation.ScriptLineNumber) | ConvertFrom-Json
# $storageKeys = az storage account keys list --account-name $SA_NAME --resource-group $SA_RG_NAME | Convertfrom-JSON

# Build storage account connection string
# testing has shown that just vaulting the secret is insufficient and instead a connection string is necessary for the
# function app to correctly connect to the functionapp resource.
# this defaults to grabbing the first key value as-is
Write-Verbose "Getting Storage Account Connection String" -Verbose
$connectionString = "DefaultEndpointsProtocol=$($CONST_ENDPOINT_PROTOCOL);AccountName=$($env:SA_NAME);AccountKey=$($storageKeys.value[0]);EndpointSuffix=$($CONST_ENDPOINT_SUFFIX)"

Write-Verbose "Adding Storage Account Connection String to Key Vault" -Verbose
# set removeWhenComplete to false as we don't want to close the key vault firewall here -- we're doing it in the master deploy already
Add-SecretToAtlasKeyvault -keyvault "$env:KV_NAME" -secretName "$SECRET_NAME" -secretValue "$connectionString" -removeWhenComplete $false


#***********************************************************************
# Atlantis Setup (follows all other validation as it performs a subnet allocation)
#***********************************************************************
# Performing validation that ASP hosts no type of App Service currently, or if it already exists it hosts the same App Service type (function vs. web app)
# Pipe error to null because it's possible it doesn't exist yet
# NOTE: we're using the Function App resource type for all the below operations
Write-Verbose "Getting App Service Plan Subnet" -Verbose
$appServiceAtlantisSubnetId = Get-AtlasAtlantisSubnetByAppServicePlan -AspName $env:ASP_NAME -AspResourceGroup $env:ASP_RG_NAME 2> $null
if ($appServiceAtlantisSubnetId) {
    # we want to validate that the ASP is setup to host the same kind of AS. E.g., if a
    # web app is currently there, we won't add a function app and vice versa. This call happens here to make sure
    # all is groovy, but it is also called earlier in the process to make the same determiniation up front and
    # fail fast if necessary.
    Write-Verbose "Validate the App Service Plan is used for only Function Apps" -Verbose
    $validWithPlan = Confirm-AppServiceTypeMatchesExistingTypeOnAsp -resourceType $CONST_AS_RESOURCE_TYPE_FUNCTION_APP -SubnetId $appServiceAtlantisSubnetId
    $currentResourceType = $CONST_AS_RESOURCE_TYPE_FUNCTION_APP
    if (!$validWithPlan) {
        Write-Error "Unable to complete joining App Service '$APP_NAME' with App Service Plan '$ENV:ASP_NAME'. The current plan is hosting
        resource types which cannot share subnet with type '$currentResourceType'. Please re-deploy with a different App Service Plan to overcome
        this issue."
        Exit 1
    }
    else {
        Write-Verbose -Verbose "Confirmed that App Service Plan '$ENV:ASP_NAME' is valid with resource type 'web'!"
    }
    $env:ATLANTIS_SUBNET = $appServiceAtlantisSubnetId
}
else {
    Write-Verbose "Getting the next available Atlantis Subnet" -Verbose
    $env:ATLANTIS_SUBNET = $(Get-AtlasNextAvailableAtlantisSubnet -resourceType $CONST_AS_RESOURCE_TYPE_FUNCTION_APP -location $APP_LOCATION).id
}
Write-Verbose "env:ATLANTIS_SUBNET: $($env:ATLANTIS_SUBNET)" -Verbose

Write-Verbose "Getting the Application Insights Instrumentation Key" -Verbose
$ais = Get-AzApplicationInsights -ResourceGroupName $env:AIS_RG_NAME -Name $env:AIS_NAME
$env:APPINSIGHTS_INSTRUMENTATIONKEY = $ais.InstrumentationKey

#**********************************************************
# Retrieve Storage Account Secret from Key Vault
# IMPORTANT: This must be the last code block
# befir running the Function App template.
#**********************************************************

Write-Verbose "Getting Storage Account Connection String SecretUri" -Verbose
$SECRETURI = $(Get-SecretFromAtlasKeyVault -keyvault $env:KV_NAME -secretName $SECRET_NAME -openNetwork $false | ConvertFrom-Json).id
