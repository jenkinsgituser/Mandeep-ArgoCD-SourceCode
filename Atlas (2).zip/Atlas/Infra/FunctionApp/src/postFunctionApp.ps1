#**********************************************************
# Grant App MSI get secret permission on Key Vault with
# the Storage Account connection string
#**********************************************************

<#
$APP_NAME = "AS-KAG20210604-834026"
$APP_RG_NAME = "RG-CMFG-T01-Atlas-Test-z485a127-834026-devSandbox"
$env:KV_NAME =  "kv-kag20210604-834026"

#TODO -JON
Write-Verbose "Forcing and update on KV tags..." -Verbose
$subId = $(az account show | ConvertFrom-Json).id
$ResourceID = "/subscriptions/$subId/resourceGroups/$APP_RG_NAME/providers/Microsoft.KeyVault/vaults/$env:KV_NAME"
$CurrentTags = (Get-AzResource -ResourceId $ResourceID).tags
$DeadOut = Set-AzResource -ResourceId $ResourceID -Tag $CurrentTags -Force
Write-Verbose "Done updating KV tags..." -Verbose
#>


# Grant MSI get secret permission on kv that was entered in
Write-Verbose "Getting Function App ObjectId" -Verbose
# always give access to the system identity since we always enable that
$GUID = $(az webapp identity show --name $APP_NAME --resource-group $APP_RG_NAME | ConvertFrom-Json).principalId
Write-Verbose "Granting Key Vault Access Permissions to Function App -- SystemAssigned Id $GUID" -Verbose
Invoke-CommandWithRetries -Command "az keyvault set-policy --name $env:KV_NAME --secret-permissions get --object-id $GUID" | Out-Null

# if user assigned MSI is being assigned to the function app, give it access to the keyvault too
if ($env:USE_MSI -eq $true) {
    $idObj = $(az webapp identity show --name $APP_NAME --resource-group $APP_RG_NAME | ConvertFrom-Json)
    foreach ($id in $idObj.userAssignedIdentities) {
        $name = $id.psobject.properties.name
        $principalId = $id.$name.principalId
        Write-Verbose "Granting Key Vault Access Permissions to Function App -- UserAssigned Id $principalId" -Verbose
        Invoke-CommandWithRetries -Command "az keyvault set-policy --name $env:KV_NAME --secret-permissions get --object-id $principalId" | Out-Null
    }
}

#**********************************************************
# Add IP rules for the FA to talk to the KV,
# which allows for AppSetting bootstrapping
#**********************************************************
Write-Verbose "Adding Function App IPs to Key Vault Firewall" -Verbose
Apply-FunctionAppIPsToKV -keyvault $env:KV_NAME -appName $APP_NAME -appResourceGroup $APP_RG_NAME

#**********************************************************
# Add the newly provisioned App Service to various subnets
# so it may be able to access other Atlas services
#**********************************************************

# Get resource id of app service
Write-Verbose "Getting Function App ResourceId" -Verbose
$resourceId = ($(az resource show -g $APP_RG_NAME -n $APP_NAME --resource-type "Microsoft.Web/sites") | ConvertFrom-Json).id

# Get subnet id of associated subnet
Write-Verbose "Getting Function App subnet" -Verbose
$subnet = ($(az resource show --ids "$resourceId/config/virtualNetwork") | ConvertFrom-Json).properties.subnetResourceId

# Allow function app subnet on keyvault
Write-Verbose "Adding Network Rule to allow Key Vault onto the same subnet as the Function App" -Verbose
Add-NetworkRuleToKV -keyvault $env:KV_NAME -ipRuleToAdd "" -subnetRuleToAdd $subnet

# Add newly acquired Atlantis subnet as allowed to FA's SA
Write-Verbose "Adding Network Rule to allow Storage Account onto the same subnet as the Function App" -Verbose
. "$env:DEPLOY_FOLDER/Common/AddAtlasAllowedSubnet.ps1" -targetResourceName $env:SA_NAME -targetResourceGroup $env:SA_RG_NAME `
    -targetResourceType $CONST_STORAGE_ACCOUNT_TYPE -sourceSubnetId $subnet

#**********************************************************
# (Optional) Get all Backend App services for an
# App Gateway and add the IPs to the Function App PaaS
#**********************************************************
if ($env:AG_WAF_RG_NAME -and $env:AG_WAF_NAME) {
    $ipAddress = Add-GwIpToAppService -appName $APP_NAME -appResourceGroup $APP_RG_NAME -appType $CONST_AS_RESOURCE_TYPE_FUNCTION_APP -gwResourceGroup $env:AG_WAF_RG_NAME -gwName $env:AG_WAF_NAME
    Write-Verbose "Successfully restricted traffic on $APP_NAME to only allow $ipAddress" -Verbose
    Write-Verbose "App Gateway WAF listening at IP address: https://$($ipAddress)" -Verbose

    Reset-GwBackendStatus -gwResourceGroup $env:AG_WAF_RG_NAME -gwName $env:AG_WAF_NAME
    Write-Verbose "Successfully update autoscaleConfiguration on $APP_NAME to re-associate backend listener." -Verbose
}
else {
    Write-Verbose "Skipping App Gateway WAF IP address integration." -Verbose
}

Write-Verbose "Restart FunctionApp post deployment to ensure config is in effect." -Verbose
az functionapp restart --name $APP_NAME --resource-group $APP_RG_NAME
