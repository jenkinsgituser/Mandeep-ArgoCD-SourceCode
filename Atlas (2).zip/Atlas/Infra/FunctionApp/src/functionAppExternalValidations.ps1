
# Reqiured Variable Validation
#***************************************************************
# confirm necessary env variables passed
if (!$env:AG_WAF_NAME -or !$env:AG_WAF_RG_NAME) {
    Write-Warning "The environment variables 'AG_WAF_NAME' and 'AG_WAF_RG_NAME' are not set. Function App will be deployed without support for HTTP Triggers"
    $env:AGWAF_ASSOCIATION = $false
}
else {
    $requestedAppGateway = az network application-gateway show -n $env:AG_WAF_NAME -g $env:AG_WAF_RG_NAME 2> $null
    if (!$requestedAppGateway) {
        Write-Error "The requested application gateway '$env:AG_WAF_NAME' in resource group '$env:AG_WAF_RG_NAME' cannot be found.
        Please ensure this exists and the deploying account has permissions to read and modify this resource."
        Exit 10
    }
    else {
        # verify Function App is not being deployed to the public subnet
        $subnetName = Get-AGWAF-SubnetName -appGateway $requestedAppGateway
        if ($null -ne $subnetName) {
            if ($subnetName -match "public") {
                Write-Error "The requested application gateway $env:AG_WAF_NAME is for use with public facing apps.
                A function app can not be deployed behind a public facing agwaf."
                Exit 10
            }
        }
        else {
            Write-Error "Unable to determine subnet type for application gateway $env:AG_WAF_NAME."
            Exit 10
        }
        $agwafLoc = ($requestedAppGateway | ConvertFrom-Json).location
        if ($agwafLoc -ne $APP_LOCATION) {
            Write-Error "Function App must have same location as AGWAF $env:AG_WAF_NAME which is located in $agwafLoc. "
            Exit 10
        }
    }
}

#**********************************************************
# App Service Plan validation
#**********************************************************
#figure out if the App Service Plan already exists, and if so, make sure it's in the same region as the web app being deployed
try {
    $aspExists = ((az appservice plan list -g $env:ASP_RG_NAME | ConvertFrom-Json) | Where-Object { $_.name -match $env:ASP_NAME }) 2> $null
    Write-Verbose "ASP Name Value Found: $($aspExists.name)" -Verbose
    if ($aspExists) {
        $existingASPLoc = ($aspExists.location).Replace(" ", "").ToLower()
        if ($existingASPLoc -ne $APP_LOCATION) {
            Write-Error "Function App must have same location as existing App Service Plan $env:ASP_NAME which is located in $existingASPLoc. "
            Exit 10
        }
    }
}
catch {
    Write-Error "App Service Plan list command failed to execute for resource group $env:ASP_RG_NAME and app service plan $env:ASP_NAME"
    Exit 10
}
