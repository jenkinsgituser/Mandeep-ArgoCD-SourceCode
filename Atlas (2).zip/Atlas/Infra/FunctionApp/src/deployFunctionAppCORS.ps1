# https://docs.microsoft.com/en-us/cli/azure/webapp/cors?view=azure-cli-latest
$CORS_ALLOWED_ORIGINS = if ($env:CORS_ALLOWED_ORIGINS) { $env:CORS_ALLOWED_ORIGINS } else { "http://localhost:5000 https://localhost:5001" }

Add-CORS-Origins -appName "$APP_NAME" -rgName "$APP_RG_NAME" -corsAlowedOrigins "$CORS_ALLOWED_ORIGINS"

Remove-CORS-Origins -appName "$APP_NAME" -rgName "$APP_RG_NAME" -corsAlowedOrigins "$CORS_ALLOWED_ORIGINS"

