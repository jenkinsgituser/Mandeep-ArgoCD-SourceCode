# define standard firewall rules for services to reference
$Global:STANDARD_CMFG_IP_RULES = @("208.91.239.30", "208.91.239.10", "208.91.239.11", "208.91.237.190", "208.91.237.161", "208.91.237.162", "8.36.116.204")
$Global:EXPECTED_BYPASS_VALUES = @("Logging", "AzureServices")


function Get-AtlasResourceConfiguration {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject]$Context,

        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $ResourceName,

        [Parameter(Mandatory = $true)]
        [AtlasResourceType] $AtlasResourceType,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken
    )

    $subscriptionID = $Context.Subscription.id

    switch ($AtlasResourceType) {
        ServiceBus { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.ServiceBus/namespaces/$ResourceName/networkRuleSets/default?api-version=2017-04-01" }
        StorageAccount { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Storage/storageAccounts/$($ResourceName)?api-version=2018-11-01" }

        default {
            $errorMsg = "Unable to determine appropriate ARM resource URI."
            Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        }
    }

    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -uri $uri -Headers $headers -Method 'GET' -UseBasicParsing
    Return $($response.Content | ConvertFrom-Json)
}


function Set-AtlasResourceConfiguration {
    [CmdletBinding(DefaultParameterSetName = "PowerShellObject")]
    param
    (
        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [PSObject]$Context,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $ResourceName,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [PSObject] $RulesObj,

        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $JsonBody,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [AtlasResourceType] $AtlasResourceType,

        [Parameter(Mandatory = $true, ParameterSetName = "PowerShellObject")]
        [Parameter(Mandatory = $true, ParameterSetName = "JsonBody")]
        [string] $AccessToken
    )

    if ($RulesObj) {
        #if the object has any Members other than "properties", remove them
        #this allows us to test by passing in objects retrieved from prior calls with minimal
        #modification necessary on our end
        $RulesObj.PSObject.Properties | Where-Object { $_.Name -ne "properties" } | ForEach-Object { $RulesObj.PSObject.Properties.Remove($_.Name) }
        $JsonBody = $RulesObj | ConvertTo-Json -Depth 10
        $JsonBody
    }

    $subscriptionID = $Context.Subscription.id
    switch ($AtlasResourceType) {
        ServiceBus { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.ServiceBus/namespaces/$ResourceName/networkRuleSets/default?api-version=2017-04-01" }
        StorageAccount { $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Storage/storageAccounts/$($ResourceName)?api-version=2018-11-01" }

        default {
            $errorMsg = "Unable to determine appropriate ARM resource URI."
            Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        }
    }

    $headers = @{"Authorization" = "Bearer " + $accessToken }
    $response = Invoke-WebRequest -uri $uri -Headers $headers -Method 'PUT' -Body $JsonBody -UseBasicParsing -ContentType "application/json"
    Return $($response.Content | ConvertFrom-Json)
}


#validate storage account network acl's
#################################################################
function Validate-AtlasESBLargeFileTransferStorageAccounts {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject]$Context,

        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken,

        [Parameter(Mandatory = $true)]
        [array] $StandardStorageAcctIpRules,

        [Parameter(Mandatory = $false)]
        [AllowNull()]
        [PSObject]$StorageAcctAllowedSubnets
    )

    # only retrieve storage accounts tagged for ESB largeFileTransfer use
    $StorageAccountNames = (Get-AzStorageAccount -ResourceGroupName $ResourceGroup -DefaultProfile $Context | Where-Object { $_.Tags.AtlasPurpose -eq "Atlas-ServiceBus-LargeFileTransfer" }).StorageAccountName

    foreach ($storageAcctNm in $StorageAccountNames) {

        Write-Output $("----Processing storage account: " + $storageAcctNm + "  for service bus: " + $serviceBus.Name)
        $storageAccount = Get-AtlasResourceConfiguration -Context $Context -AccessToken $accessToken -ResourceGroup $ResourceGroup -ResourceName $storageAcctNm -AtlasResourceType StorageAccount

        if (Compare-Object $storageAccount.properties.networkAcls.ipRules.value $standardStorageAcctIpRules.value) {

            Write-Output "-----***nonstandard firewall rules found, setting standard ip rules for storage account $storageAcctNm"
            $storageAccount.properties.networkAcls.ipRules = $StandardStorageAcctIpRules
            Write-Output "-----standard firewall rules applied for storage account $storageAcctNm"
            $changesToApply = $true
        }

        #check firewall exceptions to verify Only AzureServices is checked
        #this is split to an array as its a string value processed as an enum, so ordering
        #really doesn't matter
        $bypassConfig = $($storageAccount.properties.networkAcls.bypass -Split ',' -Replace ' ')
        #returns true if there are any differences for
        if (Compare-Object $Global:EXPECTED_BYPASS_VALUES $bypassConfig) {
            $storageAccount.properties.networkAcls.bypass = $($Global:EXPECTED_BYPASS_VALUES -join ", ")
            Write-Output "-----Storage Account $storageAcctNm firewall exceptions changed from $bypassConfig to standard: $($Global:EXPECTED_BYPASS_VALUES)"
            $changesToApply = $true
        }

        #if an allowed subnets object was passed, confirm the storage account matches
        #if it doesn't match, setup the storage account allowed subnets
        #
        #first we check that we have refernece subnets available on the SB, then we confirm we have some on the Storage Account
        #if we have both, we compare them for differences and reset if necessary using the SB as reference.
        #if we don't have any on the SB, we remove any that would exist on the SA
        #if we don't have any on the SA, we add them to match the SB
        if (($StorageAcctAllowedSubnets.subnet.id -and $storageAccount.properties.networkAcls.virtualNetworkRules.id -and (Compare-Object $StorageAcctAllowedSubnets.subnet.id $storageAccount.properties.networkAcls.virtualNetworkRules.id)) `
                -or `
            ($StorageAcctAllowedSubnets.subnet.id -and ($null -eq $storageAccount.properties.networkAcls.virtualNetworkRules.id)) `
                -or `
            ($null -eq $StorageAcctAllowedSubnets.subnet.id -and $storageAccount.properties.networkAcls.virtualNetworkRules.id)) {

            Write-Output "-----Identified allowed subnet mismatch on Storage Account $storageAcctNm"
            #grab the allowed subnets and create the appropriate object to set for a storage account
            $allowedSubnets = @()
            foreach ($id in $StorageAcctAllowedSubnets.subnet.id) {
                $property = @{"id" = $id; "action" = "Allow" }
                $allowedSubnets += New-Object PSCustomObject -Property $property
            }
            $storageAccount.properties.networkAcls.virtualNetworkRules = $allowedSubnets
            Write-Output "-----Storage Account $storageAcctNm allowed subnets updated to include $($StorageAcctAllowedSubnets.subnet.id)"
            $changesToApply = $true

        }

        if ($changesToApply) {
            Write-Output "-----Converting desired state to JSON and posting..."
            $JsonBody = $storageAccount | ConvertTo-Json -Depth 10
            Set-AtlasResourceConfiguration -Context $Context -AccessToken $accessToken -ResourceGroup $ResourceGroup -ResourceName $storageAcctNm -JsonBody $JsonBody -AtlasResourceType StorageAccount | Out-Null
            Write-Output "-----Desired state applied to Storage Account $storageAcctNm"
        }
        else {

        }

        Write-Output $("----Done processing storage account: " + $storageAcctNm + "  for service bus: " + $serviceBus.Name)
    }

}

#Function to identify the Atlas service buses (busi(?))
#executes using the currenty configured subscription context
#################################################################
function Get-AtlasServiceBusNamespace {
    param
    (
        [Parameter(Mandatory = $true)]
        [PSObject]$Context
    )

    $CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas"
    return $(Get-AzServiceBusNamespace -DefaultProfile $Context) | Where-Object { $_.tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER }
}

#Main
#################################################################

$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module Az.Accounts | Out-Null
    Import-Module Az.Automation | Out-Null
    Import-Module Az.ServiceBus | Out-Null
    Import-Module Az.Storage | Out-Null
    Import-Module Az.Resources | Out-Null
    #https://docs.microsoft.com/en-us/azure/automation/automation-runbook-execution#working-with-multiple-subscriptions
    Disable-AzContextAutosave -Scope Process | Out-Null
}
catch {
    Write-Warning "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"


#############################################################################################
# Source Atlas-CommmonCode runbook must reside in the same as your runbook
#############################################################################################
Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
if ($env:IsLocal -or $env:AGENT_ID) {
    Write-Verbose "Running in a local or build context!" -Verbose
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
}
else {
    #sourcing on the AA is slightly different than sourcing locally
    . ./Atlas-CommonCode.ps1
    Azure-Connect
    Write-AtlasOutput -Message "Azure-Connect complete."
}

#Setup rules needed by all processing
#######################################################
$standardEsbIpRules = @()
foreach ($ip in $Global:STANDARD_CMFG_IP_RULES) {
    $property = @{"ipMask" = $ip; "action" = "allow" }
    $standardEsbIpRules += New-Object pscustomobject -property $property
}

$standardStorageAcctIpRules = @()
foreach ($ip in $Global:STANDARD_CMFG_IP_RULES) {
    $property = @{"value" = $ip; "action" = "allow" }
    $standardStorageAcctIpRules += New-Object pscustomobject -property $property
}

#process each subscription for Service Bus activities. Use cmfg-sandbox for local testing
if ($env:IsLocal -or $env:AGENT_ID) {
    $subscriptions = (Select-AzSubscription -Subscription "cmfg-sandbox").Subscription.Name }
else {
    $subscriptions = $(Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object Name | Select-Object Name).Name}

# get access token here once, instead of in the functions
$azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile;
$profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile);

foreach ($subscription in $subscriptions) {
    Write-AtlasOutput -Message "--Processing subscription $sub..."
    $context = Set-AzContext -Subscription $subscription
    #the the access token per subscription, in the event that a processing occurrence runs longer than the token lifetime
    $accessToken = $profileClient.AcquireAccessToken($context.Subscription.TenantId).AccessToken;

    $serviceBusses = Get-AtlasServiceBusNamespace -Context $context
    foreach ($serviceBus in $serviceBusses) {
        Write-AtlasOutput -Message $("---Processing service bus: " + $serviceBus.Name)

        $sbNetworkRules = Get-AtlasResourceConfiguration -Context $context -AccessToken $accessToken -ResourceGroup $serviceBus.ResourceGroup -ResourceName $serviceBus.Name -AtlasResourceType ServiceBus

        if (($null -eq $sbNetworkRules.properties.ipRules.ipMask) -or `
            (Compare-Object $sbNetworkRules.properties.ipRules.ipMask $standardEsbIpRules.ipMask)) {

            Write-AtlasOutput -Message $("----***nonstandard firewall rules found, setting standard ip rules for service bus " + $serviceBus.Name)
            $sbNetworkRules.properties.ipRules = $standardEsbIpRules
            Set-AtlasResourceConfiguration -Context $context -AccessToken $accessToken -ResourceGroup $serviceBus.ResourceGroup -ResourceName $serviceBus.Name -RulesObj $sbNetworkRules -AtlasResourceType ServiceBus | Out-Null
            Write-AtlasOutput -Message $("----standard firewall rules have been applied for service bus " + $serviceBus.Name)
        }

        Validate-AtlasESBLargeFileTransferStorageAccounts -Context $context `
            -ResourceGroup $serviceBus.ResourceGroup `
            -AccessToken $accessToken `
            -StandardStorageAcctIpRules $standardStorageAcctIpRules `
            -StorageAcctAllowedSubnets $sbNetworkRules.properties.virtualNetworkRules

        Write-AtlasOutput -Message $("---Done processing service bus: " + $serviceBus.Name)
    }

    Write-AtlasOutput -Message "--$subscription processed."
}
Write-AtlasOutput -Message "Job complete."

