<#
    This script expects a resourceId for an Azure Service Bus resource.
    This Id can be hand fed or steam via webhook. Once determined, a role
    group flattening activity will be performed against the service bus. This
    will grant Contributor memberships directly to developers as the inheritied
    Group based permissions are ineffective at the moment -- known Azure bug with
    and expected fix date of end Q2 2019.
#>
param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceId,

    [Parameter (Mandatory = $false)]
    [PsObject] $WebhookData,

    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)
$RoleDef = "Contributor"

#Main
#################################################################


$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module Az.Resources | Out-Null
    Import-Module Az.ServiceBus | Out-Null
    Import-Module Az.Automation | Out-Null
    #https://docs.microsoft.com/en-us/azure/automation/automation-runbook-execution#working-with-multiple-subscriptions
    Disable-AzContextAutosave -Scope Process | Out-Null

}
catch {
    Write-Warning "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"


#############################################################################################
# Source Atlas-CommmonCode runbook must reside in the same as your runbook
#############################################################################################
Write-Verbose"Linking to Atlas-CommonCode Runbook..."  -Verbose
if ($env:IsLocal -or $env:AGENT_ID) {
    Write-Verbose  "Running in a local or build context!" -Verbose
    . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1
}
else {
    #sourcing on the AA is slightly different than sourcing locally
    . ./Atlas-CommonCode.ps1
    Azure-Connect
    Write-AtlasOutput -Message "Azure-Connect complete."
}

if ($resourceId) {
    # get the Sub Id
    $subscriptionId = ($resourceId -Split "/")[2]
}
else {
    $WebhookBody = $WebhookData.RequestBody | ConvertFrom-Json
    $subscriptionId = $WebhookBody.subject.Split("/")[2]
    $resourceid = $WebhookBody.subject
}
$context = Set-AzContext -SubscriptionId $subscriptionId

# Determine what to do
########################################################################
if ($WebhookData) {
    # check the appId that resulted in the alert fireing.  If it was our runbook runas account, don't call the runbook again.
    # if the alert that called this runbook was generated via a change from the web logging runbook, we don't need/want
    # to call the runbook again.
    # these appids are for the service principals that are the runas accounts for our runbook
    #   SP-AA-InfraMgmt-Az-D   6e5ed314-7154-4254-84b0-e43f1c638615
    #   SP-AA-InfraMgmt-Az-P   aed58b11-d650-4e8f-b740-30704654d758
    $callerAppId = $WebhookBody.data.claims.appid
    if ($callerAppId -eq "6e5ed314-7154-4254-84b0-e43f1c638615" -or
        $callerAppId -eq "aed58b11-d650-4e8f-b740-30704654d758") {
        Write-AtlasOutput -Message "Exiting early as triggering change was initiated by an automation account."
        Exit 10
    }
}

# Do the thing
##########################################################################
$resource = Get-AzResource -ResourceId $resourceId -DefaultProfile $context
if ($resource -and $resource.Type -eq "Microsoft.ServiceBus/namespaces") {
    # Get the existing group assignments on the resource
    $assignments = Get-AzRoleAssignment -Scope $resourceId -DefaultProfile $context

    # get only the group assignments effective directly on the ESB for flattening
    # explicitly ignoring inherited permissions
    $groupAssignments = $assignments | Where-Object { $_.ObjectType -eq "Group" -and $_.Scope -eq $resourceId }

    # get the user assignments which exist. Check each user against the group assignment just flattened, removing any users
    # which do not exist in the groups. This allows for automated removal of flattened users when the parent group is removed
    $userAssignments = $assignments | Where-Object { $_.ObjectType -eq "User" -and $_.Scope -eq $resourceId }

    # keep an arraylist of users which we flatten and add. Once
    $allowedFlattenedUsers = New-Object System.Collections.ArrayList($null)

    foreach ($group in $groupAssignments) {
        $members = Get-AzADGroupMember -GroupDisplayName $group.DisplayName -DefaultProfile $context
        foreach ($member in $members) {
            if ($userAssignments.SignInName -NotContains $member.UserPrincipalName) {
                try {
                    New-AzRoleAssignment -ObjectId $member.Id `
                        -RoleDefinitionName $RoleDef `
                        -Scope $resourceId `
                        -DefaultProfile $context `
                        -ErrorAction Stop `
                    | Out-Null
                    Write-AtlasOutput -Message "`t $($member.UserPrincipalName) added as $RoleDef to $resourceId `n"
                    $allowedFlattenedUsers.Add($member.UserPrincipalName) | Out-Null
                }
                catch {
                    $errorMsg = "Unable to add $($member.UserPrincipalName) as $RoleDef to $resourceId"
                    Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
                    Write-AtlasOutput -Message $_.Exception.Message
                }
            }
            else {
                Write-AtlasOutput -Message "`t $($member.UserPrincipalName) already exists as $RoleDef on $resourceId `n"
                $allowedFlattenedUsers.Add($member.UserPrincipalName) | Out-Null
            }
        }
        Write-AtlasOutput -Message "Groups flattened for $($group.DisplayName) on resource '$resourceId' `n"
    }

    foreach ($user in $userAssignments) {
        # remove the user if they aren't in the list of flattened users
        if (!$allowedFlattenedUsers.Contains($user.SignInName)) {
            try {
                Remove-AzRoleAssignment -Scope $resourceId `
                    -ObjectId $user.Objectid `
                    -RoleDefinitionName $RoleDef `
                    -ErrorAction Stop `
                | Out-Null
                Write-AtlasOutput -Message "`t $($member.UserPrincipalName) removed from $resourceId `n"
            }
            catch {
                $errorMsg = "Unable to remove $($member.UserPrincipalName) as $RoleDef from $resourceId"
                Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
                Write-AtlasOutput -Message $_.Exception.Message
            }
        }
    }

}
else {
    $errorMsg = "Unable to discover resource '$resourceId'"
    Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
}
