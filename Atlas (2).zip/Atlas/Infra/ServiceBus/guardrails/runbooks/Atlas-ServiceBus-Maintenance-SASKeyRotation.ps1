$CONST_ATLAS_EXCEPTIONS_TAG = "AtlasExceptions"
$CONST_KEY_ROTATION_EXCEPTION_VALUE = "KeyRotationException"

$ATLAS_LARGE_FILE_TRANSFER_TAG_VALUE = "Atlas-ServiceBus-LargeFileTransfer"
$CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas"

#Function to rotate SAS keys for Service Bus and Storage Account on-demand
function Invoke-AtlasServiceBus-EnforceSASPolicies {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,
        [Parameter(Mandatory = $true)]
        [array] $SBData
    )
    $ErrorActionPreference = "Continue"
    $CONST_ROOT_KEY = "RootManageSharedAccessKey"

    $busNamespace = $SBData.Name
    $SBAuthRules = Get-AzServiceBusAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $busNamespace
    Foreach ($SBAuthRule in $SBAuthRules) {
        $SAS = $SBAuthRule.name
        if ($SAS -eq $CONST_ROOT_KEY) {
            #do for both Primary and Secondary
            @('PrimaryKey', 'SecondaryKey') | ForEach-Object {
                New-AzServiceBusKey -ResourceGroupName $ResourceGroup -Namespace $busNamespace -Name $SAS -RegenerateKey $_ | Out-Null
                Write-Output "`t `t `t Rotated key $($_) for SAS $SAS on namespace $busNamespace"
            }
        }
        else {
            Remove-AzServiceBusAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $busNamespace -Name $SAS -Force
            Write-Output "`t `t `t Removed authorization rule for SAS $SAS on namespace $busNamespace"
        }
    }


    #delete any SAS configured on queues or topics -- we're not using them
    #######################################################################
    #Topic - SAS Cleanup
    Get-AzServiceBusTopic -ResourceGroupName $ResourceGroup -Namespace $busNamespace | ForEach-Object {
        $topic = $_.Name;
        Get-AzServiceBusAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $busNamespace -Topic $topic | ForEach-Object {
            Remove-AzServiceBusAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $busNamespace -Topic $topic -Name $_.Name -Force;
            Write-Output "Removed rule $rule for Topic $($_.Name) on namespace $busNamespace"
        }
    }

    #Queue - SAS Cleanup
    Get-AzServiceBusQueue -ResourceGroupName $ResourceGroup -Namespace $busNamespace | ForEach-Object {
        $queue = $_.Name;
        Get-AzServiceBusAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $busNamespace -Queue $queue | ForEach-Object {
            Remove-AzServiceBusAuthorizationRule -ResourceGroup $ResourceGroup -Namespace $busNamespace -Queue $queue -Name $_.Name -Force;
            Write-Output "`t `t `t Removed rule $rule for Queue $($_.Name) on namespace $busNamespace"
        }
    }

    #storage account SAS cleanup
    ###############################################################################################
    Get-AzStorageAccount -ResourceGroup $ResourceGroup | Where-Object { $_.Tags.AtlasPurpose -eq $ATLAS_LARGE_FILE_TRANSFER_TAG_VALUE } | ForEach-Object {
        $storageAccount = $_.StorageAccountName;
        #apparently every SA has two keys, key1 and key2
        @('key1', 'key2') | ForEach-Object {
            New-AzStorageAccountKey -ResourceGroupName $ResourceGroup -Name $storageAccount -KeyName $_ | Out-Null
            Write-Output "`t `t `t Rotated key $_ for SAS $SAS on storage account $storageAccount"
        }
    }
}

#Function to Enforce a Blob Storage Lifecycle Policy
#################################################################
function Invoke-AtlasStorageAccount-EnforceStorageAccountLifecyclePolicies {
    param
    (
        [string]$ResourceGroup
    )
    $tempPreference = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"
    $CONST_RULE_NAME = "AtlasLargeFileTransfer"

    #for any storage account in the resource group
    Get-AzStorageAccount -ResourceGroup $ResourceGroup | Where-Object { $_.Tags.AtlasPurpose -eq $ATLAS_LARGE_FILE_TRANSFER_TAG_VALUE } | ForEach-Object {

        try {
            $policies = Get-AzStorageAccountManagementPolicy -ResourceGroupName $ResourceGroup -StorageAccountName $_.StorageAccountName
        }
        catch {
            Write-Output "------No policy found for storage account $($_.StorageAccountName)"
            $polices = $null
        }

        #if the storage account does not already have the necessary policy, add it
        if ($null -eq $policies -or $policies.Rules.Name -notcontains $CONST_RULE_NAME) {
            #Build and apply a storage account lifecycle policy to purge files no more than 2 days after they are created

            #https://docs.microsoft.com/en-us/azure/storage/blobs/storage-lifecycle-management-concepts#add-or-remove-a-policy
            $action = Add-AzStorageAccountManagementPolicyAction -SnapshotAction  Delete -daysAfterCreationGreaterThan 2
            $action = Add-AzStorageAccountManagementPolicyAction -BaseBlobAction Delete -daysAfterModificationGreaterThan 2  -InputObject $action

            # Create a new filter object
            # PowerShell automatically sets BlobType as “blockblob” because it is the only available option currently
            #mdx7683 - Create filter as an empty object as we don't want to prefix match
            $filter = New-AzStorageAccountManagementPolicyFilter

            #Create a new rule object
            #PowerShell automatically sets Type as “Lifecycle” because it is the only available option currently
            $rule1 = New-AzStorageAccountManagementPolicyRule -Name $CONST_RULE_NAME -Action $action -Filter $filter

            #Set the policy
            $policy = Set-AzStorageAccountManagementPolicy -ResourceGroupName $ResourceGroup -StorageAccountName $_.StorageAccountName -Rule $rule1

            Write-Output "`t `t `t Policy 'AtlasLargeFileTransfer' added to storage account '$($_.StorageAccountName)' for resource group $ResourceGroup"
        }
        else {
            Write-Output "`t `t `t Policy 'AtlasLargeFileTransfer' exists on storage account '$($_.StorageAccountName)' in resource group $ResourceGroup"
        }
    }
    # restore the preference to the original
    $ErrorActionPreference = $tempPreference
}

#Function to identify the Atlas resource groups from ALL groups
#################################################################
function Get-AllAtlasServiceBuses {
    return Get-AzResource -ResourceType "Microsoft.ServiceBus/namespaces" | Where-Object { $_.tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER }
}

#Main
#################################################################

# Connect via Azure Automation RunAs account
try {
    Write-Output "Connecting to Automation Account"
    $spConnection = Get-AutomationConnection -Name "AzureRunAsConnection"
    Write-Output "Logging in to Azure with Automation Account..."

    $Info = Connect-AzAccount `
        -ServicePrincipal `
        -TenantId $spConnection.TenantId `
        -ApplicationId $spConnection.ApplicationId `
        -CertificateThumbprint $spConnection.CertificateThumbprint

    Write-Output "Connected as Automation Account."
}
catch {
    if (!$spConnection) {
        $ErrorMessage = "AzureRunAsConnection not found."
        throw $ErrorMessage
    }
    else {
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

Write-Output "Start Time: $(Get-Date)"
Write-Output "`r"

#process each subscription for Service Bus activities. Use cmfg-sandbox for local testing
if ($env:IsLocal -or $env:AGENT_ID) {
    $subscriptions = (Select-AzSubscription -Subscription "cmfg-sandbox").Subscription.Name }
else {
    $subscriptions = $(Get-AzSubscription).Name | Sort-Object}

foreach ($sub in $subscriptions) {
    Write-Output "`t Processing subscription $sub..."
    Set-AzContext -Subscription $sub | Out-Null
    $AtlasSBs = Get-AllAtlasServiceBuses
    foreach ($AtlasSB in $AtlasSBs) {
        Write-Output "`t `t Processing Service Bus Namespace: $($AtlasSB.Name)"
        # if the service bus namespace isn't tagged as an KeyRotation exception, rotate the keys
        if ($AtlasSB.Tags.$CONST_ATLAS_EXCEPTIONS_TAG -notmatch $CONST_KEY_ROTATION_EXCEPTION_VALUE) {
            Invoke-AtlasServiceBus-EnforceSASPolicies -ResourceGroup $AtlasSB.ResourceGroupName -SBData $AtlasSB
            Invoke-AtlasStorageAccount-EnforceStorageAccountLifecyclePolicies -ResourceGroup $AtlasSB.ResourceGroupName
        }
        else {
            # else it is tagged as an exception, so warn that this is so and move onwards
            Write-Warning "Service Bus Namespace '$($AtlasSB.Name)' will not have its keys rotated due to being tagged with a KeyRotation exception."
        }

        Write-Output "`t `t $($AtlasSB.ResourceGroupName) processed."
    }
    Write-Output "`t $sub processed."
}

Write-Output "End Time: $(Get-Date)"
Write-Output "`r"

Write-Output "Job complete."
