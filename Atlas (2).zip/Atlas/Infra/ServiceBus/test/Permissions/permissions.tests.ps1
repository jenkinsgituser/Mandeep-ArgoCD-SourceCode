param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

# source the _include file
. ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")

if ($env:IsLocal) {
    Write-Verbose "Skipping permissions tests when running local, no access to test" -Verbose
    exit
}

Describe "Permission Validation Tests" {

    BeforeAll {
        $EXPECTED_PERM_IDENTIFIER = "R-TeamTitan-LSA"
        $EXPECTED_ROLE_BUS = "Azure Service Bus Data Owner"
        $EXPECTED_ROLE_STORAGE_ACCOUNT = "Storage Blob Data Contributor"

        If ($env:STORAGE_ACCOUNT_NAME) { $STORAGE_ACCOUNT_NAME = "$env:STORAGE_ACCOUNT_NAME" }
        Else { $STORAGE_ACCOUNT_NAME = "sa" + "$env:BUS_NAMESPACE".ToLower().Replace('-', '') }
        If ($STORAGE_ACCOUNT_NAME.Length -gt 24) {
            $STORAGE_ACCOUNT_NAME = $STORAGE_ACCOUNT_NAME.Substring(0, 24)
        }
    }

    It "Permissions Assigned to Namespace" {
        $rgResources = $(az resource list -g $resourceGroup -n $env:BUS_NAMESPACE) | ConvertFrom-Json
        $busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
        $roles = $(az role assignment list --scope $busResource.Id) | ConvertFrom-Json
        $roles | Should -Not -Be $null
        $roles | Where-Object { $_.principalName -eq $EXPECTED_PERM_IDENTIFIER } | Should -Not -Be $null
        $($roles | Where-Object { $_.principalName -eq $EXPECTED_PERM_IDENTIFIER }).roleDefinitionName | Should -Be $EXPECTED_ROLE_BUS
    }

    #only run this test when appropriate
    if ([System.Convert]::ToBoolean($env:SUPPORT_LARGE_FILE_TRANSFER)) {
        It "Permissions Assigned to Storage Account" {
            $rgResources = $(az resource list -g $resourceGroup -n $STORAGE_ACCOUNT_NAME) | ConvertFrom-Json
            $saResource = $rgResources | Where-Object { $_.type -eq "Microsoft.Storage/storageAccounts" }
            $roles = $(az role assignment list --scope $saResource.Id) | ConvertFrom-Json
            $roles | Should -Not -Be $null
            $roles | Where-Object { $_.principalName -eq $EXPECTED_PERM_IDENTIFIER } | Should -Not -Be $null
            $($roles | Where-Object { $_.principalName -eq $EXPECTED_PERM_IDENTIFIER }).roleDefinitionName | Should -Be $EXPECTED_ROLE_STORAGE_ACCOUNT
        }
    }
}