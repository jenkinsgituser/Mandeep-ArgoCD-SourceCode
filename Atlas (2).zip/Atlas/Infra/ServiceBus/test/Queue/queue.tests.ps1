param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

# source the _include file
. ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")

$rgResources = (Get-AzResource -ResourceGroupName $resourceGroup -name $env:BUS_NAMESPACE)
$busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
Describe "Queue Creation Tests" {

    BeforeAll {
        #if ($rgResources -eq $null){
        $rgResources = $(az resource list -g $resourceGroup -n $env:BUS_NAMESPACE) | ConvertFrom-Json
        #}
        $busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
    
        $EXPECTED_QUEUE_NAME = $env:QUEUE_NAME
        Write-Host "QUEUE1: $EXPECTED_QUEUE_NAME"
    }


    It "EXPECTED_QUEUE_NAME is set" {
        $EXPECTED_QUEUE_NAME | Should -Not -Be $null
    }

    It "Queue is Created" {
        Write-Host "QUEUE: $EXPECTED_QUEUE_NAME"
        Write-Host "bus: $($busResource.Name)"
        . ("$DEPLOY_FOLDER\ServiceBus\operations\modify\azureAddQueue.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name) -queueName $EXPECTED_QUEUE_NAME

        $busQueue = $(az servicebus queue list --namespace-name $busResource.name -g $resourceGroup) | ConvertFrom-Json
        $busQueue | Should -Not -Be $null
        $busQueue.name | Should -Contain $EXPECTED_QUEUE_NAME
    }
}


Describe "Queue Deletion Tests" {

    BeforeAll {
        #if ($rgResources -eq $null){
        $rgResources = $(az resource list -g $resourceGroup -n $env:BUS_NAMESPACE) | ConvertFrom-Json
        #}
        $busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
    
        $EXPECTED_QUEUE_NAME = $env:QUEUE_NAME
        Write-Host "QUEUE1: $EXPECTED_QUEUE_NAME"
    }

    It "Queue is Deleted" {
        . ("$DEPLOY_FOLDER\ServiceBus\operations\delete\azureDeleteQueue.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name) -queueName $EXPECTED_QUEUE_NAME
        
        $busQueue = $(az servicebus queue list --namespace-name $busResource.name -g $resourceGroup) | ConvertFrom-Json
        $busQueue.name | Should -Not -Be $EXPECTED_QUEUE_NAME
        $busQueue.Count | Should -Be 0
    }
}