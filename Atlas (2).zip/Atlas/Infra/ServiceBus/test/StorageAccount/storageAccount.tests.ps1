param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

if ([System.Convert]::ToBoolean($env:SUPPORT_LARGE_FILE_TRANSFER)) {

    # source the _include file
    . ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")


    Describe "Storage Account Deployment Tests" {

        BeforeAll {
            If ($env:STORAGE_ACCOUNT_NAME) { $STORAGE_ACCOUNT_NAME = "$env:STORAGE_ACCOUNT_NAME" }
            Else { $STORAGE_ACCOUNT_NAME = "sa" + "$env:BUS_NAMESPACE".ToLower().Replace('-', '') }
            If ($STORAGE_ACCOUNT_NAME.Length -gt 24) {
                $STORAGE_ACCOUNT_NAME = $STORAGE_ACCOUNT_NAME.Substring(0, 24)
            }

            #expect this list of resources to evolve as our usage evolves...
            $EXPECTED_RESOURCE_TYPES = @("Microsoft.ServiceBus/namespaces", "Microsoft.Storage/storageAccounts")
            $EXPECTED_LOCATION = $(If ($env:BUS_LOCATION) { "$env:BUS_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$DEFAULT_LOCATION" })
            $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()
            $EXPECTED_TEMPLATE_VERSION = Get-AtlasVersionNumber

            Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
            Write-Verbose "Tested storage account name: $($STORAGE_ACCOUNT_NAME)" -Verbose

            $rgResources = $(Get-AzResource -ResourceGroupName $resourceGroup -name $STORAGE_ACCOUNT_NAME)
        }



        It "Resource Group variable is set" {
            $resourceGroup | Should -Not -Be $null
        }

        It "Resource Group Has Retrievable Configuration" {
            $rgResources | Should -Not -Be $null
        }

        It "Has Correct Resources in Expected Quantities" {
            $rgResources | ForEach-Object { $_.type } | Should -BeIn $EXPECTED_RESOURCE_TYPES

            $($rgResources | Where-Object { $_.type -eq "Microsoft.Storage/storageAccounts" } | Measure-Object).Count | Should -Be 1
        }

        It "Has Expected Location" {
            $saResource = $rgResources | Where-Object { $_.type -eq "Microsoft.Storage/storageAccounts" }
            $saResource.location | Should -Be $EXPECTED_LOCATION
        }

        It "Titan Atlas Version Number is set into the RG tags" {
            # The Template Version should not be empty or null/defaulted to "Unknown" or "Titan-Atlas-Beta"
            $rgResources.Count | Should -BeGreaterThan 0

            $rgResources | ForEach-Object {
                # Ignore the default Failure Anomalies cluster Alerts as the version number is not set on it.
                if ($_.type -ne "microsoft.insights/alertrules") {
                    $_.tags.TemplateVersion | Should -Not -Be $null
                    $_.tags.TemplateVersion | Should -Not -Be "Unknown"
                    $_.tags.TemplateVersion | Should -Not -Be "Titan-Atlas"

                    # Validate that the expected value was set into the RG tags
                    $_.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION
                }
            }
        }

        It "Storage Account is Deleted" {
            #$rgResources = $(az resource list -g $resourceGroup -n $STORAGE_ACCOUNT_NAME) | ConvertFrom-Json
            #$saResource = $rgResources | Where-Object { $_.type -eq "Microsoft.Storage/storageAccounts" }
        
            #. ("$DEPLOY_FOLDER\ServiceBus\operations\delete\azureDeleteLargeFileTransferSupport.ps1") -resourceGroup $resourceGroup -storageAccount $($saResource.Name)
            . ("$DEPLOY_FOLDER\ServiceBus\operations\delete\azureDeleteLargeFileTransferSupport.ps1") -resourceGroup $resourceGroup -storageAccount $STORAGE_ACCOUNT_NAME
            $storageAccount = $(az storage account show --resource-group $resourceGroup --name $STORAGE_ACCOUNT_NAME) | ConvertFrom-Json
            $storageAccount | Should -BeNullOrEmpty
        }

    }


    Describe "Large Transfer Service Creation Tests" {

        BeforeAll {
            If ($env:STORAGE_ACCOUNT_NAME) { $STORAGE_ACCOUNT_NAME = "$env:STORAGE_ACCOUNT_NAME" }
            Else { $STORAGE_ACCOUNT_NAME = "sa" + "$env:BUS_NAMESPACE".ToLower().Replace('-', '') }
            If ($STORAGE_ACCOUNT_NAME.Length -gt 24) {
                $STORAGE_ACCOUNT_NAME = $STORAGE_ACCOUNT_NAME.Substring(0, 24)
            }

            #$storageAccount = ($(az storage account list -g $resourceGroup) | ConvertFrom-Json) | Where-Object { $_.name -eq $STORAGE_ACCOUNT_NAME }
            . ("$DEPLOY_FOLDER\ServiceBus\operations\modify\azureAddLargeFileTransferSupport.ps1") -resourceGroup $resourceGroup
            $storageAccount = ($(az storage account list -g $resourceGroup) | ConvertFrom-Json) | Where-Object { $_.name -eq $STORAGE_ACCOUNT_NAME }
        }

        It "Storage Account Exists" {
            $storageAccount.name | Should -Be $STORAGE_ACCOUNT_NAME
        }

        It "Has an Expected IP Rule" {
            $EXPECTED_IP_RULES = @("8.36.116.204", "208.91.239.30", "208.91.239.10", "208.91.239.11", "208.91.237.190", "208.91.237.161", "208.91.237.162")
            #Describe "Storage Account has correct Network ACLs - IP Rules" {
            $actualNetworkRules = $(az storage account network-rule list -g $resourceGroup --account-name $storageAccount.name) | ConvertFrom-Json
            
            ForEach ($IP in $EXPECTED_IP_RULES) {
                Write-Verbose "Tested IP Rule: $IP" -Verbose
                $IP | Should -BeIn $actualNetworkRules.ipRules.ipAddressOrRange
            }
        }

        #Describe "Storage Account has correct Network ACLs - vNet Rules" {
        It "Has an Expected vNet Rule" {
            $expected_rules = $(Get-AtlasServiceBus-NetworkRules -ResourceGroup $resourceGroup -Namespace $env:BUS_NAMESPACE).properties.virtualNetworkRules
            $actualNetworkRules = $storageAccount.networkRuleSet.virtualNetworkRules.virtualNetworkResourceId
            foreach ($rule in $expected_rules) {
                Write-Verbose "Tested vNet Rule: $($rule.subnet.id)" -Verbose
                $rule.subnet.id | Should -BeIn $actualNetworkRules
            }
        }
        #}
    }

}