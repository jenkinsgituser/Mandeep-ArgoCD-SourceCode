param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

# source the _include file
. ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")


Describe "Topic Verification Tests" {
    BeforeAll {
        #if ($rgResources -eq $null){
        $rgResources = $(az resource list -g $resourceGroup -n $env:BUS_NAMESPACE) | ConvertFrom-Json
        #}
        $busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
    
        $EXPECTED_TOPIC_NAME = $env:TOPIC_NAME
    }


    It "Topic is Created" {
        . ("$DEPLOY_FOLDER\ServiceBus\operations\modify\azureAddTopic.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name) -topicName $EXPECTED_TOPIC_NAME
            
        $busTopic = $(az servicebus topic list --namespace-name $busResource.name -g $resourceGroup) | ConvertFrom-Json
        $busTopic | Should -Not -Be $null
        $busTopic.name | Should -Contain $EXPECTED_TOPIC_NAME
    }


    #$busTopic = $(az servicebus topic list --namespace-name $busResource.name -g $resourceGroup) | ConvertFrom-Json

    #only run these tests if we have a topic available
    #    if ($busTopic.name -eq $EXPECTED_TOPIC_NAME) {

    It "Topic Subscription is Created" {
        $EXPECTED_TOPIC_SUB_NAME = "test-sub"
        . ("$DEPLOY_FOLDER\ServiceBus\operations\modify\azureAddTopicSubscription.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name) -topicName $EXPECTED_TOPIC_NAME -subscriptionName $EXPECTED_TOPIC_SUB_NAME
        $busTopicSub = $(az servicebus topic subscription list --topic-name $EXPECTED_TOPIC_NAME --namespace-name $busResource.name -g $resourceGroup) | ConvertFrom-Json
        $busTopicSub | Should -Not -Be $null
        $busTopicSub.name | Should -Be $EXPECTED_TOPIC_SUB_NAME
    }

    It "Topic subscription is Deleted" {
        $EXPECTED_TOPIC_SUB_NAME = "test-sub"
        . ("$DEPLOY_FOLDER\ServiceBus\operations\delete\azureDeleteTopicSubscription.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name) -topicName $EXPECTED_TOPIC_NAME -subscriptionName $EXPECTED_TOPIC_SUB_NAME
    
        $busTopicSub = $(az servicebus topic subscription list --topic-name $EXPECTED_TOPIC_NAME --namespace-name $busResource.name -g $resourceGroup) | ConvertFrom-Json
        $busTopicSub.name | Should -Not -Be $EXPECTED_TOPIC_SUB_NAME
        $busTopicSub.Count | Should -Be 0
    }
    #    }


    It "Topic is Deleted" {
        . ("$DEPLOY_FOLDER\ServiceBus\operations\delete\azureDeleteTopic.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name) -topicName $EXPECTED_TOPIC_NAME

        $busTopic = $(az servicebus topic list --namespace-name $busResource.name -g $resourceGroup) | ConvertFrom-Json
        $busTopic.name | Should -Not -Be $EXPECTED_TOPIC_NAME
        $busTopic.Count | Should -Be 0
    }

}