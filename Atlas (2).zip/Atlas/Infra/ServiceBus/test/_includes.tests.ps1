
. ("$COMMON_FOLDER/azure-utilities.ps1")
