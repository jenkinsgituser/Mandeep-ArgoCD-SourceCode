param
(
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup,

  [Parameter(Mandatory = $false)]
  [array] $rgResources = $null
)

# source the _include file
. ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")

Describe "Utilities Tests" {

  BeforeAll {
    $EXPECTED_UTILITIES_TEST_COMMAND = "Get-AtlasServiceBus-NetworkRules"
    $EXPECTED_TEST_IP = "1.1.1.1"

    #expect this list of resources to evolve as our usage evolves...
    $EXPECTED_IP_RULES = @("8.36.116.204", "208.91.239.30", "208.91.239.10", "208.91.239.11", "208.91.237.190", "208.91.237.161", "208.91.237.162")

    . ("$COMMON_FOLDER/api/AtlasArmRestClient.ps1")

    #define service bus namespace
    $namespace = $(az servicebus namespace list --resource-group $resourceGroup --query "[0].name" -o tsv)
  }

  #Describe "ARM Rest Client Tests" {

  It "Correctly Loaded Utilities" {
    $result = Get-Command $EXPECTED_UTILITIES_TEST_COMMAND
    $result | Should -Not -Be $null
    $result.Name | Should -Be $EXPECTED_UTILITIES_TEST_COMMAND
  }

  $resourceGroup = if (!$resourceGroup) { $env:RESOURCE_GROUP }else { $resourceGroup }
  It "Has Resource Group" {
    $resourceGroup | Should -Not -Be $null
  }

  It "Has Discoverable Service Bus Namespace in Resource Group" {
    $namespace | Should -Not -Be $null
  }

  #this test needs to function at a basic level for the update to work, as it consume this function
  #this will fail if a bus is deployed without an IP rules
  It "Get Operation - Get Network ACLs from Service Bus Namespace" {
    $response = Get-AtlasServiceBus-NetworkRules -ResourceGroup $resourceGroup -Namespace $namespace
    $response.properties.ipRules | Should -Not -Be $null
  }

  It "Update Operation - Add Network ACL IP Rule" {
    $response = Add-AtlasServiceBus-IPRuleAllow -ResourceGroup $resourceGroup -Namespace $namespace -IpAddress $EXPECTED_TEST_IP
    $response.properties.ipRules | Should -Not -Be $null
    $response.properties.ipRules | Where-Object { $_.ipMask -eq $EXPECTED_TEST_IP } | Should -Not -Be $null
  }

  <#
  It "Get Operation - Get Added IP Rule" {
    $response = Get-AtlasServiceBus-NetworkRules -ResourceGroup $resourceGroup -Namespace $namespace
    $response.properties.ipRules | Should -Not -Be $null
    $response.properties.ipRules.ipMask | Should -Contain $EXPECTED_TEST_IP
  }
  #>

  #since this is infrastructure, this is inherently an integration test...hmmmm...
  #i guess we can switch on the presence of the appropriate variable(s)?
  if ($env:AKS_RGS) {
    $rg = "$env:AKS_RGS".Split(',')[0]

    $subnetId = [string]::Empty

    #get the vnet in the RG -- first item only
    $vNet = $(az network vnet list -g $rg --query "[0]") | ConvertFrom-Json

    It "Can infer vnet from resource group: $rg" {
      $vNet | Should -Not -Be $null
    }

    #this relies on another unit to test successfully..
    #get hte first subnet only
    $subnetId = Get-SubNetID -resourceGroup $rg -vnet $vnet.name -subnetName $vNet.subnets[0].name
    Write-Host "Discovered subnetUri: $subnetId"

    It "Can infer subnet from resource group: $rg" {
      $vnet | Should -Not -Be $null
      $subnetId | Should -Not -Be $null
    }

    It "Update Operation - Add vNet Rule" {
      $subnetId | Should -Not -Be $null
      Add-AtlasServiceBus-subNetRule -ResourceGroup $resourceGroup -Namespace $namespace -subNetURI $subnetId

      $RulesObj = Get-AtlasServiceBus-NetworkRules -ResourceGroup $resourceGroup -Namespace $namespace
      $RulesObj | Should -Not -Be $null
      $RulesObj.properties.virtualNetworkRules.subnet.id | Should -Contain $subnetId
    }

    #pro-tip -- run the removal after the addition, or you may get a failure due to the resource not having any subnet rules
    It "Update Operation - Remove vNet Rule" {
      $PreChangeRulesObj = Get-AtlasServiceBus-NetworkRules -ResourceGroup $resourceGroup -Namespace $namespace
      $PreChangeRulesObj.properties.virtualNetworkRules.subnet.id | Should -Not -Be $null
      $subnetIdToRemove = @($PreChangeRulesObj.properties.virtualNetworkRules.subnet.id)[0]
      $subnetIdToRemove | Should -Not -Be $null

      #subnetUri comes back in the format of an Azure Resource URI
      $componentPath = $subnetIdToRemove.Split('/')

      #/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Network/virtualNetworks/$VNET/subnets/$SUBNET
      $vNet = $componentPath[$componentPath.Length - 3]

      #subnetname is the last part of the subnet resource URI
      $subnetName = $componentPath[$componentPath.Length - 1]

      $result = Remove-AtlasServiceBus-SubNetRule -ResourceGroup $resourceGroup -Namespace $namespace -vNetName $vnet -subnetName $subnetName

      $PostChangeRulesObj = Get-AtlasServiceBus-NetworkRules -ResourceGroup $resourceGroup -Namespace $namespace
      $PostChangeRulesObj | Should -Not -Be $null
      $PostChangeRulesObj.properties.virtualNetworkRules.subnet.id | Should -Not -Contain $subnetIdToRemove
    }
  }
}

Describe "Subnet URI Discovery Unit Tests" {

  BeforeAll {
    $REFERENCE_SUBNET = "subnet2"
    $REFERENCE_VNET = "vnet-FirewallTesting-Michael"
    #note that it doesnt' matter if these values exist on the subscription...they are just constant strings for the purposes of this unit test
    $REFERENCE_SUBNETS_ARRAY = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourcegroups/rg-cmfg-ea2-atlas-servicebus-michaeld/providers/Microsoft.Network/virtualNetworks/vnet-firewalltesting-michael/subnets/subnet2", `
      "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Atlas-ServiceBus-MichaelD/providers/Microsoft.Network/virtualNetworks/vnet-FirewallTesting-Michael/subnets/subnet3"
    $EXPECTED_RESULT = @("/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Atlas-ServiceBus-MichaelD/providers/Microsoft.Network/virtualNetworks/vnet-FirewallTesting-Michael/subnets/subnet3")
  }
  
  It "Get-AtlasRemovedSubnetByInputMatch Unit Test" {
    $diff = Get-AtlasRemovedSubnetByInputMatch -virtualNetworkRules $REFERENCE_SUBNETS_ARRAY -vNetName $REFERENCE_VNET -subnetName $REFERENCE_SUBNET
    $diff | Should -Be $REFERENCE_SUBNETS_ARRAY[0]
  }

  It "Remove-AtlasSubnetByInputMatchIdsOnly Unit Test" {
    $updated = Remove-AtlasSubnetByInputMatchIdsOnly -virtualNetworkRules $REFERENCE_SUBNETS_ARRAY -vNetName $REFERENCE_VNET -subnetName $REFERENCE_SUBNET
    $updated | Should -Be $EXPECTED_RESULT
  }

}

Describe "Environment Inferment Confirmation" {
  BeforeAll {
    $EXPECTED_SANDBOX_ENVIRONMENTS = @('CMFG-Sandbox')
    $EXPECTED_NON_PROD_ENVIRONMENTS = @('CMFG NonProduction', 'Commercial-NonProd', 'CorporateServices-NonProd', 'DLX-NonProd', 'LAH-NonProd', 'Lending-Nonprod', 'OmniChannel-Nonprod', 'Retirement-NonProd', 'WMGMT-Nonprod')
    $EXPECTED_PROD_ENVIRONMENTS = @('CMFG Production', 'Commercial-Prod', 'CorporateServices-Prod', 'DLX-Prod', 'LAH-Prod', 'Lending-Prod', 'OmniChannel-Prod', 'Retirement-Prod', 'WMGMT-Prod')
  }
    
  
  It "Sandbox Environment check for $subSand" {
    foreach ($subSand in $EXPECTED_SANDBOX_ENVIRONMENTS) {
      $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $subSand
      $environment = $SubscriptionProperties.environment  
      $environment | Should -Be "Sandbox"
    }
  }

  It "NonProd Environment check for $subNP" {
    foreach ($subNP in $EXPECTED_NON_PROD_ENVIRONMENTS) {
      $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $subNP
      $environment = $SubscriptionProperties.environment  
      $environment | Should -Be "NonProd"
    }
  }

  It "Prod Environment check for $subPR" {
    foreach ($subPR in $EXPECTED_PROD_ENVIRONMENTS) {
      $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $subPR
      $environment = $SubscriptionProperties.environment  
      $environment | Should -Be "Prod"
    }
  }
}


