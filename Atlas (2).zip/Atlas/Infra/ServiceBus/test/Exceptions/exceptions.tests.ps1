param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

# source the _include file
. ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")
#if ($rgResources -eq $null){
#Write-Host "resourceGroup: $resourceGroup"
#Write-Host "SB: $env:BUS_NAMESPACE"
#$rgResources = $(az resource list -g $resourceGroup -n $env:BUS_NAMESPACE) | ConvertFrom-Json
#Write-Host "rgResources: $rgResources"
#}
#$busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
Describe "Exception Tag Addition Tests" {

    BeforeAll {
        if($rgResources -eq $null){
            $rgResources = $(az resource list -g $resourceGroup -n $env:BUS_NAMESPACE) | ConvertFrom-Json
        }
        $busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
        
    }

    It "Bus Resource found" {
        $busResource | Should -Not -Be $null
    }

    It "Exception Tag Added" {

        . ("$DEPLOY_FOLDER\ServiceBus\operations\modify\azureAddKeyRotationException.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name)

        $busNamespace = $(az servicebus namespace show -n $busResource.name -g $resourceGroup) | ConvertFrom-Json

        $busNamespace.tags.$CONST_ATLAS_EXCEPTIONS_TAG | Should -Not -Be $null
        $busNamespace.tags.$CONST_ATLAS_EXCEPTIONS_TAG | Should -Match $CONST_KEY_ROTATION_EXCEPTION_VALUE
    }

    It "Exception Tag Removed" {
        . ("$DEPLOY_FOLDER\ServiceBus\operations\delete\azureDeleteKeyRotationException.ps1") -resourceGroup $resourceGroup -namespaceName $($busResource.Name)

        $busNamespace = $(az servicebus namespace show -n $busResource.name -g $resourceGroup) | ConvertFrom-Json
        $busNamespace.tags.$CONST_ATLAS_EXCEPTIONS_TAG | Should -Not -Match $CONST_KEY_ROTATION_EXCEPTION_VALUE
    }
}