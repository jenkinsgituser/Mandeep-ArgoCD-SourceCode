
# source the _include file
. ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")

Describe "Unit Test - Namespace IP Rule Tests" {

    BeforeAll {
        #expect this list of resources to evolve as our usage evolves...
        $EXPECTED_IP_RULES = @("8.36.116.204", "208.91.239.30", "208.91.239.10", "208.91.239.11", "208.91.237.190", "208.91.237.161", "208.91.237.162")
    
        #read in ARM teamplate and convert from JSON
        #this location assumes you're executing from teh Execute-Pester.ps1 file
        $TEMPLATE_LOCATION = "$INFRA_FOLDER/ServiceBus/src/Namespace/azuredeployServiceBusNamespace.json"
        
        $ServiceBus = Get-Content -Raw -Path $TEMPLATE_LOCATION | ConvertFrom-Json
        $IpObjects = $ServiceBus.resources.properties.ipRules
        $IPRulesToBeTested = $IpObjects.ipMask
    }
    
    It "IP Rules are set" {
        $IPRulesToBeTested | Should -Not -Be $null
    }

    ForEach ($IP in $IPRulesToBeTested) {
        Write-Verbose "Tested IP Rule: $IP" -Verbose
        It "Has an Expected IP Rule" {
            $IP | Should -BeIn $EXPECTED_IP_RULES
        }
    }
}