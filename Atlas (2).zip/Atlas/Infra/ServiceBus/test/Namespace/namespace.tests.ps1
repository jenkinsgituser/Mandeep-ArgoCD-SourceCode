param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

# source the _include file
. ("$INFRA_FOLDER/ServiceBus/test/_includes.tests.ps1")

Describe "Namespace Deployment Tests" {

    BeforeAll {
        #expect this list of resources to evolve as our usage evolves...
        $EXPECTED_RESOURCE_TYPES = @("Microsoft.ServiceBus/namespaces", "Microsoft.Storage/storageAccounts")
        $EXPECTED_LOCATION = $(If ($env:BUS_LOCATION) { "$env:BUS_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$DEFAULT_LOCATION" })
        $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()
        $EXPECTED_TEMPLATE_VERSION = Get-AtlasVersionNumber
    
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        if ($rgResources -eq $null){
        $rgResources = $(az resource list -g $resourceGroup -n $env:BUS_NAMESPACE) | ConvertFrom-Json
        }
            
    }
    
    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    It "Resource Group Has Retrievable Configuration" {
        $rgResources | Should -Not -Be $null
    }
    It "Has Correct Resources in Expected Quantities" {
        $rgResources | ForEach-Object { $_.type } | Should -BeIn $EXPECTED_RESOURCE_TYPES

        $($rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" } | Measure-Object).Count | Should -Be 1
    }

    It "Has Expected Location" {
        $busResource = $rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }
        $busResource.location | Should -Be $EXPECTED_LOCATION
    }

    It "Titan Atlas Version Number is set into the RG tags" {
        # The Template Version should not be empty or null/defaulted to "Unknown" or "Titan-Atlas-Beta"
        $rgResources.Count | Should -BeGreaterThan 0

        $rgResources | ForEach-Object {
            # Ignore the default Failure Anomalies cluster Alerts as the version number is not set on it.
            if ($_.type -ne "microsoft.insights/alertrules") {
                $_.tags.TemplateVersion | Should -Not -Be $null
                $_.tags.TemplateVersion | Should -Not -Be "Unknown"
                $_.tags.TemplateVersion | Should -Not -Be "Titan-Atlas"
                Write-Verbose -Verbose "Expected template version number: $EXPECTED_TEMPLATE_VERSION"
                Write-Verbose -Verbose "Actual template version number $($_.tags.TemplateVersion)"
                # Validate that the expected value was set into the RG tags
                $_.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION
            }
        }
    }

    Describe "Namespace Verification Tests" {

        It "Invalid Namespace Fails" {
            $result = $(az servicebus namespace exists --name "Test") | ConvertFrom-Json
            $result.nameAvailable | Should -Be $false
        }

    }

}

