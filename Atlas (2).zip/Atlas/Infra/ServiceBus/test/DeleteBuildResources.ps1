#Delete the service bus
if ([string]::IsNullOrEmpty($env:BUS_NAMESPACE) -or [string]::IsNullOrEmpty($env:BUS_RG_NAME)) {
    throw "Both BUS_NAMESPACE and BUS_RG_NAME are not present in the environment. Exiting to avoid deleting other resources..."
}

# pipe 3>$null to dump warning messages for a coming deprecation that we've already addressed
$namespace = Get-AzServiceBusNamespace -Name $($env:BUS_NAMESPACE) -ResourceGroupName $($env:BUS_RG_NAME) 3> $null

Write-Verbose "Namespace to delete: $($namespace.Name)"
$namespace | Remove-AzServiceBusNamespace

#Delete the storage account
Get-AzStorageAccount -ResourceGroupName $($env:BUS_RG_NAME) | Where-Object { $_.StorageAccountName -match $($env:BUILD_BUILDNUMBER) } | Remove-AzStorageAccount -Force