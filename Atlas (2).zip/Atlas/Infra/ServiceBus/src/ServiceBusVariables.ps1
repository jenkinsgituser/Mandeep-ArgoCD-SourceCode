#########################################################################
$SUBSCRIPTION_NAME = $(az account show --query name -o tsv)
. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

Write-AtlasOutput -LogLevel "INFO" -Message "SUBSCRIPTION_NAME: $SUBSCRIPTION_NAME"

Write-AtlasOutput -LogLevel "INFO" -Message "Determine environment (prod vs. nonprod)"

$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName "$SUBSCRIPTION_NAME"
$environment = $SubscriptionProperties.environment
Write-AtlasOutput -LogLevel "INFO" -Message "Environment: $environment "
#########################################################################

$DEPLOYMENT_NAME = "azuredeployServiceBusNamespace-$(Get-Date -f yyyyMMddHHmmss)"
Write-AtlasOutput -LogLevel "INFO" -Message "DEPLOYMENT_NAME: $DEPLOYMENT_NAME"

$BUS_RG_NAME = $(If ($env:BUS_RG_NAME) { "$env:BUS_RG_NAME" } Else { Write-Error "BUS_RG_NAME: Resource Group must be set as an environment variable."; Exit 1 })
Write-AtlasOutput -LogLevel "INFO" -Message "BUS_RG_NAME: $BUS_RG_NAME"

$BUS_LOCATION = $(If ($env:BUS_LOCATION) { "$env:BUS_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$DEFAULT_LOCATION" })
$BUS_LOCATION = $BUS_LOCATION.Replace(" ", "").ToLower()

Write-AtlasOutput -LogLevel "INFO" -Message "BUS_LOCATION: $BUS_LOCATION. This is static as this region is required for RBAC support."

#note that the namespace needs to be unique
#https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-create-namespace-portal
$BUS_NAMESPACE = $(If ($env:BUS_NAMESPACE) { "$env:BUS_NAMESPACE" } Else { Write-Error "BUS_NAMESPACE: Service Bus must currently have a namespace set as an environment variable."; Exit 1 })
Write-AtlasOutput -LogLevel "INFO" -Message "BUS_NAMESPACE: $BUS_NAMESPACE"
#https://docs.microsoft.com/en-us/azure/architecture/best-practices/naming-conventions#naming-rules-and-restrictions
if ($BUS_NAMESPACE.length -lt 3 -or $BUS_NAMESPACE.length -gt 63) {
    Write-Error "Queue name must be 6 to 50 characters in length." -ErrorAction Stop
}

$BUS_QUEUE_NAME = $(If ($env:BUS_QUEUE_NAME) { "$env:BUS_QUEUE_NAME" } Else { "Default" })
Write-AtlasOutput -LogLevel "INFO" -Message "BUS_QUEUE_NAME: $BUS_QUEUE_NAME"

#only premium tier supported due to newtorking requirements
$BUS_SKU = "Premium"
Write-AtlasOutput -LogLevel "INFO" -Message "BUS_SKU: $BUS_SKU"

$SUPPORT_LARGE_FILE_TRANSFER = $(If ($env:SUPPORT_LARGE_FILE_TRANSFER) { [System.Convert]::ToBoolean($env:SUPPORT_LARGE_FILE_TRANSFER) } Else { $false })
Write-AtlasOutput -LogLevel "INFO" -Message "SUPPORT_LARGE_FILE_TRANSFER: $SUPPORT_LARGE_FILE_TRANSFER"

$CREATED_DATE = Get-Date -Format "yyyy-MM-dd"
Write-AtlasOutput -LogLevel "INFO" -Message "CREATED_DATE: $CREATED_DATE"


##############################################################################
#Generate Array of Objects for vnet firewall rules
$AKS_RGS = $(If ($env:AKS_RGS) { "$env:AKS_RGS" } Else { $null })
$VNETS = $(If ($env:VNETS) { "$env:VNETS" } Else { $null })
$SUBNETS = $(If ($env:SUBNETS) { "$env:SUBNETS" } Else { $null })


if ($AKS_RGS) {
    Write-AtlasOutput -LogLevel "INFO" -Message "RGs: $AKS_RGS"
    [array]$AKS_RGS = ($AKS_RGS.Replace(' ', '')).Split(',')
}
if ($VNETS) {
    Write-AtlasOutput -LogLevel "INFO" -Message "VNETS: $VNETS"
    [array]$VNETS = ($VNETS.Replace(' ', '')).Split(',')
}
if ($SUBNETS) {
    Write-AtlasOutput -LogLevel "INFO" -Message "SUBNETS: $SUBNETS"
    [array]$SUBNETS = ($SUBNETS.Replace(' ', '')).Split(',')
}

#only execute if we have inputs to process
if ($AKS_RGS) {
    $NETWORKRULES = $(Set-NetworkRulesJSON -resourceGroups $AKS_RGS -vNets $VNETS -subnetNames $SUBNETS -resourceType "Microsoft.ServiceBus/namespaces")
    Write-AtlasOutput -LogLevel "INFO" -Message "NETWORKRULES: $NETWORKRULES"
}
else {
    $NETWORKRULES = '[]'
    Write-AtlasOutput -LogLevel "INFO" -Message "Network Rules Resource Groups were not passed."
}
##############################################################################