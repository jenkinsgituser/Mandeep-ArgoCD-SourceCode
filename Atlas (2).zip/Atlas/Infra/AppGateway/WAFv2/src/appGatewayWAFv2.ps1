
# TODO: this needs to be tested later

$ErrorActionPreference = "Stop"

Write-Verbose "azure-utilities.ps1 is executing" -Verbose
. ("$COMMON_FOLDER/azure-utilities.ps1")

Write-Verbose "Atlas-CommonCode.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")

Write-Verbose "gateway-utilities.ps1 is executing" -Verbose
. ("$COMMON_FOLDER/gateway-utilities.ps1")

Write-Verbose "AGWafVariables.ps1 is executing" -Verbose
. ("$INFRA_FOLDER/AppGateway/WAFv2/src/AGWafVariables.ps1")

Write-Verbose "Deploying Application Gateway with WAF (v2): $AG_WAF_NAME" -Verbose

#$AG_WAF_TEMPLATE_FILE = "$SCRIPT_DIRECTORY/azuredeployGatewayWAF_v2_ssl.json"
Write-Verbose "AG_WAF_TEMPLATE_FILE_PATH: $AG_WAF_TEMPLATE_FILE_PATH" -Verbose
Write-Verbose "AG_WAF_PARAMETER_FILE_PATH: $AG_WAF_PARAMETER_FILE_PATH" -Verbose


$JSON_FILE = Test-Path $AG_WAF_TEMPLATE_FILE_PATH
If ($JSON_FILE -ne $true) {
    Write-Error "Unable to locate file: $AG_WAF_TEMPLATE_FILE_PATH"  -ErrorAction Stop
}

$JSON_FILE = Test-Path $AG_WAF_PARAMETER_FILE_PATH
If ($JSON_FILE -ne $true) {
    Write-Error "Unable to locate file: $AG_WAF_PARAMETER_FILE_PATH"  -ErrorAction Stop
}


# validate no function apps behind agwaf on public subnet
Write-Verbose "validate no function apps behind agwaf on public subnet" -Verbose
$gwSubnet = Get-AGWAF-subnetFromParmFile -filePath $agwafPropFilePath
Write-Verbose "AGWAF subnet detected is: $gwSubnet" -Verbose
if ($gwSubnet -match "public") {
    # check backends and verify no function apps
    Write-Verbose "AGWAF is on public subnet - check backends and verify no function apps" -Verbose
    $backendHasFunctions = Check-AGWAF-hasBackendFunctionsFromParmFile -filePath $agwafPropFilePath
    if ($backendHasFunctions) {
        Write-Warning "backend has function apps:  $backendHasFunctions"
        throw "AGWAF parm file is attempting to configure a Function App backend while AGWAF is on public subnet"
    }
}

############################################

$DEPLOYMENT_NAME = "azuredeployGatewayWAF_v2-$(Get-Date -f yyyyMMddHHmmss)"


#Deploy application gateway with WAF to resource group
$Action = {
    az deployment group create `
        -g "$AG_WAF_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$AG_WAF_TEMPLATE_FILE_PATH" `
        --parameters `@$AG_WAF_PARAMETER_FILE_PATH `
        --parameters "gatewayName=$AG_WAF_NAME" `
        "gatewayLocation=$AG_WAF_LOCATION" `
        "idleTimeout=$AG_WAF_IDLE_TIMEOUT" `
        "domainNameLabel=$AG_WAF_DOMAIN_NAME_LABEL" `
        "TemplateVersion=$TEMPLATE_VERSION" `
        "createdDate=$CREATED_DATE"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Application Gateway with WAF (v2): $AG_WAF_NAME" -Verbose


#update app service - remove this for AKS
#Get all Backend App services for a Gateway -NOTE: This will only work for webapp
$gatewayBackends = Get-AGWAF-AppServiceBackends -filePath $AG_WAF_TEMPLATE_FILE_PATH
$ipAddress = ""
if (![string]::IsNullOrEmpty($gatewayBackends)) {
    foreach ($backend in $gatewayBackends) {
        Write-Verbose "Name: $($backend.Name)" -Verbose
        Write-Verbose "Resource Group: $($backend.ResourceGroup)" -Verbose
        $ipAddress = Add-GwIpToAppService -appName $backend.Name -appResourceGroup $backend.ResourceGroup -appType $backend.Type -gwResourceGroup $AG_WAF_RG_NAME -gwName $AG_WAF_NAME
        Write-Verbose "Successfully restricted traffic on $($backend.Name) to only allow $ipAddress" -Verbose
    }
}
else {
    $gatewayInfo = $(az network application-gateway show --name "$AG_WAF_NAME" --resource-group "$AG_WAF_RG_NAME") | ConvertFrom-Json
    $ipAddress = $(az network public-ip show --ids $gatewayInfo.frontendIpConfigurations.publicIpAddress.id --query "ipAddress" -o tsv)    
}
Write-Verbose "Gateway listening at IP address: https://$ipAddress!!!!!!!!" -Verbose