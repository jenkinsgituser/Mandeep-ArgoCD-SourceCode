#**********************************************************
# Retrieve values from environment variables (Azure DevOps)
#**********************************************************

$SUBSCRIPTION_NAME = $(az account show --query name -o tsv)
Write-Verbose "SUBSCRIPTION_NAME: $SUBSCRIPTION_NAME"

$SUBSCRIPTION_ID = $(az account show --query id -o tsv)
Write-Verbose "SUBSCRIPTION_ID: $SUBSCRIPTION_ID" -Verbose

$CREATED_DATE = Get-Date -Format "yyyy-MM-dd"
Write-Verbose "CREATED_DATE: $CREATED_DATE" -Verbose

Write-Verbose "TEMPLATE_VERSION: $TEMPLATE_VERSION" -Verbose

#**********************************************************
# Application Gateway variables
#**********************************************************

#var simplification work
#########################################################################
Write-Verbose "Determine environment (prod vs. nonprod)" -Verbose

$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
$environment = $SubscriptionProperties.environment
Write-Verbose "Environment: $environment " -Verbose

If ($null -eq $PORT_NAME) { Write-Error "Unable to discover portfolio. Exiting..."; Exit 1 }
Write-Verbose "portfolio name: $PORT_NAME" -Verbose

#########################################################################
Write-Verbose "Setting subscription variables" -Verbose

If ($environment -eq "Prod") {
    $ATLAS_PORT_VAULT_NAME = "kv-atlas-$PORT_NAME-p"
    $ATLAS_PORT_VAULT_RG_NAME = "RG-CMFG-EA2-PR1-Atlas-Shared-Resources"
}
Else {
    $ATLAS_PORT_VAULT_NAME = "kv-atlas-$PORT_NAME-np"
    $ATLAS_PORT_VAULT_RG_NAME = "RG-CMFG-EA2-NP1-Atlas-Shared-Resources"
}
Write-Verbose "ATLAS_PORT_VAULT_NAME: $ATLAS_PORT_VAULT_NAME" -Verbose
Write-Verbose "ATLAS_PORT_VAULT_RG_NAME: $ATLAS_PORT_VAULT_RG_NAME" -Verbose
Write-Verbose "ATLAS_PORT_VAULT_SUBSCRIPTION_NAME: $ATLAS_PORT_VAULT_SUBSCRIPTION_NAME" -Verbose

#*****************************************************************************

if ($environment -eq $CONST_PROD_SUB) {
    $ATLAS_SHARED_VAULT_NAME = $CONST_KV_SHAREDSVCS_P
    $ATLAS_SHARED_VAULT_RG_NAME = $CONST_KV_SHAREDSVCS_RG_P
    $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME = $CONST_KV_SHAREDSVCS_SUB_P
}
elseif ($environment -eq $CONST_SANDBOX_SUB) {
    $ATLAS_SHARED_VAULT_NAME = $CONST_KV_SANDBOX_NP
    $ATLAS_SHARED_VAULT_RG_NAME = $CONST_KV_SANDBOX_RG_NP
    $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME = $CONST_KV_SANDBOX_SUB_NP
}
else {
    $ATLAS_SHARED_VAULT_NAME = $CONST_KV_SHAREDSVCS_NP
    $ATLAS_SHARED_VAULT_RG_NAME = $CONST_KV_SHAREDSVCS_RG_NP
    $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME = $CONST_KV_SHAREDSVCS_SUB_NP
}

Write-Verbose "ATLAS_SHARED_VAULT_NAME: $ATLAS_SHARED_VAULT_NAME" -Verbose
Write-Verbose "ATLAS_SHARED_VAULT_RG_NAME: $ATLAS_SHARED_VAULT_RG_NAME" -Verbose
Write-Verbose "ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME: $ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME" -Verbose

$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID = $(Get-Atlas-Subscription -subscription "$ATLAS_SHARED_VAULT_SUBSCRIPTION_NAME" -queryParam "id")
Write-Verbose "ATLAS_SHARED_VAULT_SUBSCRIPTION_ID: $ATLAS_SHARED_VAULT_SUBSCRIPTION_ID" -Verbose

#################################################################################################
# Check if AG_WAF_PARAMETERS_REQUEST_FILE was passed.  If so, generate the AG_WAF_PROPERTIES_FILE_NAME from it
# If the AG_WAF_PROPERTIES_FILE_NAME was also passed log a warning message.
if ($env:AG_WAF_PARAMETERS_REQUEST_FILE) {
    Write-Verbose "Found AG_WAF_PARAMETERS_REQUEST_FILE" -Verbose
    if ($env:AG_WAF_PROPERTIES_FILE_NAME) {
        Write-AtlasOutput -Loglevel "WARN" -Message "Both AG_WAF_PROPERTIES_FILE_NAME and AG_WAF_PARAMETERS_REQUEST_FILE variable were set. AG_WAF_PARAMETERS_PROPERTIES_FILE_NAME variable will be recreated"
        $AG_WAF_PROPERTIES_FILE_NAME = $env:AG_WAF_PROPERTIES_FILE_NAME
    }
    Write-Verbose "Convert Application Gateway Input File to Parm File: $AG_WAF_NAME" -Verbose
    Get-Content $env:AG_WAF_PARAMETERS_REQUEST_FILE
    Write-Verbose "Changing directory to $ATLAS_REPO_ROOT/Tools/AppGatewayConfig/AppGatewayCli" -Verbose
    Set-Location "$ATLAS_REPO_ROOT/Tools/AppGatewayConfig/AppGatewayCli"

    $AG_WAF_GENERATED_FILE = [System.IO.Path]::GetTempPath() + "temp-output-file.json"
    Write-Verbose "Generated AGWAF parm file is: $AG_WAF_GENERATED_FILE" -Verbose
    Write-Verbose "Executing AGWAF config generator" -Verbose
    #dotnet run -- -f $env:AG_WAF_PARAMETERS_REQUEST_FILE -o $AG_WAF_GENERATED_FilE > $junkjoutput
    if ($isLinux) {
        Write-Verbose "linux operating system detected." -Verbose
        Set-Location "$ATLAS_REPO_ROOT/Tools/AppGatewayConfig/AppGatewayCli/AppGatewayCli-release/linux-x64"
        chmod 777 ./AppGatewayCli  # set execute permsissions on the file
        ./AppGatewayCli -f $env:AG_WAF_PARAMETERS_REQUEST_FILE -o $AG_WAF_GENERATED_FilE
    }
    else {
        Write-Verbose "Windows operating system detected." -Verbose
        Set-Location "$ATLAS_REPO_ROOT/Tools/AppGatewayConfig/AppGatewayCli/AppGatewayCli-release/win-x64"
        ./AppGatewayCli.exe -f $env:AG_WAF_PARAMETERS_REQUEST_FILE -o $AG_WAF_GENERATED_FilE
    }

    Get-Content $AG_WAF_GENERATED_FILE
    $AG_WAF_PROPERTIES_FILE_NAME = $AG_WAF_GENERATED_FILE
}
else {
    if ($env:AG_WAF_PROPERTIES_FILE_NAME) {
        Write-Verbose "Found AG_WAF_PROPERTIES_FILE_NAME" -Verbose
        $AG_WAF_PROPERTIES_FILE_NAME = $env:AG_WAF_PROPERTIES_FILE_NAME
        Get-Content $AG_WAF_PROPERTIES_FILE_NAME
    }
}
############################################################################################


############################################################################################
# NEED TO DETERMINE WHICH KV TEAMS WILL BE USING FOR THESE CERTS

# determine whether the Portfolio vault should be used for SSL certificate retrieval
# default to true and enforce opt-in for wildcard cert use, given the user behavior encouraged
# by the use of a paramters file for the AG WAF
#if properties file is blank and no certname listed change to false
if (!$AG_WAF_PROPERTIES_FILE_NAME -and !$env:SSL_CERTIFICATE_NAME) {
    $USE_PORT_VAULT_SSL = $false
}
elseif (!$AG_WAF_PROPERTIES_FILE_NAME -and $env:SSL_CERTIFICATE_NAME) {
    $USE_PORT_VAULT_SSL = $true
}
else {
    $USE_PORT_VAULT_SSL = If ($env:USE_PORT_VAULT_SSL) { [System.Convert]::ToBoolean($env:USE_PORT_VAULT_SSL) } Else { $true }
}
Write-Verbose "USE_PORT_VAULT_SSL: $USE_PORT_VAULT_SSL" -Verbose

# We need a way to process portfolio vaulted certs seperately from a shared vault
If ($USE_PORT_VAULT_SSL) {
    $ATLAS_SSL_VAULT_ID = "/subscriptions/$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID/resourceGroups/$ATLAS_PORT_VAULT_RG_NAME/providers/Microsoft.KeyVault/vaults/$ATLAS_PORT_VAULT_NAME".ToLower()
    $ATLAS_VAULT_NAME = $ATLAS_PORT_VAULT_NAME
}
else {
    $ATLAS_SSL_VAULT_ID = "/subscriptions/$ATLAS_SHARED_VAULT_SUBSCRIPTION_ID/resourceGroups/$ATLAS_SHARED_VAULT_RG_NAME/providers/Microsoft.KeyVault/vaults/$ATLAS_SHARED_VAULT_NAME".ToLower()
    $ATLAS_VAULT_NAME = $ATLAS_SHARED_VAULT_NAME
}
Write-Verbose "ATLAS_SSL_VAULT_ID: $ATLAS_SSL_VAULT_ID" -Verbose

#*****************************************************************************

$AG_SHORT_NAME = $(If ($env:AG_SHORT_NAME) { "$env:AG_SHORT_NAME" } Else { "" })

if (($AG_SHORT_NAME.length -gt 20) -or (($AG_SHORT_NAME.length -lt 3) -and $AG_SHORT_NAME.length -gt 0)) {
    Write-Error -Message "'AG_SHORT_NAME' variable must be at least 3 characters or no more than 20 characters in length" -ErrorAction Stop
}
Write-Verbose "AG_SHORT_NAME: $AG_SHORT_NAME" -Verbose

$ORG = $(If ($env:ORG) { "$env:ORG" } Else { "CMFG" })
Write-Verbose "ORG: $ORG" -Verbose

$REGION = $(If ($env:REGION) { "$env:REGION" } Else { "EA2" })
Write-Verbose "REGION: $REGION" -Verbose

$AZENV = $(If ($env:AZENV) { "$env:AZENV" } Else { If ($environment -eq "Prod") { "PR1" } Else { "NP1" } })
Write-Verbose "AZENV: $AZENV" -Verbose

#*****************************************************************************

$AG_WAF_NAME = $(If ($env:AG_WAF_NAME) { "$env:AG_WAF_NAME" } Else { "AGWAF-$ORG-$REGION-$AZENV-$AG_SHORT_NAME" })
Write-Verbose "AG_WAF_NAME: $AG_WAF_NAME" -Verbose

$AG_WAF_RG_NAME = $(If ($env:AG_WAF_RG_NAME) { "$env:AG_WAF_RG_NAME" } Else { Write-Error "AG_WAF_RG_NAME was not passed to deployment and is a required environment variable"; Exit 10 })
Write-Verbose "AG_WAF_RG_NAME: $AG_WAF_RG_NAME" -Verbose

#Check if RG is Atlas
$IsAGRGAtlas = Is-RGAtlas -resourceGroup $AG_WAF_RG_NAME

if (!$IsAGRGAtlas) {
    Write-Error "ERROR: Application Gateway must be deployed in an Atlas Resource Group"
    Exit 14
}

#check to see if gateway exists
try {
    $gatewayExists = az network application-gateway show -g $AG_WAF_RG_NAME -n $AG_WAF_NAME 2> $null
}
catch {
    Write-Verbose -Verbose "Unable to discover $AG_WAF_NAME"
}

#need to set ag short name if it was not entered in
if (!$gatewayExists -and (!$AG_SHORT_NAME)) {
    Write-Error "Application does not exist please enter AG_SHORT_NAME"
    Exit 15
}

$AG_WAF_LOCATION = $(If ($env:AG_WAF_LOCATION) { "$env:AG_WAF_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
$AG_WAF_LOCATION = $AG_WAF_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "AG_WAF_LOCATION: $AG_WAF_LOCATION" -Verbose

$AG_WAF_IDLE_TIMEOUT = $(If ($env:AG_WAF_IDLE_TIMEOUT) { "$env:AG_WAF_IDLE_TIMEOUT" } Else { "4" })
Write-Verbose "AG_WAF_IDLE_TIMEOUT: $AG_WAF_IDLE_TIMEOUT" -Verbose

if (!$AG_SHORT_NAME) {
    $AG_WAF_DOMAIN_NAME_LABEL_TEMP = Get-GwDomainLabel -gwResourceGroup $AG_WAF_RG_NAME -gwName $AG_WAF_NAME
}
else {
    $AG_WAF_DOMAIN_NAME_LABEL_TEMP = "acg" + "$ORG" + "$REGION" + "$AZENV" + "$AG_SHORT_NAME"
}
$AG_WAF_DOMAIN_NAME_LABEL = "$AG_WAF_DOMAIN_NAME_LABEL_TEMP".ToLower()
Write-Verbose "AG_WAF_DOMAIN_NAME_LABEL: $AG_WAF_DOMAIN_NAME_LABEL" -Verbose

$FORCE_AG_DEFAULT_OVERRIDE = If ($env:FORCE_AG_DEFAULT_OVERRIDE) { [System.Convert]::ToBoolean($env:FORCE_AG_DEFAULT_OVERRIDE) } Else { $false }
Write-Verbose "FORCE_AG_DEFAULT_OVERRIDE: $FORCE_AG_DEFAULT_OVERRIDE" -Verbose

if ($AG_WAF_PROPERTIES_FILE_NAME) {
    # skip
}
elseif (!$AG_WAF_PROPERTIES_FILE_NAME -and (!$gatewayExists -or $FORCE_AG_DEFAULT_OVERRIDE)) {
    #Check for optional extras

    if ($env:APP_NAME) {
        #if($env:APP_NAME.ToUpper().StartsWith("$CONST_APP_SERVICE_PREFIX")){
        if ($env:APP_NAME.ToUpper().StartsWith("$CONST_APP_PREFIX")) {

            $APP_NAME = "$env:APP_NAME"
        }
        else {
            Write-Error "ERROR: Please enter a valid value for APP_NAME.  Must begin with '$CONST_APP_SERVICE_PREFIX'"
            Exit 1
        }
    }
    else {
        Write-Error "ERROR: Please enter a value for APP_NAME"
        Exit 1
    }


    $SSL_CERTIFICATE_NAME = $(if ($env:SSL_CERTIFICATE_NAME) { "$env:SSL_CERTIFICATE_NAME" } else { "" })
    $HOST_NAME = $(if ($env:HOST_NAME) { "$env:HOST_NAME" } else { Write-Error "ERROR: You must provide a value for HOST_NAME" })
    if ($SSL_CERTIFICATE_NAME -eq "") {
        #meaning defaulting to Atlas beta prepend hostname to ".atlasbeta.cunamutual.com"
        $HOST_NAME = "$HOST_NAME.atlasbeta.cunamutual.com"
    }

    $VNET_RG_NAME = $(if ($env:VNET_RG_NAME) { "$env:VNET_RG_NAME" } else { "" })
    $VNET_NAME = $(if ($env:VNET_NAME) { "$env:VNET_NAME" } else { "" })
    $SUBNET_NAME = $(if ($env:SUBNET_NAME) { "$env:SUBNET_NAME" } else { "" })

    $DEFAULT_PROPERTIES = Set-DefaultAGProperties -subscription $SUBSCRIPTION_ID `
        -environment $environment `
        -resourceGroup $AG_WAF_RG_NAME `
        -agWafName $AG_WAF_NAME `
        -appName $APP_NAME `
        -agWafLocation $AG_WAF_LOCATION `
        -hostName $HOST_NAME `
        -sslCertName $SSL_CERTIFICATE_NAME `
        -vnetRGName $VNET_RG_NAME `
        -vnetName $VNET_NAME `
        -subnetName $SUBNET_NAME

    $AG_WAF_PROPERTIES_FILE_NAME = $DEFAULT_PROPERTIES
}
elseif (!$AG_WAF_PROPERTIES_FILE_NAME -and $gatewayExists) {
    Write-Error "ERROR: You don't have a AG_WAF_PROPERTIES_FILE_NAME or a AG_WAF_PARAMETERS_REQUEST_FILE set but your Application Gateway $AG_WAF_NAME already exists. `
    Use the variable FORCE_AG_DEFAULT_OVERRIDE set to 'true' to force deployment over your existing Application Gateway with current default results."
    Exit 9
}
else {
    Write-Error "ERROR: Please enter either a value for AG_WAF_PROPERTIES_FILE_NAME or AG_WAF_PARAMETERS_REQUEST_FILE"
    Exit 10
}

Write-Verbose "AG_WAF_PROPERTIES_FILE_NAME: $AG_WAF_PROPERTIES_FILE_NAME" -Verbose
if (!(Test-Path $AG_WAF_PROPERTIES_FILE_NAME)) {
    $agwafPropFilePath = $(Get-ChildItem "$env:SYSTEM_DEFAULTWORKINGDIRECTORY/../" -Recurse -Force | Where-Object { $_.Name -match "^$AG_WAF_PROPERTIES_FILE_NAME" }).FullName
}
else {
    $agwafPropFilePath = $AG_WAF_PROPERTIES_FILE_NAME
}

$agParametersResult = (Get-AGParametersFile -fileName $AG_WAF_PROPERTIES_FILE_NAME -keyvaultId $ATLAS_SSL_VAULT_ID)
$AG_WAF_TEMPLATE_FILE_PATH = $agParametersResult.TemplateFilePath
$AG_WAF_PARAMETER_FILE_PATH = $agParametersResult.ParametersFilePath

Write-Verbose "AG_WAF_TEMPLATE_FILE_PATH: $AG_WAF_TEMPLATE_FILE_PATH" -Verbose
Write-Verbose "AG_WAF_PARAMETER_FILE_PATH: $AG_WAF_PARAMETER_FILE_PATH" -Verbose

$TITAN_ATLAS_VERSION = Get-AtlasVersionNumber
Write-Verbose "TITAN_ATLAS_VERSION: $TITAN_ATLAS_VERSION" -Verbose

Add-TitanVersionTagToRG -resourceGroup $AG_WAF_RG_NAME -TemplateVersionValue $TEMPLATE_VERSION

#*****************************************************************************

$ERROR_FILE = "$SCRIPT_DIRECTORY/errors.log"
Write-Verbose "Log File: $ERROR_FILE" -Verbose

#*****************************************************************************
