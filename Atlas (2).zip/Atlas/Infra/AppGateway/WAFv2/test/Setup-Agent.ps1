#Dynamically setup resource group name from a substring of the commit ID

$resourceGroupPrefix = "RG-CMFG-D01-Atlas-Test-"
$commitID = "$($env:BUILD_SOURCEVERSION)".substring(0, 8)

$buildID = "$($env:BUILD_BUILDNUMBER)"

#Setting 'subnet' must have a name that begins with an alphabet or underscore and not end with whitespace, dot or underscore.
#^ to comply, if the commitID starts with a number pre-pend a z and take the first 7 commitID numbers
$regex = [regex] '^[a-zA-Z][a-zA-Z0-9]+$'

if ($commitID -notmatch $regex) {
    $commitID = "z" + "$($commitID.substring(0,7))"
}

$resourceGroup = $resourceGroupPrefix + $commitID + "-" + $buildID

Write-Host "##vso[task.setvariable variable=AG_WAF_RG_NAME;]$resourceGroup"
#Write-Host "##vso[task.setvariable variable=APP_NAME;]$("AS-$commitID-$buildID")"

#################################################################################
#perform pester install if necessary
try {
    $result = Get-Module -ListAvailable -Name Pester
    if ($result.Version.Major -notcontains 4) {
        Install-PackageProvider -Name NuGet -Force -Scope CurrentUser
        Install-Module -Name Pester -Force -Verbose -Scope CurrentUser
    }
    Write-Host "Pester Version Installed: `n $result"
}
catch {
    Install-PackageProvider -Name NuGet -Force -Scope CurrentUser
    Install-Module -Name Pester -Force -Verbose -Scope CurrentUser
    $result = Get-Module -ListAvailable -Name Pester
}

if ($null -eq $result) {
    Write-Error "Unable to discover nor install Pester on agent. Exiting..."
    Exit 1
}
#################################################################################
