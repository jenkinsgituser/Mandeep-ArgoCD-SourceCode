# lines included here will run before any other tests within this folder
. ("$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")
