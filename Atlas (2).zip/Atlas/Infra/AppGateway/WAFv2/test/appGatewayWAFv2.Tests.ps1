param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

. ("$env:INFRA_FOLDER/AppGateway/WAFv2/test/_includes.tests.ps1") 4> $null

Describe "Application Gateway with WAF" {
    BeforeAll{
        #define expected results for assertions
        $AG_AZURE_TYPE = "Microsoft.Network/applicationGateways"
        $EXPECTED_AG_COUNT = 1
        $EXPECTED_OPERATION_STATE = "Running"
        $EXPECTED_LOCATION = $(If ($env:AG_WAF_LOCATION) { "$env:AG_WAF_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
        $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()
        $EXPECTED_WAF_STATE = "true"
        $EXPECTED_WAF_MODE = "Prevention"
        $EXPECTED_WAF_RULESET = "OWASP"
        $EXPECTED_WAF_RULESET_VERSION = "3.0"
        $EXPECTED_SSL_POLICY = "AppGwSslPolicy20170401S"
        $EXPECTED_SKU = "WAF_v2"
        $EXPECTED_TEMPLATE_VERSION = "Titan-Atlas"
        $EXPECTED_WAF_BODY_CHECK = $true
        $EXPECTED_WAF_DEFAULT_BODY_CHECK = $false
        $EXPECTED_MIN_CAPACITY = 0
        $EXPECTED_MAX_CAPACITY = 20
        $locShortName = Get-LocationShortName -Location $EXPECTED_LOCATION
        if ($env:EXPECTED_SUBNET -eq "cmfg") {
            $EXPECTED_SUBNET_NAME = "VNet-CMFG-Atlas-Atlantis" + $locShortName + "-cmfg-subnet-v1"
        }
        elseif ($env:EXPECTED_SUBNET -eq "public") {
            $EXPECTED_SUBNET_NAME = "VNet-CMFG-Atlas-Atlantis" + $locShortName + "-public-subnet-v1"
        }
        else {
            throw "invalid EXPECTED_SUBNET"
        }

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        
        #get the application gateway resource result from the resource group
        $AG_Infer_Resource = [string]::Empty
        $AG_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $AG_AZURE_TYPE })
        #get the application gateway object from the resource result
        $AG_WAF_NAME = $($AG_Infer_Resource).name
        Write-Verbose "AG Name: $AG_WAF_NAME" -Verbose

        $agJson = $(az network application-gateway show -g $resourceGroup -n $AG_WAF_NAME) | ConvertFrom-Json


    }
    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    if ($rgResources -eq $null) {
        $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
    }

    It "Application Gateway Inferred from Resource Group" {
        $($AG_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_AG_COUNT
        $AG_Infer_Resource | Should -Not -Be $null
    }

    It "Has Retrievable Configuration" {
        $agJson | Should -Not -Be $null
    }

    It "Is Operational" {
        $agJson.operationalState | Should -Be $EXPECTED_OPERATION_STATE
    }

    It "Is in the Correct Location" {
        $agJson.location | Should -Be $EXPECTED_LOCATION
    }

    It "Has Expected SKU" {
        $agJson.sku | Should -Not -Be $null
        $agJson.sku.tier | Should -Be $EXPECTED_SKU
    }

    It "Has Expected Autoscale Configuration" {
        $agJson.autoscaleConfiguration | Should -Not -Be $null
        $agJson.autoscaleConfiguration.minCapacity | Should -Be $EXPECTED_MIN_CAPACITY
        $agJson.autoscaleConfiguration.maxCapacity | Should -Be $EXPECTED_MAX_CAPACITY
    }

    It "Has Expected Frontend Configuration" {
        $agJson.frontendIpConfigurations | Should -Not -Be $null
        $agJson.frontendPorts | Should -Not -Be $null
        $agJson.httpListeners | Should -Not -Be $null
    }

    It "Has Expected Gateway IP Configuration" {
        $agJson.gatewayIpConfigurations | Should -Not -Be $null
    }

    It "Has Expected Backend Configuration" {
        $agJson.backendAddressPools | Should -Not -Be $null
        $agJson.backendHttpSettingsCollection | Should -Not -Be $null
    }

    It "Has Expected Probes" {
        $agJson.probes | Should -Not -Be $null
    }

    It "Has Expected Routing" {
        $agJson.requestRoutingRules | Should -Not -Be $null
        $agJson.urlPathMaps | Should -Not -Be $null
        $agJson.redirectConfigurations | Should -Not -Be $null
    }

    It "Has Expected SSL Configuration" {
        $agJson.sslCertificates | Should -Not -Be $null
        $agJson.sslPolicy | Should -Not -Be $null
        $agJson.sslPolicy.policyName | Should -Be $EXPECTED_SSL_POLICY
    }

    It "Has Expected WAF Configuration" {
        $agJson.webApplicationFirewallConfiguration | Should -Not -Be $null
        $agJson.webApplicationFirewallConfiguration.enabled | Should -Be $EXPECTED_WAF_STATE
        $agJson.webApplicationFirewallConfiguration.firewallMode | Should -Be $EXPECTED_WAF_MODE
        $agJson.webApplicationFirewallConfiguration.ruleSetType | Should -Be $EXPECTED_WAF_RULESET
        $agJson.webApplicationFirewallConfiguration.ruleSetVersion | Should -Be $EXPECTED_WAF_RULESET_VERSION
        if ($env:FORCE_AG_DEFAULT_OVERRIDE) {
            $agJson.webApplicationFirewallConfiguration.requestBodyCheck | Should -Be $EXPECTED_WAF_DEFAULT_BODY_CHECK
        }
        else {
            $agJson.webApplicationFirewallConfiguration.requestBodyCheck | Should -Be $EXPECTED_WAF_BODY_CHECK
        }

    }

    It "Has Expected Tags" {
        $agJson.tags | Should -Not -Be $null
        $agJson.tags.TemplateVersion | Should -Match $EXPECTED_TEMPLATE_VERSION
    }

    It "Actual Deployed Subnet Matches Expected Deployed Subnet" {
        $actualSubnetId = $agJson.gatewayIpConfigurations.subnet.id
        # subnet name is the last value in the resource Id
        $actualSubnetName = $actualSubnetId.Split('/')[-1]
        $actualSubnetName | Should -Be $EXPECTED_SUBNET_NAME
    }
}