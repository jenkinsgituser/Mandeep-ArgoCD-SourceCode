# i want to run these tests with this deployment, but I don't want to statically define them here
. ("$COMMON_FOLDER/gateway-utilities.ps1")