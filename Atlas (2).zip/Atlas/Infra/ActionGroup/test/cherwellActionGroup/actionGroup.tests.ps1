param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

$ConfigurationFilePath = $("$ATLAS_REPO_ROOT/Infra/ActionGroup/build/build-input-ActionGroup.json")

if ( -not (Test-Path $ConfigurationFilePath) ) {
    Throw "File $ConfigurationFilePath does not exist."
}


Describe "ActionGroup Tests" {

    BeforeAll {
        $ConfigurationFilePath = $("$ATLAS_REPO_ROOT/Infra/ActionGroup/build/build-input-ActionGroup.json")
        $configFileParms = Get-Content $ConfigurationFilePath | ConvertFrom-Json

        # Define expected results for assertions
        $ACTIONGROUP_TYPE = "microsoft.insights/actiongroups"
        $EXPECTED_ACTIONGROUP_COUNT = 1
        $EXPECTED_WEBHOOK_NAME = "Atlas-ActionGroup-BuildTest Webhook"

        $cherwellResourceGroupName = "RG-CMFG-NC1-P01-Cherwell"
        $cherwellAutomationAccountName = "AA-CMFG-P01-Cherwell"
        $cherwellRunbookName = "CherwellIncident-v1"
        $actionGroupName = "Atlas-ActionGroup-BuildTest"
        $webhook = "$actionGroupName Webhook"
    
        $actionGroup_Infer_Resource = [string]::Empty
        
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }

        $actionGroup_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $ACTIONGROUP_TYPE -and $_.name -eq $($configFileParms.actionGroupName) })
    }

    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    It "ActionGroup Inferred from Resource Group" {
        $actionGroup_Infer_Resource | Should -Not -Be $null
        $($actionGroup_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_ACTIONGROUP_COUNT
    }

    It "ActionGroup expected Webhook exists" {
        Set-AzContext "CMFG Production"
        $wh = Get-AzAutomationWebhook -RunbookName $cherwellRunbookName -ResourceGroup $cherwellResourceGroupName -AutomationAccountName $cherwellAutomationAccountName | Where-Object { $_.Name -match $EXPECTED_WEBHOOK_NAME }
        $wh | Should -Not -Be $null
        Set-AzContext "CMFG NonProduction"

    }

    It "Titan Atlas Version Number is set into the RG tags" {
        $actionGroup_Infer_Resource.tags | Should -Not -Be $null
        $actionGroup_Infer_Resource.tags.TemplateVersion | Should -match "Titan-Atlas"
    }
    
    It "ActionGroup has been deleted" {
        # Delete ActionGroup
        . ("$DEPLOY_FOLDER/ActionGroup/operations/deleteActionGroup.ps1") -ConfigurationFilePath $ConfigurationFilePath

        $ag = Get-AzActionGroup -ResourceGroup $resourceGroup -Name $actionGroupName -ErrorAction SilentlyContinue
        $ag | Should -Be $null
    }

    It "Webhook has been deleted" {
        Set-AzContext "CMFG Production"
        $wh = Get-AzAutomationWebhook -RunbookName $cherwellRunbookName -ResourceGroup $cherwellResourceGroupName -AutomationAccountName $cherwellAutomationAccountName  -ErrorAction SilentlyContinue | Where-Object { $_.Name -match $EXPECTED_WEBHOOK_NAME }
        $wh | Should -Be $null
        Set-AzContext "CMFG NonProduction"
    }
}