param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

$ConfigurationFilePath = $("$ATLAS_REPO_ROOT/Infra/ActionGroup/build/build-input-ActionGroup-email.json")

if ( -not (Test-Path $ConfigurationFilePath) ) {
    Throw "File $ConfigurationFilePath does not exist."
}


Describe "ActionGroup Email Tests" {

    BeforeAll {
        $ConfigurationFilePath = $("$ATLAS_REPO_ROOT/Infra/ActionGroup/build/build-input-ActionGroup-email.json")
        $configFileParms = Get-Content $ConfigurationFilePath | ConvertFrom-Json

        # Define expected results for assertions
        $ACTIONGROUP_TYPE = "microsoft.insights/actiongroups"
        $EXPECTED_ACTIONGROUP_COUNT = 1
        $EXPECTED_ACTIONGROUP_NAME = "Atlas-ActionGroup-Email-BuildTest"

        $actionGroup_Infer_Resource = [string]::Empty

        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }

        $actionGroup_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $ACTIONGROUP_TYPE -and $_.name -eq $($configFileParms.actionGroupName) })

        $ag = Get-AzActionGroup -ResourceGroup $resourceGroup -Name $($configFileParms.actionGroupName) -ErrorAction SilentlyContinue
    }

    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    It "ActionGroup Inferred from Resource Group" {
        $actionGroup_Infer_Resource | Should -Not -Be $null
        $($actionGroup_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_ACTIONGROUP_COUNT
    }

    It "Titan Atlas Version Number is set into the RG tags" {
        $actionGroup_Infer_Resource.tags | Should -Not -Be $null
        $actionGroup_Infer_Resource.tags.TemplateVersion | Should -match "Titan-Atlas"
    }

    It "ActionGroup Name is correct" {
        $ag.Name | Should -Be $EXPECTED_ACTIONGROUP_NAME
    }

    It "ActionGroup EmailReceivers.Name is correct" {
        $ag.EmailReceivers.Name | Should -Be "ds-titan"
    }

    It "ActionGroup EmailReceivers.EmailAddress is correct" {
        $ag.EmailReceivers.EmailAddress | Should -Be "ds-titan@cunamutual.com"
    }

    It "ActionGroup Status is Enabled" {
        $ag.EmailReceivers.Status | Should -Be "Enabled"
    }

    It "ActionGroup has been deleted" {
        # Delete ActionGroup
        . ("$DEPLOY_FOLDER/ActionGroup/operations/deleteActionGroup.ps1") -ConfigurationFilePath $ConfigurationFilePath

        $ag = Get-AzActionGroup -ResourceGroup $resourceGroup -Name $EXPECTED_ACTIONGROUP_NAME -ErrorAction SilentlyContinue
        $ag | Should -Be $null
    }

}