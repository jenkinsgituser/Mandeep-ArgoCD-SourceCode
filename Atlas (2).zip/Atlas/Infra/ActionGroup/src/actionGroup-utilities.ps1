
function Get-ActionGroup {
  <#
    .DESCRIPTION
    Returns an action group if it exists.  Otherwise, returns $null.

    .PARAMETER SubscriptionName
    The name of the subscription where the action group will be created.

    .PARAMETER ResourceGroupName
    The name of the resource group where the action group will be created.

    .PARAMETER ActionGroupName
    The name of the action group to create.
  #>

  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [string]$SubscriptionName,
    [Parameter(Mandatory = $True)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $True)] [string]$ActionGroupName
  )
  Write-Host "Get Action Group."

  Write-Host "Resource Group: $ResourceGroupName"
  Write-Host "SubscriptionName: $SubscriptionName"
  Write-Host "ActionGroupName: $ActionGroupName"

  $ag = az monitor action-group list `
    -g "$ResourceGroupName" `
    --subscription "$SubscriptionName"

  return (($ag | ConvertFrom-Json) | Where-Object name -eq "$ActionGroupName")
}

function New-ActionGroup {
  <#
    .DESCRIPTION
    Create an action group.  If the action group already exists, then a new one
    will not be created.

    .PARAMETER ResourceGroupName
    The name of the resource group where the action group will be created.

    .PARAMETER ActionGroupName
    The name of the action group to create.
  #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $True)] [string]$ActionGroupName
  )

  Write-Host "Creating action group."

  Write-Host "Resource Group: $ResourceGroupName"
  Write-Host "ActionGroupName: $ActionGroupName"

  $ag = az monitor action-group create `
    -g $ResourceGroupName `
    --name "$ActionGroupName"

  Write-Host "Action group created."

  $agid = ($ag | ConvertFrom-Json).id

  return $agid
}

function Get-Webhook {
  <#
    .DESCRIPTION
    Get an existing webhook on an automation runbook.

    .PARAMETER ResourceGroupName
    The name of the resource group in which the webhook exists.

    .PARAMETER AutomationAccountName
    The name of the automation account that owns the runbook associated with the
    webhook.

    .PARAMETER RunbookName
    The name of the runbook to which the webhook is attached.

    .PARAMETER WebhookName
    The name of the webhook.
  #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $True)] [string]$AutomationAccountName,
    [Parameter(Mandatory = $True)] [string]$RunbookName,
    [Parameter(Mandatory = $True)] [string]$WebhookName,
    [Parameter(Mandatory = $False)] [Hashtable]$WebhookParameter # this is here so we can pass the same object to the create and the getter
  )

  Write-Host "Getting Webhook."
  Write-Host "Resource Group: $ResourceGroupName"
  Write-Host "AutomationAccountName: $AutomationAccountName"
  Write-Host "RunbookName: $RunbookName"
  Write-Host "WebhookName: $WebhookName"

  Get-AzAutomationWebhook `
    -ResourceGroupName "$ResourceGroupName" `
    -AutomationAccountName "$AutomationAccountName" `
    -RunbookName "$RunbookName" `
  | Where-Object Name -eq "$WebhookName"
}

function New-Webhook {
  <#
    .DESCRIPTION
    Creates and returns a new webhook attached to a runbook.

    .PARAMETER ResourceGroupName
    The name of the resource group in which the webhook exists.

    .PARAMETER AutomationAccountName
    The name of the automation account that owns the runbook associated with the
    webhook.

    .PARAMETER RunbookName
    The name of the runbook to which the webhook is attached.

    .PARAMETER WebhookName
    The name of the webhook.

    .PARAMETER WebhookParameter
    The data sent with a webhook request. For Cherwell requests, this will be the JSON packet
    #>
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $True)] [string]$AutomationAccountName,
    [Parameter(Mandatory = $True)] [string]$RunbookName,
    [Parameter(Mandatory = $True)] [string]$WebhookName,
    [Parameter(Mandatory = $True)] [Hashtable]$WebhookParameter
  )

  Write-Host "Resource Group: $ResourceGroupName"
  Write-Host "AutomationAccountName: $AutomationAccountName"
  Write-Host "RunbookName: $RunbookName"

  $webhook = New-AzAutomationWebhook `
    -Name "$WebhookName" `
    -RunbookName "$RunbookName" `
    -IsEnabled $true `
    -ExpiryTime (Get-Date).AddYears(10) `
    -Parameters $WebhookParameter `
    -ResourceGroupName "$ResourceGroupName" `
    -AutomationAccountName "$AutomationAccountName" `
    -Force

  return $webhook
}

function New-AutomationRunbookReceiver {
  <#
    .DESCRIPTION
    Adds an automation runbook receiver to an existing action group.

    .PARAMETER ResourceGroupName
    The name of the resource group in which the action group exists.

    .PARAMETER ActionGroupId
    The ID of the action group to which the receiver is being added.

    .PARAMETER RunbookSubscriptionId
    The ID of the subscription in which the runbook exists.

    .PARAMETER RunbookResourceGroupName
    The name of the resource group in which the runbook exists.

    .PARAMETER AutomationAccountName
    The name of the automation account that owns the runbook.

    .PARAMETER ReceiverName
    The name to give the runbook receiver on the action group.

    .PARAMETER WebhookName
    The name of the webhook.

    .PARAMETER WebhookUri
    The URI of the webhook that calls the runbook.  Leave blank to create a new
    webhook.
  #>

  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [string]$ResourceGroupName,
    [Parameter(Mandatory = $True)] [string]$ActionGroupId,
    [Parameter(Mandatory = $True)] [string]$RunbookSubscriptionId,
    [Parameter(Mandatory = $True)] [string]$RunbookResourceGroupName,
    [Parameter(Mandatory = $True)] [string]$AutomationAccountName,
    [Parameter(Mandatory = $True)] [string]$ReceiverName,
    [Parameter(Mandatory = $True)] [string]$WebhookName,
    [Parameter(Mandatory = $False)] [string]$WebhookUri
  )

  Write-Host "Updating Action Group"

  Write-Host "Resource Group: $ResourceGroupName"
  Write-Host "AutomationAccountName: $AutomationAccountName"
  Write-Host "ReceiverName: $ReceiverName"

  az monitor action-group update --ids "$([System.Web.HttpUtility]::UrlDecode($ActionGroupId))" `
    --add automationRunbookReceivers `
    automationAccountId="/subscriptions/$RunbookSubscriptionId/resourceGroups/$RunbookResourceGroupName/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName" `
    isGlobalRunbook=false `
    name="$ReceiverName" `
    runbookName=CherwellIncident-v1 `
    serviceUri=$WebhookUri `
    useCommonAlertSchema=true `
    webhookResourceId="/subscriptions/$RunbookSubscriptionId/resourceGroups/$RunbookResourceGroupName/providers/Microsoft.Automation/automationAccounts/$AutomationAccountName/webhooks/$WebhookName"
}

function New-CherwellActionGroup {
  <#
    .DESCRIPTION
    Create an action group, webhook, and automation runbook receiver that
    integrate with Cherwell so that incidents can be created by Azure alerts.

    .PARAMETER parms
    An object containing the arguments needed to run this function.

    These include:

    $parms.subscriptionName
    $parms.resourceGroupName
    $parms.actionGroupName
    $parms.cherwellWebhookJsonInput
    $parms.actionGroupReceiverName

    $parms.cherwellSubscriptionName
    $parms.cherwellResourceGroupName
    $parms.cherwellAutomationAccountName
    $parms.cherwellRunbookName
    $parms.cherwellWebhookName
  #>

  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [Object]$parms
  )

  Write-Host ($parms | Format-List | Out-String)
  #$jsonInput = $parms.cherwellWebhookJsonInput | ConvertFrom-Json
  $webhookParm = @{"jsoninput" = $parms.cherwellWebhookJsonInput }

  $actionGroupParams = @{
    SubscriptionName  = $parms.subscriptionName
    ResourceGroupName = $parms.resourceGroupName
    ActionGroupName   = $parms.actionGroupName
  }

  $ag = Get-ActionGroup @actionGroupParams

  if ($null -ne $ag) {
    Write-Host "Action group already exists. Deleting the Action Group"

    az monitor action-group delete `
      -g $parms.resourceGroupName `
      --name $parms.actionGroupName
  }

  $createActionGroupParams = @{
    ResourceGroupName = $parms.resourceGroupName
    ActionGroupName   = $parms.actionGroupName
  }

  $agId = New-ActionGroup @createActionGroupParams

  Write-Host "Set Atlas version tag added on action group."
  $tagName = "TemplateVersion"
  $tagValue = $TEMPLATE_VERSION
  Set-TagOnAtlasResource `
    -resourceGroup $ResourceGroupName `
    -resourceName $ActionGroupName `
    -resourceType "Microsoft.Insights/ActionGroups" `
    -tagName  $tagName `
    -tagValue $tagValue

  Write-Host "Atlas version tag added on action group."

  #
  # Create the webhook if it does not already exist.
  #

  # Change to the Cherwell subscription.
  Write-Host "Changing the context to the Cherwell Subscription"
  Set-AzContext -Subscription $parms.cherwellSubscriptionName

  $webHookParms = @{
    ResourceGroupName     = $parms.cherwellResourceGroupName
    AutomationAccountName = $parms.cherwellAutomationAccountName
    RunbookName           = $parms.cherwellRunbookName
    WebhookName           = $parms.cherwellWebhookName
    WebhookParameter      = $webhookParm
  }

  Write-Host "Checking for an existing webhook parameter"
  $webhook = Get-Webhook @webHookParms

  if ($null -ne $webhook) {
    Write-Host "Webhook already exists. Deleting Webhook"

    Remove-AzAutomationWebhook -Name $parms.cherwellWebhookName `
      -ResourceGroup $parms.cherwellResourceGroupName `
      -AutomationAccountName $parms.cherwellAutomationAccountName
  }

  Write-Host "Creating a webhook."
  $webhook = New-Webhook @webHookParms
  Write-Host "Created webhook $($webhook.Name)"

  # Change back to the original subscription.
  Set-AzContext -Subscription $parms.subscriptionName

  #
  # Create the automation runbook receiver on the action group if it does not
  # already exist.
  #

  if ($webhook.WebhookURI -ne "") {
    Write-Host "Creating automation runbook receiver."

    # The only time that WebhookURI is populated is when the webhook is crated.
    # At all other times, the WebhookURI will be empty.  So, if the webhook
    # URI isn't empty, then we know the webhook was just created, and the
    # receiver also needs to be created.

    # We need the subscription ID of the runbook in order to create the receiver.
    $cherwellSubscriptionId = (Get-AzSubscription `
        -SubscriptionName "$($parms.cherwellSubscriptionName)" `
        -TenantId $tenantid).Id

    $createAutomationRunbookReceiverParms = @{
      ResourceGroupName        = $parms.resourceGroupName
      ActionGroupId            = $agid
      RunbookSubscriptionId    = $cherwellSubscriptionId
      RunbookResourceGroupName = $parms.cherwellResourceGroupName
      AutomationAccountName    = $parms.cherwellAutomationAccountName
      ReceiverName             = $parms.actionGroupReceiverName
      WebhookName              = $parms.cherwellWebhookName
      WebhookUri               = $webhook.WebhookURI
    }

    New-AutomationRunbookReceiver @createAutomationRunbookReceiverParms

    Write-Host "Automation Runbook Reciever Created."
  }
}

function Remove-ActionGroupWithActions {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [string]$ConfigurationFilePath
  )

  . ("$env:INFRA_FOLDER/ActionGroup/src/actionGroupVariables.ps1")

  az monitor action-group delete `
    -g $resourceGroupName `
    --name $actionGroupName

  Set-AzContext -Subscription $cherwellSubscriptionName

  $removeParams = @{
    Name                  = $cherwellWebhookName
    ResourceGroup         = $cherwellResourceGroupName
    AutomationAccountName = $cherwellAutomationAccountName
  }

  if ($null -ne $cherwellWebhookJsonInput) {
    Write-Verbose "We are deleting a cherwell Action Group, so also delete the associated webhook" -Verbose
    Remove-AzAutomationWebhook @removeParams
  }
}


function New-emailActionGroup {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $True)] [Object]$parms
  )

  Write-Host ($parms | Format-List | Out-String)

  $actionGroupParams = @{
    SubscriptionName  = $parms.subscriptionName
    ResourceGroupName = $parms.resourceGroupName
    ActionGroupName   = $parms.actionGroupName
  }

  $ag = Get-ActionGroup @actionGroupParams

  if ($null -ne $ag) {
    Write-Host "Action group already exists. Deleting the Action Group"

    az monitor action-group delete `
      -g $parms.resourceGroupName `
      --name $parms.actionGroupName
  }

  az monitor action-group create -g $($parms.resourceGroupName) --name $($parms.actionGroupName) --action "email" $($parms.emailName) $($parms.emailAddress)
  Write-Host "Action group created."

  Write-Host "Set Atlas version tag added on action group."
  Set-TagOnAtlasResource `
    -resourceGroup $ResourceGroupName `
    -resourceName $ActionGroupName `
    -resourceType "Microsoft.Insights/ActionGroups" `
    -tagName  "TemplateVersion" `
    -tagValue $TEMPLATE_VERSION

  Write-Host "Atlas version tag added on action group."

}
