
$configFileParms = Get-Content $ConfigurationFilePath | ConvertFrom-Json

$resourceGroupName = $configFileParms.resourceGroupName
$actionGroupName = $configFileParms.actionGroupName
$cherwellWebhookJsonInput = $configFileParms.cherwellWebhookJsonInput

$actionGroupReceiverName = "$actionGroupName Action Group Receiver"
$cherwellWebhookName = "$actionGroupName Webhook"

$cherwellSubscriptionName = "CMFG Production"
$cherwellResourceGroupName = "RG-CMFG-NC1-P01-Cherwell"
$cherwellAutomationAccountName = "AA-CMFG-P01-Cherwell"
$cherwellRunbookName = "CherwellIncident-v1"