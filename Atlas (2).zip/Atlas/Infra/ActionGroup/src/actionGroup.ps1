
. ("$env:INFRA_FOLDER/ActionGroup/src/actionGroup-utilities.ps1")
. ("$env:INFRA_FOLDER/ActionGroup/src/actionGroupVariables.ps1")

function New-CherwellActionGroupWithActions {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $True)] [string]$ConfigurationFilePath
    )

    $params = @{
        subscriptionName              = $SUBSCRIPTION_NAME
        resourceGroupName             = $configFileParms.resourceGroupName
        actionGroupName               = $configFileParms.actionGroupName
        actionGroupReceiverName       = $actionGroupReceiverName
        cherwellWebhookName           = $cherwellWebhookName
        cherwellWebhookJsonInput      = $configFileParms.cherwellWebhookJsonInput
        cherwellSubscriptionName      = $cherwellSubscriptionName
        cherwellResourceGroupName     = $cherwellResourceGroupName
        cherwellAutomationAccountName = $cherwellAutomationAccountName
        cherwellRunbookName           = $cherwellRunbookName
    }

    #TODO - Add support for multiple types of actions on a group.

    New-CherwellActionGroup -parms $params

}

function New-emailActionGroupWithActions {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $True)] [string]$ConfigurationFilePath
    )

    $params = @{
        subscriptionName              = $SUBSCRIPTION_NAME
        resourceGroupName             = $configFileParms.resourceGroupName
        actionGroupName               = $configFileParms.actionGroupName
        emailName                     = $configFileParms.emailJsonInput.emailName
        emailAddress                  = $configFileParms.emailJsonInput.emailAddress
    }

    New-emailActionGroup -parms $params

}