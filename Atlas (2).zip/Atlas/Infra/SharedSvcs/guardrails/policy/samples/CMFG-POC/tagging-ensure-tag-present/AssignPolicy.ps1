﻿$ResourceGroup = $args[0]
$policyName = $args[1]
$tagName = $args[2]


# use these if testing locally
#$ResourceGroup = "RG-CMFG-NC1-D01-JonTest"
#$policyName = "Policy-CMFG-SCE-Deny Required Tags"
#$policyName = "Policy-CMFG-SCE-Audit Required Tags"
#$tagName = "KAG"

If ($policyName -match 'Deny') { $effect = "Deny" }
If ($policyName -match 'Audit') { $effect = "Audit" }

# Get existing policy definition
$definition = Get-AzureRmPolicyDefinition -Name $policyName

# Set the scope to a resource group; may also be a subscription or management group
$scope = Get-AzureRmResourceGroup -Name $ResourceGroup

# Set the Policy Parameter (JSON format)
$policyparam = '{ "tagName": { "value": "' + $tagname + '" } }'

# Create the Policy Assignment
$TempName = "Policy-CMFG-Verify-Tag-Applied-" + $effect + "-" + $tagName
$assignment = New-AzureRmPolicyAssignment -Name $TempName -DisplayName $TempName -Scope $scope.ResourceId -PolicyDefinition $definition -PolicyParameter $policyparam



