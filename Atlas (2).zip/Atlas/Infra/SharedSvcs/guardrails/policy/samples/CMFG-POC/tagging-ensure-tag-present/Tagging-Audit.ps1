﻿$policyName = $args[0]
$Description = $args[1]
$JSONLoc = $args[2]
$ParmLoc = $args[3]

$policyName = "Policy-CMFG-SCE-Audit " + $policyName

# Use these if running locally
#$policyName = "Required Tags"
#$policyName = "Policy-CMFG-SCE-Audit " + $policyName
#$Description = "CMFG SCE This policy governs the Required Tags"
#$JSONLoc = "C:\Users\sys7577\Source\Repos\SCE-Azure-Services\Policy\policies\tagging-ensure-tag-present\azurepolicy.rules.audit.json"
#$ParmLoc = "C:\Users\sys7577\Source\Repos\SCE-Azure-Services\Policy\policies\tagging-ensure-tag-present\azurepolicy.parameters.json"

# Create the Policy Definition
$definition = New-AzureRmPolicyDefinition -Name $policyName `
  -DisplayName $policyName `
  -description $Description `
  -Policy $JSONLoc `
  -Parameter $ParmLoc `
  -Mode All

