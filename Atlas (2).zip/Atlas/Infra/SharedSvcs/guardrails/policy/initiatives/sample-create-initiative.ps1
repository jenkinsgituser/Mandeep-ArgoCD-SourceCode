$definitionFile = "test-network-initiative.json"
$initiativeName = "Test-Network-Inititiative"

az policy set-definition create --name $initiativeName --definitions $definitionFile