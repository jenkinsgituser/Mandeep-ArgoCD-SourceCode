param
(
    [Parameter(Mandatory = $true)]
    [string] $assignmentId,

    [Parameter(Mandatory = $true)]
    [string] $whiteListParamater,

    [Parameter(Mandatory = $true)]
    [string] $whiteListValue
)

try {
    $assignment = Get-AzureRMPolicyAssignment -Id $assignmentId
}
catch {
    $assignmentNotFound = $true
}

if (-Not $assignmentNotFound) {
    $policy = Get-AzureRMPolicyDefinition -Id $assignment.Properties.policyDefinitionId

    Write-Output "Getting policy: $policy"

    $newParams = @{ }
    foreach ( $property in $assignment.Properties.parameters.psobject.properties.name ) {
        Write-Output "setting value in hashtable for $property"
        $newParams[$property] = $assignment.Properties.parameters.$property.value
    }

    Write-Output $newParams

    Write-Output "writing new value for $whiteListParamater"
    $newParams["$whiteListParamater"] += "$whiteListValue"

    Write-Output "creating new assignment"
    New-AzureRMPolicyAssignment -Name $assignment.Name -Scope $assignment.Properties.scope -PolicyParameterObject $newParams -PolicyDefinition $policy -location $assignment.Location
}
else {
    Write-Error "Assignment not found"
}