function Add-SCEPolicesToResourceGroup() {
    param
    (
        [Parameter (Mandatory = $false)] [string] $resourceGroup
    )

    $filterText = "Policy-CMFG-SCE"

    $azureResourceGroup = Get-AzureRmResourceGroup -Name $resourceGroup

    #get all defined custom policies which have a name matching the filter text
    $customPolicies = Get-AzureRmPolicyDefinition | Where-Object `
    { ($_.Properties.policyType -eq "Custom") `
            -and ($null -ne $_.Properties.displayName) `
            -and ($_.Properties.displayName.Contains($filterText)) }

    foreach ($policy in $customPolicies) {
        $policyDefinition = Get-AzureRmPolicyDefinition -Name $policy.Name
        $assignmentName = "$($policy.Name)"

        $existingAssignment = $null

        try {
            $existingAssignment = Get-AzureRmPolicyAssignment -Name $assignmentName `
                -Scope $azureResourceGroup.ResourceId
        }
        catch {
            Write-Host "Assignment $assignmentName does not exist. Creating..."
        }

        if ($null -eq $existingAssignment) {
            $result = New-AzureRmPolicyAssignment `
                -Name $assignmentName `
                -Scope $azureResourceGroup.ResourceId `
                -PolicyDefinition $policyDefinition

            Write-Host $result
        }
        else {
            Write-Host "Polciy assignment already present: $existingAssignment"
        }
    }
}


$resourceGroup = $args[0]

Add-SCEPolicesToResourceGroup $resourceGroup

