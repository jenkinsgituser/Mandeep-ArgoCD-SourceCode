#$name="Assign Deny inbound NSG to Resource Group"
#$scope="/subscriptions/059ed1ab-6824-4344-9a65-a0504248340f/resourceGroups/RG-CMFG-NC1-D03-TeamTitan"
#$policyName="DenyAllInboundNSG"
#$policyName="{'listOfResourceTypesNotAllowed':{'value':['Microsoft.ContainerService/managedClusters','Microsoft.ContainerRegistry/registries']}, 'effect':{'value':'audit'}}"

param
(
    [Parameter(Mandatory = $true)]
    [string] $assignmentName,

    [Parameter(Mandatory = $true)]
    [string] $scope,

    [Parameter(Mandatory = $true)]
    [string] $policyName
)

Write-Verbose "assignmentName: $assignmentName" -Verbose
Write-Verbose "scope: $scope" -Verbose
Write-Verbose "policyName: $policyName" -Verbose
Write-Verbose "policyParamsHash: $policyParamsHash" -Verbose

Write-Verbose "getting policy definition." -Verbose
$policyDefinition = Get-AzureRmPolicyDefinition -Name $policyName

Write-Verbose "policyDefinition: $policyDefinition" -Verbose

if ($env:policyParams) {
    $policyParamsHash = @{ }
    (ConvertFrom-Json "$env:policyParams").psobject.properties | ForEach-Object { $policyParamsHash[$_.Name] = $_.Value.value }

    Write-Verbose "creating assignment with parameters" -Verbose
    $result = New-AzureRmPolicyAssignment `
        -Name $assignmentName `
        -Scope $scope `
        -PolicyDefinition $policyDefinition `
        -PolicyParameterObject $policyParamsHash
}
else {
    Write-Verbose "creating assignment without parameters" -Verbose
    $result = New-AzureRmPolicyAssignment `
        -Name $assignmentName `
        -Scope $scope `
        -PolicyDefinition $policyDefinition
}

Write-Verbose $result -Verbose