$policyName = $args[0]

# Delete the Policy Definition
$result = Remove-AzPolicyDefinition -Name $policyName -Force

$result