
param
(
    [Parameter (Mandatory = $false, HelpMessage = "Enter a comma delimted list of subscriptons to process")]
    [string] $subscriptions,

    [Parameter (Mandatory = $false)]
    [string] $assignmentName
)

foreach ($sub in ($subscriptions -Split ',')) {
    az account set -s $sub #lending non-prod
    $rgs = $(az group list | ConvertFrom-Json)
    foreach ($rg in $rgs) {
        az policy assignment delete --name $assignmentName --resource-group $rg.name
        Write-Host "---Policy assignment deleted for Atlas resource group: $($rg.name)"
    }
}