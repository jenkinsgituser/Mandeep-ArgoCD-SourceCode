$policyname = $args[0]

#get the policy definition object
$policyResource = Get-AzureRmPolicyDefinition -Name $policyname

#get all assignments for the policy in question
$assignments = Get-AzureRmPolicyAssignment -PolicyDefinitionId $policyResource.PolicyDefinitionId

#remove all assignments for the policy in question
foreach ($assignment in $assignments) {
    $result = Remove-AzPolicyAssignment `
        -Name $assignment.Name `
        -Scope $assignment.Properties.scope

    Write-Host $result
}
