$assignmentName = $args[0]
$scope = $args[1]

$result = Remove-AzPolicyAssignment `
  -Name $assignmentName `
  -Scope $scope

$result