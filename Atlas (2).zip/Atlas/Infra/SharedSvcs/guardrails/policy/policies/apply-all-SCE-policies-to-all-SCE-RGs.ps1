function Add-SCEPolicesToResourceGroup() {
    param
    (
        [Parameter (Mandatory = $false)] [string] $resourceGroup
    )

    $filterText = "Policy-CMFG-SCE"

    $azureRMResource = Get-AzureRmResource -ResourceId $resourceGroup

    #get all defined custom policies which have a name matching the filter text
    $customPolicies = Get-AzureRmPolicyDefinition | Where-Object `
    { ($_.Properties.policyType -eq "Custom") `
            -and ($null -ne $_.Properties.displayName) `
            -and ($_.Properties.displayName.Contains($filterText)) }

    foreach ($policy in $customPolicies) {
        $policyDefinition = Get-AzureRmPolicyDefinition -Name $policy.Name
        $assignmentName = "$($policy.Name): $($azureRMResource.Name)"

        $result = New-AzureRmPolicyAssignment `
            -Name $assignmentName `
            -Scope $resourceGroup `
            -PolicyDefinition $policyDefinition

        Write-Host $result
    }
}


#pull in args if passed.
$SCETag = $args[0]
$SCETagValue = $args[1]

#find all resource groups tagged as SCE
$resourceGroups = Find-AzureRmResourceGroup -Tag @{$SCETag = $SCETagValue }

foreach ($rg in $resourceGroups) {
    Add-SCEPolicesToResourceGroup $resourceGroup
}


