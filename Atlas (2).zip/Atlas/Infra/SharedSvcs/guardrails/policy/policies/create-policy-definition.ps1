$policyName = $args[0]
$policyDescription = $args[1]
$policyFile = $args[2]
$parmFile = $args[3]

#ensure created policy aligns to naming standard
$filterText = "Policy-CMFG-SCE"

if (!$policyName.StartsWith($filterText)) {
    $policyName = "$filterText-$policyName"
}

# Create the Policy Definition
$definition = New-AzureRmPolicyDefinition -Name $policyName `
    -DisplayName $policyName `
    -description $policyDescription `
    -Policy $policyFile `
    -Parameter $parmFile `
    -Mode All

$definition