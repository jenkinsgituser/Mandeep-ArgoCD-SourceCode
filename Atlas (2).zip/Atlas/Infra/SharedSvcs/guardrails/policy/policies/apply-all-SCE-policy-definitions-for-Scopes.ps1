###########################################################################################
#This script applies the discovered policy definitions to all subscriptions passed in
#as the 'subscriptions' parameter. Policy discovery defaults to the current folder,
#however an optional parameter can be passed to set where discovery begins.
#
#For discovery, all sub-folders are processed looking for three files. azurepolicy.json
#contains policy metadata, such as description and name. azurepolicy.parameters.json
#contains the parameters (with default values) for the definition. azurepolicy.rules.json
#contains the rule definition for the policy.
#
#As mentioned in the first section, this script "applies" these defnitions when run. That
#means it'll create those which do not exist, and update those which already do exist.
#This script does not update any assignments for the previous definition.
###########################################################################################
param
(
    [Parameter (Mandatory = $false, HelpMessage = "Enter a comma delimted list of subscriptons to process")]
    [string] $subscriptions,

    [Parameter (Mandatory = $false)]
    [string] $managementGroup,

    [Parameter (Mandatory = $false)]
    [string] $discoveryDirectory = $(Split-Path -Path $MyInvocation.MyCommand.Definition -Parent),

    [Parameter (Mandatory = $false)]
    [string] $policyNamingPrefix = "Policy-CMFG-SCE"
)


function Identify-Atlas-Resource-Groups {

    $CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas*"
    $CONST_ATLAS_RG_NAME_IDENTIFIER = "*Atlas-Test*"

    #note that this logic is overly Atlas centric and should be updated when a better approach is identified
    #specifically, see the const string usage which could easily vary over time
    return $(az group list | ConvertFrom-Json) | Where-Object { $_.tags.TemplateVersion -like $CONST_ATLAS_RG_TAG_IDENTIFIER -or $_.name -like $CONST_ATLAS_RG_NAME_IDENTIFIER }
}


Write-Verbose "subscriptions passed for processing: $subscriptions" -Verbose
Write-Verbose "Management Group passed for processing: $managementGroup" -Verbose
Write-Verbose "Searching directory $discoveryDirectory for policy definitions..." -Verbose
Write-Verbose "Naming prefix $policyNamingPrefix in use..." -Verbose

#confirm that only one of a mgmt group or a list of subscriptions is
#passed in for processing. Store the result in the $scopeToProcess variables
#for processing further down.
$scopeToProcess = @()
if (![string]::IsNullOrEmpty($subscriptions) -and ![string]::IsNullOrEmpty($managementGroup)) {
    Write-Error "Pass either a management group or an array of subscriptions. Do not pass both in one script."
    return
}
ElseIf (![string]::IsNullOrEmpty($subscriptions) -and [string]::IsNullOrEmpty($managementGroup)) {
    $scopeToProcess = $subscriptions -Split ','
}
ElseIf ([string]::IsNullOrEmpty($subscriptions) -and ![string]::IsNullOrEmpty($managementGroup)) {
    $scopeToProcess += $managementGroup
}

###discover all policies to be applied
$allDirectories = $(Get-ChildItem -Directory $discoveryDirectory -Recurse)
Write-Verbose "All directories found...$allDirectories" -Verbose
#iterate all of the directories found, trimming and returning only those which contain a file named "azurepolicy.json"
#existence of this file in the directory allows for the assumption that the directory is intended to contain policy rules
$policyDirectories = $allDirectories | Where-Object { $(Get-ChildItem -File $_ | Select-Object Name).Name.Contains("azurepolicy.json") }
Write-Verbose "Policy definitions found in the following directories...$policyDirectories" -Verbose

#arraylist to track all created policy definitions
[System.Collections.ArrayList]$policyDefintions = @()

foreach ($dir in $policyDirectories) {
    #get the content of the directory's "azurepolicy.json" file as an object
    Set-Location -Path $dir.FullName
    $metadataFileContent = Get-Content $(Get-ChildItem -File -Filter "azurepolicy.json") | ConvertFrom-Json

    #build a custom object which contains the DisplayName, Description, RuleFile, and ParamFile required to build a policy definition
    $policyDefinition = New-Object -TypeName psobject
    $policyDefinition | Add-Member -MemberType NoteProperty -Name "DisplayName" -value $metadataFileContent.properties.displayName
    $policyDefinition | Add-Member -MemberType NoteProperty -Name "Description" -value $metadataFileContent.properties.description
    $policyDefinition | Add-Member -MemberType NoteProperty -Name "RuleFile" -value $(Get-ChildItem -File -Filter "azurepolicy.rules.json").FullName
    $policyDefinition | Add-Member -MemberType NoteProperty -Name "ParamFile" -value $(Get-ChildItem -File -Filter "azurepolicy.parameters.json").FullName
    if ($null -ne $metadataFileContent.properties.mode) {
        $policyDefinition | Add-Member -MemberType NoteProperty -Name "Mode" -value $metadataFileContent.properties.mode
    }
    else {
        $policyDefinition | Add-Member -MemberType NoteProperty -Name "Mode" -value "All"
    }
    if ($null -ne $metadataFileContent.properties.deleteOnRedeploy) {
        $policyDefinition | Add-Member -MemberType NoteProperty -Name "DeleteOnRedeploy" -value $metadataFileContent.properties.deleteOnRedeploy
    }
    else {
        $policyDefinition | Add-Member -MemberType NoteProperty -Name "DeleteOnRedeploy" -value $false
    }

    ###apply naming standard if not already set
    #ensure created policy aligns to naming standard
    if (!$policyDefinition.DisplayName.StartsWith($policyNamingPrefix)) {
        $policyDefinition.DisplayName = "$policyNamingPrefix-$policyName"
    }
    $policyDefintions.Add($policyDefinition) >$null
    Write-Verbose "Added policy definition $($policyDefinition.DisplayName) to policyDefintions arrayList" -Verbose
}

###apply created policy defintions to each scope pass to script
foreach ($scope in $scopeToProcess) {
    #if the managementGroup parameter is not empty, process as a management group
    $mgmtGroup = ![string]::IsNullOrEmpty($managementGroup)

    #if not management group, set the context to run for the subscription to process
    if (!$mgmtGroup) {
        Write-Verbose "Switching to use subscription: $scope" -Verbose
        az account set --subscription $scope
        Write-Verbose "Subscription switched!" -Verbose
    }

    Write-Verbose "Processing defintions for scope: $scope" -Verbose
    try {
        foreach ($policyDefinition in $policyDefintions) {
            Write-Verbose "---Processing policy definition $($policyDefinition.DisplayName)" -Verbose
            $result = $null
            try {
                #create an array to hold the list of Atlas RGs if needed for pre- and post- update processing
                $atlasRGs = @()

                #https://docs.microsoft.com/en-us/cli/azure/policy/definition
                if ($policyDefinition.DeleteOnRedeploy -eq $true) {
                    #need to delete all assignmnents for this policy which already exist. Definitions cannot be
                    #deleted if they are actively assigned.

                    #this logic isn't run unless necessary to save on runtime speed
                    $atlasRGs = Identify-Atlas-Resource-Groups
                    foreach ($rg in $atlasRGs) {
                        Write-Verbose " " -Verbose
                        Write-Verbose "$($rg.name)" -verbose
                        $Locks = az group lock list --resource-group $rg.name | ConvertFrom-Json
                        $cnt = 0
                        $ErrorActionPreference = "Stop"
                        foreach ($Lock in $Locks) {
                            $cnt ++
                            # Check for RG lock and remove it
                            Try {
                                az group lock delete --ids $Lock.id 2> $null
                                Write-Verbose "   ---Deleted Lock on Atlas Resource Group: $($Lock.resourceGroup) with lock name $($lock.name)" -Verbose
                                $TempName = "LockID" + $cnt
                                $rg | Add-Member -MemberType NoteProperty -Name $TempName -value $Lock.id
                            
                            }
                            catch {
                                # If no RG lock, then lock is on the resource itself, remove it.
                                Try {
                                    az resource lock delete --ids $Lock.id 2> $null
                                    Write-Verbose "   ---Deleted Lock on Atlas Resource: $($Lock.id.Split('/')[8]) with lock name $($lock.name)" -Verbose
                                    $TempName = "LockID" + $cnt
                                    $rg | Add-Member -MemberType NoteProperty -Name $TempName -value $Lock.id
                                }
                                catch {
                                }
                            }
                        }
                        az policy assignment delete --name $policyDefinition.DisplayName --resource-group $rg.name
                        Write-Verbose "   ---Policy assignment deleted for Atlas Resource Group: $($rg.name)" -Verbose
                    }
                    #if this setting is marked true, we need to delete the definition if it already exists.
                    #if it doesn't already exist, then we can fall into the normal create logic.
                    $deleteResult = $(az policy definition delete --name $policyDefinition.DisplayName)
                    Write-Verbose "---Policy updated per DeleteOnRedeploy property." -Verbose
                }

                if ($mgmtGroup) {
                    Write-Verbose "---Creating Management Group policy definition $($policyDefinition.DisplayName) using scope: $scope" -Verbose
                    $result = $(az policy definition create --name $policyDefinition.DisplayName `
                            --display-name $policyDefinition.DisplayName `
                            --description $policyDefinition.Description `
                            --rules $policyDefinition.RuleFile `
                            --params $policyDefinition.ParamFile `
                            --mode $policyDefinition.Mode `
                            --management-group $scope)
                }
                else {
                    Write-Verbose "---Creating Subscription policy definition $($policyDefinition.DisplayName) using scope: $scope" -Verbose
                    $result = $(az policy definition create --name $policyDefinition.DisplayName `
                            --display-name $policyDefinition.DisplayName `
                            --description $policyDefinition.Description `
                            --rules $policyDefinition.RuleFile `
                            --params $policyDefinition.ParamFile `
                            --mode $policyDefinition.Mode `
                            --subscription $scope)
                }

                if ($policyDefinition.DeleteOnRedeploy -eq $true) {
                    #now we'll recreate all the assignments which were deleted earlier
                    foreach ($rg in $atlasRGs) {
                        $assignmentResult = $(az policy assignment create --name $policyDefinition.DisplayName `
                                --policy $policyDefinition.DisplayName `
                                --resource-group $rg.name)

                        Write-Verbose " " -Verbose
                        Write-Verbose "$($rg.name)" -verbose
                        $LockIDs = $rg | Get-Member | Where-Object { $_.name -match "LockID" }
                        foreach ($LockID in $LockIDs) {
                            $LockResourceID = $LockID.Definition.split('=')[1]
                            $separator = "providers/"
                            $ResourceType = ((($LockResourceID -split $separator)[1]).Split("/")[0..1]) -join "/"
                            $LockName = $($LockResourceID.Split('/'))[-1]
                            
                            # Check if RG, if so, tag the resource group 
                            if ($ResourceType -eq "Microsoft.Authorization/locks") {
                                $RGOutuput = az group lock create --resource-group $rg.name --name $LockName --lock-type CanNotDelete
                                Write-Verbose "   ---Created Lock on Atlas Resource Group: $($rg.name) with lock name $($LockID.Definition.Split('/')[-1])" -Verbose
                            }
                            # Tag the resource itself
                            else {
                                $Resource = $($LockResourceID.Split('/'))[8]
                                $ResOutuput = az resource lock create --resource-group $rg.name --name $LockName --resource $Resource --resource-type $ResourceType --lock-type CanNotDelete
                                Write-Verbose "   ---Created Lock on Atlas Resource: $Resource with lock name $($LockID.Definition.Split('/')[-1])" -Verbose
                            }
                        }

                        if ($assignmentResult) {
                            Write-Verbose "   ---Policy assigned per to Atlas resource group: $($rg.name)" -Verbose
                        }
                        else {
                            Write-Verbose "ERROR: Unable to assign updated policy defition $($policyDefinition.DisplayName) to Atlas resource group: $($rg.name)" -Verbose
                        }
                    }
                }
            }
            catch {
                #ignore intentionally
            }
            finally {
                #continue processing remainder of policies
                $global:lastExitCode = $null
            }

            if (![string]::IsNullOrEmpty($result)) {
                Write-Verbose "---Successfully added policy definition $($policyDefinition.DisplayName)" -Verbose
            }
            else {
                Write-Verbose "!!!Failed to apply policy definition $($policyDefinition.DisplayName)" -Verbose
            }
        }
    }
    catch {
        Write-Error "Unable to apply policy definition to scope $scope"
        Write-Error $_.Exception.Message
    }
    Write-Verbose "Completed processing defintions for scope: $scope..." -Verbose
}