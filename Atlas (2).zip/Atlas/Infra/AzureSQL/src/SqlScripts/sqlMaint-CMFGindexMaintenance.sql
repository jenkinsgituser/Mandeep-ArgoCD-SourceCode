
ALTER PROCEDURE [sqlMaint].[CMFGindexMaintenance]
(@reorgRebuild_updateStatistics_fl char(1) = null,
@updateStatistics_fl char(1) = null,
@reorgRebuild_fl char(1) = null)
as begin

	set nocount on;

	--validate input parms, we need at least one and only one 'Y' value
	create table #flag_tb (
	flag char(1)
	);

	insert into #flag_tb values 
	(lower(@reorgRebuild_updateStatistics_fl)),
	(lower(@updateStatistics_fl)),
	(lower(@reorgRebuild_fl));

	if (select count(*) from #flag_tb where flag = 'y') <> 1
	begin
		RAISERROR ('Error invalid parameters. One parameter value must be set to "y".', -- Message text.  
               16, -- Severity.  
               1 -- State.  
               );  
		return
	end

	--Update modified statistics on all user databases
	if lower(@updateStatistics_fl) = 'y'
	begin
		EXECUTE sqlMaint.IndexOptimize
			@FragmentationLow = NULL,
			@FragmentationMedium = NULL,
			@FragmentationHigh = NULL,
			@UpdateStatistics = 'ALL',
			@OnlyModifiedStatistics = 'Y',
			@LogToTable = 'Y';
	end

	--rebuild/reorganize all indexes with fragmentation and update modified statistics
	if lower(@reorgRebuild_updateStatistics_fl) = 'y'
	begin
		EXECUTE sqlMaint.IndexOptimize
			@FragmentationLow = null,
			@FragmentationMedium = 'INDEX_REORGANIZE,INDEX_REBUILD_ONLINE',
			@FragmentationHigh = 'INDEX_REBUILD_ONLINE,INDEX_REORGANIZE',
			@FragmentationLevel1 = 10,
			@FragmentationLevel2 = 30,
			@MinNumberOfPages = 100,
			@SortInTempdb = 'Y',
			@UpdateStatistics = 'ALL',
			@OnlyModifiedStatistics = 'Y',
			@LockTimeout = 10,
			@LogToTable = 'Y';
	end

	--rebuild/reorganize all indexes with fragmentation
	if lower(@reorgRebuild_fl) = 'y'
	begin
		EXECUTE sqlMaint.IndexOptimize
			@FragmentationLow = null,
			@FragmentationMedium = 'INDEX_REORGANIZE,INDEX_REBUILD_ONLINE',
			@FragmentationHigh = 'INDEX_REBUILD_ONLINE,INDEX_REORGANIZE',
			@FragmentationLevel1 = 10,
			@FragmentationLevel2 = 30,
			@MinNumberOfPages = 100,
			@SortInTempdb = 'Y',
			@LockTimeout = 10,
			@LogToTable = 'Y';
	end

end
;
