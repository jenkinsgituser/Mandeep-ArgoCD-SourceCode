
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'sqlMaint')
EXEC sys.sp_executesql N'CREATE SCHEMA [sqlMaint]'

