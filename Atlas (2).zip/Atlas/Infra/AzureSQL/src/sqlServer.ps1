
# Provision an Azure SQL server instance.

Write-Verbose "Provisioning the Azure SQL Server Instance." -Verbose

# source sql-utilities
. ("$env:INFRA_FOLDER/AzureSQL/src/sql-utilities.ps1")

## Bring in Atlas-CommonCode for Get-SubscriptionProperties
. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

Write-Verbose "Determine Environment." -Verbose
$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
$environment = $SubscriptionProperties.environment

Write-Verbose "Environment: $environment" -Verbose

#Set admin user for the SQL server from AAD users
#Admin is dependant on environment type
if (($environment -eq "NonProd") -or ($environment -eq "Sandbox")) {
    $aadAdminGroup = $CONST_SQL_AADADMIN_NONPROD
    $aadAdminObjId = $CONST_SQL_AADADMIN_NONPROD_OBJID
}
else {
    $aadAdminGroup = $CONST_SQL_AADADMIN_PROD
    $aadAdminObjId = $CONST_SQL_AADADMIN_PROD_OBJID
}

# for AKS clusters and functions provided as parms, get their subnetIds
Write-Verbose "Determine subnetIds for firewall rules." -Verbose
$allSubnetIds = @()
if ($aksClusterName) {
    $aksSubnetIds = @(get-AKSsubnets $aksClusterName)
    $allSubnetIds = $allSubnetIds + $aksSubnetIds
}

if ($functionName) {
    $functionSubnetIds = @(get-FunctionSubnets $functionName)
    $allSubnetIds = $allSubnetIds + $functionSubnetIds
}

if ($additionalSubnetIds) {
    # convert the csv $additionalSubnetIds into an array and append to $allSubnetIds
    $allSubnetIds = $allSubnetIds + @($additionalSubnetIds.split(","))
}

# weed out any non-atlas subnetIds
$AtlasSubnetIds = @()
if ($allSubnetIds) {
    foreach ($subnetId in $allSubnetIds) {
        $subnetId = $subnetId.trim()  #trim leading/trailing spaces
        Write-Verbose "Check subnet to verify it is from an Atlas resource:" -Verbose
        Write-Verbose "SubnetId:  $subnetId" -Verbose
        $atlasSubnet = Is-subnetAtlas $subnetId
        if ($atlasSubnet) {
            Write-Verbose "Atlas subnetId will be applied as sql firewall rule" -Verbose
            $AtlasSubnetIds = $AtlasSubnetIds + $subnetId
        }
        else {
            Write-Verbose "Subnet is not an Atlas resource, so it is not being added to the azure sql firewall rules:" -Verbose
            Write-Verbose "SubnetId:  $subnetId" -Verbose
        }
    }
}

Write-Verbose "Atlas subnetIds that will be added to firewall rules:" -Verbose
Write-Verbose "$($AtlasSubnetIds)" -Verbose

# format Atlas subnetIds as an array of objects for the arm template
[System.Collections.ArrayList]$subnetArray = @()
if ($AtlasSubnetIds) {
    foreach ($AtlasSubnetId in $AtlasSubnetIds) {
        $hashTb = @{ vNetRuleName = "rule-$($AtlasSubnetId.split('/')[8])-$($AtlasSubnetId.split('/')[10])"; subnetResourceId = $AtlasSubnetId }
        $subnetArray.Add($hashTb) | Out-Null
    }
}

$useVNetServiceEndpoint = "Yes"
if (!$subnetArray) {
    $useVNetServiceEndpoint = "No"
    # the vNet resources in the ARM template are conditionally added based on $useVNetServiceEndpoint
    # if $useVNetServiceEndpoint is 'No', we still need to pass in a valid array because the template is validated,
    # hence adding these dummy values
    [System.Collections.ArrayList]$subnetArray = @()
    $hashTb = @{vNetRuleName = "dummyValue"; subnetResourceId = "dummyValue"}
    $subnetArray.Add($hashTb) | Out-Null
}

# need to format the subnetArray for the az cli template deployment
$formattedSubnetArray = ($subnetArray | ConvertTo-Json -Compress)
Write-Verbose "Formatted subnet array is $($formattedSubnetArray)" -verbose
if (!$formattedSubnetArray.StartsWith('[')) {
    # wrap $formattedSubnetArray in [] if it is not already (when one item in array it is not wrapped)
    $formattedSubnetArray = "[" + $formattedSubnetArray + "]"
}
#$formattedSubnetArray = $formattedSubnetArray.Replace('"', '\"')

$sqlAdminPassword = Get-StrongPassword

# create the azure sql server
#  note - we'll rely on our guardrail to define the standard ip firewall rules
#       - using powershell Az vs. cli due to either:
#               notificationEmailList having semicolons and that was creating issues
#            and/or passing the subnetArray was having issues with cli
Write-Verbose "Deploy Azure SQLServer via ARM template." -Verbose
$AzureSQLServerTemplate = "$INFRA_FOLDER/AzureSQL/src/azuredeployAzureSQLServer.json"

Write-Verbose "serverName:  $serverName" -Verbose
Write-Verbose "location:  $location" -Verbose
Write-Verbose "aadAdminGroup:  $aadAdminGroup" -Verbose
Write-Verbose "aadAdminObjId:  $aadAdminObjId" -Verbose
Write-Verbose "notificationEmailList:  $notificationEmailList" -Verbose
Write-Verbose "TEMPLATE_VERSION:  $TEMPLATE_VERSION" -Verbose
Write-Verbose "CREATED_DATE:  $CREATED_DATE" -Verbose
Write-Verbose "useVNetServiceEndpoint:  $useVNetServiceEndpoint" -Verbose
Write-Verbose "formattedSubnetArray:  $formattedSubnetArray" -Verbose

$ErrorActionPreference = "Stop"
# Deploy application gateway with WAF to resource group
$Action = {
    az deployment group create `
        -g "$resourceGroup" `
        --template-file "$AzureSQLServerTemplate" `
        --parameters "sqlServerName=$serverName" `
        "sqlLocation=$location" `
        "sqlAdminPw=$sqlAdminPassword"  `
        "sqlAADAdminLogin=$aadAdminGroup"  `
        "sqlAADAdminObjectID=$aadAdminObjId"  `
        "notificationEmailList=$notificationEmailList"  `
        "TagTemplateVersion=$TEMPLATE_VERSION"  `
        "createdDate=$CREATED_DATE"  `
        "useVNetServiceEndpoint=$useVNetServiceEndpoint"  `
        "AtlasSubnetIds=$formattedSubnetArray"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "sql server deployment complete." -Verbose
