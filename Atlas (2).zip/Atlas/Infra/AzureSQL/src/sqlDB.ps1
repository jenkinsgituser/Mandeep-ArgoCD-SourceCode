# Provision an Azure SQL database.
Write-Verbose "Provisioning the Azure SQL Database." -Verbose

. "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1")
. ("$env:INFRA_FOLDER/AzureSQL/src/sql-utilities.ps1")

Write-Verbose "Determine Environment." -Verbose
$SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
$environment = $SubscriptionProperties.environment

Write-Verbose "Environment: $environment" -Verbose

#verify azure sql server exists
# if the sql server does not exist, the database template will create it but it won't be Atlas configured (bad)
Write-Verbose "Verify Azure SQL Server exists." -Verbose
$server = az sql server list --resource-group $resourceGroup | ConvertFrom-Json
$server = $server | Where-Object { $_.name -eq $serverName }
if (!$server) {
    Write-Verbose "Azure SQL server not found:  $($serverName)" -Verbose
    Write-Verbose "Azure SQL server must exist before creating database, exiting deployment" -Verbose
    exit 99
}

# create sql database
Write-Verbose "Create sql database $databaseName" -Verbose
$AzureSQLDatabaseTemplate = "$INFRA_FOLDER/AzureSQL/src/azuredeployAzureSQLDatabase.json"
$ErrorActionPreference = "Stop"
# Deploy application gateway with WAF to resource group
$Action = {
    az deployment group create `
    -g "$resourceGroup" `
    --template-file "$AzureSQLDatabaseTemplate" `
    --parameters "sqlServerName=$serverName" `
    "sqlDatabaseName=$databaseName" `
    "requestedServiceObjectiveName=$databaseServiceObjective" `
    "databaseCollation=$databaseCollation" `
    "sqlLocation=$location" `
    "TagTemplateVersion=$TEMPLATE_VERSION" `
    "createdDate=$CREATED_DATE"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

# update database max size, can't be done in arm template if we want to use azure default, so only run this if user provided value
if ($null -ne $SQL_DATABASE_MAXSIZE_GB_FORMATTED) {
    Write-Verbose "set database maxsize to SQL_DATABASE_MAXSIZE_GB_FORMATTED: $SQL_DATABASE_MAXSIZE_GB_FORMATTED" -Verbose
    az sql db update -g $resourceGroup -s $serverName -n $databaseName --max-size $SQL_DATABASE_MAXSIZE_GB_FORMATTED
}

# figure out if data layer permissions have already been setup and exit if so.
# at a future time this can call Get-AtlasNeedToCompleteDatabaseSetup to determine if we actually need to complete the setup,
# but given that the hosted agents run off untrusted networks it'll be easiest to switch after we run from Atlas hosted agents
$completeDatabaseSetup = $true
Write-Verbose "Need to complete database setup? $completeDatabaseSetup" -Verbose

if ($completeDatabaseSetup) {
    $SQLAdminInfo = Get-SqlAdminAccountConfigurationInfo-HostedAgent -environment $environment

    #can't set this in hybrid worker runbook due to AD access from AA MSI, so needs to be done before calling it
    Write-Verbose $("set temporary AAD admin for sql server, SQLAdminUser is $($SQLAdminInfo.userName)") -Verbose
    $spObjectId = az ad user show --id $SQLAdminInfo.username --query "id" -o tsv
    # use this when we switch to using the Service Principal and retire the domain service account
    #$spObjectId = (az ad app list --display-name $($SQLAdminInfo.userName) | ConvertFrom-Json).objectId
    az sql server ad-admin update --resource-group $resourceGroup --server $serverName --display-name $SQLAdminInfo.userName --object-id $spObjectId

    #find and source the runbook
    ##########################################
    #store current subscription
    $currentSub = (Get-AzContext).Subscription.Name
    $Params = @{"sqlServer" = $serverName; "sqlDatabase" = $databaseName; "resourceGroup" = $resourceGroup; "Subscription" = $currentSub }
    . ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
    Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-SelfServeSQLDatabaseSetup" -Parameters $Params
    ####################################################################

    #Set admin user for the SQL server from AAD users.
    if (($environment -eq "NonProd") -or ($environment -eq "Sandbox")) {
        $aadAdminGroup = $CONST_SQL_AADADMIN_NONPROD
        $aadAdminObjId = $CONST_SQL_AADADMIN_NONPROD_OBJID
    }
    else {
        $aadAdminGroup = $CONST_SQL_AADADMIN_PROD
        $aadAdminObjId = $CONST_SQL_AADADMIN_PROD_OBJID
    }

    Write-Verbose "Set AAD admin for sql server back to desired account/group: $aadAdminGroup" -Verbose

    az sql server ad-admin update --resource-group $resourceGroup --server $serverName --display-name $aadAdminGroup --object-id $aadAdminObjId


}
else {
    Write-Verbose "Database setup skipped as preconditions satisfied" -Verbose
}

Write-Verbose "sql database deployment complete." -Verbose