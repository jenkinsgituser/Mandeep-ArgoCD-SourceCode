# Common
########################################################


Function Get-StrongPassword {
    param(
        [Parameter (Mandatory = $false)]
        [bool]$Insecure = $false
    )
    # generate a random password based on guid
    # sql complexity requirements:
    # https://docs.microsoft.com/en-us/sql/relational-databases/security/password-policy?view=sql-server-ver15

    #ascii characters between 65-90 are upper case A-Z
    $oneUpper = (Get-Random -Minimum 65 -Maximum 90) | ForEach-Object { [char]$_ }
    #ascii characters between 97-122 are lower case a-z
    $oneLower = (Get-Random -Minimum 97 -Maximum 122) | ForEach-Object { [char]$_ }
    # get a single Integer
    $oneInt = (Get-Random -Minimum 1 -Maximum 9)
    $specialChar = "@"
    $eachCharType = $oneUpper + $oneLower + $oneInt + $specialChar

    $password = ((New-Guid).Guid + "-" + $eachCharType)
    if ($Insecure) {
        return $password
    }
    else {
        # build a pw from a new guid and one of each character type generated above
        $strongPassword = ConvertTo-SecureString -String $password -AsPlainText -Force
        return $strongPassword
    }
}


# Atlas-databaseRestore.ps1
########################################################
Function fn-RenameDatabase {
    [CmdletBinding()]
    [OutputType([bool])]
    PARAM (
        $targetDbNm,
        $sourceDbNm,
        $sourceSvrNm,
        $srcRGNm
    )

    az sql db rename --new-name $targetDbNm  `
        --name $sourceDbNm  `
        --resource-group $srcRGNm  `
        --server $sourceSvrNm

}

Function fn-RestoreDatabase {
    [CmdletBinding()]
    [OutputType([bool])]
    PARAM (
        $targetDbNm,
        $sourceDbNm,
        $sourceSvrNm,
        $srcRGNm,
        $restorePoint
    )

    az sql db restore --dest-name $targetDbNm  `
        --name $sourceDbNm  `
        --resource-group $srcRGNm  `
        --server $sourceSvrNm  `
        --time $restorePoint

}

Function Setup-AtlasSqlTestDBConnection {
    param(
        [Parameter (Mandatory = $true)]
        [string]$ResourceGroup,

        [Parameter (Mandatory = $true)]
        [string]$SqlServerName
    )
    # need to tag this with network exceptions so it doens't get ripped off along the way
    Add-AtlasExceptionTag -resourceGroup $ResourceGroup -resourceName $SqlServerName -tagValueToAdd "Network" -resourceType "Microsoft.Sql/servers"

    $externalIp = (Get-MyIp).replace("/32", "")
    $ruleName = "AtlasSQLPermissionsDeployment-TestSQLAccess-$(Get-Date -Format "yyyyMMddHHmmss")"
    Write-Verbose "Temporarily add azure sql firewall rule to allow this Atlas SQL Deployment to access database" -Verbose
    az sql server firewall-rule create --resource-group $ResourceGroup --server $SqlServerName -n $ruleName --start-ip-address $externalIp --end-ip-address $externalIp
    Write-Verbose "external ip added as firewall rule:  $externalIp" -Verbose

    $userName = 'sa-' + $SqlServerName
    $logonPW = Get-StrongPassword -Insecure $true

    Write-Verbose "Updating the password so the test script can access the server..." -Verbose
    $SecureString = ConvertTo-SecureString $logonPW  -AsPlainText -Force
    Set-AzSqlServer -ResourceGroupName $ResourceGroup -ServerName $SqlServerName -SqlAdministratorPassword $secureString

    return @{Username = $userName; LogonPassword = $logonPW; }
}

Function Teardown-AtlasSqlTestDBConnection {
    param(
        [Parameter (Mandatory = $true)]
        [string]$ResourceGroup,

        [Parameter (Mandatory = $true)]
        [string]$SqlServerName
    )

    Remove-AtlasExceptionTag -resourceGroup $ResourceGroup -resourceName $SqlServerName -tagValueToRemove "Network" -resourceType "Microsoft.Sql/servers"
}
###############################################################


# =======================================================================================
# if we connect to the database, we can check if setup has already been performed.
# if it has been performed, we can skip the steps below and continue onwards
# =======================================================================================
Function Get-AtlasNeedToCompleteDatabaseSetup {
    param(
        [Parameter (Mandatory = $true)]
        [string]$ResourceGroup,

        [Parameter (Mandatory = $true)]
        [string]$SqlServerName,

        [Parameter (Mandatory = $false)]
        [bool]$SkipNetworkManipulation = $false
    )

    return $true
    <# Code below requires review for the optimization it provides

    $CONST_MAX_ATTEMPTS = 3
    $CONST_SLEEP_TIME = 5

    # default to true so we do the work if anything goes wrong
    $completeDatabaseSetup = $true

    $permsQuery = "SELECT pr.principal_id, pr.name, pe.permission_name
                    FROM sys.database_principals AS pr
                    JOIN sys.database_permissions AS pe
                    ON pe.grantee_principal_id = pr.principal_id;"

    $rolesQuery = "SELECT DP1.name AS DatabaseRoleName,
                    isnull (DP2.name, 'No members') AS DatabaseUserName
                    FROM sys.database_role_members AS DRM
                    RIGHT OUTER JOIN sys.database_principals AS DP1
                    ON DRM.role_principal_id = DP1.principal_id
                    LEFT OUTER JOIN sys.database_principals AS DP2
                    ON DRM.member_principal_id = DP2.principal_id
                    WHERE DP1.type = 'R'
                    ORDER BY DP1.name;"

    try{
        $setupVariables = Setup-AtlasSqlTestDBConnection -ResourceGroup $ResourceGroup -SqlServerName $SqlServerName

        $permsParams = @{
            'ServerInstance' = "$SqlServerName.database.windows.net";
            'Database' = $env:SQL_DATABASE_NAME;
            'Username' = $setupVariables.Username;
            'Password' = $setupVariables.LogonPassword;
            'Query' = $permsQuery;
        }

        $rolesParams = @{
            'ServerInstance' = "$SqlServerName.database.windows.net";
            'Database' = $env:SQL_DATABASE_NAME;
            'Username' = $setupVariables.Username;
            'Password' = $setupVariables.LogonPassword;
            'Query' = $rolesQuery;
        }

        $i = 0
        $success = $false
        $ErrorActionPreference = "Stop"

        #===============================================================================
        # Run multiple queries in one go, and then do assertions after
        #===============================================================================
        $dbPerms = Invoke-SqlCmd @permsParams
        $dbRoles = Invoke-SqlCmd @rolesParams
        $success = $true  # if we got here the sql commands worked

        $SARmAccount = "SA-RM-ITPort-P@cmutual.com"
        $SPRmAccount = "SP-RM-Sandbox-P"
        $SaAtlasAzSqlPermAccount = "SA-AtlasAzSqlPerm-D@cmutual.com"

        # mirroring our datalayer tests
        $saRmAccountSetupComplete = $false
        $saRmAccountResult = $dbPerms | Where-Object {$_.name -eq $SARmAccount}
        $saRmAccountRole = $dbRoles | Where-Object {$_.DatabaseUserName -eq $SARmAccount}
        if ($saRmAccountResult -ne $null `
            -and $saRmAccountResult.Count -eq 7 `
            -and $saRmAccountRole.DatabaseRoleName -eq "db_ddladmin")
        {
            Write-Verbose "$SARmAccount already setup." -Verbose
            $saRmAccountSetupComplete = $true
        } else{
            Write-Verbose "$SARmAccount has not been setup. Early returning..." -Verbose
            return $true
        }

        $spRmAccountSetupComplete = $false
        $spRmAccountResult = $dbPerms | Where-Object {$_.name -eq $SPRmAccount}
        $spRmAccountRole = $dbRoles | Where-Object {$_.DatabaseUserName -eq $SPRmAccount}
        if ($spRmAccountResult -ne $null `
            -and $spRmAccountResult.Count -eq 7 `
            -and $spRmAccountRole.DatabaseRoleName -eq "db_ddladmin")
        {
            Write-Verbose "$SPRmAccount already setup." -Verbose
            $spRmAccountSetupComplete = $true
        } else{
            Write-Verbose "$SPRmAccount has not been setup. Early returning..." -Verbose
            return $true
        }

        $saAtlasAccountSetupComplete = $false
        $saAtlasAcctResult = $dbPerms | Where-Object {$_.name -eq $SaAtlasAzSqlPermAccount}
        $saAtlasAccountRole = $dbRoles | Where-Object {$_.DatabaseUserName -eq $SaAtlasAzSqlPermAccount}
        if ($saAtlasAcctResult -ne $null `
            -and $saAtlasAccountRole.DatabaseRoleName -eq "db_owner")
        {
            Write-Verbose "$SaAtlasAzSqlPermAccount already setup." -Verbose
            $saAtlasAccountSetupComplete = $true
        } else{
            Write-Verbose "$SaAtlasAzSqlPermAccount has not been setup. Early returning..." -Verbose
            return $true
        }

        # if all pre-conditions pass, skip database setup
        if ($saRmAccountSetupComplete -and $spRmAccountSetupComplete -and $saAtlasAccountSetupComplete){
            $completeDatabaseSetup = $false
        }

        return $completeDatabaseSetup

    }catch{
        Write-Verbose "Unable to complete check of existing database state. Continuing foward to ensure baseline setup..." -Verbose
    }finally{
        # default to cleaning this up, but add a switch for when testing and want to skip it
        if($SkipNetworkManipulation -eq $false){
            Teardown-AtlasSqlTestDBConnection -ResourceGroup $ResourceGroup -SqlServerName $SqlServerName
        }
    }
#>
}