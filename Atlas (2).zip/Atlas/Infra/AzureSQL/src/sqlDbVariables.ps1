$databaseName = $(If ($env:SQL_DATABASE_NAME) { "$env:SQL_DATABASE_NAME" } Else { Write-Error "Missing required variable SQL_DATABASE_NAME"; Exit 1 })
Write-Verbose "SQL_DATABASE_NAME: $databaseName" -Verbose

$databaseServiceObjective = $(If ($env:SQL_DATABASE_SERVICEOBJECTIVE) { "$env:SQL_DATABASE_SERVICEOBJECTIVE" } Else { Write-Error "Missing required variable SQL_DATABASE_SERVICEOBJECTIVE"; Exit 1 })
Write-Verbose "SQL_DATABASE_SERVICEOBJECTIVE: $databaseServiceObjective" -Verbose

if ($env:SQL_DATABASE_COLLATION) {
    $databaseCollation = "$env:SQL_DATABASE_COLLATION"
}
else {
    $databaseCollation = "SQL_Latin1_General_CP1_CI_AS"
}
Write-Verbose "databaseCollation: $databaseCollation" -Verbose

$SQL_DATABASE_MAXSIZE_GB = $(If ($env:SQL_DATABASE_MAXSIZE_GB) { "$env:SQL_DATABASE_MAXSIZE_GB" } Else { $null })
if ($null -ne $SQL_DATABASE_MAXSIZE_GB) {
    Write-Verbose "SQL_DATABASE_MAXSIZE_GB: $SQL_DATABASE_MAXSIZE_GB" -Verbose
    # use regex to verify the value is an integer (only numeric digits)
    if ($SQL_DATABASE_MAXSIZE_GB -match "^\d+$") {
        $SQL_DATABASE_MAXSIZE_GB_FORMATTED = $SQL_DATABASE_MAXSIZE_GB + "GB"
        Write-Verbose "SQL_DATABASE_MAXSIZE_GB_FORMATTED: $SQL_DATABASE_MAXSIZE_GB_FORMATTED" -Verbose
    }
    else {
        throw "SQL_DATABASE_MAXSIZE_GB value of: $SQL_DATABASE_MAXSIZE_GB is not an integer.  The value must be an integer."
    }
}
