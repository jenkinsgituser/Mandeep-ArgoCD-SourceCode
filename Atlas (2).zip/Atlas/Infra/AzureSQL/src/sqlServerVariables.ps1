Write-Verbose "Setting deployment variables."

$CREATED_DATE = Get-Date -Format "yyyy-MM-dd"
Write-Verbose "CREATED_DATE: $CREATED_DATE" -Verbose

#Append server name with "sql-" and convert to lowercase if already not done so
$serverName = $(If ($env:SQL_SERVER_NAME) { "$env:SQL_SERVER_NAME" } Else { Write-Error "Missing required variable SQL_SERVER_NAME"; Exit 1 })
Write-Verbose "SQL_SERVER_NAME: $serverName" -Verbose

if (!($serverName.ToLower().StartsWith($CONST_SQL_PREFIX))) {
    $serverName = $CONST_SQL_PREFIX + $serverName
}
$serverName = ($serverName).ToLower()
Write-Verbose "serverName: $serverName" -Verbose

#The admin username for the SQL server is the server name
#prepended with "sa-"
$sqlAdminUsername = "sa-" + $serverName
Write-Verbose "sqlAdminUsername: $sqlAdminUsername" -Verbose

$resourceGroup = $(If ($env:SQL_RESOURCE_GROUP) { "$env:SQL_RESOURCE_GROUP" } Else { Write-Error "Missing required variable SQL_RESOURCE_GROUP"; Exit 1 })
Write-Verbose "SQL_RESOURCE_GROUP: $resourceGroup" -Verbose

# have location set once here and then it can also be inherited by the DB deployment
if ($env:SQL_LOCATION) {
    $location = $env:SQL_LOCATION
}
else {
    $location = $(If ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { $CONST_LOCATION_DEFAULT })
}
Write-Verbose "SQL_LOCATION: $location" -Verbose
$notificationEmailList = $(If ($env:NOTIFICATION_EMAIL_LIST) { "$env:NOTIFICATION_EMAIL_LIST" } Else { Write-Error "Missing required variable NOTIFICATION_EMAIL_LIST"; Exit 1 })
Write-Verbose "notificationEmailList: $notificationEmailList" -Verbose

# no more default beta behavior. If this is failing we want a hard fail

if ($env:AKS_CLUSTER_NAME) {
    $aksClusterName = $env:AKS_CLUSTER_NAME.split(",")
}
else {
    $aksClusterName = $null
}
Write-Verbose "aksClusterName: $aksClusterName" -Verbose

if ($env:FUNCTION_NAME) {
    $functionName = $env:FUNCTION_NAME.split(",")
}
else {
    $functionName = $null
}
Write-Verbose "functionName: $functionName" -Verbose

if ($env:ADDITIONAL_SUBNET_IDS) {
    $additionalSubnetIds = $env:ADDITIONAL_SUBNET_IDS
}
Write-Verbose "additionalSubnetIds: $additionalSubnetIds" -Verbose
