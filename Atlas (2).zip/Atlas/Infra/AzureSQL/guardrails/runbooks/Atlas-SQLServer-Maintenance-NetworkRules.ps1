
param
(
    [Parameter (Mandatory = $false)]
    [PsObject] $WebhookData,

    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false,

    <#
    The two parameters below exist to run the script ad-hoc against a specific SQL instance.
    #>
    [Parameter (Mandatory = $false)]
    [string] $TargetSubscription = [string]::Empty,

    [Parameter (Mandatory = $false)]
    [string] $TargetSQLServerRG = [string]::Empty,

    [Parameter (Mandatory = $false)]
    [string] $TargetSQLServerName = [string]::Empty
)

# Function to determine if a resource group is atlas.
#################################################################
function Is-RGAtlas {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [parameter(Mandatory = $true)][PsObject]$Context
    )
    $CONST_ATLAS_RG_TAG_IDENTIFIER = "Titan-Atlas"

    $tags = $(Get-AzResourceGroup -Name $resourceGroup -DefaultProfile $Context).Tags

    $RGIsAtlas = $false
    $version = $tags.TemplateVersion
    If (($null -ne $version) -and ($version.Contains($CONST_ATLAS_RG_TAG_IDENTIFIER))) {
        $RGIsAtlas = $true
    }#else ignore

    return $RGIsAtlas
}


# Function to check for network exception tag
#################################################################
function Check-AtlasNetworkException {
    param(
        [Parameter(Mandatory = $true)][string]$resourceGroup,
        [Parameter(Mandatory = $true)][string]$sqlServerName,
        [parameter(Mandatory = $true)][PsObject]$Context
    )

    $networkExceptionExists = $true

    $sqlObj = Get-AzSqlServer -ResourceGroupName $resourceGroup -ServerName $sqlServerName -DefaultProfile $Context

    if (($null -ne $sqlObj.Tags.AtlasExceptions) -and ($sqlObj.Tags.AtlasExceptions.Contains("Network"))) {
        Write-AtlasOutput -LogLevel "INFO" -Message "`t SQL Server $($sqlObj.ServerName) contains a Network Exception tag, skipping firewall rule validation."
    }
    else {
        $networkExceptionExists = $false
    }

    return $networkExceptionExists
}


# Function to check sql server vNet rules
#################################################################
function Check-SqlVnetRules {
    param(
        [Parameter(Mandatory = $true)][string] $sqlServerRG,
        [Parameter(Mandatory = $true)][string] $sqlServerName,
        [parameter(Mandatory = $true)][PsObject]$Context
    )
    $sqlVnetRules = Get-AzSqlServerVirtualNetworkRule -ResourceGroupName $sqlServerRG -ServerName $sqlServerName -DefaultProfile $Context

    # process each of the returned rules for Atlas compliance status
    foreach ($vnetRule in $sqlVnetRules) {
        $stringSplit = ($vnetRule.VirtualNetworkSubnetId) -split "/"
        $vnetSubscription = $stringSplit[2]
        $vnetResourceGroup = $stringSplit[4]
        $vnetName = $stringSplit[8]
        $vnetRuleName = $vnetRule.VirtualNetworkRuleName

        # consumes function sourced from Atlas-CommonCode.ps1
        # null check for the vNet result is handled in this function, providing benefit of the doubt in
        # cases where the Azure API is not responding
        if ((Validate-NetworkLocationIsAtlasAllowed -subnetResourceId $vnetRule.VirtualNetworkSubnetId -context $Context) -eq $false) {
            Write-AtlasOutput -LogLevel "WARN" -Message "WARNING: Non-Titan VNet found: $vnetName"

            #Remove vnet rule from sql server if vnet does not have atlas tags
            Write-AtlasOutput -LogLevel "INFO" -Message "`r remove vNet rule '$vNetName' due to failing Atlas compliance check!"
            Remove-AzSqlServerVirtualNetworkRule -ResourceGroupName $sqlServerRG -ServerName $sqlServerName -VirtualNetworkRuleName $vnetRuleName -DefaultProfile $sub
        }
    }
}


function Do-ProcessSqlServerResource {
    param
    (
        [Parameter(Mandatory = $true)][string] $sqlServerRG,
        [Parameter(Mandatory = $true)][string] $sqlServerName,
        [parameter(Mandatory = $true)][PsObject] $Context
    )
    #check if rg is atlas, if not atlas skip
    $isAtlasResourceGroup = Is-RGAtlas -resourceGroup $sqlServerRG -Context $Context
    if ($isAtlasResourceGroup) {
        $networkException = Check-AtlasNetworkException -resourceGroup $sqlServerRG -sqlServerName $sqlServerName -Context $Context
        if (!$networkException) {
            Write-AtlasOutput -LogLevel "INFO" -Message "No network exception tag, check firewall rules."
            Ensure-SqlFirewallRules -sqlServerRG $sqlServerRG -sqlServerName $sqlServerName -Context $Context
            Check-SqlVnetRules -sqlServerRG $sqlServerRG -sqlServerName $sqlServerName -Context $Context
        }
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "$sqlServerName Not Atlas resource, skipping...."
    }
}


#MAIN
#-----------------------------------------------------------------------------------------------------

$ErrorActionPreference = "Stop"
$VerbosePreference = "SilentlyContinue"

try {
    # do the import in the silenced block
    Import-Module Az.Accounts | Out-Null
    Import-Module Az.Network | Out-Null
    Import-Module Az.Sql | Out-Null
    Import-Module Az.Resources | Out-Null
}
catch {
    Write-AtlasOutput -LogLevel WARN "Error importing required modules. $($_.Exception.Message)"
}

Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
# if i'm local or i'm running on a build agent, source the file by location
# rather than relying on its presence within the AA
if ($env:IsLocal -or $env:AGENT_ID) {
    . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1
    . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1
}
else {
    #sourcing on the AA is slightly different than sourcing locally
    . ./Atlas-CommonCode.ps1
    . ./Atlas-CommonSQLCode.ps1
    Azure-Connect
}
$VerbosePreference = "Continue"

Write-AtlasOutput -Message " "
$CONST_AUTOMATION_ACCOUNT_NAME = "AA-CMFG-P01-InfraMgmt-AZ"
$CONST_AUTOMATION_ACCOUNT_NAME_NP = "AA-CMFG-D01-InfraMgmt-AZ"
$CONST_RUNBOOK_NAME = "Atlas-SQLServer-Maintenance-NetworkRules"


# if there is webhook data, process that event
if ($WebhookData) {
    $WebhookBody = $WebhookData.RequestBody | ConvertFrom-Json
    $subscriptionId = $WebhookBody.subject.Split("/")[2]

    # if we have webhook data, the following variables will be overwritten if also passed in
    $TargetSubscription = (Get-AzSubscription -SubscriptionId $subscriptionId).Name
    $TargetSQLServerRG = $WebhookBody.subject.Split("/")[4]
    $TargetSQLServerName = $WebhookBody.subject.Split("/")[8]

    Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $TargetSubscription"
    $Context = Set-AzContext -Subscription $TargetSubscription

    # check the appId that resulted in the alert fireing.  If it was our runbook runas account, don't call the runbook again.
    # if the alert that called this runnbook was generated via a change from the web logging runbook, we don't need/want
    # to call the runbook again.
    # these appids are for the service principals that are the runas accounts for our runbook
    #   SP-AA-InfraMgmt-Az-D   6e5ed314-7154-4254-84b0-e43f1c638615
    #   SP-AA-InfraMgmt-Az-P   aed58b11-d650-4e8f-b740-30704654d758
    $callerAppId = $WebhookBody.data.claims.appid
    if (((Check-CallerIsTrustedAtlasIdentity -callerAppId $callerAppId) -eq $false) `
            -and $null -ne $WebhookBody.subject) {
        Do-ProcessSqlServerResource -sqlServerRG $TargetSQLServerRG -sqlServerName $TargetSQLServerName -Context $Context
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "This alert was generated via a change from trusted source $callerAppId, so no action taken."
        Write-AtlasOutput -LogLevel "INFO" -Message "  TargetSubscription:  $TargetSubscription"
        Write-AtlasOutput -LogLevel "INFO" -Message "  TargetSQLServerRG:  $TargetSQLServerRG"
        Write-AtlasOutput -LogLevel "INFO" -Message "  TargetSQLServerName:  $TargetSQLServerName"
    }
}
elseif
# if a specific azure sql resource is passed, just process that one
    ($TargetSubscription -and $TargetSQLServerName -and $TargetSQLServerRG) {
    # this case exists for manual triggering of the runbook
    Write-AtlasOutput -LogLevel "INFO" -Message "TargetSubscription:  $TargetSubscription"
    Write-AtlasOutput -LogLevel "INFO" -Message "TargetSQLServerRG:  $TargetSQLServerRG"
    Write-AtlasOutput -LogLevel "INFO" -Message "TargetSQLServerName:  $TargetSQLServerName"
    $subFound = Get-AzSubscription | Where-Object { $_.name -eq $TargetSubscription }
    $Context = Set-AzContext -Subscription $TargetSubscription

    if ($subFound) {
        Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $TargetSubscription"
        $Context = Set-AzContext -Subscription $TargetSubscription
        $sqlFound = Get-AzSqlServer -ResourceGroupName $TargetSQLServerRG -ServerName $TargetSQLServerName -ErrorAction SilentlyContinue -DefaultProfile $Context
        if ($sqlFound) {
            Do-ProcessSqlServerResource -sqlServerRG $TargetSQLServerRG -sqlServerName $TargetSQLServerName -Context $Context
        }
        else {
            Write-AtlasOutput -LogLevel "WARN" -Message "Invalid TargetSQLServerRG: $TargetSQLServerRG TargetSQLServerName: $TargetSQLServerName"
        }
    }
    else {
        Write-AtlasOutput -LogLevel "WARN" -Message "Invalid TargetSubscription: $TargetSubscription"
    }

}
elseif
# if all parms are empty we will sweep all subscriptions
([string]::IsNullOrEmpty($WebhookData) -and
[string]::IsNullOrEmpty($TargetSubscription) -and
[string]::IsNullOrEmpty($TargetSQLServerName) -and
[string]::IsNullOrEmpty($TargetSQLServerRG)
) {
    $subscriptions = (Get-AzSubscription).Name
    foreach ($subscription in $subscriptions) {
        Write-AtlasOutput -LogLevel "INFO" -Message "--Processing in subscription: $subscription"
        $Context = Set-AzContext -Subscription $subscription
        $sqlServers = Get-AzSqlServer
        foreach ($sqlServer in $sqlServers) {
            Do-ProcessSqlServerResource -sqlServerRG $($sqlServer.ResourceGroupName) -sqlServerName $($sqlServer.ServerName) -Context $Context
        }
    }
}

Write-AtlasOutput -LogLevel "INFO" -Message "Job Complete"
