
# This script is ONLY used for setting up the DLX admin MSI's
# Do not use this for any other teams or accounts

param
(
    [Parameter (Mandatory = $true)]
    [string] $subscription,

    [Parameter (Mandatory = $true)]
    [string] $sqlServerName,

    [Parameter (Mandatory = $true)]
    [string] $sqlDatabaseName,

    [Parameter (Mandatory = $true)]
    [string] $identity
)


Function Provision-DLXAdminDBUser {
    param (
        $con,
        $identity
    )

    Try {
        $cmd = New-Object System.Data.SqlClient.SqlCommand

        $query = "IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = '$identity')
                  CREATE USER [$identity] FROM EXTERNAL PROVIDER"
        $cmd.CommandText = $query
        $cmd.Connection = $con
        Write-AtlasOutput -Message $("   Executing: " + $query)
        $x = $cmd.ExecuteNonQuery()

        $query = "ALTER ROLE [db_owner] ADD MEMBER [$identity]"
        $cmd.CommandText = $query
        $cmd.Connection = $con
        Write-AtlasOutput -Message $("   Executing: " + $query)
        $x = $cmd.ExecuteNonQuery()
    }
    Catch [System.Data.SqlClient.SqlException] {
        Write-AtlasOutput -Message "   sql exception creating user:"
        Write-AtlasOutput -LogLevel "ERROR" -Message $_.Exception.Message
        throw $_.Exception
    }
    Catch {
        $errorMsg = $('There was an error in Provision-DLXAdminDBUser for user: ' + $identity)
        Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
        Throw $_
    }
}


###############################################################################################################
## MAIN #######################################################################################################

# Trim leading and trailing spaces
$subscription = $subscription.trim()
$sqlServerName = $sqlServerName.trim()
$sqlDatabaseName = $sqlDatabaseName.trim()
$identity = $identity.trim()

$VerbosePreference = "SilentlyContinue"
if (!$env:IsLocal -and !$env:AGENT_ID) {
    . ./Atlas-CommonCode.ps1
    . ./Atlas-CommonSQLCode.ps1
}
else {
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1"
}

try {
    # do the import in the silenced block
    Import-Module Az.Resources | Out-Null
    Import-Module Az.Sql | Out-Null
    Import-Module Az.KeyVault | Out-Null
    Import-Module Az.Automation | Out-Null
}
catch {
    Write-AtlasOutput -LogLevel "WARN" -Message "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"

if (!$env:IsLocal) {
    Azure-Connect -RunHybridWorker $true
    $runbookSub = Get-RunbookCurrentSubscription
    Write-AtlasOutput -Message "Automation Account Runbook Subscription: $($runbookSub)"
    $runbookContext = Select-AzSubscription $runbookSub
    $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $runbookSub
    $AAenvironment = $SubscriptionProperties.environment
}
else {
    $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $((Get-AzContext).Subscription.Name)
    $AAenvironment = $SubscriptionProperties.environment
}

Write-AtlasOutput -Message "Automation Account Environment: $AAenvironment"

$subCtx = Set-AzContext $subscription

###############################################################################################################
# input validation
# subscription must be DLX

if ($subscription -notlike "DLX*") {
    throw "This script is only for DLX subscriptions"
}

# $identity should be for a valid app service
$appSvc = Get-AzResource -Name $identity -ResourceType "Microsoft.Web/sites" -DefaultProfile $subCtx
if ($null -eq $appSvc) {
    throw "identity $identity needs to be an existing DLX app service"
}
###############################################################################################################

# get sql server and databases
$sqlServer = Get-AzResource -Name $sqlServerName -ResourceType "Microsoft.Sql/servers" -DefaultProfile $subCtx
$sqlDatabases = Get-AzSqlDatabase -ServerName $sqlServerName -ResourceGroupName $sqlServer.ResourceGroupName -DefaultProfile $subCtx

# filter databases based on variable, always exclude "master" database
$sqlDatabases = ($sqlDatabases | Where-Object { ($_.DatabaseName -like $sqlDatabaseName) -and ($_.DatabaseName -ne "master") }).DatabaseName | Sort-Object

Write-AtlasOutput -Message "databases to process: $sqlDatabases"

###############################################################################################################

Write-AtlasOutput -Message "Get SQL Admin account info"
$SQLAdminInfo = Get-SqlAdminAccountConfigurationInfo -environment $AAenvironment
Write-AtlasOutput -Message "user: $($SQLAdminInfo.userName)"

Write-AtlasOutput -Message "Get SQL Admin domain service account password from keyvault"
$sqlPermUserPwSecret = (Get-AzKeyVaultSecret -VaultName $SQLAdminInfo.userKV -Name $SQLAdminInfo.userKVSecretName -DefaultProfile $runbookContext).SecretValue

# get database access token for sql admin account
$TenantId = "a00452fd-8469-409e-91a8-bb7a008e2da0"
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $($SQLAdminInfo.userName), $sqlPermUserPwSecret
$sqlContext = Connect-AzAccount -TenantId $TenantId -Credential $Credential
$resourceAppIdURI = 'https://database.windows.net/'
$SPNToken = (Get-AzAccessToken -ResourceUrl $resourceAppIdURI -DefaultProfile $sqlContext).token
# set context back to original after getting access token for sql admin account
$eatIt = Set-AzContext $runbookContext

###############################################################################################################

Write-AtlasOutput -Message "Add temporary sql firewall rule so deployment script can connect"
$fwData = Set-TemporarySQLFirewallRule -sqlServer $sqlServerName -subscriptionContext $subCtx

$con = New-Object System.Data.SqlClient.SqlConnection

foreach ($sqlDatabase in $sqlDatabases) {

    Write-AtlasOutput -Message "DATABASE: $sqlServerName/$sqlDatabase"

    $con.ConnectionString = "Server=tcp:$sqlServerName" + ".database.windows.net" + ";Initial Catalog=$sqlDatabase;Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;"
    $con.AccessToken = $SPNToken

    Write-AtlasOutput -Message "open connection to $sqlServerName : $sqlDatabase"
    try {
        $con.Open()
    }
    catch {
        Write-AtlasOutput -LogLevel "ERROR" -Message "$($_.Exception.Message)"
        throw $_.Exception
    }

    Write-AtlasOutput -Message "create database user $identity"
    Provision-DLXAdminDBUser -con $con -identity $identity

    $con.close()
}
