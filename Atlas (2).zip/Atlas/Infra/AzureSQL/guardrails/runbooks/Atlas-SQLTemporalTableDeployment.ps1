
param
(
  [Parameter (Mandatory = $true)]
  [string] $subscription,

  [Parameter (Mandatory = $true)]
  [string] $sqlServerName,

  [Parameter (Mandatory = $true)]
  [string] $sqlDatabaseName,

  [Parameter (Mandatory = $true)]
  [string] $sqlScript
)


Function Apply-SqlTemporalTableScript {
  param (
    $con,
    $sqlScript
  )

  Try {
    $cmd = New-Object System.Data.SqlClient.SqlCommand

    $cmd.CommandText = $sqlScript
    $cmd.Connection = $con
    Write-AtlasOutput -Message $("Executing sql script: " + $sqlScript)
    $x = $cmd.ExecuteNonQuery()
  }
  Catch [System.Data.SqlClient.SqlException] {
    Write-AtlasOutput -Message "sql exception executing sql script:"
    Write-AtlasOutput -Message $_.Exception.Message
    Write-AtlasOutput -LogLevel "ERROR" -Message $_.Exception.Message
    throw $_.Exception
  }
  Catch {
    $errorMsg = $("There was an error in Apply-SqlTemporalTableScript")
    Write-AtlasOutput -LogLevel "ERROR" -Message $errorMsg
    Throw $_
  }
}


###############################################################################################################
## MAIN #######################################################################################################

# Trim leading and trailing spaces
$subscription = $subscription.trim()
$sqlServerName = $sqlServerName.trim()
$sqlDatabaseName = $sqlDatabaseName.trim()

$VerbosePreference = "SilentlyContinue"
if (!$env:IsLocal -and !$env:AGENT_ID) {
  . ./Atlas-CommonCode.ps1
  . ./Atlas-CommonSQLCode.ps1
}
else {
  . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
  . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1"
}

try {
  # do the import in the silenced block
  Import-Module Az.Resources | Out-Null
  Import-Module Az.Sql | Out-Null
  Import-Module Az.KeyVault | Out-Null
  Import-Module Az.Automation | Out-Null
}
catch {
  Write-AtlasOutput -LogLevel "WARN" -Message "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"

if (!$env:IsLocal) {
  Azure-Connect -RunHybridWorker $true
  $runbookSub = Get-RunbookCurrentSubscription
  Write-AtlasOutput -Message "Automation Account Runbook Subscription: $($runbookSub)"
  $runbookContext = Select-AzSubscription $runbookSub
  $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $runbookSub
  $AAenvironment = $SubscriptionProperties.environment
}
else {
  $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $((Get-AzContext).Subscription.Name)
  $AAenvironment = $SubscriptionProperties.environment
}

Write-AtlasOutput -Message "Automation Account Environment: $AAenvironment"

# set context to the subscription where the sql resource is
$subCtx = Set-AzContext $subscription

###############################################################################################################
# input validation

# get sql server and databases
$sqlServer = Get-AzResource -Name $sqlServerName -ResourceType "Microsoft.Sql/servers" -DefaultProfile $subCtx
if ($null -eq $sqlServer) {
  Write-AtlasOutput -Message "azure sql server not found: $sqlServerName"
  throw "azure sql server not found: $sqlServerName"
}

$sqlDatabase = Get-AzSqlDatabase -ServerName $sqlServerName -ResourceGroupName $sqlServer.ResourceGroupName -DatabaseName $sqlDatabaseName -DefaultProfile $subCtx
if ($null -eq $sqlDatabase) {
  Write-AtlasOutput -Message "azure sql database $sqlDatabaseName not found on server $sqlServerName"
  throw "azure sql database $sqlDatabaseName not found on server $sqlServerName"
}

# convert sql script from json back to a string
if ($null -eq ($sqlScript | ConvertFrom-Json).value) {
  # powershell core format
  $sqlScript = $sqlScript | ConvertFrom-Json
}
else {
  # powershell v5 format requires to get the .value
  $sqlScript = ($sqlScript | ConvertFrom-Json).value
}


###############################################################################################################

Write-AtlasOutput -Message "Get SQL Admin account info"
$SQLAdminInfo = Get-SqlAdminAccountConfigurationInfo -environment $AAenvironment
Write-AtlasOutput -Message "user: $($SQLAdminInfo.userName)"

Write-AtlasOutput -Message "Get SQL Admin account password from keyvault"
$sqlPermUserPwSecret = (Get-AzKeyVaultSecret -VaultName $SQLAdminInfo.userKV -Name $SQLAdminInfo.userKVSecretName -DefaultProfile $runbookContext).SecretValue

# get database access token for sql admin account
$TenantId = "a00452fd-8469-409e-91a8-bb7a008e2da0"
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $($SQLAdminInfo.userName), $sqlPermUserPwSecret
$sqlContext = Connect-AzAccount -TenantId $TenantId -Credential $Credential
$resourceAppIdURI = 'https://database.windows.net/'
$SPNToken = (Get-AzAccessToken -ResourceUrl $resourceAppIdURI -DefaultProfile $sqlContext).token
# set context back to original after getting access token for sql admin account
$eatIt = Set-AzContext $runbookContext

###############################################################################################################

Write-AtlasOutput -Message "Set temporary sql firewall rule"
$fwRuleAdded = $true  #default to true so we Ensure-SqlFirewallRules at end by default
$fwRuleAdded = Set-TemporarySQLFirewallRule -sqlServer $sqlServerName -subscriptionContext $subCtx

$con = New-Object System.Data.SqlClient.SqlConnection
$con.ConnectionString = "Server=tcp:$sqlServerName" + ".database.windows.net" + ";Initial Catalog=$sqlDatabaseName;Persist Security Info=False;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;"
$con.AccessToken = $SPNToken

Write-AtlasOutput -Message "open connection to $sqlServerName : $sqlDatabaseName"
try {
  $con.Open()
  Write-AtlasOutput -Message "Apply temporal table script to database: $sqlServerName/$sqlDatabaseName"

  $approvedSqlScript = $false
  $approvedSqlScript, $sqlInvalidCommand = validate-SqlTemporalTableScript -sqlScript $sqlScript
  Write-AtlasOutput -Message "sql script passed validation:  $approvedSqlScript"
  if ($approvedSqlScript) {
    Apply-SqlTemporalTableScript -con $con -sqlScript $sqlScript
  }
  else {
    Write-AtlasOutput -LogLevel "WARN" -Message "`rSQL script has failed validation due to unallowed command ($sqlInvalidCommand), only CREATE/ALTER/DROP TABLE commands are allowed."
    throw "SQL script has failed validation due to unallowed command ($sqlInvalidCommand), only CREATE/ALTER/DROP TABLE commands are allowed."
  }

  $con.close()
}
catch {
  Write-AtlasOutput -LogLevel "ERROR" -Message "$($_.Exception.Message)"
  throw $_.Exception
}
finally {
  if ($null -ne $con) {
    $con.Close()
  }

  if ($fwRuleAdded) {
    Write-AtlasOutput -Message "Ensure sql firewall rules are in desired state"
    $sqlResourceGroup = (Get-AzSqlServer -ServerName $sqlServerName -DefaultProfile $subCtx).ResourceGroupName
    Remove-AtlasExceptionTag-Runbook -resourceGroup $sqlResourceGroup -resourceName $sqlServerName -tagValueToRemove "Network" -resourceType "Microsoft.sql/servers" -Context $subCtx
    Write-AtlasOutput -Message "network exception tag was removed"
    Ensure-SqlFirewallRules -sqlServerRG $sqlResourceGroup -sqlServerName $sqlServerName -Context $subCtx
  }
}

Write-AtlasOutput -Message "Atlas-SQLTemporalTableDeployment complete."
