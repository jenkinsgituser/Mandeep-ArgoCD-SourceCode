param
(
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "Atlas SQL Database" {

    BeforeAll {
        .("$env:COMMON_FOLDER\utilities.ps1")
        . ("$env:ATLAS_REPO_ROOT/Infra/AzureSQL/src/sqlServerVariables.ps1")
        #define expected results for assertions
        $SQL_AZURE_TYPE = "Microsoft.Sql/servers/databases"
        $EXPECTED_DB_COUNT = 1
        $EXPECTED_LOCATION = $location
        $EXPECTED_TEMPLATE_VERSION_NUMBER = Get-AtlasVersionNumber

        #get the SQL Server DB resource result from the resource group
        $SQL_Infer_Resource = [string]::Empty
        Write-Host $rgResources
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }
        $SQL_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $SQL_AZURE_TYPE } | Where-Object { $_.name -notlike '*master*' })
        $sqlDbJson = $SQL_Infer_Resource

        $SQL_DB_FULL_NAME = $($SQL_Infer_Resource).name
        $bothNames = $SQL_DB_FULL_NAME.split("/")
        $SQL_SERVER_NAME = $bothNames[0]
        $SQL_DB_NAME = $bothNames[1]
        Write-Verbose "SQL DB Name: $SQL_DB_NAME" -Verbose

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        $dbPSObj = Get-AzSqlDatabase -ServerName $SQL_SERVER_NAME -DatabaseName $SQL_DB_NAME -ResourceGroupName $resourceGroup
    }


    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    It "SQL Server DB Inferred from Resource Group" {
        ##PBI said we were missing a count of databases on the server, but it looks like that test is already accounted for (unless we want to update to include master?)
        $($SQL_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_DB_COUNT
        $SQL_Infer_Resource | Should -Not -Be $null
    }

    It "Has Correct Template Version Tags" {
        $sqlDbJson.tags | Should -Not -Be $null
        $sqlDbJson.tags | Should -Not -Be [string]::Empty
        $sqlDbJson.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION_NUMBER
    }

    It "It is in the correct location: $EXPECTED_LOCATION" {
        $SQL_Infer_Resource.location = $EXPECTED_LOCATION
    }

    Context "Fn-RenameDatabase Tests" {
        It "renames the database" {
            # Test has not yet been implemented.
            # Requires an existing resource and cannot easily be mocked.
            # If a means to run from an integrated test pipeline is discovered,
            # executing this capability may impact any tests that follow.
            Set-ItResult -Skipped -Because "unable to call RenameDatabse from this context. Manually verified Dec 2019"
        }
    }

    Context "Fn-RestoreDatabase" {
        It "restores the database" {
            # Test has not yet been implemented.
            # Requires an existing resource and cannot easily be mocked as a backup is not available for an extended period.

            # If a means to run from an integrated test pipeline is discovered,
            # executing this capability may impact any tests that follow.

            # Would need to pull this test out into another location to run against a static resource in a static RG.
            # Doing this would likely also require a tagging convention to built a lock to prevent multiple occurrences of the
            # test from running concurrently.
            Set-ItResult -Skipped -Because "unable to delete and/or restore the db from this context. Manually verified Dec 2019"
        }
    }

    # DB Desired State Tests

    It "Requested Service objective is Basic" {
        $objective = $dbPSObj.RequestedServiceObjectiveName
        $objective | Should -Be "Basic"
    }

    It "Current Service objective is Basic" {
        $objective = $dbPSObj.CurrentServiceObjectiveName
        $objective | Should -Be "Basic"
    }

    It "Transparent Data Encryption is enabled" {
        $tde = Get-AzSqlDatabaseTransparentDataEncryption -ServerName $SQL_SERVER_NAME -ResourceGroupName $resourceGroup -DatabaseName $SQL_DB_NAME
        $tde.State | Should -Be "Enabled"

    }

}
