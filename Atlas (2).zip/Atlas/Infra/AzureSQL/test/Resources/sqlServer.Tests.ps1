
param
(
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "Atlas SQL Server" {

    BeforeAll {
        .("$env:COMMON_FOLDER\utilities.ps1")
        .("$env:COMMON_FOLDER\AutomationAccount\AtlasCommon\Atlas-CommonCode.ps1")
        .("$env:COMMON_FOLDER\AutomationAccount\AtlasCommon\Atlas-CommonSQLCode.ps1")
        #calling variables to get the location
        . ("$env:ATLAS_REPO_ROOT/Infra/AzureSQL/src/sqlServerVariables.ps1")

        $SQL_AZURE_TYPE = "Microsoft.SQL/servers"
        $EXPECTED_SQL_COUNT = 1
        $EXPECTED_LOCATION = $location
        $EXPECTED_TEMPLATE_VERSION_NUMBER = Get-AtlasVersionNumber
        $EXPECTED_AAD_ADMIN = "R-AzureSQL-Admins-NonProd"
        $EXPECTED_MIN_TLS_VERISON = "1.2"

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        #get the SQL Server resource result from the resource group
        $SQL_Infer_Resource = [string]::Empty
        Write-Host $rgResources
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }
        $SQL_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $SQL_AZURE_TYPE })

        #get the sql server object from the resource result
        $SQL_SERVER_NAME = $($SQL_Infer_Resource).name
        $SQL_SERVER_NAME = $SQL_SERVER_NAME.split('/')[0]
        Write-Verbose "SQL Server Name: $SQL_SERVER_NAME" -Verbose

        # Get the SQL Server details
        $serverJson = $(az sql server show -g $resourceGroup -n $SQL_SERVER_NAME) | ConvertFrom-Json
        $serverADJson = $(az sql server ad-admin list --resource-group $resourceGroup --server $SQL_SERVER_NAME) | ConvertFrom-Json

    }


    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }


    It "SQL Server Inferred from Resource Group" {
        $($SQL_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_SQL_COUNT
        $SQL_Infer_Resource | Should -Not -Be $null
    }


    It "Server Admin is named properly" {

        $expectedName = "sa-" + $env:SQL_SERVER_NAME
        $actualName = $serverJson.administratorLogin
        $actualName | Should -Be $expectedName
    }

    It "AdvancedDataSecurity is enabled" {
        $policy = Get-AzSqlServerAdvancedDataSecurityPolicy -ServerName $SQL_SERVER_NAME -ResourceGroupName $resourceGroup
        $policy.IsEnabled | Should -Be "True"
    }

    Context "Email Notification List tests" {
        #$expectedEmails = $env:NOTIFICATION_EMAIL_LIST
        # $acutalEmails = $serverJson.notificationEmailList

        It "Notification list matches the one user submitted" {
            # 05/2020: Yet to discover CommandLet to pull this attribute. Revisit at a future time.
            Set-ItResult -Skipped -Because "Notification list unavailable in powershell"
        }

        It "All emails on the list are valid" {
            # 05/2020: Yet to discover CommandLet to pull this attribute. Revisit at a future time.
            Set-ItResult -Skipped -Because "Notification list unavailable in powershell"
        }
    }

    It "$ipAddressRulesExpected Firewall rules present" {
        $fwRulesActual = Get-AzSqlServerFirewallRule -ResourceGroupName $resourceGroup -ServerName $SQL_SERVER_NAME
        $fwRulesActual
        $ipAddressRulesExpected = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).count

        $fwRulesActual.Count | Should -Be $ipAddressRulesExpected
    }



    It "Has Retrievable Configuration" {
        $serverJson | Should -Not -Be $null
    }

    It "Is in the Correct Location" {
        $serverJson.location | Should -Be $EXPECTED_LOCATION
    }
    It "Min TLS Version is : $EXPECTED_MIN_TLS_VERISON" {
        $serverJson.minimalTlsVersion | Should -Be $EXPECTED_MIN_TLS_VERISON
    }

    It "Is has the correct Azure AD Admin" {
        $serverADJson.login | Should -Be $EXPECTED_AAD_ADMIN
    }

    # verify firewall rules are configured
    It "does not allow 'All Azure Services'" {
        $hasFWissue = $false
        $sqlFwRules = az sql server firewall-rule list --server $SQL_SERVER_NAME --resource-group $resourceGroup | ConvertFrom-Json
        foreach ($sqlFwRule in $sqlFwRules) {
            $sqlFwRule.startIpAddress
            if ($sqlFwRule.startIpAddress -eq "0.0.0.0" -and $sqlFwRule.endIpAddress -eq "0.0.0.0") {
                Write-Verbose "bad fw rule - Allow access to Azure Services is ON" -verbose
                $hasFWissue = $true
            }
        }

        $hasFWissue | Should -Be $false
    }

    It "Has CMFG Standard Addresses Allowed" {
        $rules = az sql server firewall-rule list -g $resourceGroup --server $SQL_SERVER_NAME | ConvertFrom-Json
        $allowedIps = @()
        $IPs = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
        foreach ($IP in $IPs) {
            if ($IP -match "/") {
                $ipRange = Get-SubnetAddressRangeForCIDR -CIDR $IP
                $allowedIps = $allowedIps + $ipRange.firstIp
            } else {
                $allowedIps = $allowedIps + $IP
            }
        }

        $allowedIps | Should -Not -Be $null
        $allowedIps | Should -BeIn $rules.StartIpAddress
    }

    It "Has only CMFG Standard Addresses" {
        $rules = az sql server firewall-rule list -g $resourceGroup --server $SQL_SERVER_NAME | ConvertFrom-Json
        $allowedIps = @()
        $IPs = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
        foreach ($IP in $IPs) {
            if ($IP -match "/") {
                $ipRange = Get-SubnetAddressRangeForCIDR -CIDR $IP
                $allowedIps = $allowedIps + $ipRange.firstIp
            } else {
                $allowedIps = $allowedIps + $IP
            }
        }

        $allowedIps | Should -Not -Be $null
        $rules.StartIpAddress | Should -BeIn $allowedIps
    }



    # "Verify logging and diagnostics are configured"

    # For best results, this test would be run alongside the guardrail itself. For now, we're running the test
    # in its current format simply to acquire data points for how frequently the test succeeds vs. is skipped
    # due to the guardrail not yet running.
    It "Verify diagnostics logging." {

        # gets all databases for server.
        $databases = az sql db list --server $SQL_SERVER_NAME --resource-group $resourceGroup | ConvertFrom-Json
        $hasErrors = $false

        ForEach ($db in $databases) {
            If ($db.name -ne 'master') {
                $policy = Get-AzDiagnosticSetting -ResourceId $db.id
                If ($policy.workspaceId -eq $null -and $policy.EventHubAuthorizationRuleId -eq $null) {
                    $errorMessage = '{0} is missing one or more diagnostic logging policies' -f $db.name
                    Write-Verbose $errorMessage -Verbose
                    $hasErrors = $true
                }
            }
        }

        if ($hasErrors) {
            Set-ItResult -Skipped -Because "This test verifies expected state after a guardrail has run and we can't guarantee the execution of the runbook before this test"
        }
        else {
            $hasErrors | Should -be $false
        }
    }


    It "Verify the Template Version Tags" {
        $serverJson.tags | Should -Not -Be $null
        $serverJson.tags | Should -Not -Be [string]::Empty
        $serverJson.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION_NUMBER
    }

}