param
(
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)



#===============================================================================
# Start Test Block
#===============================================================================
Describe "Atlas SQL Database Managed Setup Permissions" {

    BeforeAll {
            #check the resource group exists is defined
        if (!$resourceGroup) {
            if (!$env:SQL_RESOURCE_GROUP) {
                Throw "Resource group undefined. Please provide a resource group environment variable"
            }
            else {
                $resourceGroup = $env:SQL_RESOURCE_GROUP
            }
        }

        if (!$env:SQL_SERVER_NAME -or !$env:SQL_DATABASE_NAME) {
            Throw "Missing required environment variables!"
        }

        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }

        if ($env:IsLocal -and (Get-Module sqlserver) -eq $null) {
            # need to get this into the container image
            Install-Module sqlserver -Force
            Import-Module sqlserver
        }

        #===============================================================================
        . "$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1"
        . "$env:COMMON_FOLDER/azure-utilities.ps1"
        . "$env:INFRA_FOLDER/AzureSQL/src/sql-utilities.ps1"
        #===============================================================================

        #===============================================================================
        # Complete Setup Activities
        #===============================================================================
        # get a database connection
        $setupVariables = Setup-AtlasSqlTestDBConnection -ResourceGroup $resourceGroup -SqlServerName $env:SQL_SERVER_NAME

        #===============================================================================
        # Setup Script Constants
        #===============================================================================
        $CONST_EXPECTED_MAINT_TABLE_NAMES = @("CommandLog", "CMFGindexMaintenance", "CommandExecute", "IndexOptimize")

        $sqlOpsFolder = "$env:DEPLOY_FOLDER/AzureSQL/operations/"
        $applyPerms = "$sqlOpsFolder/Atlas-ApplySqlPermissions.ps1"

        $jsonPath = "$env:INFRA_FOLDER/AzureSQL/test/Access/"
        $invalidPerms = $jsonPath + "testInvalidPerms.json"
        $invalidUser = $jsonPath + "testInvalidUser.json"
        $invalidRole = $jsonPath + "testInvalidRole.json"
        $validPermissions = $jsonPath + "testValidPermissions.json"

        $testTeam = "R-TeamTitan"
        $FQsqlServer = $env:SQL_SERVER_NAME + '.database.windows.net'

        $SARmAccount = "SA-RM-ITPort-P@cmutual.com"
        $SPRmAccount = "SP-RM-Sandbox-P"
        $SaAtlasAzSqlPermAccount = "SA-AtlasAzSQLPerm-D@cmutual.com"

        #===============================================================================
        # SQL Queries
        #===============================================================================
        $maintQuery = "select count(*)
                    from sys.objects
                    where schema_name(schema_id) = 'sqlMaint'"

        $maintQuery2 = "with sqlMaintObj as (
                        select TABLE_NAME
                        from INFORMATION_SCHEMA.TABLES
                        where TABLE_SCHEMA = 'sqlMaint'
                        union all
                        select ROUTINE_NAME
                        from INFORMATION_SCHEMA.ROUTINES
                        where SPECIFIC_SCHEMA = 'sqlMaint')
                        select *
                        from sqlMaintObj"

        $permsQuery = "SELECT pr.principal_id, pr.name, pe.permission_name
                        FROM sys.database_principals AS pr
                        JOIN sys.database_permissions AS pe
                        ON pe.grantee_principal_id = pr.principal_id;"

        $rolesQuery = "SELECT DP1.name AS DatabaseRoleName,
                        isnull (DP2.name, 'No members') AS DatabaseUserName
                        FROM sys.database_role_members AS DRM
                        RIGHT OUTER JOIN sys.database_principals AS DP1
                        ON DRM.role_principal_id = DP1.principal_id
                        LEFT OUTER JOIN sys.database_principals AS DP2
                        ON DRM.member_principal_id = DP2.principal_id
                        WHERE DP1.type = 'R'
                        ORDER BY DP1.name;"

        $schemaQuery = "select s.name as schema_name,
                        s.schema_id,
                        u.name as schema_owner
                        from sys.schemas s
                        inner join sys.sysusers u
                            on u.uid = s.principal_id
                        order by s.name"

        #===============================================================================
        # Sql Command Parameters
        #===============================================================================
        $maintParams = @{
            'ServerInstance' = $FQsqlServer;
            'Database'       = $env:SQL_DATABASE_NAME;
            'Username'       = $setupVariables.Username;
            'Password'       = $setupVariables.LogonPassword;
            'Query'          = $maintQuery;
        }

        $maintParams2 = @{
            'ServerInstance' = $FQsqlServer;
            'Database'       = $env:SQL_DATABASE_NAME;
            'Username'       = $setupVariables.Username;
            'Password'       = $setupVariables.LogonPassword;
            'Query'          = $maintQuery2;
        }

        $permsParams = @{
            'ServerInstance' = $FQsqlServer;
            'Database'       = $env:SQL_DATABASE_NAME;
            'Username'       = $setupVariables.Username;
            'Password'       = $setupVariables.LogonPassword;
            'Query'          = $permsQuery;
        }

        $rolesParams = @{
            'ServerInstance' = $FQsqlServer;
            'Database'       = $env:SQL_DATABASE_NAME;
            'Username'       = $setupVariables.Username;
            'Password'       = $setupVariables.LogonPassword;
            'Query'          = $rolesQuery;
        }

        $schemaParams = @{
            'ServerInstance' = $FQsqlServer;
            'Database'       = $env:SQL_DATABASE_NAME;
            'Username'       = $setupVariables.Username;
            'Password'       = $setupVariables.LogonPassword;
            'Query'          = $schemaQuery;
        }
        #===============================================================================

        # the tests expect this file to be already run against the database via the pipline, however for local testing it still require execution
        if ($env:IsLocal) {
            $env:SYSTEM_DEFINITIONID = "111" # need to set a value for this so permissions code works
            $env:SYSTEM_TEAMPROJECTID = "222" # need to set a value for this so permissions code works
            .($applyPerms) -sqlServer $env:SQL_SERVER_NAME -sqlDatabase $env:SQL_DATABASE_NAME -sqlPermissionsFile $validPermissions
        }

        #===============================================================================
        # Get the data needed to test
        #===============================================================================
        # execute database queries in try/catch loop, sometimes there is a delay in the firewall rule implementation
        $i = 0
        $success = $false
        $ErrorActionPreference = "Stop"

        #===============================================================================
        # Run multiple queries in one go, and then do assertions after
        #===============================================================================
        while (!$success -and $i -lt $CONST_MAX_ATTEMPTS) {
            try {
                $dbPerms = Invoke-Sqlcmd @permsParams
                $dbRoles = Invoke-Sqlcmd @rolesParams
                $dbMaintResult = Invoke-Sqlcmd @maintParams
                $dbMaintResult2 = Invoke-Sqlcmd @maintParams2
                $success = $true  # if we got here the sql commands worked
            }
            catch {
                Write-Verbose "WARN: Failed to execute SQL attempt $i. ERROR: $($_.Exception.Message)" -Verbose
                if ($i -lt $CONST_MAX_ATTEMPTS - 1) {
                    Write-Verbose "INFO:  Attempting to execute/connect again in $CONST_SLEEP_TIME seconds." -Verbose
                    Start-Sleep -Seconds $CONST_SLEEP_TIME
                }
            }
            $i++
        }

        # create schema for tests
        $deploySchemaFile = "$env:DEPLOY_FOLDER/AzureSQL/operations/Atlas-createSchema.ps1"
        $SchemaToCreate = "test123_atlas"
        . $deploySchemaFile -sqlServer $env:SQL_SERVER_NAME -sqlDatabase $env:SQL_DATABASE_NAME -schemaName $SchemaToCreate
    }

    #============================================================
    # Confirm the existence of expected CMFG Identities and Perms
    #============================================================
    # test - Validate Expected Identities Configured

    It "Has $SARmAccount account added" {
        $saRmAccountResult = $dbPerms | Where-Object { $_.name -eq $SARmAccount }

        $saRmAccountResult | Should -Not -Be $null
        $saRmAccountResult.name | ForEach-Object { $_ | Should -Be $SARmAccount }
        $saRmAccountResult.Count | Should -Be 9

        $accountRole = $dbRoles | Where-Object { $_.DatabaseUserName -eq $SARmAccount }
        $accountRole.DatabaseRoleName | Should -Be "db_ddladmin"
    }

    It "Has $SPRmAccount account added" {
        $spRmAccountResult = $dbPerms | Where-Object { $_.name -eq $SPRmAccount }

        $spRmAccountResult | Should -Not -Be $null
        $spRmAccountResult.name | ForEach-Object { $_ | Should -Be $SPRmAccount }
        $spRmAccountResult.Count | Should -Be 9

        $accountRole = $dbRoles | Where-Object { $_.DatabaseUserName -eq $SPRmAccount }
        $accountRole.DatabaseRoleName | Should -Be "db_ddladmin"
    }

    It "Has $SaAtlasAzSqlPermAccount account added" {
        $saAtlasAcctResult = $dbPerms | Where-Object { $_.name -eq $SaAtlasAzSqlPermAccount }

        $saAtlasAcctResult | Should -Not -Be $null
        $saAtlasAcctResult.name | Should -Be $SaAtlasAzSqlPermAccount

        # validate - Atlas deployments require powershell version 6+
        # Display message in logs if Powershell version 5 detected
        if ($PSVersionTable.PSVersion.Major -lt 6) {
            $saAtlasAcctResult.Count | Should -Be $null
        }
        else {
            $saAtlasAcctResult.Count | Should -Be 1
        }

        $accountRole = $dbRoles | Where-Object { $_.DatabaseUserName -eq $SaAtlasAzSqlPermAccount }
        $accountRole.DatabaseRoleName | Should -Be "db_owner"
    }


    # This test will be skipped until we cutover the DB deployment to perform the check within
    # Get-AtlasNeedToCompleteDatabaseSetup, which allows for a short circuiting of DB setups if
    # the database already matches desired state. This is currently avoided due to the hosted agents
    # running off a network that isn't Atlas trusted.
    # test - Database Setup Task Skips when already setup
    It "Returns False as Expected" -Skip {
        $needToCompleteSetup = Get-AtlasNeedToCompleteDatabaseSetup -ResourceGroup $resourceGroup -SqlServerName $env:SQL_SERVER_NAME -SkipNetworkManipulation $true
        # setup has already been confirmed about so should be false
        $needToCompleteSetup | Should -Be $false
    }


    #===========================================================
    # Confirm the existence of expected CMFG Maintenance Objects
    #===========================================================
    # test - Validate Managed Maintenance Object Existence"
    It "Has Expected Maintenance Object Count" {
        $dbMaintResult | Should -Not -Be $null
        # expect a value of 5 to be returned from this query
        $dbMaintResult[0] | Should -Be 5
    }

    It "Has Expected Maintenance Object Values" {
        $dbMaintResult2.TABLE_NAME | ForEach-Object {
            $_ | Should -BeIn $CONST_EXPECTED_MAINT_TABLE_NAMES
        }
    }


    #=========================================================================
    # Confirm we can create a Schema successfully using Atlas-CreateSchema.ps1
    #=========================================================================
    Context "Schema Tests" {

        It "Schema should be configured" {
            #TODO: connection should still be doable, but may need to ensure it doesn't get closed before this can be run
            $dbSchemaResult = Invoke-Sqlcmd @schemaParams

            $targetSchema = $dbSchemaResult | Where-Object { $_.schema_name -eq $SchemaToCreate }
            $targetSchema | Should -Not -Be $null
            $targetSchema.schema_owner | Should -Be "dbo"
        }
    }

    # test - CreateDBUser Tests
    It "throws an error when attempting to add an invalid user" {
        Write-Verbose "Attempting to apply invalid permissions..." -Verbose
        { .($applyPerms) -sqlServer $env:SQL_SERVER_NAME -sqlDatabase $env:SQL_DATABASE_NAME -sqlPermissionsFile $invalidUser } | Should -Throw
    }

    It "throws an exception when parsing invalid permissions" {
        Write-Verbose "Attempting to apply invalid permissions..." -Verbose
        { .($applyPerms) -sqlServer $env:SQL_SERVER_NAME -sqlDatabase $env:SQL_DATABASE_NAME -sqlPermissionsFile $invalidPerms } | Should -Throw
    }

    It "doesn't create a duplicate if user already exists" {
        $matches = @()
        foreach ($row in $dbPerms) {
            if ($row.name -eq $testTeam) {
                $matches += $row
            }
        }
        #error
        $matches.count | Should -Be 5
    }
    #testSqlPermissions.json includes an entry for a fake user called "r-fake-role-group" No entries should have been added
    It "didn't add invalid users" {
        $invalidPerms = $dbPerms.name | Where-Object { $_ -eq "r-fake-role-group" }
        $invalidPerms.count | Should -Be 0
    }


    It "didn't add invalid perms" {
        $grantedPerms = @()
        foreach ($row in $dbPerms) {
            if ($row.name -contains $testTeam) {
                $grantedPerms += $row
            }
        }
        $badPermsPresent = $false
        foreach ($perm in $grantedPerms.permission_name) {
            if ($perm -eq "drop") {
                $badPermsPresent = $true
            }
        }
        $badPermsPresent | Should -Be $false
    }


    # test - ProvisionDBRoles tests
    It "Valid request is granted" {
        $titanRows = @()
        foreach ($row in $dbRoles) {
            if ($row.DatabaseUserName -eq $testTeam) {
                $titanRows += $row
            }
        }
        $adminPresent = $false
        foreach ($role in $titanRows) {
            if ($role.DatabaseRoleName -eq "db_ddladmin") {
                $adminPresent = $true
            }
        }
        $adminPresent | Should -Be $true
    }
    It "throws an error when attempting to apply permissions for invalid roles" {
        Write-Verbose "Attempting to apply invalid permissions..." -Verbose
        { .($applyPerms) -sqlServer $env:SQL_SERVER_NAME -sqlDatabase $env:SQL_DATABASE_NAME -sqlPermissionsFile $invalidRole } | Should -Throw

    }
    It "invalid request is not granted" {
        $matches = @{ }
        foreach ($row in $dbRoles) {
            if ($row.DatabaseRoleName -eq "db_czar") {
                $matches += $row
            }
        }
        $matches.Count | Should -Be 0
    }

    # test - ProvisionServiceAccountPerms
    It "doesn't grant invalid perms to SA" {
        $fakeUserRow = $null
        foreach ($row in $dbPerms.name) {
            if ($row -eq "sa-fakeuser") {
                $fakeUserRow = $row
            }
        }
        #invalid perms so it shouldn't be in the table
        $fakeUserRow | Should -Be $null
    }

    It "grants valid SA permissions" {
        $matches = @()
        foreach ($row in $dbPerms) {
            if ($row.name -eq "SA-SQLDBT17-T1-D@cmutual.com") {
                $matches += $row
            }
        }
        #5 granted plus CONNECT = 6 perms
        $matches.count | Should -Be 6
    }

    It "Throws on invalid input" {
        { Provision-AtlasServiceAccountPermissions -RequestedGrants @("KAG") -Username "KAG" } | Should -Throw
    }

    Context "Drop user tests" {
        BeforeAll {
            $dropUser = "$env:DEPLOY_FOLDER/AzureSQL/operations/Atlas-dropDatabaseUser.ps1"
            $testTeam = "R-TeamTitan"
            Write-Verbose "removing $($testTeam)'s sql permissions" -Verbose
            .($dropUser) -sqlServer $env:SQL_SERVER_NAME -sqlDatabase $env:SQL_DATABASE_NAME -Identity $testTeam

            # need to re-open the network connection after the above test
            $setupVariables = Setup-AtlasSqlTestDBConnection -ResourceGroup $resourceGroup -SqlServerName $env:SQL_SERVER_NAME

            # the above just rotated the password, so we'll reset that as well
            $permsParams.Password = $setupVariables.LogonPassword
            $permsParams.Username = $setupVariables.Username
            $rolesParams.Password = $setupVariables.LogonPassword
            $rolesParams.Username = $setupVariables.Username

            $i = 0
            $success = $false
            $ErrorActionPreference = "Stop"
            while (!$success -and $i -lt $CONST_MAX_ATTEMPTS) {
                try {
                    $permsAfterRemoved = Invoke-Sqlcmd @permsParams
                    $rolesAfterRemoved = Invoke-Sqlcmd @rolesParams
                    $success = $true  # if we got here the sql commands worked
                }
                catch {
                    Write-Verbose "WARN: Failed to execute SQL attempt $i. ERROR: $($_.Exception.Message)" -Verbose
                    if ($i -lt $CONST_MAX_ATTEMPTS - 1) {
                        Write-Verbose "INFO:  Attempting to execute/connect again in $CONST_SLEEP_TIME seconds." -Verbose
                        Start-Sleep -Seconds $CONST_SLEEP_TIME
                    }
                }
                $i++
            }
        }

        It "Successfully retrieved results - Perms" {
            $permsAfterRemoved | Should -Not -Be $null
        }

        It "Successfully retrieved results - Roles" {
            $rolesAfterRemoved | Should -Not -Be $null
        }

        It "removed the user from the permissions table" {
            $nameMatches = 0
            foreach ($name in $permsAfterRemoved.Name) {
                if ($name -eq $testTeam) { $nameMatches ++ }
            }
            $nameMatches | Should -Be 0
        }
        It "removed the user from the roles table" {
            $roleMatches = 0
            foreach ($name in $rolesAfterRemoved.DatabaseUserName) {
                if ($name -contains $testTeam) { $roleMatches ++ }
            }
            $roleMatches | Should -Be 0
        }
    }

}

AfterAll {
    # cleanup
    Teardown-AtlasSqlTestDBConnection -ResourceGroup $resourceGroup -SqlServerName $env:SQL_SERVER_NAME
}
