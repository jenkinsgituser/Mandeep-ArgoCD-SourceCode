##Testing Assumptions
* Tests will be executed using Pester
* Tests, as currently written, will be executed against a resource group which has a Titan-Atlas SQL environment deployed via a standard pipeline deployment
* Tests will use the resource group "RG-CMFG-EA2-NP1-Atlas-Test-SQL-Infra" (which is locked) as a reference for any AKS components, e.g., subnets

##Testing Requirements
* The runtime environment has the Pester module installed - v4.6.0 is what has been used for testing to date. 
* The executing context has a valid Az CLI session and has authorization to query the resource group supplied

##Improvement Opportunities (In Order of Need and/or Value)
* Implement tests that are stubbed out