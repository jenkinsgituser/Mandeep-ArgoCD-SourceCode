# lines included here will run before any other tests within this folder
. ("$INFRA_FOLDER/AzureSQL/src/sqlServerVariables.ps1")
. ("$INFRA_FOLDER/AzureSQL/src/sqlDbVariables.ps1")
