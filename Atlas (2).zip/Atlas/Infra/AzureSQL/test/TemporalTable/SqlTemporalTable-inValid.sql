
CREATE TABLE Temporal_test_tb_hist
(
    DeptID INT NOT NULL
  , DeptName VARCHAR(50) NOT NULL
  , ManagerID INT NULL
  , ParentDeptID INT NULL
  , SysStartTime DATETIME2 NOT NULL
  , SysEndTime DATETIME2 NOT NULL
)

CREATE TABLE Temporal_test_tb
(
    DeptID INT NOT NULL PRIMARY KEY CLUSTERED
  , DeptName VARCHAR(50) NOT NULL
  , ManagerID INT NULL
  , ParentDeptID INT NULL
  , SysStartTime DATETIME2 GENERATED ALWAYS AS ROW START NOT NULL
  , SysEndTime DATETIME2 GENERATED ALWAYS AS ROW END NOT NULL
  , PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime)
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.Temporal_test_tb_hist));

sp_addrolemember 'role', 'member'

--alter TABLE Temporal_test_tb
--  alter column DeptName varchar(50);

grant xxxx

--ALTER TABLE dbo.Temporal_test_tb SET (SYSTEM_VERSIONING = OFF);
--ALTER TABLE dbo.Temporal_test_tb SET (SYSTEM_VERSIONING = ON);

ALTER TABLE dbo.Temporal_test_tb SET (SYSTEM_VERSIONING = OFF);
drop table Temporal_test_tb_hist;
drop table Temporal_test_tb;
