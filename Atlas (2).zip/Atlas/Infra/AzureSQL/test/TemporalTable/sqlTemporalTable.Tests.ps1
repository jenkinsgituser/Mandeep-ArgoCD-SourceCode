param
(
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "SQL Temporal Table tests" {

    BeforeAll {
        . ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1")

        $validSqlScriptFile = "Infra\AzureSQL\test\TemporalTable\SqlTemporalTable-valid.sql"
        $validSqlScript = Get-Content -Raw -Path $validSqlScriptFile

        $inValidSqlScriptFile = "Infra\AzureSQL\test\TemporalTable\SqlTemporalTable-inValid.sql"
        $inValidSqlScript = Get-Content -Raw -Path $inValidSqlScriptFile

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
    }

    It "Temporal Table valid script" {
        $approvedSqlScript, $sqlInvalidCommand = validate-SqlTemporalTableScript -sqlScript $validSqlScript
        $approvedSqlScript | Should -Be $true
    }

    It "Temporal Table inValid script" {
        $approvedSqlScript, $sqlInvalidCommand = validate-SqlTemporalTableScript -sqlScript $inValidSqlScript
        $approvedSqlScript | Should -Be $false
    }

}
