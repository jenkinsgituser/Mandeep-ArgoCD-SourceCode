param
(
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

#get the database object from the resource result
if (!$env:SQL_SERVER_NAME) {
    throw 'environment variable SQL_SERVER_NAME must be set to execute these tests'
}

Describe "Atlas-SQLServer-Maintenance-NetworkRules Tests" {

    BeforeAll {

        . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1"
        . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1"
        . "$env:INFRA_FOLDER/AzureSQL/src/sqlServerVariables.ps1"

        #get the database object from the resource result
        if (!$env:SQL_SERVER_NAME) {
            throw 'environment variable SQL_SERVER_NAME must be set to execute these tests'
        }

        function Invoke-SqlServerNetworkRulesGuardrail {
            param
            (
                [Parameter (Mandatory = $false)]
                [string] $TargetSubscription = (az account show --query "name" -o tsv),

                [Parameter (Mandatory = $false)]
                [string] $TargetSQLServerRG = $resourceGroup,

                [Parameter (Mandatory = $false)]
                [string] $TargetSQLServerName = $env:SQL_SERVER_NAME
            )

            . "$env:INFRA_FOLDER/AzureSQL/guardrails/runbooks/Atlas-SQLServer-Maintenance-NetworkRules.ps1" `
                -TargetSubscription $TargetSubscription -TargetSQLServerRG $TargetSQLServerRG -TargetSQLServerName $TargetSQLServerName
        }

        function Add-SqlServerIPRule {
            param
            (
                [Parameter (Mandatory = $false)]
                [string] $TargetSQLServerRG = $resourceGroup,

                [Parameter (Mandatory = $false)]
                [string] $TargetSQLServerName = $env:SQL_SERVER_NAME,

                [Parameter (Mandatory = $true)]
                [string] $IpAddress,

                [Parameter (Mandatory = $false)]
                [string] $Name = "testIp-$(New-Guid)"
            )

            az sql server firewall-rule create --start-ip-address $IpAddress --end-ip-address $IpAddress --name $Name -g $TargetSQLServerRG --server $TargetSQLServerName | Out-Null
        }

        function Add-SqlServervNetRule {
            param
            (
                [Parameter (Mandatory = $false)]
                [string] $TargetSQLServerRG = $resourceGroup,

                [Parameter (Mandatory = $false)]
                [string] $TargetSQLServerName = $env:SQL_SERVER_NAME,

                [Parameter (Mandatory = $true)]
                [string] $Subnet,

                [Parameter (Mandatory = $false)]
                [string] $Name = "testVnet-$(New-Guid)"
            )

            az sql server vnet-rule create --name $Name -g $TargetSQLServerRG --server $TargetSQLServerName --subnet $Subnet | Out-Null
        }

    }

    # IP Rules Tests
    It "Removes bad IP address" {
        Write-Verbose "ADD rule 1.1.1.1" -Verbose
        $badIP = "1.1.1.1"
        Add-SqlServerIPRule -ipAddress $badIP
        Write-Verbose "Remove Network Exception tag" -Verbose
        Remove-AtlasExceptionTag -resourceGroup $resourceGroup -resourceName $env:SQL_SERVER_NAME -tagValueToRemove "Network" -resourceType "Microsoft.Sql/servers"
        Write-Verbose "call Invoke-SqlServerNetworkRulesGuardrail" -Verbose
        Invoke-SqlServerNetworkRulesGuardrail
        $rules = az sql server firewall-rule list -g $resourceGroup --server $env:SQL_SERVER_NAME | ConvertFrom-Json
        $rules.StartIpAddress | Should -Not -Contain $badIP
    }

    It "Contains all expected IP addresses" {
        $rules = az sql server firewall-rule list -g $resourceGroup --server $env:SQL_SERVER_NAME | ConvertFrom-Json
        $allowedIps = @()
        $IPs = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
        foreach ($IP in $IPs) {
            if ($IP -match "/") {
                $ipRange = Get-SubnetAddressRangeForCIDR -CIDR $IP
                $allowedIps = $allowedIps + $ipRange.firstIp
            } else {
                $allowedIps = $allowedIps + $IP
            }
        }

        $allowedIps | Should -Not -Be $null
        $allowedIps | Should -BeIn $rules.StartIpAddress
    }

    It "Contains only expected IP addresses" {
        $rules = az sql server firewall-rule list -g $resourceGroup --server $env:SQL_SERVER_NAME | ConvertFrom-Json
        $allowedIps = @()
        $IPs = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "ipAddress" }).value
        foreach ($IP in $IPs) {
            if ($IP -match "/") {
                $ipRange = Get-SubnetAddressRangeForCIDR -CIDR $IP
                $allowedIps = $allowedIps + $ipRange.firstIp
            } else {
                $allowedIps = $allowedIps + $IP
            }
        }

        $allowedIps | Should -Not -Be $null
        $rules.StartIpAddress | Should -BeIn $allowedIps
    }


    # vNet Rules Tests
    It "Allows Atlas vNet" {
        # specify vNet to be allowed and allow it to be overridden with an environment var
        if ($location -eq 'centralus') {
            $subid = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-CUS-NP1-RP-Test/subnets/rp-test-private-subnet"

        }
        else {
            $subid = "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-EA2-NP1-RP-Test/subnets/rp-test-private-subnet"

        }

        $sourceAtlasSubnet = if ($env:TEST_ATLAS_SOURCE_SUBNET) { $env:TEST_ATLAS_SOURCE_SUBNET } else { $subid }
        Add-SqlServervNetRule -Subnet $sourceAtlasSubnet
        Invoke-SqlServerNetworkRulesGuardrail
        $rules = az sql server vnet-rule list -g $resourceGroup --server $env:SQL_SERVER_NAME --query "[].virtualNetworkSubnetId" | ConvertFrom-Json

        # confirm that the added subnet is in the values
        $sourceAtlasSubnet | Should -BeIn $rules
    }

    It "Ensures Only Appropriate vNets exist on Resource" {
        $rules = az sql server vnet-rule list -g $resourceGroup --server $env:SQL_SERVER_NAME | ConvertFrom-Json
        $values = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "subnetResourceId" }).value

        # confirm that any other subnets added to the sql server are also listed in the allowed values
        $Context = Get-AzContext
        $rules.virtualNetworkSubnetId | ForEach-Object {
            Validate-NetworkLocationIsAtlasAllowed -subnetResourceId $_ -context $Context | Should -Be $true
        }
    }

    # the following test cannot be run from a pipeline as the Sandbox RM account doesn't have access to Read any of the
    # subnets on our whitelist, as they are in higher subscriptions (CMFG NonProduction, CMFG Production).
    # skipping for now because of this
    It "Allows Known Non-Atlas vNet" -Skip {
        $sourceGoodSubnet = if ($env:TEST_GOOD_SOURCE_SUBNET) { $env:TEST_GOOD_SOURCE_SUBNET } else { "" }
        # g-serv subnet -- will remain after added
    }

    It "Removes bad vNet" {
        $sourceBadSubnet = if ($env:TEST_BAD_SOURCE_SUBNET) { $env:TEST_BAD_SOURCE_SUBNET } else { "/subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-EA2-Test-Atlas-ResourcePermissions/providers/Microsoft.Network/virtualNetworks/test-nonatlas-eastus2/subnets/default" }
        Add-SqlServervNetRule -Subnet $sourceBadSubnet

        # wrap in try/catch to handle case where the real guardrail runs and removes the rule before this instance does
        try {
            Invoke-SqlServerNetworkRulesGuardrail
        }
        catch {
            Write-Warning $($_.Exception.Message)
        }
        $rules = az sql server vnet-rule list -g $resourceGroup --server $env:SQL_SERVER_NAME | ConvertFrom-Json

        $values = (Get-AtlasAllowedNetworkRules | Where-Object { $_.type -eq "subnetResourceId" }).value
        $values | Should -Not -Be $null

        $sourceBadSubnet | Should -Not -BeIn $values
    }

}