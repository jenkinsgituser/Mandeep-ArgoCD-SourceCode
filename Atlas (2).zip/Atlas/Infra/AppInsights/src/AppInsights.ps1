. ("$INFRA_FOLDER/AppInsights/src/AppInsightsVariables.ps1")

Write-Verbose "Deploying Azure App Insights: $AIS_NAME" -Verbose

$AIS_TEMPLATE_FILE = ("$INFRA_FOLDER/AppInsights/src/AppInsights.json")
Write-Verbose "AIS_TEMPLATE_FILE: $AIS_TEMPLATE_FILE" -Verbose


$DEPLOYMENT_NAME = "deployAppInsights-$(Get-Date -f yyyyMMddHHmmss)"
$Action = {
    az deployment group create `
        -g "$AIS_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$AIS_TEMPLATE_FILE" `
        --parameters "appInsightsName=$AIS_NAME" `
        "location=$AIS_LOCATION" `
        "createdDate=$CREATED_DATE" `
        "TemplateVersion=$TEMPLATE_VERSION"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed App Insights: $AIS_NAME" -Verbose

