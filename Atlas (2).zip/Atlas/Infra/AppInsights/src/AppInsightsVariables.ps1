
#**********************************************************
# App Insights variables
#**********************************************************
if ($env:AIS_NAME) {
    if ($env:AIS_NAME.ToUpper().StartsWith("$CONST_AIS_PREFIX")) {
        $AIS_NAME = "$env:AIS_NAME"
    }
    else {
        Write-Error "ERROR: Please enter a valid value for AIS_NAME.  Must begin with '$CONST_AIS_PREFIX'"
        Exit 1
    }
}
else {
    Write-Error "ERROR: Please enter a value for AIS_NAME"
    Exit 1
}
Write-Verbose "AIS_NAME: $AIS_NAME" -Verbose

$AIS_RG_NAME = $(If ($env:AIS_RG_NAME) { "$env:AIS_RG_NAME" } Else { Write-Error "ERROR: Missing value for 'AIS_RG_NAME'"; Exit 1 })
Write-Verbose "AIS_RG_NAME: $AIS_RG_NAME" -Verbose

$AIS_LOCATION = $(If ($env:AIS_LOCATION) { "$env:AIS_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
$AIS_LOCATION = $AIS_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "AIS_LOCATION: $AIS_LOCATION" -Verbose
