param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "Application Insights Tests" {

    . ("$env:COMMON_FOLDER/constants.ps1")
    BeforeAll{
        #define expected results for assertions
        $AIS_AZURE_TYPE = "Microsoft.Insights/components"
        $AIS_NAME = $env:AIS_NAME
        $EXPECTED_AIS_COUNT = 1
        $EXPECTED_LOCATION = $(If ($env:AIS_LOCATION) { "$env:AIS_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
        $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        
        #get the application gateway resource result from the resource group
        $AIS_Infer_Resource = [string]::Empty
        if ($rgResources -eq $null) {
            $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        }

        $AIS_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $AIS_AZURE_TYPE -and $_.name -eq $AIS_NAME })
    }
    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    It "App Insights Inferred from Resource Group" {
        $($AIS_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_AIS_COUNT
        $AIS_Infer_Resource | Should -Not -Be $null
    }

    It "App Insights in expected location" {
        $AIS_Infer_Resource.location | Should -Be $EXPECTED_LOCATION
    }

    It "Has Necessary Tags" {
        $AIS_Infer_Resource.tags | Should -Not -Be $null
        $AIS_Infer_Resource.tags.AtlasPurpose | Should -Be "Atlas-AppInsights-Generic"
        $AIS_Infer_Resource.tags.createdOn | Should -Not -Be $null
        $AIS_Infer_Resource.tags.TemplateVersion | Should -match "Titan-Atlas"
    }

}