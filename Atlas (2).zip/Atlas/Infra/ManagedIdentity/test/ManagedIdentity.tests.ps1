
param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "Creation of MSI and Tests" {
    BeforeAll {
        #define expected results for assertions
        $MSI_AZURE_TYPE = "Microsoft.ManagedIdentity/userAssignedIdentities"
        $EXPECTED_AIS_COUNT = 1
        $EXPECTED_LOCATION = $(If ($env:IDENTITY_LOCATION) { "$env:IDENTITY_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "eastus2" })
        $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()
        Write-Verbose "EXPECTED_LOCATION: $EXPECTED_LOCATION" -Verbose
        $MSI_Infer_Resource = [string]::Empty
        $MSI_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $MSI_AZURE_TYPE -and $_.name -eq $env:IDENTITY_NAME })
    }

    It "Resource Group variable is set" {
        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose
        $resourceGroup | Should -Not -Be $null
    }

    It "MSI Inferred from Resource Group" {
        $($MSI_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_AIS_COUNT
        $MSI_Infer_Resource | Should -Not -Be $null
    }

    It "MSI has expected location" {
        $MSI_Infer_Resource.location | Should -Be $EXPECTED_LOCATION
    }

    It "Has Necessary Tags" {
        $MSI_Infer_Resource.tags | Should -Not -Be $null
        Write-Verbose "tag: $($MSI_Infer_Resource.tags.AtlasPurpose)" -Verbose
        $MSI_Infer_Resource.tags.AtlasPurpose | Should -Be "Atlas-MSI-Generic"

        Write-Verbose "tag: $($MSI_Infer_Resource.tags.createdOn)" -Verbose
        $MSI_Infer_Resource.tags.createdOn | Should -Not -Be $null

        Write-Verbose "tag: $($MSI_Infer_Resource.tags.TemplateVersion)" -Verbose
        $MSI_Infer_Resource.tags.TemplateVersion | Should -match "Titan-Atlas"
    }

    It "Resource Group Is Tagged" {
        $rg = $(az group show --name $resourceGroup) | ConvertFrom-Json
        $tagFound = $false
        foreach ($tag in $rg.tags.psobject.properties) {
            if ($tag.name -eq "TemplateVersion" ) {
                $tagFound = $true
            }
        }
        $tagFound | Should -Be $true
    }


    It "Has Access Provisioned Correctly" {
        If ($env:IDENTITY_OPERATOR) {
            $OPERATOR_ROLE = "Managed Identity Operator"
            #write the code to lookup SP assignment
            ## $role = $(az role assignment list --role $OPERATOR_ROLE --scope $MSI_Infer_Resource.Id) |ConvertFrom-Json
            $role = $(Get-AzRoleAssignment -Scope $MSI_Infer_Resource.Id | Where-Object { $_.roleDefinitionName -eq $OPERATOR_ROLE })
            $role | Should -Not -Be $null
            $role.DisplayName.Contains($env:IDENTITY_OPERATOR) | Should -Be $true
            $role.ObjectType | Should -Be "ServicePrincipal"
        }
    }

    It "Should not create a duplicate MSI" {
        $tempRG = $env:IDENTITY_RG_NAME
        $env:IDENTITY_RG_NAME = "RG-CMFG-EA2-Test-Atlas-ResourcePermissions"
        # Call create script a second time with the same MSI but with a different RG to throw a message.
        { . "$env:ATLAS_REPO_ROOT/Deploy/ManagedIdentity/deployManagedIdentity.ps1" } | Should -Throw
        $env:IDENTITY_RG_NAME = $tempRG
    }

}

Describe "Deletion Tests" {
    BeforeAll {
        #define expected results for assertions
        $MSI_AZURE_TYPE = "Microsoft.ManagedIdentity/userAssignedIdentities"

        $MSI_Infer_Resource = [string]::Empty
        $MSI_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $MSI_AZURE_TYPE -and $_.name -eq $env:IDENTITY_NAME })
        $identityExists = az identity show --resource-group $resourceGroup --name $MSI_Infer_Resource.name | ConvertFrom-Json
    }

    It "Identity Inferred from Resource Group" {
        $MSI_Infer_Resource.name | Should -Not -Be $null
    }

    It "Managed Identity exists before deletion" {
        $identityExists | Should -Not -Be $null
    }

    It "No longer exists" {
        if ($identityExists) {
            Write-Verbose "Starting Managed Identity delete..." -Verbose
            . ("$env:ATLAS_REPO_ROOT/Deploy/ManagedIdentity/deleteManagedIdentity.ps1")
            Write-Verbose "Managed Identity delete complete." -Verbose
        }
        $exists = az identity show --resource-group $ResourceGroup --name $MSI_Infer_Resource.name | ConvertFrom-Json
        $exists | Should -Be $null
    }
}

