﻿
param (
    [Parameter(Mandatory = $false)]  [string] $ResourceGroupName = $env:IDENTITY_RG_NAME,
    [Parameter(Mandatory = $false)]  [string] $IdentityName = $env:IDENTITY_NAME
)

if (!$env:IDENTITY_RG_NAME -or !$env:IDENTITY_NAME) {
    Write-Error "Ensure the environment variables or parameters have been set."
    Exit 1
}


# setup
###################################################################################################################
# Trim leading & trailing spaces from parameters
$ResourceGroupName = $ResourceGroupName.trim()
$IdentityName = $IdentityName.trim()

# validate MSI exists, delete if present
###################################################################################################################
try {

    $UserAssignedIdentity = az identity show --resource-group $ResourceGroupName --name $IdentityName | ConvertFrom-Json

    if (!$UserAssignedIdentity) {
        # Found nothing so throw error to be caught
        throw

    }
    Write-Verbose "Managed Identity '$($UserAssignedIdentity.Name)' found in subscription '$subscriptionName'" -Verbose
    Write-Verbose "`t Deleting managed service identity... $IdentityName" -Verbose

    az identity delete --resource-group $ResourceGroupName --name $IdentityName

    # we need to verify the MSI is actually deleted before exiting the script (in DevOps).  If we don't wait, the script/task
    # ends with success, but the MSI is not actually deleted.
    $exists = $true
    while ($exists -and $i -lt 100) {
        Write-Verbose "`t Managed service identity still being deleted..." -Verbose
        $exists = az identity show --resource-group $ResourceGroupName --name $IdentityName | ConvertFrom-Json
        $i += 1;
        Start-Sleep -Seconds 5
    }

    Write-Verbose "`t Managed service identity has been deleted!!" -Verbose
}
catch {
    throw "**** MSI not found.  Script ending ****"
}

Write-Verbose "Managed service identity deletion script complete" -verbose
