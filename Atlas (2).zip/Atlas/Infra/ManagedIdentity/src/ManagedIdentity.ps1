<#
.SYNOPSIS
    This script will create a User Assigned Managed Service Identity and
    provision the necessary access if a service principal is also passed.

.DESCRIPTION
    The script will:
    *Create new user assigned managed identity if it doesn't already exist
    *optional:  assign the passed service principal 'managed identity operator' rbac on the new msi via a call to Titan permissions service

.PARAMETER $ResourceGroupName
    the resource group where the MSI should be created

.PARAMETER $IdentityName
    the user assigned managed identity that should be created

.PARAMETER $IdentityOperator
    optional: a service principal name to provision access to MSI

.PARAMETER $IdentityLocation
    optional: the azure location for the MSI
.EXAMPLE
    sample parm values for an app:
        $ResourceGroupName = 'RG-CMFG-EA2-NP1-Commercial-RockTumbler'
        $IdentityName = 'MSI-RockTumbler-mybatch2-d'
        optional:  $IdentityOperator
         = 'SP-AKS-Comm-D'
#>

param (
    [Parameter(Mandatory = $false)]  [string] $ResourceGroupName = $env:IDENTITY_RG_NAME,
    [Parameter(Mandatory = $false)]  [string] $IdentityName = $env:IDENTITY_NAME,
    [Parameter(Mandatory = $false)] [string] $IdentityOperator = $env:IDENTITY_OPERATOR,
    [Parameter(Mandatory = $false)] [string] $IdentityLocation = $env:IDENTITY_LOCATION
)


if (!$env:IDENTITY_RG_NAME -or !$env:IDENTITY_NAME) {
    Write-Error "Ensure the environment variables or parameters have been set."
    Exit 1
}

. $env:COMMON_FOLDER//azure-utilities.ps1

Write-Verbose "utilities loaded" -Verbose

# setup
##################################################################################################################

# Trim leading & trailing spaces from parameters

$RESOURCETYPE = "Microsoft.ManagedIdentity/userAssignedIdentities"
$ResourceGroupName = $ResourceGroupName.trim()

$IdentityName = $IdentityName.trim()
# we should only trim() this if we have a value.  If the value is null the .trim() will fail.
if ($IdentityOperator) {
    $IdentityOperator = $IdentityOperator.trim()
}

Write-Verbose "Variable setup is executing..." -Verbose

$MSI_LOCATION = $(If ($IdentityLocation) { "$IdentityLocation" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
$MSI_LOCATION = $MSI_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "MSI_LOCATION: $MSI_LOCATION" -Verbose

$AtlasPurpose = "Atlas-MSI-Generic"

# check for MSI - create if not exists, tag if does exist
###################################################################################################################

$UserAssignedIdentity = $(az identity list) | ConvertFrom-Json
$UserAssignedIdentity = $UserAssignedIdentity | Where-Object { $_.Name -eq $IdentityName }

# Check if multiple MSIs already exist, if so, end script
If ($UserAssignedIdentity.count -gt 1) {

    Write-Verbose "Managed identity: $IdentityName" -Verbose
    Throw "Exception - Multiple Managed Identities already found, exiting script...."
}

# if UserAssignedIdentity does not exist, then create it
if (!$UserAssignedIdentity) {
    Write-Verbose "Create new user assigned managed identity: $IdentityName" -Verbose
    $tags = @()
    $tagName = "TemplateVersion"
    $tagvalue = $TEMPLATE_VERSION
    $tags += "$($tagName)=$($tagValue)"

    $tagName = "AtlasPurpose"
    $tagValue = $AtlasPurpose
    $tags += "$($tagName)=$($tagValue)"

    $tagName = "createdOn"
    $tagValue = $CREATED_DATE
    $tags += "$($tagName)=$($tagValue)"


    $UserAssignedIdentity = az identity create --resource-group $ResourceGroupName --name $IdentityName --location $MSI_LOCATION --tags $tags | ConvertFrom-Json

    Write-Verbose "User assigned managed identity has been created: $($UserAssignedIdentity.Name)" -Verbose
}
else {
    # If the RG for the found MSI matches the RG passed in, then update the tags
    if ($UserAssignedIdentity.resourceGroup -eq $ResourceGroupName) {
        Write-Verbose "Managed Identity $($UserAssignedIdentity.Name) already exists. No new resource created. Reapplying Atlas tags to existing resource..." -Verbose

        $tagName = "createdOn"
        $tagValue = $CREATED_DATE

        Set-TagOnAtlasResource `
            -resourceGroup $UserAssignedIdentity.resourceGroup `
            -resourceName $IdentityName `
            -resourceType $RESOURCETYPE `
            -tagName  $tagName `
            -tagValue $tagValue

        $tagName = "AtlasPurpose"
        $tagValue = $AtlasPurpose

        Set-TagOnAtlasResource `
            -resourceGroup $UserAssignedIdentity.resourceGroup `
            -resourceName $IdentityName `
            -resourceType $RESOURCETYPE `
            -tagName  $tagName `
            -tagValue $tagValue

        $tagName = "TemplateVersion"
        $tagValue = $TEMPLATE_VERSION

        Set-TagOnAtlasResource `
            -resourceGroup $UserAssignedIdentity.resourceGroup `
            -resourceName $IdentityName `
            -resourceType $RESOURCETYPE `
            -tagName  $tagName `
            -tagValue $tagValue

        #
        #  NOTE -- The User Assigned Identity ARM resource provider currently lower cases the first letter of the tag
        #  when posted. This results in 'TemplateVersion' becoming 'templateVersion' on post...
        #

        Write-Verbose "Atlas tags reapplied to resource." -Verbose
    }
    else {
        # If the RG for the found MSI does not match the RG passed in, write error and exit
        Write-Verbose "Managed identity: $IdentityName already exists in Resource Group: $()" -Verbose
        Throw "Exception - Managed Identity already exists in a diffent resource group, exiting script...."
    }
}

# if parm $IdentityOperato is passed, then call the permissions runbook to provision access to the MSI
###################################################################################################################
if ($IdentityOperator) {
    if ($env:IsLocal) {
        Write-Verbose "We will not set Identity Operator permissions from a local execution. Skipping operator assignment!" -Verbose
    }
    else {
        # we are just building a string which is the fully pathed powershell script with named parms and executing it via Invoke-Expression
        Invoke-Expression "$DEPLOY_FOLDER/ManagedIdentity/operations/addMSIOperator.ps1 -MSIName $IdentityName -Identity $IdentityOperator -Permissions 'Managed Identity Operator'"
    }
}

###################################################################################################################
Write-Verbose "MSI creation script complete" -verbose
