. ("$INFRA_FOLDER/AppServicePlan/src/AppServicePlanVariables.ps1")

Write-Verbose "Deploying Azure App Service Plan: $ASP_NAME" -Verbose

$ASP_TEMPLATE_FILE = ( "$INFRA_FOLDER/AppServicePlan/src/AppServicePlan.json")
Write-Verbose "ASP_TEMPLATE_FILE: $ASP_TEMPLATE_FILE" -Verbose

$DEPLOYMENT_NAME = "deployAppServicePlan-$(Get-Date -f yyyyMMddHHmmss)"

$Action = {
    az deployment group create `
        -g "$ASP_RG_NAME" `
        -n "$DEPLOYMENT_NAME" `
        --template-file "$ASP_TEMPLATE_FILE" `
        --parameters "planName=$ASP_NAME" `
        "planSkuCode=$ASP_SKU_CODE" `
        "numberOfWorkers=$ASP_NUM_INSTANCES" `
        "location=$ASP_LOCATION" `
        "createdDate=$CREATED_DATE" `
        "TemplateVersion=$TEMPLATE_VERSION"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed App Service Plan: $ASP_NAME" -Verbose

