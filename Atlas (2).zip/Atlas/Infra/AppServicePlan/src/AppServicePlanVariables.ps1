#**********************************************************
# App Service ASP variables
#**********************************************************
$ASP_CREATE_NEW = $(If ($env:ASP_CREATE_NEW) { [System.Convert]::ToBoolean($env:ASP_CREATE_NEW) } Else { $true })
Write-Verbose "ASP_CREATE_NEW: $ASP_CREATE_NEW" -Verbose

if ($env:ASP_NAME) {
    if ($env:ASP_NAME.ToUpper().StartsWith("$CONST_ASP_PREFIX")) {
        $ASP_NAME = "$env:ASP_NAME"
    }
    else {
        Write-Error "ERROR: Please enter a valid value for ASP_NAME.  Must begin with '$CONST_ASP_PREFIX'"
        Exit 1
    }
}
else {
    Write-Error "ERROR: Please enter a value for ASP_NAME"
    Exit 1
}


$ASP_RG_NAME = $(If ($env:ASP_RG_NAME) { "$env:ASP_RG_NAME" } Else { Write-Error "ERROR: Missing value for 'ASP_RG_NAME'"; Exit 1 })
Write-Verbose "ASP_RG_NAME: $ASP_RG_NAME" -Verbose

$ASP_LOCATION = $(If ($env:ASP_LOCATION) { "$env:ASP_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
$ASP_LOCATION = $ASP_LOCATION.Replace(" ", "").ToLower()
Write-Verbose "ASP_LOCATION: $ASP_LOCATION" -Verbose

$Valid_SKUs = @("S1", "S2", "S3", "P1V2", "P2V2", "P3V2", "P1V3", "P2V3", "P3V3")
if ($env:ASP_SKU_CODE) {
    if ($Valid_SKUs.contains($env:ASP_SKU_CODE)) {
        $ASP_SKU_CODE = $env:ASP_SKU_CODE
    }
    else {
        $ErrorMessage = "Invalid App Service Plan SKU entered, please use one of the following: $Valid_SKUs"
        throw $ErrorMessage
    }
}
else {
    $ASP_SKU_CODE = $CONST_ASP_SKU_CODE_DEFAULT
}
Write-Verbose "ASP_SKU_CODE: $ASP_SKU_CODE" -Verbose

$ASP_NUM_INSTANCES = $(If ($env:ASP_NUM_INSTANCES) { "$env:ASP_NUM_INSTANCES" } Else { "$CONST_ASP_NUM_INSTANCES_DEFAULT" })
Write-Verbose "ASP_NUM_INSTANCES: $ASP_NUM_INSTANCES" -Verbose