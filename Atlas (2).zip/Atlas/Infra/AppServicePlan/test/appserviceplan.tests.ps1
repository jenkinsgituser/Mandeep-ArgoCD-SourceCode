param
(
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)


Describe "App Service Plan Tests" {

    . ("$env:COMMON_FOLDER/constants.ps1")
    BeforeAll{
        #define expected results for assertions
        $ASP_TYPE = "Microsoft.Web/serverFarms"
        $EXPECTED_ASP_COUNT = $(If ($env:ASP_NUM_INSTANCES) { "$env:ASP_NUM_INSTANCES" } Else { "$CONST_ASP_NUM_INSTANCES_DEFAULT" })
        $EXPECTED_LOCATION = $(If ($env:ASP_LOCATION) { "$env:ASP_LOCATION" } ElseIf ($env:ATLAS_DEFAULT_LOCATION) { "$env:ATLAS_DEFAULT_LOCATION" } Else { "$CONST_LOCATION_DEFAULT" })
        $EXPECTED_LOCATION = $EXPECTED_LOCATION.Replace(" ", "").ToLower()

        Write-Verbose "Tested Resource Group: $resourceGroup" -Verbose

        #get the application gateway resource result from the resource group
        $ASP_Infer_Resource = [string]::Empty

        $ASP_Infer_Resource = $($rgResources | Where-Object { $_.type -eq $ASP_TYPE -and $_.name -eq "$env:ASP_NAME" })
    }
    It "Resource Group variable is set" {
        $resourceGroup | Should -Not -Be $null
    }

    
    if ($rgResources -eq $null) {
        $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
    }


    It "App Service Plan Inferred from Resource Group" {
        $($ASP_Infer_Resource | Measure-Object).Count | Should -Be $EXPECTED_ASP_COUNT
        $ASP_Infer_Resource | Should -Not -Be $null
    }

    It "App Service Plan is in expected location" {
        $ASP_Infer_Resource.location | Should -Be $EXPECTED_LOCATION
    }

    It "Has Necessary Tags" {
        $ASP_Infer_Resource.tags | Should -Not -Be $null
        $ASP_Infer_Resource.tags.AtlasPurpose | Should -Be "Atlas-AppServicePlan-Generic"
        $ASP_Infer_Resource.tags.createdOn | Should -Not -Be $null
        $ASP_Infer_Resource.tags.TemplateVersion | Should -match "Titan-Atlas"
    }

}