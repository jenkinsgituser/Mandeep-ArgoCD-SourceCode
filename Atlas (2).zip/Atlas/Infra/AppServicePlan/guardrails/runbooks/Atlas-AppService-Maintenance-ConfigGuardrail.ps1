<#
    Log Analtyics Results Query
    ##############################################
    AzureDiagnostics
    | where TimeGenerated > now() - 30m
    and ResourceProvider == "MICROSOFT.AUTOMATION"
    and Category == "JobStreams"
    and RunbookName_s == "Atlas-AppService-Maintenance-ConfigGuardrail"
    and (ResultDescription contains "ERROR" or ResultDescription contains "WARN")
    | project ResultDescription
#>

Param
(
    [Parameter (Mandatory = $false)]
    [bool] $RunAsHybridWorker = $false
)

$CONST_ATLAS_TAG_IDENTIFIER = "Titan-Atlas"
$CONST_WEBAPP_EXCEPTION_TAG = "AtlasExceptions"
$CONST_WEBAPP_EXCEPTION_VALUE = "AppServiceConfigException"

#constant values for allowed versions
$CONST_ALLOWED_CURRENT_STACKS = @("dotnetcore", "node")
$CONST_DEFAULT_PHP_VERSION = "5.6"
$CONST_DEFAULT_NET_FRAMEWORK = "v4.0"
$CONST_ALLOWED_NODE_VERSIONS = @("10.6")

# Custom ARM client to pull sectoins unavailble via Az Commands
###############################################################
function Get-AtlasResourceConfiguration {
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $ResourceName,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken,

        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID,

        [Parameter(Mandatory = $false)]
        [bool] $IsFunction = $false
    )

    $VerbosePreference = "SilentlyContinue"

    if ($IsFunction) {
        $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Web/sites/$($ResourceName)?api-version=2018-02-01"
        $headers = @{"Authorization" = "Bearer " + $AccessToken }
        $response = Invoke-WebRequest -uri $uri -Headers $headers -Method 'GET' -UseBasicParsing
    }
    else {
        $uri = "https://management.azure.com/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Web/sites/$ResourceName/config/metadata/list?api-version=2018-02-01"
        $headers = @{"Authorization" = "Bearer " + $AccessToken }
        #don't ask me why Azure wants a POST
        $response = Invoke-WebRequest -uri $uri -Headers $headers -Method 'POST' -UseBasicParsing
    }

    $VerbosePreference = "Continue"
    Return $($response.Content | ConvertFrom-Json)
}

function Get-WebAppSitePackageComplianceResult {
    param
    (
        [Parameter(Mandatory = $true)]
        [String] $DirectoryPath
    )

    $isCompliant = $false
    #find the files we care about
    $configs = Get-ChildItem -Path $DirectoryPath -Include "*.json" -Recurse -ErrorAction SilentlyContinue

    if ($configs) {
        #parse them
        foreach ($config in $configs) {
            #whitelist the configs we want to inspect
            # dotnet core v2.0+ or v3.0+
            if ($config.Name.ToLower() -like "*runtimeconfig.json") {
                Write-AtlasOutput -LogLevel "TRACE" -Message "Identified file '$($config.Name)' as a runtime configuration file. Inspecting..."
                $configContent = $(Get-Content $config -Raw | ConvertFrom-Json)
                if ($configContent.runtimeOptions.framework.version -match '^(2.|3.)' ) {
                    Write-AtlasOutput -LogLevel "TRACE" -Message "Framework version '$($configContent.runtimeOptions.framework.version)' meets compliance requirement."
                    $isCompliant = $true
                }
                else {
                    Write-AtlasOutput -LogLevel "TRACE" -Message "Framework version '$($configContent.runtimeOptions.framework.version)' does not meet compliance requirement."
                }
            }
            #will return false if a whitelisted file isn't found and approved...may need a manual exception tag?????
        }
    }
    else {
        Write-AtlasOutput -LogLevel "TRACE" -Message "No configuration files discovered in '$DirectoryPath'"
    }

    return $isCompliant
}

function Get-FunctionAppSitePackageComplianceResult {
    param
    (
        [Parameter(Mandatory = $true)]
        [String] $DirectoryPath
    )

    $isCompliant = $false
    #find the files we care about
    $configs = Get-ChildItem -Path $DirectoryPath -Include "*.json" -Recurse -ErrorAction SilentlyContinue

    if ($configs) {
        #parse them
        foreach ($config in $configs) {
            #whitelist the configs we want to inspect
            # dotnet core v2.0+ or v3.0+
            if ($config.Name.ToLower() -like "*deps.json") {
                #need to changes this to parse properly given the new file
                Write-AtlasOutput -LogLevel "TRACE" -Message "Identified file '$($config.Name)' as a runtime configuration file. Inspecting..."
                $configContent = $(Get-Content $config -Raw | ConvertFrom-Json)
                $version = $($configContent.runtimeTarget.name).Split('=')[1]
                $stack = $($configContent.runtimeTarget.name).Split(',')[0]
                if (($version -match '^(v2.|v3.)') -and ($stack -eq ".NETCoreApp")) {
                    Write-AtlasOutput -LogLevel "TRACE" -Message "Framework $($stack) version '$($version)' meets compliance requirement."
                    $isCompliant = $true
                }
                else {
                    Write-AtlasOutput -LogLevel "TRACE" -Message "Framework $($stack) version '$($version)' does not meet compliance requirement."
                }
            }
            #will return false if a whitelisted file isn't found and approved...may need a manual exception tag?????
        }
    }
    else {
        Write-AtlasOutput -LogLevel "TRACE" -Message "No configuration files discovered in '$DirectoryPath'"
    }

    return $isCompliant
}


function Get-KuduComplianceResults {
    param
    (
        [Parameter(Mandatory = $true)]
        [PsObject] $AppService,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken,

        [Parameter(Mandatory = $true)]
        [string] $kind
    )

    $CONST_SITE_ROOT_ENDPOINT = "api/vfs/site/wwwroot/"
    $CONST_LOCAL_DIR = ".\$($AppService.name)"
    $hostName = $AppService.EnabledHostNames | Where-Object { $_ -match ".scm." }
    $isCompliant = $false

    try {
        $VerbosePreference = "SilentlyContinue"

        $deployedFiles = Invoke-RestMethod -Uri "https://$($hostName)/$($CONST_SITE_ROOT_ENDPOINT)" `
            -Headers @{"Authorization" = "Bearer " + $AccessToken } `
            -Method 'GET' `
            -UseBasicParsing

        $filesToDownLoad = New-Object System.Collections.ArrayList
        $deployedFiles | ForEach-Object { $filesToDownLoad.Add($_) | Out-Null }

        if (!(Test-Path $CONST_LOCAL_DIR)) { New-Item $CONST_LOCAL_DIR -ItemType Directory | Out-Null }

        $i = 0
        #recursive download all the deployed files for processing
        while ($i -lt $filesToDownLoad.Count) {
            $file = $filesToDownload[$i]
            $destFileName = "$($CONST_LOCAL_DIR)\$($file.name)"

            $j = 0
            while (Test-Path $destFileName) {
                $destFileName += "_$j"
                $j += 1
            }

            if ($file.mime -eq "inode/directory") {
                #dowload the files and append them to the list of what to process
                $childFiles = (Invoke-RestMethod -Uri $file.href `
                        -Headers @{"Authorization" = "Bearer " + $AccessToken } `
                        -Method 'GET' `
                        -UseBasicParsing)
                $childFiles | ForEach-Object { $filesToDownLoad.Add($_) | Out-Null }
            }
            elseif ($file.name -match ".json") {
                Invoke-RestMethod -Uri $file.href `
                    -Headers @{"Authorization" = "Bearer " + $AccessToken; "If-Match" = "*" } `
                    -Method 'GET' `
                    -OutFile $destFileName `
                    -ContentType "multipart/form-data" `
                    -UseBasicParsing
            }
            #do nothing with dlls, etc.
            $i += 1
        }
        $VerbosePreference = "Continue"

        $downloadedFileCount = $(Get-ChildItem -Path $CONST_LOCAL_DIR).Count
        if ((($downloadedFileCount -gt 1) -and ($kind -eq "functionapp")) -or (($kind -ne "functionapp") -and ($downloadedFileCount -gt 0))) {
            if ($kind -eq "functionapp") {
                $isCompliant = Get-FunctionAppSitePackageComplianceResult -DirectoryPath $CONST_LOCAL_DIR
            }
            else {
                $isCompliant = Get-WebAppSitePackageComplianceResult -DirectoryPath $CONST_LOCAL_DIR
            }
            Write-AtlasOutput -LogLevel "INFO" -Message "$($AppService.name): Kudu compliance results: $isCompliant"
        }
        else {
            Write-AtlasOutput -LogLevel "WARN" -Message "$($AppService.name): Kudu compliance check skipped as no app deployment found."
            $isCompliant = $true
        }
    }
    catch {
        Write-AtlasOutput -LogLevel "ERROR" -Message $_.Exception.Message
    }
    finally {
        #cleanup
        Remove-Item $CONST_LOCAL_DIR -Force -Recurse
        $VerbosePreference = "Continue"
    }

    return $isCompliant
}

# validate storage account network acl's
#################################################################
function Confirm-IsValidAtlasAppService {
    param
    (
        [Parameter(Mandatory = $true)]
        [PsObject] $AppService,

        [Parameter(Mandatory = $true)]
        [PsObject] $Context,

        [Parameter(Mandatory = $true)]
        [string] $AccessToken,

        [Parameter(Mandatory = $true)]
        [string] $SubscriptionID,

        [Parameter(Mandatory = $true)]
        [string] $kind
    )

    # validate that any IP rules associated with the Web App are Atlas associated
    # AGWAFs and not just any ingress
    $isValid = $true
    $isNodeRuntime = $false

    #doing the initial retrieval as we do doesn't seem to populate SiteConfig. Doing it with an
    #explicitly named WApp solves the issue
    $webAppConfig = (Get-AzWebApp -Name $AppService.Name).SiteConfig
    $ErrorMessage = [string]::Empty

    #checks that each of the following configuration settings is null as expected
    if (![string]::IsNullOrEmpty($webAppConfig.javaContainer) -or `
            ![string]::IsNullOrEmpty($webAppConfig.javaContainerVersion) -or `
            ![string]::IsNullOrEmpty($webAppConfig.javaVersion)) {

        $isValid = $false
        $ErrorMessage = "$($AppService.name): Identified disallowed runtime configuration setting on resource -- Java Settings"
    }

    if (![string]::IsNullOrEmpty($webAppConfig.linuxFxVersion)) {

        $isValid = $false
        if ($ErrorMessage) {
            $ErrorMessage += ",LinuxFxVersion"
        }
        else {
            $ErrorMessage = "$($AppService.name): Identified disallowed runtime configuration setting on resource -- LinuxFxVersion"
        }
    }

    if ($false -ne $webAppConfig.localMySqlEnabled) {
        $isValid = $false
        if ($ErrorMessage) {
            $ErrorMessage += ",localMySqlEnabled"
        }
        else {
            $ErrorMessage = "$($AppService.name): Identified disallowed runtime configuration setting on resource -- localMySqlEnabled"
        }
    }

    if ($false -ne $webAppConfig.pythonVersion) {
        $isValid = $false
        if ($ErrorMessage) {
            $ErrorMessage += ",pythonVersion"
        }
        else {
            $ErrorMessage = "$($AppService.name): Identified disallowed runtime configuration setting on resource -- PythonVersion"
        }
    }

    # allows only Empty or expected versions
    # 10.6 is the only version expected to be supported up front
    if (![string]::IsNullOrEmpty($webAppConfig.nodeVersion)) {
        if ($webAppConfig.nodeVersion -in $CONST_ALLOWED_NODE_VERSIONS) {
            $isNodeRuntime = $true
        }
        else {
            if ($ErrorMessage) {
                $ErrorMessage += ",nodeVersion"
            }
            else {
                $ErrorMessage = "$($AppService.name): Identified disallowed runtime configuration setting on resource -- nodeVersion"
            }
        }
    }

    #######################################################################################
    # WARN don't ERROR for these
    # WARN will be logged but won't flag an immediate follow up. Expectation is to capture these types of issues in
    # weekly or monthly report review
    $WarnMessage = [string]::Empty

    # 5.6 is the default deployed currently (06/2019)
    if ($webAppConfig.phpVersion -ne $CONST_DEFAULT_PHP_VERSION) {
        $WarnMessage = "$($AppService.name): Identified disallowed runtime configuration setting on resource -- phpVersion"
    }

    # 4.0 is the default deployed currently (06/2019)
    if ($webAppConfig.netFrameworkVersion -ne $CONST_DEFAULT_NET_FRAMEWORK) {
        if ($WarnMessage) {
            $WarnMessage += ",netFrameworkVersion"
        }
        else {
            $WarnMessage = "$($AppService.name): Identified disallowed runtime configuration setting on resource  -- netFrameworkVersion"
        }
    }

    if ($WarnMessage) {
        Write-AtlasOutput -LogLevel "WARN" -Message $WarnMessage
    }
    #######################################################################################

    $webAppMetaDataConfig = Get-AtlasResourceConfiguration -ResourceGroup $AppService.ResourceGroup `
        -ResourceName $AppService.Name `
        -AccessToken $AccessToken `
        -SubscriptionID $SubscriptionID

    if ( $kind -ne "functionapp" -and ([string]::IsNullOrEmpty($webAppMetaDataConfig.properties.CURRENT_STACK) -or `
                $webAppMetaDataConfig.properties.CURRENT_STACK.ToLower() -notin $CONST_ALLOWED_CURRENT_STACKS)) {
        $isValid = $false
        Write-AtlasOutput -LogLevel "ERROR" -Message "$($AppService.name): Identified configured CURRENT_STACK on resource is not in allowed list $CONST_ALLOWED_CURRENT_STACKS. Value '$($webAppMetaDataConfig.properties.CURRENT_STACK)'"
    }
    else {
        if (!$isNodeRuntime) {
            #if all checks to-date have passed, do a download of the sitepackages and validate
            $isValid = Get-KuduComplianceResults -AppService $AppService -AccessToken $AccessToken -kind $kind
            #Write-Verbose "Type1: $($isValid.GetType()) Value: $($isValid)" -Verbose
            if (!$isValid) {
                Write-AtlasOutput -LogLevel "ERROR" -Message "$($AppService.name): KuduComplainceResult: False. Could not validate that App Service is running an allowed version of the runtime '$($webAppMetaDataConfig.properties.CURRENT_STACK)'"
            }
        }
        else {
            Write-AtlasOutput -LogLevel "WARN" -Message "$($AppService.name): Skipping Kudu compliance validation as App Service runtime has set a Node Version which is in allowed runtimes list."
        }
    }

    if ((!$isValid) -and ($ErrorMessage)) {
        Write-AtlasOutput -LogLevel "ERROR" -Message $ErrorMessage
    }

    return ($isValid)
}

# Function to identify the Atlas Web Apps from ALL Web Apps
#################################################################
function Get-AllAtlasAppServices {
    param
    (
        [Parameter(Mandatory = $true)]
        [PsObject] $Context
    )
    return Get-AzWebApp -DefaultProfile $Context | Where-Object { ($_.tags.TemplateVersion -match $CONST_ATLAS_TAG_IDENTIFIER) -or ($_.tag.templateVersion -match $CONST_ATLAS_TAG_IDENTIFIER) }
}

#Main
#################################################################

$VerbosePreference = "SilentlyContinue"
try {
    # do the import in the silenced block
    Import-Module Az.Resources | Out-Null
    Import-Module Az.Automation | Out-Null
    #https://docs.microsoft.com/en-us/azure/automation/automation-runbook-execution#working-with-multiple-subscriptions
    Disable-AzContextAutosave -Scope Process | Out-Null

}
catch {
    Write-Warning "Error importing required modules. $($_.Exception.Message)"
}
$VerbosePreference = "Continue"

#############################################################################################
# Source Atlas-CommmonCode runbook must reside in the same as your runbook
#############################################################################################
Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. ./Atlas-CommonCode.ps1
Write-AtlasOutput -Message " "

Azure-Connect
$runbookDetail = Get-RunbookCurrentContext
#Setup rules needed by all processing
#######################################################

# get access token here once, instead of in the functions
$azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile;
$profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile);

#process each subscription
$subscriptions = $(Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object Name | Select-Object Name).Name
#$subscriptions = $(Get-AzSubscription -SubscriptionName "CMFG-Sandbox").Name

$wAppstatus = [string]::Empty
foreach ($subscription in $subscriptions) {
    # Removed - Jon
    #$subscriptionID = $(Get-AzContext).Subscription.Id
    Write-AtlasOutput -Message "Processing subscription: $subscription..." -LogLevel "INFO"

    $VerbosePreference = "SilentlyContinue"
    #see link at top of script for context ;)
    $context = Set-AzContext -Subscription $subscription
    $AccessToken = $profileClient.AcquireAccessToken($context.Subscription.TenantId).AccessToken
    $AtlasWApps = Get-AllAtlasAppServices -Context $context
    $VerbosePreference = "Continue"

    foreach ($AtlasWApp in $AtlasWApps) {
        #if the webapp is tagged appropriately, log it and skip additional validation
        if ($AtlasWApp.Tags.$CONST_WEBAPP_EXCEPTION_TAG -match $CONST_WEBAPP_EXCEPTION_VALUE) {
            $isValid = $true
            Write-AtlasOutput -LogLevel "WARN" -Message "$($AtlasWApp.Name): Validation skipped due to resource being tagged as exception. Tag Name: '$($CONST_WEBAPP_EXCEPTION_TAG)', Tag Value: '$($CONST_WEBAPP_EXCEPTION_VALUE)'"
        }
        else {
            $webAppFunctionConfig = $null
            try {
                $webAppFunctionConfig = Get-AtlasResourceConfiguration -ResourceGroup $AtlasWApp.ResourceGroup `
                    -ResourceName $AtlasWApp.Name `
                    -AccessToken $AccessToken `
                    -SubscriptionID $context.Subscription.Id `
                    -IsFunction $true
            }
            catch [System.Net.WebException] {
                if ($_.Exception.Response.StatusCode.value__ -eq "404") {
                    Write-AtlasOutput -Message "$($AtlasWApp.Name): Function endpoint returned 404" -LogLevel "INFO"
                }
                else {
                    Write-AtlasOutput -LogLevel "ERROR" -Message $($_.Exception.Message)
                }
            }
            catch {
                Write-AtlasOutput -LogLevel "ERROR" -Message $($_.Exception.Message)
            }

            $isValid = Confirm-IsValidAtlasAppService -AppService $AtlasWApp `
                -Context $context `
                -AccessToken $AccessToken `
                -SubscriptionID $context.Subscription.Id `
                -kind $webAppFunctionConfig.kind

        }

        if (!$isValid) {
            $wAppstatus += "WARN: $($AtlasWApp.Name) failed Web App validation. Please investigate ID: '$($AtlasWApp.Id)' `n"
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "$($AtlasWApp.Name) successfully validated!"
        }
        Write-AtlasOutput -Message " $($AtlasWApp.Name): Done processing resource." -LogLevel "DEBUG"
    }
    Write-AtlasOutput -Message "$subscription processed." -LogLevel "INFO"
}

if (![string]::IsNullOrEmpty($wAppstatus)) {
    $emailFrom = "$($runbookDetail.RunbookName)@cunamutual.com"
    $emailSubject = "Atlas App Service Runtime Configuration Validation Report"

    $emailBody = "This is a list of invalid Atlas Web App deployments `r `r"
    $emailBody += $wAppstatus
    $emailBody += "`r `r `r Executed from $($runbookDetail.AutomationAccountName), Runbook is $($runbookDetail.RunbookName)."
    $EmailbodyData = $emailBody | Out-String
    try {
        Send-TeamTitanEmailAlert -emailFrom $emailFrom -emailSubject $emailSubject -EmailbodyData $EmailbodyData -ErrorAction stop
    }
    catch {
        $errorMessage = "ERROR: Failed to send email."
        throw $errorMessage
    }
    Write-AtlasOutput -Message "Invalid resources:`n$wAppstatus" -LogLevel "ERROR"
}
else {
    Write-AtlasOutput -Message "No web apps failed validation. `n" -LogLevel "DEBUG"
}

Write-AtlasOutput -Message "Job complete." -LogLevel "DEBUG"
