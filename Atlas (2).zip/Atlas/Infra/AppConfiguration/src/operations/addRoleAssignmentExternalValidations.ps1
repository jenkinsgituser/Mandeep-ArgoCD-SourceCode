#**********************************************************
# Managed Identity validation
#**********************************************************
if ($IDENTITY_NAME) {
    $requestedIdentity = az identity show -n $IDENTITY_NAME -g $IDENTITY_RG_NAME 2> $null
    if (!$requestedIdentity) {
        Write-Error "The requested Managed Identity '$IDENTITY_NAME' in resource group '$IDENTITY_RG_NAME' cannot be found.
        Please ensure this exists and the deploying account has permissions to read and modify this resource."
        Exit 10
    } # else -- TODO: we could deploy an identity on their behalf?
}