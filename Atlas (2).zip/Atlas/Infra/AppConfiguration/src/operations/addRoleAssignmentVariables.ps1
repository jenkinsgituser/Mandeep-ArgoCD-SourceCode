Write-Verbose "Setting App Configuration [Add Role Assignment] deployment variables." -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_NAME)) {
    Write-Error "Missing required variable APP_CONFIG_NAME"
    Exit 1
}
Write-Verbose "APP_CONFIG_NAME: $APP_CONFIG_NAME" -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_RG_NAME)) {
    Write-Error "Missing required variable APP_CONFIG_RG_NAME"
    Exit 1
}
Write-Verbose "APP_CONFIG_RG_NAME: $APP_CONFIG_RG_NAME" -Verbose

if ([string]::IsNullOrEmpty($IDENTITY_NAME)) {
    Write-Error "Missing required variable IDENTITY_NAME"
    Exit 1
}
Write-Verbose "IDENTITY: $IDENTITY_NAME" -Verbose

if ([string]::IsNullOrEmpty($IDENTITY_RG_NAME)) {
    Write-Error "Missing required variable IDENTITY_RG_NAME"
    Exit 1
}
Write-Verbose "IDENTITY_RG_NAME: $IDENTITY_RG_NAME" -Verbose