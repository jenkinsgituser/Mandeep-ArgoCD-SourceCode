#**********************************************************
# File Format Validation
#**********************************************************
if ($CONFIG_FILE_FORMAT) {
    $format = $CONFIG_FILE_FORMAT.ToLower()
    if ($format -ne "json" -and $format -ne "yaml") {
        Write-Error "The requested file format was not recognized. Please use 'json', 'yaml'."
        Exit 10
    }
}

#**********************************************************
# File Separator Validation
#**********************************************************
if ($CONFIG_FILE_SEPARATOR) {
    $separator = $CONFIG_FILE_SEPARATOR
    if (($separator -ne ".") -and ($separator -ne ",") -and ($separator -ne ";") -and ($separator -ne "-") -and ($separator -ne "_") -and ($separator -ne "__") -and ($separator -ne "/") -and ($separator -ne ":")) {
        Write-Error "The requested file separator is not supported. Supported values: '.', ',', ';', '-', '_', '__', '/', ':'."
        Exit 10
    }
}