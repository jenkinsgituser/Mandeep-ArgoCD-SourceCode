Write-Verbose "Setting App Configuration [Import] deployment variables." -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_NAME)) {
    Write-Error "Missing required variable APP_CONFIG_NAME"
    Exit 1
}
Write-Verbose "APP_CONFIG_NAME: $APP_CONFIG_NAME" -Verbose

if ([string]::IsNullOrEmpty($CONFIG_FILE_PATH)) {
    Write-Error "Missing required variable CONFIG_FILE_PATH"
    Exit 1
}
Write-Verbose "CONFIG_FILE_PATH: $CONFIG_FILE_PATH" -Verbose

if ([string]::IsNullOrEmpty($CONFIG_FILE_FORMAT)) {
    $CONFIG_FILE_FORMAT = "json"
}
Write-Verbose "CONFIG_FILE_FORMAT: $CONFIG_FILE_FORMAT" -Verbose

if ([string]::IsNullOrEmpty($CONFIG_FILE_SEPARATOR)) {
    $CONFIG_FILE_SEPARATOR = ":"
}
Write-Verbose "CONFIG_FILE_SEPARATOR: $CONFIG_FILE_SEPARATOR" -Verbose
