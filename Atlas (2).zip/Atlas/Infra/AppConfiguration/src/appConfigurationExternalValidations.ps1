#**********************************************************
# Managed Identity validation
#**********************************************************
if ($APP_CONFIG_IDENTITY) {
    if ($APP_CONFIG_IDENTITY -ne "[system]") {
        $requestedIdentity = az identity show -n $APP_CONFIG_IDENTITY -g $APP_CONFIG_IDENTITY_RG_NAME 2> $null
        if (!$requestedIdentity) {
            Write-Error "The requested Managed Identity '$APP_CONFIG_IDENTITY' in resource group '$APP_CONFIG_IDENTITY_RG_NAME' cannot be found.
            Please ensure this exists and the deploying account has permissions to read and modify this resource."
            Exit 10
        } # else -- TODO: we could deploy an identity on their behalf?
    }
}