Write-Verbose "Setting App Configuration [Create] deployment variables." -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_NAME)) {
    Write-Error "Missing required variable APP_CONFIG_NAME"
    Exit 1
}
Write-Verbose "APP_CONFIG_NAME: $APP_CONFIG_NAME" -Verbose

if (!($APP_CONFIG_NAME.ToLower().StartsWith($CONST_APP_CONFIG_PREFIX))) {
    $APP_CONFIG_NAME = $CONST_APP_CONFIG_PREFIX + $APP_CONFIG_NAME
}
$APP_CONFIG_NAME = ($APP_CONFIG_NAME).ToLower()
Write-Verbose "APP_CONFIG_NAME (cleaned): $APP_CONFIG_NAME" -Verbose

# Set the App Configuration location if the user doesn't provide the location
if ([string]::IsNullOrEmpty($APP_CONFIG_LOCATION)) {
    if ($env:ATLAS_DEFAULT_LOCATION) {
        $APP_CONFIG_LOCATION = $env:ATLAS_DEFAULT_LOCATION
    }
    else {
        $APP_CONFIG_LOCATION = $CONST_LOCATION_DEFAULT
    }
}
$APP_CONFIG_LOCATION = $APP_CONFIG_LOCATION.Replace(" ", "").ToLower()

Write-Verbose "APP_CONFIG_LOCATION: $APP_CONFIG_LOCATION" -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_RG_NAME)) {
    Write-Error "Missing required variable APP_CONFIG_RG_NAME"
    Exit 1
}
Write-Verbose "APP_CONFIG_RG_NAME: $APP_CONFIG_RG_NAME" -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_SKU)) {
    $APP_CONFIG_SKU = "standard"
}
Write-Verbose "APP_CONFIG_SKU: $APP_CONFIG_SKU" -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_IDENTITY)) {
    $APP_CONFIG_IDENTITY = [string]::Empty
}
Write-Verbose "APP_CONFIG_IDENTITY: $APP_CONFIG_IDENTITY" -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_IDENTITY_RG_NAME)) {
    $APP_CONFIG_IDENTITY_RG_NAME = [string]::Empty
}
Write-Verbose "APP_CONFIG_IDENTITY_RG_NAME: $APP_CONFIG_IDENTITY_RG_NAME" -Verbose

