param (
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "App Configuration [Import] Deployment Tests" {
    BeforeAll {
        $importedConfigs = az appconfig kv list --name $env:APP_CONFIG_NAME --all | ConvertFrom-Json
    }

    It "Imports a JSON file correctly" {
        $jsonConfigFound = $false
        foreach ($config in $importedConfigs) {
            if ($config -match "json") {
                $jsonConfigFound = $true
            }
        }
        $jsonConfigFound | Should -Be $true
    }

    It "Imports a YAML file correctly" {
        $yamlConfigFound = $false
        foreach ($config in $importedConfigs) {
            if ($config -match "yaml") {
                $yamlConfigFound = $true
            }
        }
        $yamlConfigFound | Should -Be $true
    }
}