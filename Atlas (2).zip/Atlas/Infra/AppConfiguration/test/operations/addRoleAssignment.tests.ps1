param (
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "App Configuration [Add Role Assignment] Deployment Tests" {
    BeforeAll {
        $EXPECTED_RESOURCE_TYPE = "Microsoft.AppConfiguration/configurationStores"
        $EXPECTED_ROLE = "App Configuration Data Reader"
    }

    It "Adds the Role Assignment correctly" {
        $resources = az resource list --resource-group $resourceGroup | ConvertFrom-Json
        $appConfigResource = $resources | Where-Object { $_.type -eq $EXPECTED_RESOURCE_TYPE -and $_.name -eq $env:APP_CONFIG_NAME }
        $roles = az role assignment list --scope $appConfigResource.id | ConvertFrom-Json

        $identityId = az identity show --name $env:IDENTITY_NAME --resource-group $env:IDENTITY_RG_NAME --query principalId -o tsv

        # handles cases where you end up with multiple roles returned
        $targetRole = $roles | Where-Object { $_.principalId -eq $identityId }
        $targetRole | Should -Not -Be $null
        $targetRole.roleDefinitionName | Should -Contain $EXPECTED_ROLE
    }
}