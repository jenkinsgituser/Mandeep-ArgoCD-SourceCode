param (
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "App Configuration [Create] Deployment Tests" {
    BeforeAll {
        $APP_CONFIG_NAME = $env:APP_CONFIG_NAME
        $APP_CONFIG_LOCATION = $env:APP_CONFIG_LOCATION
        $APP_CONFIG_RG_NAME = $env:APP_CONFIG_RG_NAME
        $APP_CONFIG_SKU = $env:APP_CONFIG_SKU
        $APP_CONFIG_IDENTITY = $env:APP_CONFIG_IDENTITY
        $APP_CONFIG_IDENTITY_RG_NAME = $env:APP_CONFIG_IDENTITY_RG_NAME

        . "$env:COMMON_FOLDER/utilities.ps1"
        . "$env:COMMON_FOLDER/constants.ps1"
        . "$env:INFRA_FOLDER/AppConfiguration/src/appConfigurationVariables.ps1" 4> $null

        $EXPECTED_RESOURCE_TYPE = "Microsoft.AppConfiguration/configurationStores"
        $EXPECTED_TEMPLATE_VERSION = Get-AtlasVersionNumber

        $rgResources = $(az resource list -g $resourceGroup) | ConvertFrom-Json
        $appConfigResource = $rgResources | Where-Object { $_.type -eq $EXPECTED_RESOURCE_TYPE -and $_.name -eq $APP_CONFIG_NAME }
    }

    It "Sets name correct" {
        $appConfigResource.name | Should -BeLike $APP_CONFIG_NAME
    }
    It "Sets location correctly" {
        $appConfigResource.location | Should -Be $APP_CONFIG_LOCATION
    }
    It "Sets SKU correctly" {
        $appConfigResource.sku.name | Should -Be $APP_CONFIG_SKU
    }
    if ($APP_CONFIG_IDENTITY) {
        It "Sets the Managed Identity correctly" {
            $appConfigResource.identity | Should -Be $APP_CONFIG_IDENTITY
        }
    }
    It "Sets the Template Tag correctly" {
        $appConfigResource.tags.TemplateVersion | Should -Not -Be $null
        $appConfigResource.tags.TemplateVersion | Should -Not -Be "Unknown"
        $appConfigResource.tags.TemplateVersion | Should -Not -Be "Titan-Atlas"
        # Validate that the expected value was set into the RG tags
        $appConfigResource.tags.TemplateVersion | Should -Be $EXPECTED_TEMPLATE_VERSION
    }
}

