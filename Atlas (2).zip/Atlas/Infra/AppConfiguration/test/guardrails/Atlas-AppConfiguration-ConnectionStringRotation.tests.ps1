param(
    [Parameter(Mandatory = $true)]
    [string] $resourceGroup,

    [Parameter(Mandatory = $false)]
    [array] $rgResources = $null
)

Describe "App Configuration Connection String Rotation Unit Tests" -Tag 'Unit' {
    BeforeAll {
        # set to true to ensure the below runbook doesn't run fully, allowing us to source the functions
        $env:IsTest = $true
        . "$env:INFRA_FOLDER/AppConfiguration/test/_includes.tests.ps1" 4> $null
        . "$env:INFRA_FOLDER/AppConfiguration/guardrails/runbooks/Atlas-AppConfiguration-ConnectionStringRotation.ps1" 4> $null
        #Install and import the Az.AppConfiguration module if it's not available
        $module = Get-Module -name Az.AppConfiguration
        if (!$module) {
#TODO:  Below 'RequiredVersion' flags should be removed after we update the AtlasHostedAgents past whatever version the AZ powershell is currently.
            Install-Module -name Az.AppConfiguration -RequiredVersion 1.1.0 -Scope CurrentUser -Force 2> $null
            Import-Module Az.AppConfiguration -RequiredVersion 1.1.0 2> $null
        }
        $VerbosePreference = 'silentlycontinue'
        $context = Get-AzContext
        $outPut1 = Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup "InvalidRG" -AppConfigName $env:APP_CONFIG_NAME -context $context -ErrorAction SilentlyContinue
        $outPut2 = Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup $ResourceGroup -AppConfigName "InvalidAppConfig" -context $context -ErrorAction SilentlyContinue
        $outPut3 = Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup $ResourceGroup -AppConfigName $env:APP_CONFIG_NAME -context $context -ErrorAction SilentlyContinue
    }
    Context "Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies" {
        It "Resource Group name is not valid " {
            $outPut1 | Where-Object { $_.Status -eq "Failed" } | Should -Not -Be $null
        }
        It "Mandatory Resource Group name is not specified" {
            { Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup -AppConfigName $env:APP_CONFIG_NAME -context $context -ErrorAction SilentlyContinue } | Should -Throw
        }
        It "Resource Group name is null" {
            { Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup $null -AppConfigName $env:APP_CONFIG_NAME -context $context -ErrorAction SilentlyContinue } | Should -Throw
        }
        It "App Configuration Name is not valid " {
           $outPut2 | Where-Object { $_.Status -eq "Failed" } | Should -Not -Be $null
        }
        It "Mandatory App Configuration Name is not specified" {
            { Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup $ResourceGroup -AppConfigName -context $context -ErrorAction SilentlyContinue } | Should -Throw
        }
        It "App Configuration Name is null" {
            { Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup $ResourceGroup -AppConfigName $null -context $context -ErrorAction SilentlyContinue } | Should -Throw
        }
        It "Both Resource Group name and App Configuration Name are valid" {
            $outPut3 | Where-Object { $_.Status -eq "Success" } | Should -Not -Be $null
        }
    }
}

Describe "App Configuration Connection String Rotation Integration tests" -Tag 'Integration' {
}

Describe "App Configuration Connection String Rotation Acceptance Tests" -Tag 'Acceptance' {
    BeforeAll {
        #Get original connection strings for the Atlas app configuration
        $originalKeysAtlas = az appconfig credential list --name $env:APP_CONFIG_NAME --resource-group $resourceGroup | ConvertFrom-Json

        $nonAtlasAppConfig = "AppConfigNonAtlas"
        az appconfig create --location "eastus2" --name $nonAtlasAppConfig --resource-group 'RG-CMFG-NP2-Atlas-Infrastructure-Build-Testing-AppConfig' --sku "standard"

        #Get original connection strings for the non Atlas app configuration.
        $originalKeysNonAtlas = az appconfig credential list --name $nonAtlasAppConfig --resource-group $resourceGroup | ConvertFrom-Json

        # setup IsTest to run the Gurailrail for acceptance testing
        $env:IsTest = $false

        . "$env:INFRA_FOLDER/AppConfiguration/guardrails/runbooks/Atlas-AppConfiguration-ConnectionStringRotation.ps1" 4> $null
    }

    It "Fetched Initial Values for Atlas App Configuration" {
        $originalKeysAtlas | Where-Object { $_.name -eq "Primary" } | Should -Not -Be $null
        $originalKeysAtlas | Where-Object { $_.name -eq "Secondary" } | Should -Not -Be $null
        $originalKeysAtlas | Where-Object { $_.name -eq "Primary Read Only" } | Should -Not -Be $null
        $originalKeysAtlas | Where-Object { $_.name -eq "Secondary Read Only" } | Should -Not -Be $null
    }

    It "Fetched Initial Values for Non Atlas App Configuration" {
        $originalKeysNonAtlas | Where-Object { $_.name -eq "Primary" } | Should -Not -Be $null
        $originalKeysNonAtlas | Where-Object { $_.name -eq "Secondary" } | Should -Not -Be $null
        $originalKeysNonAtlas | Where-Object { $_.name -eq "Primary Read Only" } | Should -Not -Be $null
        $originalKeysNonAtlas | Where-Object { $_.name -eq "Secondary Read Only" } | Should -Not -Be $null
    }

    Context "Atlas App Configruation Connection String Rotation Validation" {
        It "Rotated All Keys for Atlas App Configuration" {
            $updatedKeys = az appconfig credential list --name $env:APP_CONFIG_NAME --resource-group $resourceGroup | ConvertFrom-Json

            $updatedPrimaryKeyValue = $updatedKeys | Where-Object { $_.name -eq "Primary" } | Select-Object -Property value
            $updatedSecondaryKeyValue = $updatedKeys | Where-Object { $_.name -eq "Secondary" } | Select-Object -Property value
            $updatedPrimaryReadOnlyKeyValue = $updatedKeys | Where-Object { $_.name -eq "Primary Read Only" } | Select-Object -Property value
            $updatedSecondaryReadOnlyKeyValue = $updatedKeys | Where-Object { $_.name -eq "Secondary Read Only" } | Select-Object -Property value

            $originalPrimaryKeyValue = $originalKeysAtlas | Where-Object { $_.name -eq "Primary" } | Select-Object -Property value
            $originalSecondaryKeyValue = $originalKeysAtlas | Where-Object { $_.name -eq "Secondary" } | Select-Object -Property value
            $originalPrimaryReadOnlyKeyValue = $originalKeysAtlas | Where-Object { $_.name -eq "Primary Read Only" } | Select-Object -Property value
            $originalSecondaryReadOnlyKeyValue = $originalKeysAtlas | Where-Object { $_.name -eq "Secondary Read Only" } | Select-Object -Property value

            $updatedPrimaryKeyValue.value | Should -Not -Be $originalPrimaryKeyValue.value
            $updatedSecondaryKeyValue.value | Should -Not -Be $originalSecondaryKeyValue.value
            $updatedPrimaryReadOnlyKeyValue.value | Should -Not -Be $originalPrimaryReadOnlyKeyValue.value
            $updatedSecondaryReadOnlyKeyValue.value | Should -Not -Be $originalSecondaryReadOnlyKeyValue.value
        }
    }
    Context "Non Atlas App configraution Connection String Rotation Validation" {
        It "All Keys are remaining same for Non Atlas App Configuration" {
            $updatedKeys = az appconfig credential list --name $nonAtlasAppConfig --resource-group $resourceGroup | ConvertFrom-Json

            $updatedPrimaryKeyValue = $updatedKeys | Where-Object { $_.name -eq "Primary" } | Select-Object -Property value
            $updatedSecondaryKeyValue = $updatedKeys | Where-Object { $_.name -eq "Secondary" } | Select-Object -Property value
            $updatedPrimaryReadOnlyKeyValue = $updatedKeys | Where-Object { $_.name -eq "Primary Read Only" } | Select-Object -Property value
            $updatedSecondaryReadOnlyKeyValue = $updatedKeys | Where-Object { $_.name -eq "Secondary Read Only" } | Select-Object -Property value

            $originalPrimaryKeyValueNonAtlas = $originalKeysNonAtlas | Where-Object { $_.name -eq "Primary" } | Select-Object -Property value
            $originalSecondaryKeyValueNonAtlas = $originalKeysNonAtlas | Where-Object { $_.name -eq "Secondary" } | Select-Object -Property value
            $originalPrimaryReadOnlyKeyValueNonAtlas = $originalKeysNonAtlas | Where-Object { $_.name -eq "Primary Read Only" } | Select-Object -Property value
            $originalSecondaryReadOnlyKeyValueNonAtlas = $originalKeysNonAtlas | Where-Object { $_.name -eq "Secondary Read Only" } | Select-Object -Property value

            $updatedPrimaryKeyValue.value | Should -Be $originalPrimaryKeyValueNonAtlas.value
            $updatedSecondaryKeyValue.value | Should -Be $originalSecondaryKeyValueNonAtlas.value
            $updatedPrimaryReadOnlyKeyValue.value | Should -Be $originalPrimaryReadOnlyKeyValueNonAtlas.value
            $updatedSecondaryReadOnlyKeyValue.value | Should -Be $originalSecondaryReadOnlyKeyValueNonAtlas.value
        }
    }
    AfterAll {
        # Delete the non atlas app configuration
        az appconfig delete -g $resourceGroup -n $nonAtlasAppConfig --yes
    }
}