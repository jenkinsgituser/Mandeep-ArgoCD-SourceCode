#################################################################################################
# RunBook Name: Atlas-AppConfiguration-ConnectionString-Rotation
# Author:       Nicole He (Modified the code based on original code wrote by Pablojohn )
# Version: v1.0
# The purpose of this script is to force rotate the connection strings for App configuration:
#  1) Look for all Atlas App Configuration for all subscriptions.
#  2) Regenerate the connection strings for App Configuration. The connection strings include:
#     Connection string for Read-write primary key
#     Connection string for Read-write Secondary key
#     Connection String for Read-Only primary key
#     Connection String for Read-Only Secondary key
#  3) The runbook is scheduled for 12 hour intervals
#  4) The runbook was hardcoded to run in the cmfg-sandbox if the script running in local or nonProd AA.
#     You can comment the line #94 if you are ready to run all non productions in NonProd AA.
#  5) Warning message will be displayed in the log if not able to rotate the connection string successfully
#     for any app configuration. For example: resource not exist,resource locked etc.
#  6) An email will be sent to Team Titan with a list of App Configurations which did not
#     regenerate the connection strings successfully.
#################################################################################################
function New-AppConfigRotationStatusObj {
    New-Object PSObject -Property @{
        AppConfigName                        = $null
        KeyName                              = $null
        Exception                            = $null
        Status                               = $null
    }
}

function New-KeyRotationStatusObj {
    New-Object PSObject -Property @{
        Status                               = $null
        Exception                            = $null
    }
}

function Add-AppConfigRotationStatus {
param(
        [Parameter(Mandatory = $true)]
        [string] $AppConfigName,

        [Parameter(Mandatory = $true)]
        [string] $KeyName,

        [Parameter(Mandatory = $true)]
        [psobject] $Status,

        [Parameter(Mandatory = $true)]
        [psobject] $Exception

    )

    $AppConfigRotationStatusObj = New-AppConfigRotationStatusObj
    $AppConfigRotationStatusObj.AppConfigName = $AppConfigName
    $AppConfigRotationStatusObj.KeyName = $KeyName
    $AppConfigRotationStatusObj.Status = $Status
    $AppconfigRotationStatusObj.Exception = $Exception
    $AppConfigRotationStatusObjColl.Add($AppConfigRotationErrObj) | Out-Null

}


function Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies {
    param(
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroup,

        [Parameter(Mandatory = $true)]
        [string] $AppConfigName,

        [Parameter(Mandatory = $true)]
        [psobject] $context

    )

    $AppConfigRotationStatusObjColl = New-Object System.Collections.ArrayList

    try {
        $keys = Get-AzAppConfigurationStoreKey -name $AppConfigName -resourcegroup $ResourceGroup -DefaultProfile $context -ErrorAction stop
    }
    catch {
        Write-AtlasOutput -logLevel "WARN" -Message "Unable to get the access key for the App Configuration named $($AppConfigName)"
        Write-AtlasOutput -logLevel "WARN" -Message "$($_.Exception.Message)"

        $AppConfigRotationStatusObj = New-AppConfigRotationStatusObj
        $AppConfigRotationStatusObj.AppConfigName = $AppConfigName
        $AppConfigRotationStatusObj.KeyName = $null
        $AppConfigRotationStatusObj.Status = "Failed"
        $AppconfigRotationStatusObj.Exception = $($_.Exception.Message)
        $AppConfigRotationStatusObjColl.Add($AppConfigRotationStatusObj) | Out-Null
    }

    if (![string]::IsNullOrEmpty($keys)) {
        foreach ($key in $keys) {
            Write-AtlasOutput -LogLevel "INFO" -Message  "Attempting to rotate $($key.name)"
            try {
                $rotationResult = Rotate-Key -AppConfigName $AppConfigName -ResourceGroupName $ResourceGroup -KeyID $key.id -DefaultProfile $context
                Write-AtlasOutput -LogLevel "INFO" -Message "Result from Rotate-Key function is $($rotationResult.Status)"
                if ($rotationResult.Status -eq "Success") {
                    Write-AtlasOutput -LogLevel "INFO" -Message  "Rotated $($key.name) for the app configuration named $($AppConfigName)"
                    $AppConfigRotationStatusObj = New-AppConfigRotationStatusObj
                    $AppConfigRotationStatusObj.AppConfigName = $AppConfigName
                    $AppConfigRotationStatusObj.KeyName = $key.name
                    $AppConfigRotationStatusObj.Status = $rotationResult.Status
                    $AppconfigRotationStatusObj.Exception = $null
                    $AppConfigRotationStatusObjColl.Add($AppConfigRotationStatusObj) | Out-Null
                }else {
                    Write-AtlasOutput -LogLevel "WARN" -Message "Unable to regenerate access key with id of $($key.id) for the app configuration named $($AppConfigName) "
                    Write-AtlasOutput -LogLevel "WARN" -Message "Exception returned from Rotate-Key function was: $($rotationResult.Exception)"
                    $AppConfigRotationStatusObj = New-AppConfigRotationStatusObj
                    $AppConfigRotationStatusObj.AppConfigName = $AppConfigName
                    $AppConfigRotationStatusObj.KeyName = $key.name
                    $AppConfigRotationStatusObj.Status = $rotationResult.Status
                    $AppConfigRotationStatusObj.Exception = $rotationResult.Exception
                    $AppConfigRotationStatusObjColl.Add($AppConfigRotationStatusObj) | Out-Null
                }

            }
            catch {
                Write-AtlasOutput -LogLevel "WARN" -Message "Unable to regenerate access key with id of $($key.id) for the app configuration named $($AppConfigName) "
                Write-AtlasOutput -LogLevel "WARN" -Message "$($_.Exception.Message)"
                $AppConfigRotationStatusObj = New-AppConfigRotationStatusObj
                $AppConfigRotationStatusObj.AppConfigName = $AppConfigName
                $AppConfigRotationStatusObj.KeyName = $key.name
                $AppConfigRotationStatusObj.Status = "Failed"
                $AppConfigRotationStatusObj.Exception = $_.Exception.Message
                $AppConfigRotationStatusObjColl.Add($AppConfigRotationStatusObj) | Out-Null
            }
        }

        return $AppConfigRotationStatusObjColl
    }
    else {
        return $AppConfigRotationStatusObjColl

    }
}

function Rotate-Key {
    param (
        [Parameter(Mandatory = $true)]
        [psobject] $AppConfigName,
        [Parameter(Mandatory = $true)]
        [psobject] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [psobject] $KeyID,
        [Parameter(Mandatory = $true)]
        [psobject] $DefaultProfile
    )

    $currentAttempts = 1
    $CONST_MAX_ATTEMPTS = 3
    $CONST_SLEEP_TIME = 10
    $result = "Failed"

    $KeyRotationStatusObj = New-KeyRotationStatusObj

    while ($currentAttempts -le $CONST_MAX_ATTEMPTS -and $result -ne $true){
         try{
             Write-Verbose "Attempt $currentAttempts to rotate key with KeyID $KeyID" -Verbose
             $output = New-AzAppConfigurationStoreKey -Name $AppConfigName -ResourceGroupName $ResourceGroupName -id $KeyID -DefaultProfile $DefaultProfile -ErrorAction stop
             $result = "Success"
            break

           } catch {
                Write-Verbose "Failed attempt $currentAttempts to rotate key with KeyID $KeyID" -Verbose
                $lastException = $($_.Exception.Message)
                Start-Sleep -Seconds $CONST_SLEEP_TIME
                $currentAttempts ++
           }
     }

    $KeyRotationStatusObj.Status = $result
    $KeyRotationStatusObj.Exception = $lastException
    return $KeyRotationStatusObj

}

function Get-AllAtlasAppConfigurations {
    param(
        [Parameter(Mandatory = $true)]
        [psobject] $context
    )
    return Get-AzResource -ResourceType "Microsoft.AppConfiguration/configurationStores" -DefaultProfile $context | Where-Object { $_.tags.TemplateVersion -match $CONST_ATLAS_RG_TAG_IDENTIFIER }
}


#################################################################
#Main
#################################################################
# wrap in an InTest variable check to enable unit testing of functions in this script
If ($env:IsTest -ne $true) {
    $VerbosePreference = "SilentlyContinue"
    try {
        # Do the import in the silenced block
        Import-Module Az.Resources | Out-Null
        Import-Module Az.Automation | Out-Null
        Import-Module Az.Accounts | Out-Null
        Import-Module Az.AppConfiguration | Out-Null
    }
    catch {
        Write-Warning "Error importing required modules: $($_.Exception.Message)"
    }
    $VerbosePreference = "Continue"
    Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
    if ($env:IsLocal -or $env:AGENT_ID) {
        Write-Verbose -Verbose "Running in a local or build context!"
        . $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1
    }
    else {
        # Sourcing on the AA is slightly different than sourcing locally
        . ./Atlas-CommonCode.ps1
        Azure-Connect
        $runbookDetail = Get-RunbookCurrentContext
    }

    Write-AtlasOutput -LogLevel "INFO" -Message "Start Time: $(Get-Date)"

    # Process each subscription for App Config activities
    $subscriptions = $(Get-AzSubscription).Name | Sort-Object

    # Set for sandbox subscription when running the script locally
    if ($env:IsLocal -or $env:AGENT_ID) {
        $subscriptions = "CMFG-SANDBOX"
    }
    elseif ($runbookDetail.AutomationAccountName -eq "AA-CMFG-D01-InfraMgmt-AZ") {
        # For testing purposes, we set the testing scope to CMFG-Sandbox. Comment this line out if we are ready to run for non production subscriptons.
        $subscriptions = "CMFG-SANDBOX"
    }
    foreach ($sub in $subscriptions) {
        $quotes = '"'
        Write-AtlasOutput -LogLevel "INFO" -Message "Processing subscription $sub..."
        $context = Set-AzContext -Subscription $sub
        # Get all Atlas App Configurations
        $AtlasAppConfigs = Get-AllAtlasAppConfigurations -context $context
        foreach ($AtlasAppConfig in $AtlasAppConfigs) {
            Write-AtlasOutput -LogLevel "INFO" -Message "Processing App Configuration - $($AtlasAppConfig.Name) in $($AtlasAppConfig.ResourceGroupName)."
            # Rotate the connection strings for App Configuration
            $rotateAppConfigResults = Invoke-AtlasAppConfiguration-EnforceConnectionStringPolicies -ResourceGroup $AtlasAppConfig.ResourceGroupName -AppConfigName $AtlasAppConfig.Name -context $context

            foreach($rotateResult in $rotateAppConfigResults) {
                if($rotateResult.Status -ne "Success") {
                    $rotateStatus += "WARN: Failed connection string rotation for key $quotes$($rotateResult.KeyName)$quotes in App Configuration $quotes$($rotateResult.AppConfigName)$quotes in resource group $quotes$($AtlasAppConfig.ResourceGroupName)$quotes. `n"
                }
            }
            Write-AtlasOutput -LogLevel "INFO" -Message "$($AtlasAppConfig.Name) processed."
        }
        Write-AtlasOutput -LogLevel "INFO" -Message "Subscription $sub processed."
    }
    if (![string]::IsNullOrEmpty($rotateStatus)) {
        if (!($env:IsLocal -or $env:AGENT_ID)) {
            $emailFrom = "$($runbookDetail.RunbookName)@cunamutual.com"
            $emailSubject = "Atlas App Configuration Connection String Rotation Issue Report"
            $emailBody = "This is a list of Atlas App Configurations which failed the connection string rotation `r `r"
            $emailBody += $rotateStatus
            $emailBody += "`r `r `r Executed from $($runbookDetail.AutomationAccountName), Runbook is $($runbookDetail.RunbookName)."
            $EmailbodyData = $emailBody | Out-String
            try {
                Send-TeamTitanEmailAlert -emailFrom $emailFrom -emailSubject $emailSubject -EmailbodyData $EmailbodyData -ErrorAction stop
            }
            catch {
                $errorMessage = "ERROR: Failed to send email."
                throw $errorMessage
            }
        }
        else {
            Write-AtlasOutput -LogLevel "INFO" -Message "Below are the App Configurations which failed connection string rotation:`n$rotateStatus"
        }
    }
    else {
        Write-AtlasOutput -LogLevel "INFO" -Message "No App Configurations failed connection string rotation. `n"
    }
    Write-AtlasOutput -LogLevel "INFO" -Message "End Time: $(Get-Date)"

    Write-AtlasOutput -LogLevel "INFO" -Message "Job complete."

}
