param(
  [Parameter(Mandatory = $false)]
  [bool] $FORCE_NONATLAS_DEPLOY = $false
)

$ErrorActionPreference = "Stop"
Write-Verbose "Requested By: $env:RELEASE_REQUESTEDFOREMAIL"

##############################################################################################
#Runtime setup
##############################################################################################
######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

Write-Verbose "azure-utilities.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/azure-utilities.ps1")

#Write-Verbose "servicebus-utilities.ps1 is executing" -Verbose
#. ("$COMMON_FOLDER/ServiceBus-utilities.ps1")


##############################################################################################
#Resource deployment & Permissions setup
##############################################################################################

try {
  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }
  ######################################################################################

  Write-Verbose "ServiceBusVariables.ps1 is executing" -Verbose
  . ("$INFRA_FOLDER/ServiceBus/src/ServiceBusVariables.ps1")

  #validate is RG is Atlas
  Validate-DeploymentRGIsAtlas -resourceGroup $BUS_RG_NAME -forceFlag $FORCE_NONATLAS_DEPLOY

  #confirm namespace availability
  $result = $(az servicebus namespace exists --name $BUS_NAMESPACE) | ConvertFrom-Json
  if ($result.nameAvailable -eq $false) {
    Write-Warning "Desired namespace is unavailable: $($result.message)" -ErrorAction Stop
    Write-Warning "This deployment will overwrite an existing namespace but will not deploy a new one."
  }

  #Namespace deployment
  ##############################################################################################
  Write-Verbose "Deploying Service Bus Namespace..." -Verbose

  #$BUS_TEMPLATE_FILE = "$PSScriptRoot/Namespace/azuredeployServiceBusNamespace.json"
  $BUS_TEMPLATE_FILE = "$INFRA_FOLDER/ServiceBus/src/Namespace/azuredeployServiceBusNamespace.json"

  #note that the namespace needs to be unique
  #https://docs.microsoft.com/en-us/azure/service-bus-messaging/service-bus-create-namespace-portal
  $Action = {
    az deployment group create `
      -g "$BUS_RG_NAME" `
      -n "$DEPLOYMENT_NAME" `
      --template-file "$BUS_TEMPLATE_FILE" `
      --parameters "createdDate=$CREATED_DATE" `
      "defaultSASKeyName=RootManageSharedAccessKey" `
      "location=$BUS_LOCATION" `
      "networkRules=$NETWORKRULES" `
      "serviceBusNamespaceName=$BUS_NAMESPACE" `
      "TemplateVersion=$TEMPLATE_VERSION"
  }

  # wrap the above in a functional delegate for improved resiliency
  Retry-FunctionalDelegate -Action $Action

  Write-Verbose "Successfully Deployed Service Bus: $BUS_NAMESPACE" -Verbose

  #Large file transfer SA deploy
  ##############################################################################################
  if ($SUPPORT_LARGE_FILE_TRANSFER) {
    . ("$DEPLOY_FOLDER/ServiceBus/operations/modify/azureAddLargeFileTransferSupport.ps1") -resourceGroup $($BUS_RG_NAME)
  }

  # telemetry completion
  ######################################################################################
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "deployServiceBusNamespace-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
  Write-Error "ERROR: $ERROR_MESSAGE" -ErrorAction Stop
}

Write-Verbose "Service Bus deployment complete." -Verbose