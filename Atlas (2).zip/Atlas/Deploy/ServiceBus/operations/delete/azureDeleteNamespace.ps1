param
(
  [Alias("resourceGroupName")]
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup = $env:BUS_RG_NAME,

  [Alias("namespace")]
  [Parameter(Mandatory = $false)]
  [string] $namespaceName = $env:BUS_NAMESPACE
)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

Write-AtlasSanitizeInputs

Write-Verbose "Executing delete of namespace $namespaceName in resource group $resourceGroup..." -Verbose

az servicebus namespace delete --resource-group $resourceGroup --name $namespaceName

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureDeleteNamespace-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Execution complete. See output above for any error messages from az cli command." -Verbose