param
(
    [Alias("resourceGroupName")]
    [Parameter(Mandatory = $true, Position = 0)]
    [string] $resourceGroup = $env:BUS_RG_NAME,

    [Alias("namespace")]
    [Parameter(Mandatory = $true, Position = 1)]
    [string] $namespaceName = $env:BUS_NAMESPACE,

    [Parameter(Mandatory = $true, Position = 2)]
    [string] $vNetName,

    [Parameter(Mandatory = $true, Position = 3)]
    [string] $subnetName

)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    ######################################################################################

    #source the utilities.ps1 file
    #Write-Verbose "servicebus-utilities.ps1 is executing" -Verbose
    #. ("$COMMON_FOLDER/ServiceBus-utilities.ps1")

    Write-Verbose "AtlasArmRestClient.ps1 is executing" -Verbose
    . ("$COMMON_FOLDER/api/AtlasArmRestClient.ps1")

    Write-AtlasSanitizeInputs


    Write-Verbose "Discovering target Service Bus resource..." -Verbose
    $servicebusNamespace = $(az servicebus namespace list --resource-group $ResourceGroup --query "[].name" -o tsv)
    $storageAccount = $(az storage account list --resource-group $ResourceGroup --query "[].name" -o tsv)
    Write-Verbose "Discovered target Service Bus resource." -Verbose

    Write-Verbose "Removing Subnet $subnetName as allowed..." -Verbose

    #writing this as a foreach-object as the role of this could expand over time and the goal of today isn't to enforce a single ESB
    #however, there is an EXPECTATION that only a single ESB should be in place -- enforcement occurs elsewhere
    $servicebusNamespace | ForEach-Object {
        #add the rule on the servicebus side
        Remove-AtlasServiceBus-SubNetRule -ResourceGroup $ResourceGroup -Namespace $servicebusNamespace -vNetName $vNetName -subnetName $subnetName
        Write-Verbose "Subnet $subnetUri removed from allowed ACL on $servicebusNamespace..." -Verbose
    }

    #writing this as a foreach-object as the role of this could expand over time and the goal of today isn't to enforce a single SA
    #however, there is an EXPECTATION that only a single SA should be in place -- enforcement occurs elsewhere
    $storageAccount | ForEach-Object {
        $currentSubNets = $(az storage account network-rule list --account-name $storageAccount --resource-group $ResourceGroup --query "virtualNetworkRules[*].virtualNetworkResourceId" -o tsv)

        $subnetUriToRemove = Get-AtlasRemovedSubnetByInputMatch -virtualNetworkRules $currentSubNets `
            -vNetName $vNetName `
            -subnetName $subnetName
        #add the rule on the storage account side
        az storage account network-rule remove --account-name $storageAccount --resource-group $ResourceGroup --subnet $subnetUriToRemove --query "networkRuleSet"
        Write-Verbose "Subnet $subnetUriToRemove removed from allowed ACL on $storageAccount..." -Verbose
    }


    Write-Verbose "Network rule removed successfully!" -Verbose
}
catch {
    Write-Verbose "An error occurred while processing your network firewall modifications." -Verbose
    Write-Error $_.Exception.Message -ErrorAction Stop
}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureDeleteNetworkRuleSubnet-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes