param
(
    [Alias("resourceGroupName")]
    [Parameter(Mandatory = $false)]
    [string] $resourceGroup = $env:BUS_RG_NAME,

    [Alias("namespace")]
    [Parameter(Mandatory = $false)]
    [string] $namespaceName = $env:BUS_NAMESPACE,

    [Parameter(Mandatory = $true)]
    [string] $queueName
)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

#Basic input validation
###############################################################################################
Write-AtlasSanitizeInputs

if ($null -eq $resourceGroup ) {
    Write-Error "Resource group not correctly passed in to script." -ErrorAction Stop
}
elseif ($null -eq $namespaceName) {
    Write-Error "Namespace name not correctly passed in to script." -ErrorAction Stop
}
elseif ($null -eq $queueName) {
    Write-Error "Queue name not correctly passed in to script." -ErrorAction Stop
}

Write-Verbose "Resource Group: $resourceGroup" -Verbose
Write-Verbose "Namespace: $namespaceName" -Verbose
Write-Verbose "Queue Name: $queueName" -Verbose

#Build deployment variables
###############################################################################################
Write-Verbose "Building deployment variables from runtime environment and Atlas defaults..." -Verbose

#mdx7683 -- using default as of 4/11/2019
#az servicebus queue show -g RG-CMFG-EA2-Atlas-ServiceBus-MichaelD --namespace-name CMFG-Michael-Test-Pester-Sandbox2 --name Test
###############################################################################################
$QUEUE_ENABLE_BATCHED_OPERATIONS = if ($env:QUEUE_ENABLE_BATCHED_OPERATIONS) { [System.Convert]::ToBoolean($env:QUEUE_ENABLE_BATCHED_OPERATIONS) } else { $true }
Write-Verbose "QUEUE_ENABLE_BATCHED_OPERATIONS: $QUEUE_ENABLE_BATCHED_OPERATIONS" -Verbose

$QUEUE_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION = if ($env:QUEUE_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION) { [System.Convert]::ToBoolean($env:QUEUE_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION) } else { $false }
Write-Verbose "QUEUE_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION: $QUEUE_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION" -Verbose

$QUEUE_ENABLE_DUPLICATE_DETECTION = if ($env:QUEUE_ENABLE_DUPLICATE_DETECTION) { [System.Convert]::ToBoolean($env:QUEUE_ENABLE_DUPLICATE_DETECTION) } else { $false }
Write-Verbose "QUEUE_ENABLE_DUPLICATE_DETECTION: $QUEUE_ENABLE_DUPLICATE_DETECTION" -Verbose

$QUEUE_ENABLE_EXPRESS = if ($env:QUEUE_ENABLE_EXPRESS) { [System.Convert]::ToBoolean($env:QUEUE_ENABLE_EXPRESS) } else { $false }
Write-Verbose "QUEUE_ENABLE_EXPRESS: $QUEUE_ENABLE_EXPRESS" -Verbose

$QUEUE_ENABLE_PARTITIONING = if ($env:QUEUE_ENABLE_PARTITIONING) { [System.Convert]::ToBoolean($env:QUEUE_ENABLE_PARTITIONING) } else { $false }
Write-Verbose "QUEUE_ENABLE_PARTITIONING: $QUEUE_ENABLE_PARTITIONING" -Verbose

$QUEUE_ENABLE_SESSION = if ($env:QUEUE_ENABLE_SESSION) { [System.Convert]::ToBoolean($env:QUEUE_ENABLE_SESSION) } else { $false }
Write-Verbose "QUEUE_ENABLE_SESSION: $QUEUE_ENABLE_SESSION" -Verbose

$QUEUE_MAX_SIZE = if ($env:QUEUE_MAX_SIZE) { $env:QUEUE_MAX_SIZE } else { 1024 }
Write-Verbose "QUEUE_MAX_SIZE: $QUEUE_MAX_SIZE" -Verbose

$QUEUE_STATUS = if ($env:QUEUE_STATUS) { $env:QUEUE_STATUS } else { "Active" }
Write-Verbose "QUEUE_STATUS: $QUEUE_STATUS" -Verbose

$QUEUE_MAX_DELIVERY_COUNT = if ($env:QUEUE_MAX_DELIVERY_COUNT) { $env:QUEUE_MAX_DELIVERY_COUNT } else { 10 }
Write-Verbose "QUEUE_MAX_DELIVERY_COUNT: $QUEUE_MAX_DELIVERY_COUNT" -Verbose

<# Currently unsupported --------------------------

$QUEUE_FORWARD_TO = if ($env:QUEUE_FORWARD_TO) { $env:QUEUE_FORWARD_TO } else { $null }
Write-Verbose "QUEUE_FORWARD_TO: $QUEUE_FORWARD_TO" -Verbose
$QUEUE_FORWARD_DEAD_LETTERED_MESSAGES_TO = if ($env:QUEUE_FORWARD_DEAD_LETTERED_MESSAGES_TO) { $env:QUEUE_FORWARD_DEAD_LETTERED_MESSAGES_TO } else { $null }
Write-Verbose "QUEUE_FORWARD_DEAD_LETTERED_MESSAGES_TO: $QUEUE_FORWARD_DEAD_LETTERED_MESSAGES_TO" -Verbose

#>
$QUEUE_AUTO_DELETE_ON_IDLE = if ($env:QUEUE_AUTO_DELETE_ON_IDLE) { $env:QUEUE_AUTO_DELETE_ON_IDLE } else { 'P1000D' }
Write-Verbose "QUEUE_AUTO_DELETE_ON_IDLE: $QUEUE_AUTO_DELETE_ON_IDLE" -Verbose

#default-message-time-to-live : "defaultMessageTimeToLive": "14 days, 0:00:00",
$QUEUE_DEFAULT_MESSAGE_TIME_TO_LIVE = if ($env:QUEUE_DEFAULT_MESSAGE_TIME_TO_LIVE) { $env:QUEUE_DEFAULT_MESSAGE_TIME_TO_LIVE } else { 'P14D' }
Write-Verbose "QUEUE_DEFAULT_MESSAGE_TIME_TO_LIVE: $QUEUE_DEFAULT_MESSAGE_TIME_TO_LIVE" -Verbose

#duplicate-detection-history-time-window : "duplicateDetectionHistoryTimeWindow": "0:10:00",
$QUEUE_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW = if ($env:QUEUE_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW) { $env:QUEUE_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW } else { '0:10:00' }
Write-Verbose "QUEUE_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW: $QUEUE_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW" -Verbose

#lock-duration : "lockDuration": "0:00:30",
$QUEUE_LOCK_DURATION = if ($env:QUEUE_LOCK_DURATION) { $env:QUEUE_LOCK_DURATION } else { '0:00:30' }
Write-Verbose "QUEUE_LOCK_DURATION: $QUEUE_LOCK_DURATION" -Verbose

#Execute deployment
###############################################################################################
Write-Verbose "Executing create of queue $queueName in namespace $namespaceName in resource group $resourceGroup..." -Verbose

az servicebus queue create --resource-group $resourceGroup `
    --namespace-name $namespaceName `
    --name $queueName `
    --auto-delete-on-idle $QUEUE_AUTO_DELETE_ON_IDLE `
    --default-message-time-to-live $QUEUE_DEFAULT_MESSAGE_TIME_TO_LIVE `
    --duplicate-detection-history-time-window $QUEUE_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW `
    --enable-batched-operations $QUEUE_ENABLE_BATCHED_OPERATIONS `
    --enable-dead-lettering-on-message-expiration $QUEUE_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION `
    --enable-duplicate-detection $QUEUE_ENABLE_DUPLICATE_DETECTION `
    --enable-express $QUEUE_ENABLE_EXPRESS `
    --enable-partitioning $QUEUE_ENABLE_PARTITIONING `
    --enable-session $QUEUE_ENABLE_SESSION `
    --lock-duration $QUEUE_LOCK_DURATION `
    --max-delivery-count $QUEUE_MAX_DELIVERY_COUNT `
    --max-size $QUEUE_MAX_SIZE `
    --status $QUEUE_STATUS

<#  Currently unsupported -----------------
                        --forward-dead-lettered-messages-to $QUEUE_FORWARD_DEAD_LETTERED_MESSAGES_TO `
                        --forward-to $QUEUE_FORWARD_TO `
#>

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureAddQueue-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Queue deployment complete. See above for any potential errors. " -Verbose