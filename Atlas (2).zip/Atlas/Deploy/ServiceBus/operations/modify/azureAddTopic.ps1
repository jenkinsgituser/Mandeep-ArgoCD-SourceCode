param
(
  [Alias("resourceGroupName")]
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup = $env:BUS_RG_NAME,

  [Alias("namespace")]
  [Parameter(Mandatory = $false)]
  [string] $namespaceName = $env:BUS_NAMESPACE,

  [Parameter(Mandatory = $true)]
  [string] $topicName
)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

#Basic input validation
###############################################################################################
Write-Verbose "Loading repo utilties..." -Verbose

Write-AtlasSanitizeInputs

if ($null -eq $resourceGroup ) {
  Write-Error "Resource group not correctly passed in to script." -ErrorAction Stop
}
elseif ($null -eq $namespaceName) {
  Write-Error "Namespace name not correctly passed in to script." -ErrorAction Stop
}
elseif ($null -eq $topicName) {
  Write-Error "Topic name not correctly passed in to script." -ErrorAction Stop
}

Write-Verbose "Resource Group: $resourceGroup" -Verbose
Write-Verbose "Namespace: $namespaceName" -Verbose
Write-Verbose "Topic Name: $topicName" -Verbose

#Build deployment variables
###############################################################################################
Write-Verbose "Building deployment variables from runtime environment and Atlas defaults..." -Verbose

$TOPIC_AUTO_DELETE_ON_IDLE = if ($env:TOPIC_AUTO_DELETE_ON_IDLE) { $env:TOPIC_AUTO_DELETE_ON_IDLE } else { 'P1000D' }
Write-Verbose "TOPIC_AUTO_DELETE_ON_IDLE: $TOPIC_AUTO_DELETE_ON_IDLE" -Verbose

$TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE = if ($env:TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE) { $env:TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE } else { 'P14D' }
Write-Verbose "TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE: $TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE" -Verbose

$TOPIC_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW = if ($env:TOPIC_AUTO_DELETE_ON_IDLE) { $env:TOPIC_AUTO_DELETE_ON_IDLE } else { '0:10:00' }
Write-Verbose "TOPIC_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW: $TOPIC_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW" -Verbose

$TOPIC_ENABLE_BATCHED_OPERATIONS = if ($env:TOPIC_ENABLE_BATCHED_OPERATIONS) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_BATCHED_OPERATIONS) } else { $true }
Write-Verbose "TOPIC_ENABLE_BATCHED_OPERATIONS: $TOPIC_ENABLE_BATCHED_OPERATIONS" -Verbose

$TOPIC_ENABLE_DUPLICATE_DETECTION = if ($env:TOPIC_ENABLE_DUPLICATE_DETECTION) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_DUPLICATE_DETECTION) } else { $false }
Write-Verbose "TOPIC_ENABLE_DUPLICATE_DETECTION: $TOPIC_ENABLE_DUPLICATE_DETECTION" -Verbose

$TOPIC_ENABLE_EXPRESS = if ($env:TOPIC_ENABLE_EXPRESS) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_EXPRESS) } else { $false }
Write-Verbose "TOPIC_ENABLE_EXPRESS: $TOPIC_ENABLE_EXPRESS" -Verbose

$TOPIC_ENABLE_ORDERING = if ($env:TOPIC_ENABLE_ORDERING) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_ORDERING) } else { $true }
Write-Verbose "TOPIC_ENABLE_ORDERING: $TOPIC_ENABLE_ORDERING" -Verbose

$TOPIC_ENABLE_PARTITIONING = if ($env:TOPIC_ENABLE_PARTITIONING) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_PARTITIONING) } else { $false }
Write-Verbose "TOPIC_ENABLE_PARTITIONING: $TOPIC_ENABLE_PARTITIONING" -Verbose

$TOPIC_MAX_SIZE = if ($env:TOPIC_MAX_SIZE) { $env:TOPIC_MAX_SIZE } else { 1024 }
Write-Verbose "TOPIC_MAX_SIZE: $TOPIC_MAX_SIZE" -Verbose

$TOPIC_STATUS = if ($env:TOPIC_STATUS) { $env:TOPIC_STATUS } else { "Active" }
Write-Verbose "TOPIC_STATUS: $TOPIC_STATUS" -Verbose

#Execute deployment
###############################################################################################
Write-Verbose "Executing create of topic $topicName in namespace $namespaceName in resource group $resourceGroup..." -Verbose

#see github issue here for history as to why --max-size was removed
#https://github.com/Azure/azure-cli/issues/9319

az servicebus topic create --resource-group $resourceGroup `
  --namespace-name $namespaceName `
  --name $topicName `
  --auto-delete-on-idle $TOPIC_AUTO_DELETE_ON_IDLE `
  --default-message-time-to-live $TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE `
  --duplicate-detection-history-time-window $TOPIC_DUPLICATE_DETECTION_HISTORY_TIME_WINDOW `
  --enable-batched-operations $TOPIC_ENABLE_BATCHED_OPERATIONS `
  --enable-duplicate-detection $TOPIC_ENABLE_DUPLICATE_DETECTION `
  --enable-express $TOPIC_ENABLE_EXPRESS `
  --enable-ordering $TOPIC_ENABLE_ORDERING `
  --enable-partitioning $TOPIC_ENABLE_PARTITIONING `
  --status $TOPIC_STATUS `
  --max-size $TOPIC_MAX_SIZE

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureAddTopic-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Topic deployment complete. See above for any potential errors. " -Verbose