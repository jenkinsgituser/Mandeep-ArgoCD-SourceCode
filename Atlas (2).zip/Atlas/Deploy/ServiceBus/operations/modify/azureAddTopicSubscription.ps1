param
(
  [Alias("resourceGroupName")]
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup = $env:BUS_RG_NAME,

  [Alias("namespace")]
  [Parameter(Mandatory = $false)]
  [string] $namespaceName = $env:BUS_NAMESPACE,

  [Parameter(Mandatory = $true)]
  [string] $topicName,

  [Parameter(Mandatory = $true)]
  [string] $subscriptionName
)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

<#
unimplemented flags
                                        [--forward-dead-lettered-messages-to]
                                        [--forward-to
#>

#Build deployment variables
###############################################################################################
Write-Verbose "Building deployment variables from runtime environment and Atlas defaults..." -Verbose

$TOPIC_AUTO_DELETE_ON_IDLE = if ($env:TOPIC_AUTO_DELETE_ON_IDLE) { $env:TOPIC_AUTO_DELETE_ON_IDLE } else { 'P1000D' }
Write-Verbose "TOPIC_AUTO_DELETE_ON_IDLE: $TOPIC_AUTO_DELETE_ON_IDLE" -Verbose

$TOPIC_DEAD_LETTER_ON_FILTER_EXCEPTIONS = if ($env:TOPIC_DEAD_LETTER_ON_FILTER_EXCEPTIONS) { [System.Convert]::ToBoolean($env:TOPIC_DEAD_LETTER_ON_FILTER_EXCEPTIONS) } else { $false }
Write-Verbose "TOPIC_DEAD_LETTER_ON_FILTER_EXCEPTIONS: $TOPIC_DEAD_LETTER_ON_FILTER_EXCEPTIONS" -Verbose

$TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE = if ($env:TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE) { $env:TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE } else { 'P14D' }
Write-Verbose "TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE: $TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE" -Verbose

$TOPIC_ENABLE_BATCHED_OPERATIONS = if ($env:TOPIC_ENABLE_BATCHED_OPERATIONS) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_BATCHED_OPERATIONS) } else { $true }
Write-Verbose "TOPIC_ENABLE_BATCHED_OPERATIONS: $TOPIC_ENABLE_BATCHED_OPERATIONS" -Verbose

$TOPIC_STATUS = if ($env:TOPIC_STATUS) { $env:TOPIC_STATUS } else { "Active" }
Write-Verbose "TOPIC_STATUS: $TOPIC_STATUS" -Verbose

$TOPIC_MAX_DELIVERY_COUNT = if ($env:TOPIC_MAX_DELIVERY_COUNT) { $env:TOPIC_MAX_DELIVERY_COUNT } else { 10 }
Write-Verbose "TOPIC_MAX_DELIVERY_COUNT: $TOPIC_MAX_DELIVERY_COUNT" -Verbose

$TOPIC_LOCK_DURATION = if ($env:TOPIC_LOCK_DURATION) { $env:TOPIC_LOCK_DURATION } else { '0:00:30' }
Write-Verbose "TOPIC_LOCK_DURATION: $TOPIC_LOCK_DURATION" -Verbose

$TOPIC_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION = if ($env:TOPIC_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION) } else { $false }
Write-Verbose "TOPIC_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION: $TOPIC_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION" -Verbose

$TOPIC_ENABLE_SESSION = if ($env:TOPIC_ENABLE_SESSION) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_SESSION) } else { $false }
Write-Verbose "TOPIC_ENABLE_SESSION: $TOPIC_ENABLE_SESSION" -Verbose

#Execute deployment
###############################################################################################
Write-Verbose "Executing create of subscription $subscriptionName for topic $topicName in namespace $namespaceName in resource group $resourceGroup..." -Verbose
az servicebus topic subscription create --resource-group $resourceGroup `
  --namespace-name $namespaceName `
  --topic-name $topicName `
  --name $subscriptionName `
  --auto-delete-on-idle $TOPIC_AUTO_DELETE_ON_IDLE `
  --dead-letter-on-filter-exceptions $TOPIC_DEAD_LETTER_ON_FILTER_EXCEPTIONS `
  --default-message-time-to-live $TOPIC_DEFAULT_MESSAGE_TIME_TO_LIVE `
  --enable-batched-operations $TOPIC_ENABLE_BATCHED_OPERATIONS `
  --enable-dead-lettering-on-message-expiration $TOPIC_ENABLE_DEAD_LETTERING_ON_MESSAGE_EXPIRATION `
  --enable-session $TOPIC_ENABLE_SESSION `
  --lock-duration $TOPIC_LOCK_DURATION `
  --max-delivery-count $TOPIC_MAX_DELIVERY_COUNT `
  --status $TOPIC_STATUS
<#
                                        --forward-dead-lettered-messages-to `
                                        --forward-to `
#>

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureAddTopicSubscription-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Subscription deployment complete. See above for any potential errors. " -Verbose