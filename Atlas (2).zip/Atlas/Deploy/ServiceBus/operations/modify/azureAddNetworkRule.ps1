param
(
    [Alias("resourceGroupName")]
    [Parameter(Mandatory = $true, Position = 0)]
    [string] $resourceGroup = $env:BUS_RG_NAME,

    [Alias("namespace")]
    [Parameter(Mandatory = $true, Position = 1)]
    [string] $namespaceName = $env:BUS_NAMESPACE,

    [Parameter(Mandatory = $true, Position = 2)]
    [string] $vNetResourceGroup,

    [Parameter(Mandatory = $false, Position = 3)]
    [string] $vNet,

    [Parameter(Mandatory = $false, Position = 4)]
    [string] $subnetName
)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    ######################################################################################

    Write-Verbose "AtlasArmRestClient.ps1 is executing" -Verbose
    . ("$COMMON_FOLDER/api/AtlasArmRestClient.ps1")

    Write-AtlasSanitizeInputs

    $servicebusNamespace = $(az servicebus namespace list --resource-group $ResourceGroup --query "[].name" -o tsv)
    $storageAccount = $(az storage account list --resource-group $ResourceGroup --query "[].name" -o tsv)
    Write-Verbose "Discovered target Service Bus resource." -Verbose

    Write-Verbose "Discovering target subnet URI..." -Verbose

    if ([string]::IsNullOrEmpty($vNet) -or [string]::IsNullOrEmpty($subnetName)) {
        #note that vnet can be false -- this function handles for that case regardless
        $subnetUri = Get-SubNetID -ResourceGroup $vNetResourceGroup

    }
    else {
        $subnetUri = Get-SubNetID -ResourceGroup $vNetResourceGroup -vNet $vNet -subnetName $subnetName
        if (!$subnetUri) {
            Write-Error "Unable to determine subnet URI given resource group, vNet, and subnet names."
        }
    }

    Write-Verbose "Found subnet URI: $subnetUri" -Verbose
    Write-Verbose "Proceeding to add allow rule for subnet..."

    #subnetUri comes back in the format of an Azure Resource URI
    $componentPath = $subnetUri.Split('/')

    #/subscriptions/$subscriptionID/resourceGroups/$ResourceGroup/providers/Microsoft.Network/virtualNetworks/$VNET/subnets/$SUBNET
    $vNet = $componentPath[$componentPath.Length - 3]

    #subnetname is the last part of the subnet resource URI
    $subnetName = $componentPath[$componentPath.Length - 1]

    Write-Verbose "Adding Subnet $subnetUri as allowed..." -Verbose

    #writing this as a foreach-object as the role of this could expand over time and the goal of today isn't to enforce a single ESB
    #however, there is an EXPECTATION that only a single ESB should be in place -- enforcement occurs elsewhere
    $servicebusNamespace | ForEach-Object {
        #add the rule on the servicebus side
        Write-Verbose "Processing namespace $servicebusNamespace..." -Verbose
        Add-AtlasServiceBus-subNetRule -ResourceGroup $ResourceGroup -Namespace $servicebusNamespace -SubNetUri $subnetUri
        Write-Verbose "Subnet $subnetUri added as allowed to $servicebusNamespace..." -Verbose
    }

    #writing this as a foreach-object as the role of this could expand over time and the goal of today isn't to enforce a single SA
    #however, there is an EXPECTATION that only a single SA should be in place -- enforcement occurs elsewhere
    $storageAccount | ForEach-Object {
        #add the rule on the storage account side
        Write-Verbose "Processing storage account $storageAccount..." -Verbose
        az storage account network-rule add --account-name $storageAccount --action 'Allow' --subnet $subnetUri --query "networkRuleSet"
        Write-Verbose "Subnet $subnetUri added as allowed to $storageAccount..." -Verbose
    }

    #not concerned if the rule applies to the service bus but not to the storage account - other automation ensures eventual consistency, although short
    #term this could cause a headache for a development team deploying fresh and relying on the storage account.

    Write-Verbose "Network rule added successfully!" -Verbose
}
catch {
    Write-Verbose "An error occurred while processing your network firewall modifications." -Verbose
    Write-Error $_.Exception.Message -ErrorAction Stop
}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureAddNetworkRuleSubnet-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes