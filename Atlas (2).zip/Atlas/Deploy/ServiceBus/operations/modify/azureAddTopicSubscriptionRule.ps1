param
(
  [Alias("resourceGroupName")]
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup = $env:BUS_RG_NAME,

  [Alias("namespace")]
  [Parameter(Mandatory = $false)]
  [string] $namespaceName = $env:BUS_NAMESPACE,

  [Parameter(Mandatory = $true)]
  [string] $topicName,

  [Parameter(Mandatory = $true)]
  [string] $subscriptionName,

  [Parameter(Mandatory = $true)]
  [string] $ruleName
)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

#Build deployment variables
###############################################################################################
$TOPIC_ACTION_COMPATIBILITY_LEVEL = if ($env:TOPIC_ACTION_COMPATIBILITY_LEVEL) { $env:TOPIC_ACTION_COMPATIBILITY_LEVEL } else { }
Write-Verbose "TOPIC_ACTION_COMPATIBILITY_LEVEL: $TOPIC_ACTION_COMPATIBILITY_LEVEL" -Verbose

$TOPIC_ACTION_SQL_EXPRESSION = if ($env:TOPIC_ACTION_SQL_EXPRESSION) { $env:TOPIC_ACTION_SQL_EXPRESSION } else { }
Write-Verbose "TOPIC_ACTION_SQL_EXPRESSION: $TOPIC_ACTION_SQL_EXPRESSION" -Verbose

$TOPIC_CONTENT_TYPE = if ($env:TOPIC_CONTENT_TYPE) { $env:TOPIC_CONTENT_TYPE } else { }
Write-Verbose "TOPIC_CONTENT_TYPE: $TOPIC_CONTENT_TYPE" -Verbose

$TOPIC_CORRELATION_ID = if ($env:TOPIC_CORRELATION_ID) { $env:TOPIC_CORRELATION_ID } else { }
Write-Verbose "TOPIC_CORRELATION_ID: $TOPIC_CORRELATION_ID" -Verbose

$TOPIC_ENABLE_ACTION_PREPROCESSING = if ($env:TOPIC_ENABLE_ACTION_PREPROCESSING) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_ACTION_PREPROCESSING) } else { }
Write-Verbose "TOPIC_ENABLE_ACTION_PREPROCESSING: $TOPIC_ENABLE_ACTION_PREPROCESSING" -Verbose

$TOPIC_ENABLE_CORRELATION_PREPROCESSING = if ($env:TOPIC_ENABLE_CORRELATION_PREPROCESSING) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_CORRELATION_PREPROCESSING) } else { }
Write-Verbose "TOPIC_ENABLE_CORRELATION_PREPROCESSING: $TOPIC_ENABLE_CORRELATION_PREPROCESSING" -Verbose

$TOPIC_ENABLE_SQL_PREPROCESSING = if ($env:TOPIC_ENABLE_SQL_PREPROCESSING) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_SQL_PREPROCESSING) } else { }
Write-Verbose "TOPIC_ENABLE_SQL_PREPROCESSING: $TOPIC_ENABLE_SQL_PREPROCESSING" -Verbose

$TOPIC_ENABLE_SQL_EXPRESSION = if ($env:TOPIC_ENABLE_SQL_EXPRESSION) { [System.Convert]::ToBoolean($env:TOPIC_ENABLE_SQL_EXPRESSION) } else { }
Write-Verbose "TOPIC_ENABLE_SQL_EXPRESSION: $TOPIC_ENABLE_SQL_EXPRESSION" -Verbose

$TOPIC_FILTER_SQL_EXPRESSION = if ($env:TOPIC_FILTER_SQL_EXPRESSION) { $env:TOPIC_FILTER_SQL_EXPRESSION } else { }
Write-Verbose "TOPIC_FILTER_SQL_EXPRESSION: $TOPIC_FILTER_SQL_EXPRESSION" -Verbose

$TOPIC_LABEL = if ($env:TOPIC_LABEL) { $env:TOPIC_LABEL } else { }
Write-Verbose "TOPIC_LABEL: $TOPIC_LABEL" -Verbose

$TOPIC_MESSAGE_ID = if ($env:TOPIC_MESSAGE_ID) { $env:TOPIC_MESSAGE_ID } else { }
Write-Verbose "TOPIC_MESSAGE_ID: $TOPIC_MESSAGE_ID" -Verbose

$TOPIC_REPLY_TO = if ($env:TOPIC_REPLY_TO) { $env:TOPIC_REPLY_TO } else { }
Write-Verbose "TOPIC_REPLY_TO: $TOPIC_REPLY_TO" -Verbose

$TOPIC_REPLY_TO_SESSION_ID = if ($env:TOPIC_REPLY_TO_SESSION_ID) { $env:TOPIC_REPLY_TO_SESSION_ID } else { }
Write-Verbose "TOPIC_REPLY_TO_SESSION_ID: $TOPIC_REPLY_TO_SESSION_ID" -Verbose

$TOPIC_SESSION_ID = if ($env:TOPIC_SESSION_ID) { $env:TOPIC_SESSION_ID } else { }
Write-Verbose "TOPIC_SESSION_ID: $TOPIC_SESSION_ID" -Verbose

$TOPIC_TO = if ($env:TOPIC_TO) { $env:TOPIC_TO } else { }
Write-Verbose "TOPIC_TO: $TOPIC_TO" -Verbose

#Execute deployment
###############################################################################################
Write-Verbose "Executing create of subscription $subscriptionName for topic $topicName in namespace $namespaceName in resource group $resourceGroup..." -Verbose

if ($TOPIC_FILTER_SQL_EXPRESSION -and !$TOPIC_ACTION_SQL_EXPRESSION) {

  az servicebus topic subscription rule create --resource-group $resourceGroup `
    --namespace-name $namespaceName `
    --topic-name $topicName `
    --subscription-name $subscriptionName `
    --name $ruleName `
    --filter-sql-expression $TOPIC_FILTER_SQL_EXPRESSION

}
elseif (!$TOPIC_FILTER_SQL_EXPRESSION -and $TOPIC_ACTION_SQL_EXPRESSION) {

  az servicebus topic subscription rule create --resource-group $resourceGroup `
    --namespace-name $namespaceName `
    --topic-name $topicName `
    --subscription-name $subscriptionName `
    --name $ruleName `
    --action-sql-expression $TOPIC_ACTION_SQL_EXPRESSION
}
elseif ($TOPIC_FILTER_SQL_EXPRESSION -and $TOPIC_ACTION_SQL_EXPRESSION) {

  az servicebus topic subscription rule create --resource-group $resourceGroup `
    --namespace-name $namespaceName `
    --topic-name $topicName `
    --subscription-name $subscriptionName `
    --name $ruleName `
    --filter-sql-expression $TOPIC_FILTER_SQL_EXPRESSION `
    --action-sql-expression $TOPIC_ACTION_SQL_EXPRESSION

}
else {
  Write-Error "Currently only supporting SQL Filter, SQL Action, or both in rule creation. Feel free to fork, extend, and upstream as necessary."
}
<#
currently un/underimplemented
                                        --action-compatibility-level $TOPIC_ACTION_COMPATIBILITY_LEVEL `
                                        --content-type $TOPIC_CONTENT_TYPE `
                                        --correlation-id $TOPIC_CORRELATION_ID `
                                        --enable-action-preprocessing $TOPIC_ENABLE_ACTION_PREPROCESSING `
                                        --enable-correlation-preprocessing $TOPIC_ENABLE_CORRELATION_PREPROCESSING `
                                        --enable-sql-preprocessing $TOPIC_ENABLE_SQL_PREPROCESSING `
                                        --label $TOPIC_LABEL `
                                        --message-id $TOPIC_MESSAGE_ID `
                                        --reply-to $TOPIC_REPLY_TO `
                                        --reply-to-session-id $TOPIC_REPLY_TO_SESSION_ID `
                                        --session-id $TOPIC_SESSION_ID `
                                        --to $TOPIC_TO
#>
# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureAddTopicSubscriptionRule-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Subscription deployment complete. See above for any potential errors. " -Verbose
