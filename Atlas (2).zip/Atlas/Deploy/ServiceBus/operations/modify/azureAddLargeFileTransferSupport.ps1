param
(
  [Alias("resourceGroupName")]
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup = $env:BUS_RG_NAME
)
$ErrorActionPreference = "Stop"

######################################################################################################

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

Write-Verbose "AtlasArmRestClient.ps1 is executing" -Verbose
. ("$COMMON_FOLDER/api/AtlasArmRestClient.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

Write-AtlasSanitizeInputs

#Pre-deployment validation logic
######################################################################################################
If ($env:STORAGE_ACCOUNT_NAME) { $STORAGE_ACCOUNT_NAME = "$env:STORAGE_ACCOUNT_NAME" }
Else { $STORAGE_ACCOUNT_NAME = "sa" + "$BUS_NAMESPACE".ToLower().Replace('-', '') }
If ($STORAGE_ACCOUNT_NAME.Length -gt 24) {
  $STORAGE_ACCOUNT_NAME = $STORAGE_ACCOUNT_NAME.Substring(0, 24)
}
Write-Verbose -Verbose "Storage Account: $env:STORAGE_ACCOUNT_NAME"
Write-Verbose -Verbose "Servicebus namespace: $env:BUS_NAMESPACE"
$rgResources = $(az servicebus namespace list -g $resourceGroup) | ConvertFrom-Json

# #confirm one and only one ESB is deployed to the RG as it sits.
 $namespaceCount = $($rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" } | Measure-Object).Count
if ($namespaceCount -ne 1) {
  Write-Verbose -Verbose "Namespace count: $namespaceCount"
  Write-Error "Unable to proceed with current inputs as the target resource group does not have the expected Service Bus namespace count. This is an unsupported condition. Aborting..." -ErrorAction Stop
}
#confirm the RG doesn't already have a storage account. If it does, make sure at most we're doing a modify.
#currently no support for multiple SA's in a bus RG
#"Microsoft.Storage/storageAccounts" is the type used by MSFT for storage accounts

$saCount = $($rgResources | Where-Object { $_.type -eq "Microsoft.Storage/storageAccounts" } | Measure-Object).Count
if ($saCount -eq 1) {
  $saResource = $($rgResources | Where-Object { $_.type -eq "Microsoft.Storage/storageAccounts" })
  if ($saResource.name -ne $STORAGE_ACCOUNT_NAME) {
    Write-Error "Unable to proceed with current inputs as it would result in two Large Transfer Storage Accounts. This is an unsupported condition. Aborting..." -ErrorAction Stop
  }
}
elseif ($saCount -gt 1) {
  Write-Error "Resource group has more than one storage account. This is an unsupported condition. Aborting..." -ErrorAction Stop
}
#if neither of the conditions above are met, there is either 0 or 1 SA in the RG already
#if there is 1 SA in the RG, it will be modified by the deployment below.
#if there are 0 SAs in the RG, one will be created

######################################################################################################

#linkup to the storage account template file
$STORAGE_ACCOUNT_TEMPLATE_FILE = "$INFRA_FOLDER/ServiceBus/src/StorageAccount/azuredeployStorageAccount_Titan.json"

$DEPLOYMENT_NAME = "azuredeployLargeTransferStorageAccount-$(Get-Date -f yyyyMMddHHmmss)"
Write-Verbose "DEPLOYMENT_NAME: $DEPLOYMENT_NAME" -Verbose

#we have rgResources above - get the service bus namesapce from this list of resources as we've already confirmed there's only one
$BUS_NAMESPACE = $(If ($env:BUS_NAMESPACE) { "$env:BUS_NAMESPACE" } Else { $($rgResources | Where-Object { $_.type -eq "Microsoft.ServiceBus/namespaces" }).Name })
Write-Verbose "BUS_NAMESPACE: $BUS_NAMESPACE" -Verbose

Write-Verbose "STORAGE_ACCOUNT_NAME: $STORAGE_ACCOUNT_NAME" -Verbose
Write-Host "##vso[task.setvariable variable=STORAGE_ACCOUNT_NAME;]$STORAGE_ACCOUNT_NAME" #write the variable to the build agent for use if necessary

$STORAGE_ACCOUNT_TYPE = $(If ($env:STORAGE_ACCOUNT_TYPE) { "$env:STORAGE_ACCOUNT_TYPE" } Else { "Standard_LRS" })
Write-Verbose "STORAGE_ACCOUNT_TYPE: $STORAGE_ACCOUNT_TYPE" -Verbose

$STORAGE_ACCOUNT_ACCESS_TIER = $(If ($env:STORAGE_ACCOUNT_ACCESS_TIER) { "$env:STORAGE_ACCOUNT_ACCESS_TIER" } Else { "Hot" })
Write-Verbose "STORAGE_ACCOUNT_ACCESS_TIER: $STORAGE_ACCOUNT_ACCESS_TIER" -Verbose

$CREATED_DATE = Get-Date -Format "yyyy-MM-dd"
Write-Verbose "CREATED_DATE: $CREATED_DATE" -Verbose

######################################################################################################

#port the network ACLs from the Service Bus Namespace to the storage account -- no good reason to have
#a highly secured service bus but a wide open, network access wise, storage account
$Allowed_Subnet_Ids = "[]"

$rulesToAdd = @()
$existingNamespaceRules = Get-AtlasServiceBus-NetworkRules -ResourceGroup $resourceGroup -Namespace $BUS_NAMESPACE
foreach ($rule in $existingNamespaceRules.properties.virtualNetworkRules) {
  $rulesToAdd += @{"id" = $rule.subnet.id; "action" = "Allow" }
}
if ($rulesToAdd) {
  $Allowed_Subnet_Ids = $rulesToAdd | ConvertTo-Json

  #so this looks stupid on paper, as the convertTo-Json above renders perfectly fine JSON...
  #except for feeding into an ARM template, as the template really wants its JSON in one
  #string with escapes where necessary. This approach gives you that result by stripping
  #tabs, carriage returns, and newlines before pumping it back out to a new JSON-ish result
  $Allowed_Subnet_Ids = $Allowed_Subnet_Ids -replace "`t|`r|`n| " | ConvertTo-Json

  #if the array is only 1 item, make sure the resulting JSON is treated as an array object still
  if ($rulesToAdd.Count -eq 1) {
    $Allowed_Subnet_Ids = "[$Allowed_Subnet_Ids]"
  }
}

Write-Host "Allowed_Subnet_Ids: `n$Allowed_Subnet_Ids" -Verbose
######################################################################################################

$Action = {
  az deployment group create `
    -g "$resourceGroup" `
    -n "$DEPLOYMENT_NAME" `
    --template-file "$STORAGE_ACCOUNT_TEMPLATE_FILE" `
    --parameters "storageAccountName=$STORAGE_ACCOUNT_NAME" `
    "storageAccountType=$STORAGE_ACCOUNT_TYPE" `
    "accessTier=$STORAGE_ACCOUNT_ACCESS_TIER" `
    "allowedSubNetIds=$Allowed_Subnet_Ids" `
    "location=$BUS_LOCATION" `
    "createdDate=$CREATED_DATE" `
    "TemplateVersion=$TEMPLATE_VERSION"
}

# wrap the above in a functional delegate for improved resiliency
Retry-FunctionalDelegate -Action $Action

Write-Verbose "Successfully Deployed Service Bus Large File Transfer Add-On: $STORAGE_ACCOUNT_NAME" -Verbose
#Call the Perms service to provision appropriate permissions

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureAddLargeFileTransferSupport-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
