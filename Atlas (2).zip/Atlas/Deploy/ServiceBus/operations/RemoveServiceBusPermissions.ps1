Param(
  [Parameter(Mandatory = $true)]
  [string] $Namespace,
  [Parameter(Mandatory = $false)]
  [string] $Topic,
  [Parameter(Mandatory = $false)]
  [string] $Queue,
  [Parameter(Mandatory = $true)]
  [string] $Identity
)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

# Remove TypeData for this session.  This is required b/c of a bug in Powershell versions < 7.0
# This bug causes the .count and .value properties to be interjected into the $ArrayOfPerms below which
# in turn causes the build to fail.
if ($PSVersionTable.PSVersion.Major -lt 6) {
  Remove-TypeData -TypeName System.Array
}

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")
$currentSub = $(Get-AzContext).Subscription.Name
Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}

# Get context
$Context = Get-AzContext

$RequestType = ""

# Get resource ID for Service Bus Namespace
$AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName $Namespace -ResourceType "Microsoft.ServiceBus/namespaces"
$NamespaceResourceId = $AtlasResourceObj.ResourceId
$ResourceGroupName = (Get-AzResource -ResourceId $NamespaceResourceId).ResourceGroupName
Write-AtlasOutput -Loglevel "INFO" -Message "Service Bus Namespace $($Namespace)"

# If ResourceId is not found exit
if (!$NamespaceResourceId) {
  Throw "Service Bus Namespace was not found, exiting..."
}

if ($Topic -and $Queue) {
  Write-AtlasOutput -Loglevel "ERROR" -Message "Passed in both -Queue and -Topic. You can pass in either, but not both."
  Throw "Cannot remove permissions from a topic AND a queue."
}

#Todo Consider writing a common code function for topics and queue resource lookups
# Check if a topic and or queue name has been passed in and, if so get their respecive resource ids and add to parm array.
if ($Topic -or $Queue) {
  if ($Topic) {
    $RequestType = "Topic"
    Write-AtlasOutput -Loglevel "INFO" -Message "Topic variable was passed so retrieving Topic information..."
    $AtlasTopicResourceObj = (Get-AzServiceBusTopic -Namespace $Namespace -ResourceGroupName $ResourceGroupName -Name $Topic)
    $TopicResourceId = $AtlasTopicResourceObj.Id
    Write-AtlasOutput -Loglevel "INFO" -Message "ResourceId of Topic is: $($TopicResourceId)"

    # Check if permissions requested are granted at the Topic level and if not fail since they can only be removed at the scope they
    # granted at.
    $IsTopicPermission = $false
    $TopicPermissionsList = Get-AzRoleAssignment -ResourceGroup $ResourceGroupName -ResourceName $Namespace  -ResourceType "Microsoft.ServiceBus/namespaces"
    foreach ($TopicPerm in $TopicPermissionsList) {
      if ($TopicPerm.DisplayName -eq $Identity -and $TopicPerm.Scope -eq $TopicResourceId) {
        Write-AtlasOutput -Loglevel "INFO" -Message "Topic contains permission: $($TopicPerm.RoleDefinitionName) for $($Identity)."
        $IsTopicPermission = $true
      }
    }
    if (!$IsTopicPermission) {
      Write-AtlasOutput -Loglevel "ERROR" -Message "Topic does not contain permissions for $($Identity). No permission to remove an inherited permission at this scope. Instead, remove the permission from the namespace level."
      Throw "Topic does not contain permissions for $($Identity)."
    }

    if ($TopicResourceId) {
      $ResourceId = $TopicResourceId
      $Combined_Json = @(
        @{
          Resources = @(
            @{
              ResourceId       = $TopicResourceId
              PermissionsArray = @(
                @{
                  Identity = $Identity;
                  Action   = "Remove";
                })
            }
          )
        }
      )
    }
    else {
      Write-AtlasOutput -Loglevel "ERROR" -Message "Service Bus Topic was not found, exiting..."
      Throw "Service Bus Topic was not found, exiting..."
    }
  }
  if ($Queue) {
    $RequestType = "Queue"
    Write-AtlasOutput -Loglevel "INFO" -Message "Queue variable was passed so retrieve Queue information..."
    $AtlasResourceObj = (Get-AzServiceBusQueue -Namespace $Namespace -ResourceGroupName $ResourceGroupName -Name $Queue)
    $QueueResourceId = $AtlasResourceObj.Id
    Write-AtlasOutput -Loglevel "INFO" -Message "ResourceId of Queue is: $($QueueResourceId)"
    $IsQueuePermission = $false
    # Check if permissions requested are granted at the Topic level and if not fail since they can only be removed at the scope they
    # granted at.
    $QueuePermissionsList = Get-AzRoleAssignment -ResourceGroup $ResourceGroupName -ResourceName $Namespace  -ResourceType "Microsoft.ServiceBus/namespaces"
    foreach ($QueuePerm in $QueuePermissionsList) {
      #Write-AtlasOutput -Loglevel "INFO" -Message "Existing permision is $($TopicPerm.DisplayName)"
      if ($QueuePerm.DisplayName -eq $Identity -and $QueuePerm.Scope -eq $QueueResourceId) {
        Write-AtlasOutput -Loglevel "INFO" -Message "Queue contains permission: $($QueuePerm.RoleDefinitionName) for $($Identity). OK to proceed."
        $IsQueuePermission = $true
      }
    }
    if (!$IsQueuePermission) {
      Write-AtlasOutput -Loglevel "ERROR" -Message "Queue does not contain permissions for $($Identity). No permission to remove an inherited permission at this scope. Instead, remove the permission from the namespace level."
      Throw "Queue does not contain permissions for $($Identity). "
    }

    if ($QueueResourceId) {
      # If a Topic was passed add the queue request to the Combined_Json perm array already created for Topic
      if ($Topic) {
        $RequestType = "Queue and Topic"
        $Combined_Json_AddQueue = @{
          ResourceId       = $QueueResourceId
          PermissionsArray = @(
            @{
              Identity = $Identity;
              Action   = "Remove";
            })
        }
        $Combined_Json[0].Resources += $Combined_Json_AddQueue
      }
      else {
        # No Topic was passed so this is only a Queue permissions request so populate Combined_Json variable for Queue
        $Combined_Json = @(
          @{
            Resources = @(
              @{
                ResourceId       = $QueueResourceId
                PermissionsArray = @(
                  @{
                    Identity = $Identity;
                    Action   = "Remove";
                  }
                )
              }
            )
          }
        )
      }
    }
    else {
      Write-AtlasOutput -Loglevel "ERROR" -Message "Service Bus Queue was not found, exiting...."
      Throw "Service Bus Queue was not found, exiting..."
    }
  }
}
else {
  # Neither a topic or queue parameter was entered so process this as a service bus only permissions request
  if ($NamespaceResourceId) {
    $RequestType = "Namespace"
    # Build the Json payload for the service bus namespace
    $Combined_Json = @(
      @{
        Resources = @(
          @{
            ResourceId       = $NamespaceResourceId
            PermissionsArray = @(
              @{
                Identity = $Identity;
                Action   = "Remove";
              }
            )
          }
        )
      }
    )
    $ResourceGroup = (Get-AzResource -Name $Namespace | Where-Object { $_.ResourceType -eq "Microsoft.ServiceBus/namespaces" }).ResourceGroupName
    $LargeFileTransfer = (Get-AzStorageAccount -ResourceGroupName $ResourceGroup)

    # Generate additional permissions requests for any associated large file transfer storage
    if ($LargeFileTransfer) {

      foreach ($sa in $LargeFileTransfer) {
        $AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName $sa.StorageAccountName
        $StorageAccountResourceId = $AtlasResourceObj.ResourceId
        Write-AtlasOutput -Loglevel "INFO" -Message "Adding storage account with ResourceId $($StorageAccountResourceId) to permissions removal request"
        $Combined_Json_AddSA = @{
          ResourceId       = $StorageAccountResourceId
          PermissionsArray = @(
            @{
              Identity = $Identity;
              Action   = "Remove";
            })
        }
        $Combined_Json[0].Resources += $Combined_Json_AddSA
        Write-AtlasOutput -Loglevel "INFO" -Message "Added request to remove permissions for storage account $($sa.StorageAccountName) to Json"
      }
    }
    else {
      Write-AtlasOutput -Loglevel "INFO" -Message "No associated storage accounts discovered."
    }
  }
  else {
    Write-AtlasOutput -Loglevel "ERROR" -Message "Service Bus was not found, exiting..."
    Throw "Service Bus was not found, exiting..."
  }
}

$jsonBody = $Combined_Json | ConvertTo-Json -Depth 10
Write-Verbose "jsonBody is $jsonBody" -Verbose

$ssRbacApiUrl = "https://gw.developer.cunamutual.com/cmfg/prod-int/secure-cloud-rbac/v1/requestrbac?client_id=bd9821d84cbdbe986abd0e41739691a6"
# Retrieve token scoped to the SSRBAC api for auth purposes
$ssRbacResourceUri = "https://securecloudrbacapi"
$token = (Get-AzAccessToken -ResourceUrl $ssRbacResourceUri).token

# Create auth header
$authHeader = @{
  "Authorization" = "Bearer " + $Token
}
Write-Verbose "About to call RBAC API" -Verbose
# Invoke Tiger's API
$results = Invoke-RestMethod -Uri $ssRbacApiUrl -Headers $authHeader -Method "POST" -Body $jsonBody -ContentType "application/json" -SkipHttpErrorCheck

Write-Verbose -Message "Rbac update via SARBAC api service returned: $results" -Verbose
if ($results.statusCode -ne 200) {
  Write-Verbose "Rbac update via auth api service failed with error: $($results.RawContent)" -Verbose
  Write-Error $($results.error)
}
else {
  Write-Output "Removed permission for service bus $StorageAccountName"
}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-ServiceBus-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-AtlasOutput -Loglevel "INFO" -Message "Runbook Execution complete for Service Bus permission removal."