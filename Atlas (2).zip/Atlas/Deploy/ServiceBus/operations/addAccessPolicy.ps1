param
(
  [Alias("namespaceName")]
  [Parameter(Mandatory = $false)]
  [string] $Namespace = $env:BUS_NAMESPACE,

  [Parameter(Mandatory = $true)]
  [string] $Identity,

  [Parameter(Mandatory = $false)]
  [string] $Permissions
)
$ErrorActionPreference = "Stop"

######################################################################################################
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

$currentSub = $(Get-AzContext).Subscription.Name

$Context = Set-AzContext -Subscription $currentSub

# Get resource ID for Service Bus Namespace
$AtlasNamespaceResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName $Namespace -ResourceType "Microsoft.ServiceBus/namespaces"
$NamespaceResourceId = $AtlasNamespaceResourceObj.ResourceId

Write-AtlasOutput -Loglevel "INFO" -Message "Service Bus Namespace $($Namespace)"

# If ResourceId is not found exit
if (!$NamespaceResourceId) {
  Write-AtlasOutput -Loglevel "ERROR" -Message "Service Bus Namespace was not found, exiting..."
  Throw "Service Bus Namespace was not found, exiting..."
}

# The following JSON contains an array of one requests, which will add Storage Blob Data Reader access for R-TigerTeam-LSA to the specified Storage Account
Write-Verbose "Resource ID is: $NamespaceResourceId" -Verbose

$subscriptionDetails = Get-SubscriptionProperties -SubscriptionName $currentSub
$Environment = $subscriptionDetails.environment
if ($Environment -eq "Sandbox") {
  $Environment = "NonProd"
}

if (!$Permissions) {
  # Get the environment from the subscription.  Switch "Sandbox" to Non-Prod since there is only Prod/Non-Prod options

  $IdentityInfo = Find-AtlasIdentityInfo -Context $Context -Identity $Identity
  if ($IdentityInfo.Type -eq [AtlasIdentityInfo]::Group) {
    $IdentityType = "Group"
  }
  else {
    $IdentityType = "AppIdentity"
  }

  Write-Verbose "Identity type is is $($IdentityType)" -Verbose

  if (($Environment -eq "NonProd") -and (($IdentityType -eq "Group") -or ($IdentityType -eq "AppIdentity"))) {
    $Permissions = "Azure Service Bus Data Owner"
  }
  elseif (($Environment -eq "Prod") -and ($IdentityType -eq "Group")) {
    $Permissions = "Azure Service Bus Data Receiver "
  }
  else {
    $Permissions = "Azure Service Bus Data Owner"
  }
}

$NewPermArray = @()
[array]$PermsArray = $Permissions.Split(",")
foreach ($Perm in $PermsArray) {
  $Perm = $Perm.Trim()
  $NewPermArray += $Perm
}


$jsonInput = @(
  @{
    Resources = @(
      @{
        ResourceId       = $NamespaceResourceId
        PermissionsArray = @(
          @{
            Identity    = $Identity
            Permissions = @($NewPermArray)
          }
        )
      }
    )
  }
)

Write-Verbose "JSON Body for SB only is: $jsonBody" -Verbose

$ResourceGroupName = (Get-AzResource -Name $Namespace | Where-Object { $_.ResourceType -eq "Microsoft.ServiceBus/namespaces" }).ResourceGroupName
$LargeFileTransfer = (Get-AzStorageAccount -ResourceGroupName $ResourceGroupName)


#add any associated large file transfer storage
if ($LargeFileTransfer) {

  if (($Environment -eq "NonProd") -and (($IdentityType -eq "Group") -or ($IdentityType -eq "AppIdentity"))) {
    $Permissions = "Storage Blob Data Contributor"
  }
  elseif (($Environment -eq "Prod") -and ($IdentityType -eq "Group")) {
    $Permissions = "Storage Blob Data Reader"
  }
  else {
    $Permissions = "Storage Blob Data Contributor"
  }

  foreach ($sa in $LargeFileTransfer) {

    $AtlasStorageAccountResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName $sa.storageaccountname -ResourceType "Microsoft.Storage/storageAccounts"
    $StorageAccountResourceId = $AtlasStorageAccountResourceObj.ResourceId
    $JsonSA_Add = @{
      ResourceId       = $StorageAccountResourceId
      PermissionsArray = @(
        @{
          Identity    = $Identity
          Permissions = [array] ($Permissions)
        }
      )
    }
    $jsonInput[0].Resources += $JsonSA_Add
    Write-Output "Added permission for storage account $($sa.storageaccountname)"
  }
}
else {
  Write-Output "No associated storage accounts discovered."
}

$jsonBody = $jsonInput | ConvertTo-Json -Depth 10
Write-Verbose "JSON Body with SA added is: $jsonBody" -Verbose

$ssRbacApiUrl = "https://gw.developer.cunamutual.com/cmfg/prod-int/secure-cloud-rbac/v1/requestrbac?client_id=bd9821d84cbdbe986abd0e41739691a6"
# Retrieve token scoped to the SSRBAC api for auth purposes
$ssRbacResourceUri = "https://securecloudrbacapi"
$token = (Get-AzAccessToken -ResourceUrl $ssRbacResourceUri).token

# Create auth header
$authHeader = @{
  "Authorization" = "Bearer " + $Token
}
Write-Verbose "About to call RBAC API" -Verbose
# Invoke Tiger's API
$results = Invoke-RestMethod -Uri $ssRbacApiUrl -Headers $authHeader -Method "POST" -Body $jsonBody -ContentType "application/json" -SkipHttpErrorCheck

Write-Verbose -Message "Rbac update via SARBAC api service returned: $results"
if ($results.statusCode -ne 200) {
  Write-Verbose "Rbac update via auth api service failed with error: $($results.RawContent)" -Verbose
  Write-Error $($results.error)
}
else {
  Write-Output "Added permissions for storage account $StorageAccountName"

}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-ServiceBus-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Output "API Execution complete for Service Bus permission add."