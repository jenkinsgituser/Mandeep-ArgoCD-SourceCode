param
(
  [Alias("resourceGroupName")]
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup = $env:EH_RG_NAME,

  [Alias("namespace")]
  [Parameter(Mandatory = $false)]
  [string] $namespaceName = $env:EH_NAMESPACE,

  [Parameter(Mandatory = $true)]
  [string] $Identity,

  [Parameter(Mandatory = $false)]
  [string] $Permissions,

  [Parameter(Mandatory = $false)]
  [string] $eventHubName
)
$ErrorActionPreference = "Stop"

######################################################################################################
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################
# Get current subscription
$currentSub = (Get-AzContext).Subscription.Name

if ($eventHubName) {
  # get the Event Hub resource id
  $resourceId = $(az eventhubs eventhub show --resource-group $resourceGroup --namespace-name $namespaceName --name $eventHubName --query id -o tsv)
}
else {
  # get the Event Hubs namespace resource id
  $resourceId = $(az eventhubs namespace show --resource-group $resourceGroup --name $namespaceName --query id -o tsv)
}

$subscriptionDetails = Get-SubscriptionProperties -SubscriptionName $currentSub
$Environment = $subscriptionDetails.environment
if ($Environment -eq "Sandbox") {
  $Environment = "NonProd"
}

if (!$Permissions) {
  # Get the environment from the subscription.  Switch "Sandbox" to Non-Prod since there is only Prod/Non-Prod options

  if ($Environment = "NonProd") {
    $Permissions = "Azure Event Hubs Data Owner "
  }
  else {
    $Permissions = "Azure Event Hubs Data Receiver"
  }
}

$NewPermArray = @()
[array]$PermsArray = $Permissions.Split(",")
foreach ($Perm in $PermsArray) {
  $Perm = $Perm.Trim()
  $NewPermArray += $Perm
}

$jsonInput = @(
  @{
    Resources = @(
      @{
        ResourceId       = $resourceId
        PermissionsArray = @(
          @{
            Identity    = $Identity
            Permissions = @($NewPermArray)
          }
        )
      }
    )
  }
)

$jsonBody = $jsonInput | ConvertTo-Json -Depth 10

Write-Verbose "jsonBody is $($jsonBody)" -Verbose

$ssRbacApiUrl = "https://gw.developer.cunamutual.com/cmfg/prod-int/secure-cloud-rbac/v1/requestrbac?client_id=bd9821d84cbdbe986abd0e41739691a6"
# Retrieve token scoped to the SSRBAC api call for auth purposes
$ssRbacResourceUri = "https://securecloudrbacapi"
$token = (Get-AzAccessToken -ResourceUrl $ssRbacResourceUri).token


# Create auth header
$authHeader = @{
  "Authorization" = "Bearer " + $Token
}

Write-Verbose "About to call RBAC API" -Verbose
# Invoke Tiger's API
$results = Invoke-RestMethod -Uri $ssRbacApiUrl -Headers $authHeader -Method "POST" -Body $jsonBody -ContentType "application/json" -SkipHttpErrorCheck
Write-Verbose -Message "Rbac update via SSRBAC api service returned: $($results)" -Verbose

if ($results.statusCode -ne 200) {
  Write-Verbose "Rbac update via auth api service failed with error: $($results.RawContent)"
  Write-Error $($results.error)
}
else {
  Write-Verbose "Rbac update via auth api service completed successfully" -Verbose
}


# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-EventHubs-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Output "API Execution complete for Event Hubs permission add."