param
(
  [Alias("resourceGroupName")]
  [Parameter(Mandatory = $false)]
  [string] $resourceGroup = $env:EH_RG_NAME,

  [Alias("namespace")]
  [Parameter(Mandatory = $false)]
  [string] $namespaceName = $env:EH_NAMESPACE,

  [Parameter(Mandatory = $true)]
  [string] $eventHubName
)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

#Basic input validation
###############################################################################################
Write-Verbose "Loading repo utilties..." -Verbose

Write-AtlasSanitizeInputs

if ($null -eq $resourceGroup ) {
  Write-Error "Resource group not correctly passed in to script." -ErrorAction Stop
}
elseif ($null -eq $namespaceName) {
  Write-Error "Namespace name not correctly passed in to script." -ErrorAction Stop
}
elseif ($null -eq $eventHubName) {
  Write-Error "Event Hub name not correctly passed in to script." -ErrorAction Stop
}

Write-Verbose "Resource Group: $resourceGroup" -Verbose
Write-Verbose "Namespace: $namespaceName" -Verbose
Write-Verbose "Event Hub: $eventHubName" -Verbose

$eventHubs = $(az eventhubs eventhub list --resource-group $resourceGroup --namespace-name $namespaceName) | ConvertFrom-Json
if ($eventHubs.name -contains $eventHubName) {
  Write-Verbose "Event Hub $eventHubName already exists in namespace $namespaceName. No change made." -Verbose
}
else {
  #Build deployment variables
  ###############################################################################################
  Write-Verbose "Building deployment variables from runtime environment and Atlas defaults..." -Verbose

  $EVENT_HUB_MESSAGE_RETENTION = if ($env:EVENT_HUB_MESSAGE_RETENTION) { $env:EVENT_HUB_MESSAGE_RETENTION } else { 7 }
  Write-Verbose "EVENT_HUB_MESSAGE_RETENTION: $EVENT_HUB_MESSAGE_RETENTION" -Verbose

  $EVENT_HUB_PARTITION_COUNT = if ($env:EVENT_HUB_PARTITION_COUNT) { $env:EVENT_HUB_PARTITION_COUNT } else { 1 }
  Write-Verbose "EVENT_HUB_PARTITION_COUNT: $EVENT_HUB_PARTITION_COUNT" -Verbose

  #Execute deployment
  ###############################################################################################
  Write-Verbose "Executing create of event hub $eventHubName in namespace $namespaceName in resource group $resourceGroup..." -Verbose

  az eventhubs eventhub create --resource-group $resourceGroup `
    --namespace-name $namespaceName `
    --name $eventHubName `
    --message-retention $EVENT_HUB_MESSAGE_RETENTION `
    --partition-count $EVENT_HUB_PARTITION_COUNT `

}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "azureAddEventHub-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Event Hub deployment complete. See above for any potential errors. " -Verbose