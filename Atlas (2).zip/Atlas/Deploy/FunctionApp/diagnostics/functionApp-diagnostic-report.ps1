
param
(
    [Parameter (Mandatory = $false)]
    [string] $APP_RG_NAME = $env:APP_RG_NAME,

    [Parameter (Mandatory = $false)]
    [string] $APP_NAME = $env:APP_NAME

)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################
.("$env:COMMON_FOLDER/setupEnvironment.ps1")

<#
potential enhancement ideas:
these have not been issues in the past, but these checks could be added:
-add check to make sure function system assigned identity has secret Get access on keyvault
-add check to make sure function egress ip's are listed in keyvault network rules

#>

try {
  Write-Verbose "`n`n*** Starting functionApp validation ***`n" -Verbose
  # get AzureWebJobsStorage functionApp setting
  Write-Verbose "Get keyvault url from functionApp setting AzureWebJobsStorage" -Verbose
  $appSettings = az functionapp config appsettings list --name $APP_NAME --resource-group $APP_RG_NAME | ConvertFrom-Json
  $AzureWebJobsStorageValue = ($appSettings | Where-Object {$_.name -match "AzureWebJobsStorage" }).value
  # extract keyvault url from functionApp setting

  $kvUrl = ($AzureWebJobsStorageValue.split("=")[1]).trim(")")
  $kvName = $kvUrl.split("/")[2]
  Write-Verbose "keyvault name referenced in functionApp setting AzureWebJobsStorage: `n $kvName" -Verbose
  Write-Verbose "keyvault url referenced in functionApp setting AzureWebJobsStorage: `n $kvUrl" -Verbose

  Write-Verbose "Retrieve storage account key value from keyvault" -Verbose
  $secret = az keyvault secret show --id $kvUrl | ConvertFrom-Json
  if (!$?) {
    throw "error retrieving keyvault secret - see messages in log above for details"
  }
  $saName = (($secret.value).Split(";") -match "AccountName").split("=")[1]
  $saKeyInKeyvault = (($secret.value).split(";")[2]).replace("AccountKey=","")
  Write-Verbose "Determined storage account referenced in keyvault secret is: $saName" -Verbose

  # check storage account key found in keyvault to verify length as indicator that it is valid
  if (($saKeyInKeyvault).Length -gt 20) {
    Write-Verbose "SUCCESS - The storage key value in the keyvault has a length greater than 20, so it is expected to be a valid key, but will be validated next." -Verbose
  } else {
    $errorMsg = "FAILURE - Based on the length of the value found, it appears the storage key value in the keyvault is invalid, we'll validate it next anyway."
    Write-Warning $errorMsg
  }

  # get storage account keys
  Write-Verbose "Check storage account keys to verify storage key in keyvault is valid" -Verbose
  $saKeys = az storage account keys list -g $APP_RG_NAME -n $saName | ConvertFrom-Json
  # check SA keys for the key found in keyvault
  if (($saKeys.value).contains($saKeyInKeyvault)) {
    Write-Verbose "SUCCESS - Storage key value in keyvault matches one of the Storage Keys." -Verbose
  } else {
    $errorMsg = "FAILURE - Storage key value in keyvault DOES NOT match any of the Storage Keys."
    Write-Warning $errorMsg
    throw $errorMsg
  }
} catch {
  if ($null -ne $errorMsg) {
    # this means we are throwing an error we identified in the config rather than a script error
    Write-Warning "If there were FAILURE's reported, you can try rotating your function app storage account key which should get
    the functionApp setting (AzureWebJobsStorage), keyvault and storage account configured properly again.

    See this wiki page for the deployment script to rotate the key:
    Rotating Your Function App Storage Account Keys
    https://dev.azure.com/cunamutual/SecureCloudEnablement/_wiki/wikis/Atlas%20Wiki%20V2/1515/Rotating-Your-Function-App-Storage-Account-Keys
    "
  }
  throw $_
}


