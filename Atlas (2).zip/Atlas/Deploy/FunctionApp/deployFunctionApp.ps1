﻿#**********************************************************
# Get Azure DevOps Release Pipeline Variables
#**********************************************************
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################


Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

Write-Verbose "Atlantis-utilities.ps1 is executing" -Verbose
. ("$COMMON_FOLDER/Atlantis-utilities.ps1")
Write-Verbose "gateway-utilities.ps1 is executing" -Verbose
. ("$COMMON_FOLDER/gateway-utilities.ps1")
Write-Verbose "Atlas-CommonCode.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")
Write-Verbose "functionAppVariables.ps1 is executing" -Verbose
. ("$INFRA_FOLDER/FunctionApp/src/functionAppVariables.ps1")
Write-Verbose "functionAppExternalValidations.ps1 is executing" -Verbose
. ("$INFRA_FOLDER/FunctionApp/src/functionAppExternalValidations.ps1")


#validate is RG is Atlas - not supporting force flag due to Atlantis network usage
Validate-DeploymentRGIsAtlas -resourceGroup $APP_RG_NAME -forceFlag $false

#**********************************************************
# Deploy infrastructure
#**********************************************************
# aspExists is defined in the webAppExternalValidations file
if (!$aspExists) {
    Write-Verbose "Deploying App Service Plan..." -Verbose
    # Added the following If statement because the Start Job command changed from PS 5 to PS 6
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $aspJob = Start-ThreadJob -Name "ASP-Deploy" `
            -FilePath "$env:ATLAS_REPO_ROOT/Deploy/AppServicePlan/deployAppServicePlan.ps1"
    }
    else {
        $aspJob = Start-Job -Name "ASP-Deploy" `
            -LiteralPath "$env:ATLAS_REPO_ROOT/Deploy/AppServicePlan/deployAppServicePlan.ps1"
    }

    Write-Verbose "App Service Plan Deploy Initiated." -Verbose
}
else {
    Write-Verbose "ASP '$($env:ASP_NAME)' already exists. No modifications to its configuration will be made from this deployment." -Verbose
}

Write-Verbose "Deploying Key Vault..." -Verbose
Write-Verbose "Deploying App Insights..." -Verbose
Write-Verbose "Deploying Storage Account..." -Verbose

# Reset location to Atlas Root folder if ATLAS_REPO_ROOT already set
if ($env:ATLAS_REPO_ROOT) {
    Set-Location $env:ATLAS_REPO_ROOT
}

$VerbosePreference = "Continue"  # need this set so that verbose output is returned from Start-ThreadJob

if ($PSVersionTable.PSVersion.Major -ge 6) {
    $kvJob = Start-ThreadJob -Name "KV-Deploy" `
        -FilePath "$env:DEPLOY_FOLDER/KeyVault/deployKeyVault.ps1"

    $aisJob = Start-ThreadJob -Name "AIS-Deploy" `
        -FilePath "$env:DEPLOY_FOLDER/AppInsights/deployAppInsights.ps1"

    $saJob = Start-ThreadJob -Name "SA-Deploy" `
        -FilePath "$env:DEPLOY_FOLDER/StorageAccount/deployStorageAccount.ps1"
}
else {
    $kvJob = Start-Job -Name "KV-Deploy" `
        -LiteralPath "$env:DEPLOY_FOLDER/KeyVault/deployKeyVault.ps1"

    $aisJob = Start-Job -Name "AIS-Deploy" `
        -LiteralPath "$env:DEPLOY_FOLDER/AppInsights/deployAppInsights.ps1"

    $saJob = Start-Job -Name "SA-Deploy" `
        -LiteralPath "$env:DEPLOY_FOLDER/StorageAccount/deployStorageAccount.ps1"
}

Write-Verbose "Key Vault Deploy Initiated." -Verbose
Write-Verbose "App Insights Deploy Initiated." -Verbose
Write-Verbose "Storage Account Deploy Initiated." -Verbose

# write the output of the jobs to the console
Wait-JobCompletion -job $aisJob
Wait-JobCompletion -job $kvJob
Wait-JobCompletion -job $saJob

# only await the ASP job if it exists
if ($aspJob) {
    Wait-JobCompletion -job $aspJob
}

# Pre-requisite jobs are now complete. Proceed to Function App stuff.
#####################################################################################
Write-Verbose "Verify or Wait for the Existence of the App Service Plan" -Verbose
$asp = Invoke-CommandWithRetries -Command "az appservice plan show --name $env:ASP_NAME --resource-group $env:ASP_RG_NAME" -LineNumber $MyInvocation.ScriptLineNumber

if (!$asp) {
    Write-Error "Unable to verify the existence of App Service Plan '$env:ASP_NAME' in Resource Group '$env:ASP_RG_NAME'."
    Exit 1
}

Write-Verbose "Getting Temporary Network Connection to Key Vault" -Verbose
Get-NetworkConnectionToKV -keyvault $env:KV_NAME

Write-Verbose "Executing Pre-deployment..." -Verbose
. (Join-Path $env:INFRA_FOLDER "/FunctionApp/src/preFunctionApp.ps1")
Write-Verbose "Pre-deployment complete." -Verbose

Write-Verbose "Deploying Function App..." -Verbose
. (Join-Path $env:INFRA_FOLDER "/FunctionApp/src/functionApp.ps1")
Write-Verbose "Function App Deployed." -Verbose

Write-Verbose "Executing Post-deployment..." -Verbose
. (Join-Path $env:INFRA_FOLDER "/FunctionApp/src/postFunctionApp.ps1")
Write-Verbose "Post-deployment complete." -Verbose

# We don't want to remove our current connection if we're local and on-prem, as
# that'll undo one of our expected IP rules
if (!$env:IsLocal) {
    Write-Verbose "Removing Temporary Network Connection to Key Vault" -Verbose
    Remove-NetworkConnectionToKV -keyvault $env:KV_NAME
}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "deployFunctionApp-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes