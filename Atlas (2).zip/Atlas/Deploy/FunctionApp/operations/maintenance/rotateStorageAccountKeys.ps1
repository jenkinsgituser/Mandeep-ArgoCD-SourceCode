param
(
  [Parameter(Mandatory = $true)]
  [string] $functionApp,

  [Parameter(Mandatory = $true)]
  [string] $resourceGroup
)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

$TargetResourceSubscription = $(Get-AzContext).Subscription.Name

$Params = @{
  subscription      = $TargetResourceSubscription
  resourceGroup     = $resourceGroup
  functionApp       = $functionApp
  RunAsHybridWorker = $false
}

Write-Verbose "Rotating storage account key for function app  $($functionApp)" -Verbose

#find and source the runbook
##########################################
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-RotateFunctionAppStorageKey" -Parameters $Params

#restore current subscription after runbook execution changes it
Set-AzContext -Subscription $TargetResourceSubscription | Out-Null

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "rotateStorageAccountKeys-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Runbook Execution complete for Storage Account key rotation." -Verbose
