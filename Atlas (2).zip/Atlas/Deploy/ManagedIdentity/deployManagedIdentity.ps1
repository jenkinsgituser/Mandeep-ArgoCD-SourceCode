param(
  [Parameter(Mandatory = $false)]
  [string] $IDENTITY_NAME,

  [Parameter(Mandatory = $false)]
  [string] $IDENTITY_RG_NAME,

  [Parameter(Mandatory = $false)]
  [string] $IDENTITY_OPERATOR,

  [Parameter(Mandatory = $false)]
  [string] $IDENTITY_LOCATION,

  [Parameter(Mandatory = $false)]
  [bool] $FORCE_NONATLAS_DEPLOY = $false

)

if ($IDENTITY_NAME) { $env:IDENTITY_NAME = $IDENTITY_NAME }
if ($IDENTITY_RG_NAME) { $env:IDENTITY_RG_NAME = $IDENTITY_RG_NAME }
if ($IDENTITY_OPERATOR) { $env:IDENTITY_OPERATOR = $IDENTITY_OPERATOR }
if ($IDENTITY_LOCATION) { $env:IDENTITY_LOCATION = $IDENTITY_LOCATION }


######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }
  ######################################################################################

  #validate is RG is Atlas
  Validate-DeploymentRGIsAtlas -resourceGroup $env:IDENTITY_RG_NAME -forceFlag $FORCE_NONATLAS_DEPLOY
  
  #deploy app gateway
  . ("$INFRA_FOLDER/ManagedIdentity/src/ManagedIdentity.ps1")

  # telemetry completion
  ######################################################################################
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "deployManagedIdentity-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
  Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
  Log-TelemetryException -exception $_.
}