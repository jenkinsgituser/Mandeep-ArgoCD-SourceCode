﻿#**********************************************************
# Get Azure DevOps Release Pipeline Variables
#**********************************************************

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

Write-Verbose "Atlantis-utilities.ps1 is executing" -Verbose
. ("$COMMON_FOLDER/Atlantis-utilities.ps1")
Write-Verbose "gateway-utilities.ps1 is executing" -Verbose
. ("$COMMON_FOLDER/gateway-utilities.ps1")
Write-Verbose "Atlas-CommonCode.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

# Peform input validation prior to executing each of the following deployments
Write-Verbose "Validating deployment variables..." -Verbose
. (Join-Path $env:ATLAS_REPO_ROOT "Infra/WebApp/src/webAppVariables.ps1")
. (Join-Path $env:ATLAS_REPO_ROOT "Infra/WebApp/src/webAppExternalValidations.ps1")
Write-Verbose "Inputs validated. Deployment proceeding..." -Verbose

#**********************************************************
# Tag the parent RG with the version
#**********************************************************

#validate is RG is Atlas - not supporting force flag due to Atlantis network usage
Validate-DeploymentRGIsAtlas -resourceGroup $APP_RG_NAME -forceFlag $false

#**********************************************************
# Deploy infrastructure
#**********************************************************

Write-Verbose "Deploying App Insights..." -Verbose
. (Join-Path $env:ATLAS_REPO_ROOT "Deploy/AppInsights/deployAppInsights.ps1")

#aspExists is defined in the webAppExternalValidations file
if (!$aspExists) {
  Write-Verbose "Deploying App Service Plan..." -Verbose
  . (Join-Path $env:ATLAS_REPO_ROOT "Deploy/AppServicePlan/deployAppServicePlan.ps1")
}
else {
  Write-Verbose "ASP '$($env:ASP_NAME)' already exists. No modifications to its configuration will be made from this deployment." -Verbose
}

# TODO: AIS and ASP can be deployed in parallel. This was working from
# a container but broke on my local machine (mdx7683). Should be trivial to fix.
<#
#$AisJob = Start-Job -Name "AIS-Deploy" -LiteralPath (Join-Path $env:ATLAS_REPO_ROOT "Deploy/AppInsights/deployAppInsights.ps1") -ArgumentList $AisParms
#$AspJob = Start-Job -Name "ASP-Deploy" -LiteralPath (Join-Path $env:ATLAS_REPO_ROOT "Deploy/AppServicePlan/deployAppServicePlan.ps1") -ArgumentList $AspParms
Wait-JobCompletion $AisJob
Write-Verbose "App Insights Deployed." -Verbose

Wait-JobCompletion $AspJob
Write-Verbose "App Service Plan Deployed." -Verbose
#>

Write-Verbose "Executing pre deploy..." -Verbose
. (Join-Path $env:ATLAS_REPO_ROOT "Infra/WebApp/src/preWebApp.ps1")
Write-Verbose "Deployment complete." -Verbose

# Web App needs to be deployed after other things exist
Write-Verbose "Deploying Web App..." -Verbose
. (Join-Path $env:ATLAS_REPO_ROOT "Infra/WebApp/src/webApp.ps1")
Write-Verbose "Web App Deployed." -Verbose

Write-Verbose "Executing post deploy..." -Verbose
. (Join-Path $env:ATLAS_REPO_ROOT "Infra/WebApp/src/postWebApp.ps1")
Write-Verbose "Deployment complete." -Verbose

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "deployWebApp-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
