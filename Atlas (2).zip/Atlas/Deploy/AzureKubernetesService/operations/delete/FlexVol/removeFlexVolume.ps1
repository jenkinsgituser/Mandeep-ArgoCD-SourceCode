param (
    [Parameter(Mandatory = $true)]
    [string] $ResourceGroup,

    [Parameter(Mandatory = $true)]
    [string] $AKSCluster
)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    ######################################################################################

    az aks get-credentials -n $AKSCluster -g $ResourceGroup -a --overwrite-existing | Out-Null

    Write-Verbose "Deleting Flex Volume from cluster..." -Verbose
    $ErrorActionPreference = "Continue"
    $flexVolNamespace = kubectl get ns kv 2> $null
    if ($flexVolNamespace) {
        kubectl delete ns kv
        Write-Verbose "Successfully Deleted Flex Volume" -Verbose
    }
    else {
        Write-Verbose -Verbose "Default FlexVol namespace 'kv' could not be found on cluster. No action was taken."
    }

    # telemetry completion
    ######################################################################################
    $stopwatch.Stop()
    Write-AtlasTelemetryMetric -Name "removeFlexVolume-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
    Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
    Write-Error "An error occurred while removing FlexVol."
}
finally {
    if (Test-Path -Path "$env:HOME/.kube/config") {
        Write-Verbose "`t Removing kubectl config file from '$env:HOME/.kube/config'" -Verbose
        Remove-Item -Path "$env:HOME/.kube/config"
    }
    else {
        Write-Verbose "`t Kubectl config file does not exist at '$env:HOME/.kube/config' and could not be removed." -Verbose
        exit 1
    }
}

