﻿<#
    This script will either restart one specific node or all nodes in the specified node pool in a version 1.18+ cluster.  If the RestartType
    is set to "Force" all nodes in the cluster will be simultaneously restarted, otherwise each will be restarted one at a time.
    To restart each node one at a time the following process will execute:
        1) Scale the node pool up one additional node so the reboots do not impact the cluster performance
        2) Reboot each node, one at a time
        3) Wait 10 seconds after each reboot to allow the node to become active
        4) After all reboots complete, scale the cluster back down by one node.
#>

param (
    [Parameter(Mandatory = $true)]
    [string] $ResourceGroup,
    [Parameter(Mandatory = $true)]
    [string] $AKSCluster,
    [Parameter(Mandatory = $true)]
    [string] $NodePool,
    [Parameter(Mandatory = $false)]
    [string] $SpecificNode,
    [Parameter(Mandatory = $false)]
    [string] $RestartType = "Rolling",
    [Parameter(Mandatory = $false)]
    [string] $PodName,
    [Parameter(Mandatory = $false)]
    [int] $Timeout = 7200
)

function RestartAllNodes {
    param(
        [Parameter(Mandatory = $true)]
        [string] $MCGroupName,
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string] $AKSCluster,
        [Parameter(Mandatory = $true)]
        [string[]] $VMSSNames,
        [Parameter(Mandatory = $true)]
        [string] $NodePool,
        [Parameter(Mandatory = $true)]
        [string] $RestartType,
        [Parameter(Mandatory = $false)]
        [string] $CurrentNode
    )

    try {
        # Initialize status to failure to prevent reporting success in case we break in the middle of an iteration.
        $restartAllNodes_Status = "Failed"
        # If the RestartType is Force then restart all nodes in the node pool
        if ($RestartType -eq "Force") {
            # Loop through the node pools until you find the specified one and restart it
            foreach ($vm in $VMSSNames) {
                if ($vm -match "atlasagent") {
                    Write-AtlasOutput -Loglevel "INFO" -Message "`t ***** You can not do a Force restart of the 'atlasagent' nodepool, exiting *****" 
                    $restartAllNodes_Status = "Succeeded"
                    break
                }
                if ($vm -match $NodePool) {
                    $restartResult = Restart-AzVmss -ResourceGroupName $MCGroupName -VMScaleSetName $vm
                    Write-AtlasOutput -Loglevel "INFO" -Message "`t Restart of nodepool $($NodePool) $($restartResult.Status)"
                    $restartAllNodes_Status = $restartResult.Status
                    If ($restartAllNodes_Status -ne "Succeeded") {
                        Write-AtlasOutput -LogLevel "ERROR" -Message "Restart of nodepool $($NodePool) failed...throwing error"
                        throw
                    }
                }
            }
            if ($restartAllNodes_Status -eq "Succeeded") {
                Return $true
            }
            else {
                Return $false
            }
        }
        else {
            # Verify the optional Timeout variable isn't set too high. If it is, set it to 10 hours.
            Write-AtlasOutput -LogLevel "INFO" -Message "The Timeout is set to: $($Timeout) seconds"
            if ($Timeout -gt 36000)
            {
                Write-AtlasOutput -Loglevel "WARN" -Message "The given Timeout period is too long (greater than 10 hours). Setting the timeout to 10 hours. Please use a shorter timeframe or opt for the Force restart option."
                $Timeout = 36000
            }

            [INT] $startingNodeCount = 0

            # Loop through all nodes in the node pool and and restart them individually
            # Write-AtlasOutput -Loglevel "INFO" -Message "Getting current number of nodes in the node pool before adding a node"
            Write-AtlasOutput -Loglevel "INFO" -Message "Checking if Auto Scaling is Enabled"
            $nodePoolInfo = az aks nodepool show --cluster-name $AKSCluster --name $NodePool --resource-group $ResourceGroupName | ConvertFrom-Json

            $infobefore = kubectl get nodes -o json | ConvertFrom-Json
            
            if(!$infobefore) {
                Write-Verbose "Encountered a network error. Exiting..." -Verbose
                throw
            }

            if ($($nodePoolInfo.enableAutoScaling) -eq $false) {
                Write-AtlasOutput -Loglevel "INFO" -Message "Auto Scaling is NOT Enabled"
                Write-AtlasOutput -Loglevel "INFO" -Message "Current number of nodes in the node pool: $($nodePoolInfo.count)"
                $startingNodeCount = $nodePoolInfo.count
                $scaleUpNodeCount = $startingNodeCount + 1
                Write-AtlasOutput -Loglevel "INFO" -Message "Adding 1 node to the node pool, please wait..."

                $scaleResult = ScaleNodes -NodePool $NodePool -AKSCluster $AKSCluster -ResourceGroupName $ResourceGroupName -OriginalNodeCount $startingNodeCount -NewNodeCount $scaleUpNodeCount

                if ($scaleResult) {
                    # Scale operation succeeded...continue
                    Write-AtlasOutput -Loglevel "INFO" -Message "Successful scale operation...continuing"
                }
                else {
                    Write-AtlasOutput -Loglevel "ERROR" -Message "Unsuccessful scale operation...exiting"
                    throw
                }
            }
            else {
                Write-AtlasOutput -Loglevel "INFO" -Message "Auto Scaling is Enabled, not adding a node to the pool"
            }

            # Cycle through the list of nodes in $infobefore.items.metadata.name and reboot each one
            Write-AtlasOutput -Loglevel "INFO" -Message "Cycling through nodes in nodepool: $($NodePool)"

            $nodesFailedToRestart = @()

            Foreach ($node in $infobefore.items) {
                # Skip restarting the VM the restart process is running on
                if ($node.metadata.name -eq $CurrentNode) {
                    Write-AtlasOutput -Loglevel "INFO" -Message "`t ***** Skipping restart of node: $($node.metadata.name)"
                }
                else {
                    # Extract name of the Virtual Machine Scale Set (VMSS) from the array in the 10th position
                    $VMSSName = $node.spec.providerid.Split("/")[10]

                    if ($VMSSName -match "$NodePool") {
                        # Extract the instanceId from the array in the 12th position
                        $instanceId = $node.spec.providerid.Split("/")[12]
                        # Build the name of the node instance from the VMSS name and the instanceid
                        $nameOfNode = -join ($VMSSName, "_", $instanceId)

                        ## The drain gives us expected warnings because of daemonsets, so we need to temporarily
                        ##  set the ErrorActionPreference to SilentlyContinue
                        $origErrorActionPreference = $errorActionPreference
                        $errorActionPreference = "SilentlyContinue"
                        
                        $timer = [Diagnostics.Stopwatch]::StartNew()

                        Write-AtlasOutput -Loglevel "INFO" -Message "`t Draining node $($node.metadata.name) so pods can gracefully terminate"
                        $drainInfo = kubectl drain $node.metadata.name --ignore-daemonsets --delete-emptydir-data --timeout=$($Timeout)s 2> $null         
                        Write-Verbose "Drain Info Details: $($drainInfo)" -Verbose
                        $timer.Stop();
                        if ($timer.Elapsed.Seconds -ge $Timeout) {
                            Write-Verbose "Node Drain timed out. Force restarting and continuing." -Verbose
                        }

                        ## With a successful drain, add back
                        $errorActionPreference = $origErrorActionPreference
                        Write-AtlasOutput -Loglevel "INFO" -Message "`t Restarting node instance $($nameOfNode)"
                        $nodeRestartResult = Restart-AzVmss -ResourceGroupName $MCGroupName -Name $VMSSName -InstanceId $instanceId

                        Write-AtlasOutput -Loglevel "INFO" -Message  "`t `t Sleeping 10 Seconds to allow VM to complete the restart"
                        Start-Sleep -Seconds 10

                        Write-AtlasOutput -Loglevel "INFO" -Message "`t Restart result for node instance - $($nameOfNode): $($nodeRestartResult.Status)"
                        $restartNode_Status = $nodeRestartResult.Status

                        Write-AtlasOutput -Loglevel "INFO" -Message "`t Uncordoning node $($nameOfNode) so pods can be scheduled."
                        kubectl uncordon $node.metadata.name

                        if ($restartNode_Status -eq "Failed") {
                            Write-AtlasOutput -Loglevel "ERROR" -Message "Node $($node) failed to restart...adding it to failed list"
                            # Node failed to restart so append it to the failed array
                            $nodesFailedToRestart += $node
                        }
                    }
                }
            }
            Write-AtlasOutput -Loglevel "INFO" -Message "Finished restarting the nodes in nodepool $($NodePool)."

            Write-AtlasOutput -Loglevel "INFO" -Message "Removing the node from the cluster that was added earlier ..."

            $scaleResult = ScaleNodes -NodePool $NodePool -AKSCluster $AKSCluster -ResourceGroupName $ResourceGroupName -OriginalNodeCount $scaleUpNodeCount -NewNodeCount $startingNodeCount

            if ($scaleResult) {
                Write-AtlasOutput -Loglevel "INFO" -Message "Scale down operation was successful...continuing"
            }
            else {
                Write-AtlasOutput -Loglevel "WARN" -Message "Scale down operation failed...unable to return node count to $($startingNodeCount)"
            }

            if ($nodesFailedToRestart.count -ne 0) {
                Write-AtlasOutput -Loglevel "ERROR" -Message "Failure restarting the following nodes:"
                foreach ($failedNode in $nodesFailedToRestart) {
                    Write-AtlasOutput -Loglevel "ERROR" "`t $failedNode"
                }
                throw
            }
            else {
                Return $true
            }
        }
    }
    catch {
        Write-Verbose "Failed to restart nodes!" -Verbose
        # Check to see if the failure occured before or during/after scaling.
        if(!$infobefore) {
            # A Network error occurred getting the cluster info
            Write-AtlasOutput -Loglevel "INFO" -Message "Kubectl command encountered a network error. You may be using an unauthorized IP Address."
        } else {
            # Check current nodes to be sure we didn't scale up and leave it there.
            Write-AtlasOutput -Loglevel "INFO" -Message "Checking that we have returned to the original node count of $($startingNodeCount)"
            
            $nodePoolInfo = az aks nodepool show --cluster-name $AKSCluster --name $NodePool --resource-group $ResourceGroupName | ConvertFrom-Json
            if ($nodePoolInfo.count -gt $startingNodeCount) {
                # Nodes are higher than when we started so try to scale back down before exiting.
                Write-AtlasOutput -Loglevel "INFO" -Message "Current node count is greater than starting node count...attempting to scale back down"
                $scaleResult = ScaleNodes -NodePool $NodePool -AKSCluster $AKSCluster -ResourceGroupName $ResourceGroupName -OriginalNodeCount $nodePoolInfo.count -NewNodeCount $startingNodeCount
                if ($scaleResult) {
                    Write-AtlasOutput -Loglevel "INFO" -Message "Node count returned to original number of $($nodePoolInfo.count)"
                }
                else {
                    Write-AtlasOutput -Loglevel "ERROR" -Message "Unable to return node count to $($startingNodeCount)"
                }
            }
        }
        # Now that we've scaled back down, we can print the error message and fail the task.
        Write-AtlasOutput -Loglevel "ERROR" -Message "An error occurred attempting to restart nodes! $($_.Exception.Message)"
        Return $False
    }
}

function ScaleNodes {
    param(
        [Parameter(Mandatory = $true)]
        [string] $NodePool,
        [Parameter(Mandatory = $true)]
        [string] $AKSCluster,
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [int] $OriginalNodeCount,
        [Parameter(Mandatory = $true)]
        [int] $NewNodeCount
    )

    try {
        $nodePoolInfo = (az aks nodepool show --cluster-name $AKSCluster --name $NodePool --resource-group $ResourceGroupName) | ConvertFrom-Json
        if ($($nodePoolInfo.enableAutoScaling) -eq $false) {
            Write-AtlasOutput -Loglevel "INFO" -Message "Scaling node $($NodePool) from $($OriginalNodeCount) to $($NewNodeCount)"

            $scaleinfo = $(az aks scale --resource-group $ResourceGroupName  --name $AKSCluster --node-count $newNodeCount  --nodepool-name $NodePool) | ConvertFrom-Json
            if ($scaleinfo) {
                Write-AtlasOutput -Loglevel "INFO" -Message "Scale operation result was successful"
                $nodePoolInfo = az aks nodepool show --cluster-name $AKSCluster --name $NodePool --resource-group $ResourceGroupName | ConvertFrom-Json
                Write-AtlasOutput -Loglevel "INFO" -Message "Number of nodes after scale operation is: $($nodePoolInfo.Count)"
                Return $true
            }
            else {
                Write-AtlasOutput -Loglevel "ERROR" -Message "Node Scaling Operation Failed"
                throw
            }
        }
        else {
            Write-AtlasOutput -Loglevel "INFO" -Message "Auto Scaling is enabled on this nodepool, we will not add/remove a node to the pool"
        }

    }
    catch {
        Write-AtlasOutput -Loglevel "ERROR" -Message "Failed to scale node pool $($NodePool) to $($NewNodeCount)"
        Return $False
    }
}

function RestartSpecificNode {
    param(
        [Parameter(Mandatory = $true)]
        [string] $NodeId,
        [Parameter(Mandatory = $true)]
        [string] $NodePool,
        [Parameter(Mandatory = $true)]
        [string] $ResourceGroupName,
        [Parameter(Mandatory = $true)]
        [string[]] $VMScaleSetNames

    )


    Try {
        foreach ($vmss in $VMScaleSetNames) {
            if ($vmss -match $NodePool) {
                Write-AtlasOutput -Loglevel "INFO" -Message "Restarting node $($NodeId) in VMScaleSet $($vmss) for ResourceGroup $($ResourceGroupName)"
                $Result = (Restart-AzVmss -ResourceGroupName $ResourceGroupName -VMScaleSetName $vmss -InstanceId $NodeId)
                Write-AtlasOutput -Loglevel "INFO" -Message "Result of restart operation is: $($Result.status)"
                if ($Result.status -eq "Succeeded") {
                    Return $true
                }
            }
        }
    }
    Catch {
        Write-AtlasOutput -Loglevel "ERROR" -Message "An error occurred restarting specific node:$($Node)! $($_.Exception.Message)"
        Return = $false
    }
}

#####################################################################################
#  Main Script
#####################################################################################
Write-Verbose "Starting Time (UTC): $(Get-Date)"  -Verbose

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
    . ($SetupHostPath + "/SetupHost.ps1")
}
else {
    . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    ######################################################################################

    # get credentials
    Write-AtlasOutput -Loglevel "INFO" -Message "Getting Credentials..."
    az aks get-credentials -n $AKSCluster -g $ResourceGroup -a --overwrite-existing | Out-Null

    $DefaultProfile = Get-AzContext

    $strDefaultProfileName = $DefaultProfile.Subscription.Name

    Write-AtlasOutput -Loglevel "INFO" -Message "Default profile is $($strDefaultProfileName)"

    $CurrentNode = $null
    # Get the current node this process is running on if on atlasagent pool from the pod name passed in
    if ($NodePool -eq "atlasagent") {
        Write-AtlasOutput -Loglevel "INFO" -Message "Pod Name Passed in: $PodName"
        $CurrentNode = ($(kubectl get pods $PodName -n "atlashostedagent" -o=json) | ConvertFrom-Json).spec.nodeName
        Write-AtlasOutput -Loglevel "INFO" -Message "This process is running on node: $CurrentNode"
    }

    # Get the MC group Name
    Write-AtlasOutput -Loglevel "INFO" -Message "Getting MC Group Name"

    $MCGroupName = (Get-AzAksCluster -ResourceGroupName $ResourceGroup -Name $AKSCluster).NodeResourceGroup

    Write-AtlasOutput -Loglevel "INFO" -Message "MCName is $MCGroupName"

    # Get the Node Pool Scale sets
    Write-AtlasOutput -Loglevel "INFO" "Getting Virtual Machine Scale Set Names"
    $VMSSNames = (Get-AzVmss -ResourceGroupName $MCGroupName -DefaultProfile $DefaultProfile).Name
    if ($VMSSNames) {
        Write-AtlasOutput -Loglevel "INFO" -Message "Virtual Machine Scale Set Names: $($VMSSNames -join ",")"

        $SpecificNodeRestarted = $False
        $allNodesRestarted = $False

        if ($SpecificNode) {
            Write-AtlasOutput -Loglevel "INFO" -Message "Restarting specific Node - $($SpecificNode)"

            $SpecificNodeRestarted = RestartSpecificNode -NodeId $SpecificNode -NodePool $NodePool  -VMScaleSetNames $VMSSNames -ResourceGroupName $MCGroupName
            if ($SpecificNodeRestarted) {
                Write-AtlasOutput -Loglevel "INFO" -Message "Specific Node Restart for Node $($SpecificNode) was successful"
            }
            else {
                Write-AtlasOutput -Loglevel "ERROR" -Message "Specific Node Restart for Node $($SpecificNode) failed"
                throw
            }
        }
        else {
            # A specific node was not specified for restart so restart all nodes in the node pool
            Write-AtlasOutput -Loglevel "INFO" -Message "RestartType is $($RestartType)"

            Write-AtlasOutput -Loglevel "INFO" -Message "Restarting all Nodes in $NodePool"

            $allNodesRestarted = RestartAllNodes -MCGroupName $MCGroupName `
                -ResourceGroupName $ResourceGroup `
                -AKSCluster $AKSCluster `
                -VMSSNames $VMSSNames `
                -NodePool $NodePool `
                -RestartType $RestartType `
                -CurrentNode $CurrentNode

            if ($allNodesRestarted) {
                Write-AtlasOutput -Loglevel "INFO" -Message "Restarting all nodes for NodePool $($NodePool) was successful"
            }
            else {
                Write-AtlasOutput -Loglevel "ERROR" -Message "Restarting all nodes for NodePool $($NodePool) failed"
                throw
            }
        }
    }
    else {
        Write-AtlasOutput -Loglevel "ERROR" -Message "Virtual Machine ScaleSet nodes for resource group $($MCGroupName)  not found"
        throw
    }
}
catch {
    Write-Verbose "The exception identified is: $($_.Exception.Message) " -Verbose
    if ($($_.Exception.Message).Contains("as current context in")) {
        Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
    }
    else {
        Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
        Write-AtlasOutput -Loglevel "ERROR" -Message "An error occurred during processing! $($_.Exception.Message)"
    }

}
finally {
    if (Test-Path -Path "$USERPROFILE/.kube/config") {
        Write-AtlasOutput -Loglevel "INFO" -Message "`t Removing kubectl config file from '$USERPROFILE/.kube/config'"
        Remove-Item -Path "$USERPROFILE/.kube/config"
    }
    else {
        Write-AtlasOutput -Loglevel "WARN" -Message "`t Kubectl config file does not exist at '$USERPROFILE/.kube/config' and could not be removed."
    }
}

Write-AtlasOutput -Loglevel "INFO" -Message "Completed Time (UTC): $(Get-Date)"
Write-AtlasOutput -Loglevel "INFO" -Message "Each node in the cluster has been rebooted.  Process has been completed."