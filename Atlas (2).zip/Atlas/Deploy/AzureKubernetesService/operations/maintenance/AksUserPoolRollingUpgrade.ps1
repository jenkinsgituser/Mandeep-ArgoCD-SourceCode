﻿param (
    [Parameter(Mandatory = $true)]  [string] $ResourceGroup,
    [Parameter(Mandatory = $true)]  [string] $AKSCluster,
    [Parameter(Mandatory = $true)]  [string] $AKSNodePool,
    [Parameter(Mandatory = $false)] [string] $AKSVersion
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

Write-Verbose "Atlas-CommonCode.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")

try {
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    $controlPlaneVersion = az aks show --name $AKSCluster --resource-group $ResourceGroup --query "kubernetesVersion" -o json
    $controlPlaneVersion = $controlPlaneVersion -replace '"', ""
    $currentVersion = az aks nodepool show --cluster-name $AKSCluster --name $AKSNodePool --resource-group $ResourceGroup --query "orchestratorVersion" -o json
    $currentVersion = $currentVersion -replace '"', ""

    Write-AtlasOutput -Message "`t Existing control plane version: $controlPlaneVersion"
    Write-AtlasOutput -Message "`t Existing node pool version: $currentVersion"

    if ($AKSVersion) {
        Write-AtlasOutput -Message "`t Requested version to upgrade to: $AKSVersion"
    }
    else {
        Write-AtlasOutput -Message "`t No specified version, attempting to upgrade to $controlPlaneVersion"
    }

    $upgrades = az aks nodepool get-upgrades --cluster-name $AKSCluster --nodepool-name $AKSNodePool --resource-group $ResourceGroup | ConvertFrom-Json

    $availableUpgrades = @()
    foreach ($upgrade in $upgrades.upgrades) {
        if ($null -eq $upgrade.isPreview) {
            $availableUpgrades += $upgrade.kubernetesVersion
        }
    }

    Write-AtlasOutput -Message "`t Available upgrades: $($availableUpgrades -join ", ")"
    $versionToUpgrade = $null

    if ($AKSVersion) {
        if ($availableUpgrades -notcontains $AKSVersion) {
            Write-AtlasOutput -Message "Error: Passed in version $($AKSVersion) is not available to upgrade." -LogLevel "ERROR"
        }
        if ([version]('{0}.{1}.{2}' -f $AKSVersion.split('.')) -gt [version]('{0}.{1}.{2}' -f $controlPlaneVersion.split('.'))) {
            Write-AtlasOutput -Message "Error: Passed in version $($AKSVersion) is greater than your control plane version. Upgrade your control plane to specified version first." -LogLevel "ERROR"
        }
        Write-AtlasOutput -Message "`t Setting upgrade version to $AKSVersion."
        $versionToUpgrade = $AKSVersion
    }
    else {
        Write-AtlasOutput -Message "`t Setting upgrade version to control plane version $controlPlaneVersion."
        $versionToUpgrade = $controlPlaneVersion
    }

    Write-AtlasOutput -Message "`t Upgrading to $versionToUpgrade..."
    az aks nodepool upgrade --cluster-name $AKSCluster --name $AKSNodePool --resource-group $ResourceGroup --kubernetes-version $versionToUpgrade
}
catch {
    Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
    Write-AtlasOutput -Message "Error processing node pool upgrade! $($_.Exception.Message)" -LogLevel "ERROR"
}

Write-AtlasOutput -Message "Completed Time (UTC): $(Get-Date)"
Write-AtlasOutput -Message " "
Write-AtlasOutput -Message "Rolling AKS node pool upgrade process has been completed."
Write-AtlasOutput -Message " "


