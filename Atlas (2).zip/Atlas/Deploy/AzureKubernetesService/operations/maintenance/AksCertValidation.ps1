﻿
param (
    [Parameter(Mandatory = $true)]
    [string] $AKS_RG_NAME = $env:AKS_RG_NAME,
    [Parameter(Mandatory = $true)]
    [string] $AKS_NAME = $env:AKS_NAME,
    [Parameter(Mandatory = $true)]
    [string] $AKS_SSL_CERT_IDENTIFIER = $env:AKS_SSL_CERT_IDENTIFIER
)


#############################################################################################################################

#####################################################################################
#  Main Script
#####################################################################################
Write-Verbose "Starting Time (UTC): $(Get-Date)"  -Verbose


######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
    . ($SetupHostPath + "/SetupHost.ps1")
}
else {
    . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")
function get-kvCertInfo {
    param (
        [Parameter(Mandatory = $true)][string]$certIdentifier
    )

    try {
        Write-Verbose "Getting Keyvault Cert info..." -Verbose

        # determine environment and atlas keyvault
        $SubscriptionProperties = Get-SubscriptionProperties -SubscriptionName $SUBSCRIPTION_NAME
        $environment = $SubscriptionProperties.environment
        Write-Verbose "Environment: $environment " -Verbose

        If ($environment -eq $CONST_PROD_SUB) {
            $ATLAS_PORT_VAULT_NAME = "kv-atlas-$PORT_NAME-p"
        }
        Else {
            $ATLAS_PORT_VAULT_NAME = "kv-atlas-$PORT_NAME-np"
        }
        Write-Verbose "ATLAS_PORT_VAULT_NAME: $ATLAS_PORT_VAULT_NAME" -Verbose


        $kvCertName = $certIdentifier + "-cert"
        $kvCert = (az keyvault certificate show --vault-name $ATLAS_PORT_VAULT_NAME --name $kvCertName | ConvertFrom-Json)
        if ($null -eq $kvCert) {
            throw "Certificate not found in Atlas keyvault.
                keyvault: $ATLAS_PORT_VAULT_NAME
                certname: $kvCertName
                - see messages in log above for additional details"
        }
        $base64Cert = $kvCert.cer
        $byteArray = [System.Convert]::FromBase64String($base64Cert)
        #$cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($byteArray, $certPw, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
        $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($byteArray)
        $kvCertObj = [PSCustomObject]@{
            Thumbprint      = $cert.Thumbprint
            expiration      = $cert.NotAfter
            Subject         = $cert.subject
            Issuer          = $cert.Issuer
            SerialNumber    = $cert.SerialNumber
        }

        return $kvCertObj
    }
    catch {
        throw $($_.Exception.Message)
    }
}

function get-AppGwCertInfo {
    param (
        [Parameter(Mandatory = $true)][string]$appGwRg,
        [Parameter(Mandatory = $true)][string]$appGwName,
        [Parameter(Mandatory = $true)][string]$certIdentifier
    )

    try {
        Write-Verbose "Getting Application Gateway Cert info..." -Verbose
        # $appGwCert = az network application-gateway ssl-cert list --resource-group $appGw.resourceGroup --gateway-name $appGw.name | ConvertFrom-Json
        $appGwCert = az network application-gateway ssl-cert show --resource-group $appGwRg --gateway-name $appGwName --name "appGatewayFrontEndSslCert" | ConvertFrom-Json
        if ($null -eq $appGwCert) {
            throw "appGatewayFrontEndSslCert not found in Application Gateway - see messages in log above for additional details"
        }

        $base64Cert = $appGwCert.publicCertData
        $byteArray = [System.Convert]::FromBase64String($base64Cert)
        $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
        #$certCollection.Import($byteArray,"",[System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
        $certCollection.Import($byteArray)
        # replace hyphon with period, replace wildcard with asterisk.  Need to escape the asterisk with a forward slash
        $subjectNameSearch = $certIdentifier.Replace("-",".").Replace("wildcard","/*")
        $publicCert = $certCollection | where-object {$_.Subject -match $subjectNameSearch}
        $appGwCertObj = [PSCustomObject]@{
            Thumbprint     = $publicCert.Thumbprint
            expiration     = $publicCert.NotAfter
            Subject        = $publicCert.Subject
            Issuer         = $publicCert.Issuer
            SerialNumber   = $publicCert.SerialNumber
        }

        return $appGwCertObj
    }
    catch {
        throw $($_.Exception.Message)
    }
}


function get-AKSCertInfo {
    param (
        [Parameter(Mandatory = $true)][string]$AKS_RG_NAME,
        [Parameter(Mandatory = $true)][string]$AKS_NAME,
        [Parameter(Mandatory = $true)][string]$certIdentifier
    )

    try {
        Write-Verbose "Getting AKS (nginx) Cert info..." -Verbose
        # validate that aks cluster exists based on input
        Write-Verbose "Getting AKS Credentials..." -Verbose
        $clusterInfo = az aks list --resource-group $AKS_RG_NAME | Where-Object {$_.name -eq $AKS_NAME}
        if ($? -eq $false) {
            throw "AKS Cluster not found
            AKS_RG_NAME:  $AKS_RG_NAME
            AKS_NAME:  $AKS_NAME
             - see messages in log above for additional details"
        }

        # get aks credentials
        if ($env:isLocal) {
            az aks get-credentials --resource-group $AKS_RG_NAME --name $AKS_NAME --overwrite-existing
            kubelogin convert-kubeconfig -l "azurecli"
        } else {
            #$KUBE_CONFIG_PATH = [IO.Path]::Combine($env:TEMP, ".kube", "config")
            #az aks get-credentials -n $AKS_NAME -g $AKS_RG_NAME -a -f "$KUBE_CONFIG_PATH" --overwrite-existing | Out-Null
            az aks get-credentials -n $AKS_NAME -g $AKS_RG_NAME -a --overwrite-existing | Out-Null
        }
        if ($? -eq $false) {
            throw "error getting AKS credentials
            AKS_RG_NAME:  $AKS_RG_NAME
            AKS_NAME:  $AKS_NAME
             - see messages in log above for additional details"
        }

        $n = "ingress-nginx"
        #kubectl get secrets -n $n --field-selector type=kubernetes.io/tls
        #$nginxSecrets = (kubectl get secrets -n $n -o json | ConvertFrom-Json)
        #$nginxSecrets.items
        #$nginxSecret = $nginxSecrets | Where-Object {$_.items.type -eq "kubernetes.io/tls"}
        #$nginxSecret.items.data.'tls.crt'

        $nginxSecretName = $certIdentifier + "-cert-tls"
        $tlsSecret = (kubectl get secret $nginxSecretName -n $n -o json) | ConvertFrom-Json
        if ($null -eq $tlsSecret) {
            Write-Verbose "Cert : $certIdentifier not found in AKS - see messages in log above for additional details" -Verbose
            throw "cert : $certIdentifier not found in AKS - see messages in log above for additional details"
        }
        $base64Cert = $tlsSecret.data."tls.crt"
        $byteArray = [System.Convert]::FromBase64String($base64Cert)
        #$certPw = ""
        #$cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($byteArray, $certPw, [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
        $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($byteArray)
        $nginxCertObj = [PSCustomObject]@{
            Thumbprint      = $cert.Thumbprint
            expiration      = $cert.NotAfter
            Subject         = $cert.Subject
            Issuer          = $cert.Issuer
            SerialNumber    = $cert.SerialNumber
        }

        return $nginxCertObj
    }
    catch {
        throw $($_.Exception.Message)
    }
}


################################
# main

try {
    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    ######################################################################################

    <#
    #----Passed In
    $AKS_RG_NAME = "RG-CMFG-EA2-D01-Ken-aks"
    $AKS_NAME = "AKS-NP1-atlastest"
    $AKS_SSL_CERT_IDENTIFIER = "wildcard-atlasbeta-cunamutual"
    . ./Deploy\AzureKubernetesService\operations\maintenance\AksCertValidation.ps1 -AKS_RG_NAME "RG-CMFG-EA2-D01-Ken-aks" -AKS_NAME "AKS-NP1-atlastest" -AKS_SSL_CERT_IDENTIFIER "wildcard-atlasbeta-cunamutual"

    . ./Deploy\AzureKubernetesService\operations\maintenance\AksCertValidation.ps1 -AKS_RG_NAME "RG-CMFG-M25-Lending-Stargate" -AKS_NAME "AKS-NP1-Lend-M25" -AKS_SSL_CERT_IDENTIFIER "wildcard-lendingnonprodcluster-cunamutual"
    . ./Deploy\AzureKubernetesService\operations\maintenance\AksCertValidation.ps1 -AKS_RG_NAME "RG-CMFG-M25-Lending-Stargate" -AKS_NAME "AKS-NP1-Lend-M25" -AKS_SSL_CERT_IDENTIFIER "paymentguard-trustagedev"
    #>
    Write-Verbose "AKS_RG_NAME: $AKS_RG_NAME" -Verbose
    Write-Verbose "AKS_NAME: $AKS_NAME" -Verbose
    Write-Verbose "AKS_SSL_CERT_IDENTIFIER: $AKS_SSL_CERT_IDENTIFIER" -Verbose

    Write-Verbose "Getting Application Gateway info..." -Verbose
    $appGw = (az resource list --resource-group $AKS_RG_NAME --resource-type "Microsoft.Network/applicationGateways" | ConvertFrom-Json)
    if ($null -eq $appGw) {
        throw "Application Gateway not found - see messages in log above for additional details"
    }
    Write-Verbose "AppGw Name: $($appGw.name)" -Verbose
    Write-Verbose "AppGw RG: $($appGw.resourceGroup)" -Verbose


    # get cert info from kv, appgw, aks
    $kvCertInfo = get-kvCertInfo -certIdentifier $AKS_SSL_CERT_IDENTIFIER
    $appGwCertInfo = get-AppGwCertInfo -appGwRg $appGw.resourceGroup -appGwName $appGw.name -certIdentifier $AKS_SSL_CERT_IDENTIFIER
    $AKSCertInfo = get-AKSCertInfo -AKS_RG_NAME $AKS_RG_NAME -AKS_NAME $AKS_NAME -certIdentifier $AKS_SSL_CERT_IDENTIFIER

    #write certificate info to log for visability
    Write-Verbose " ******************************************************************
    Certificate verification for:
       AKS cluster RG:          $AKS_RG_NAME
       AKS cluster:             $AKS_NAME
       AKS_SSL_CERT_IDENTIFIER: $AKS_SSL_CERT_IDENTIFIER `n" -Verbose

    Write-Output "Atlas Keyvault Certificate Info:"
    Write-Output $kvCertInfo

    Write-Output "Application Gateway Certificate Info:"
    Write-Output $appGwCertInfo

    Write-Output "AKS Certificate Info:"
    Write-Output $AKSCertInfo

    # compare thumbprints
    if (($kvCertInfo.Thumbprint -eq $appGwCertInfo.Thumbprint) -and
        ($kvCertInfo.Thumbprint -eq $AKSCertInfo.Thumbprint)) {
        Write-Verbose "Certificates match!" -Verbose

    } else {
        Write-Verbose "Certificates don't match!" -Verbose
        throw "Certificates don't match!"
    }

    $stopwatch.Stop()
    Write-AtlasTelemetryMetric -Name "AksCertValidation-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
    Write-Verbose "Certificate validation failed: $($_.Exception.Message) " -Verbose
    throw $($_.Exception.Message)
}
finally {
}

Write-Verbose "Completed Time (UTC): $(Get-Date)" -Verbose
