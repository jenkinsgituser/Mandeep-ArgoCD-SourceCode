#**********************************************************
# Script Name: deployDynatrace (pipeline front end)
# Author:       Team Zoidberg
# Version: v2.0
# The purpose of this script is to deploy the dynatrace OneAgent Operator and DynaKube resource into an existing AKS cluster
# in different versions (like 1.15 or 1.17(latest))
# The dynatrace PaaS / API tokens and API URL are stored in a key vault instead of hardcoded in the YAML file.
# Pester Script is covered for testing
# Please check the detail test plan in below link:
# https://dev.azure.com/cunamutual/SecureCloudEnablement/_workitems/edit/1678622
#**********************************************************
try {
  ######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

  Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
  . ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

  ###########################################################################
  $ErrorActionPreference = "Stop"

  #### Setup values to run the script locally####

  # if ($env:IsLocal) {
  #   #$env:AKS_NAME = "<Provide a test AKS cluster name>"
  #   $env:AKS_SHORT_NAME = "<Provide a test AKS short name>"
  #   $env:AKS_RG_NAME = "<Provide a test AKS RG name>"
  # }

  #****************************************************
  . ("$INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
  . ("$env:ATLAS_REPO_ROOT/Common/constants.ps1")
  . ("$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")
  . ("$INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/dynatraceVariables-v2.ps1")

  if (!(Confirm-Kubectl)) {
    Write-Error "Unable to confirm Kubectl on agent. Exiting..."
    Exit 90
  }

  # Install Dynatrace in the AKS
  . ("$INFRA_FOLDER/AzureKubernetesService/src/Dynatrace/azuredeployDynatrace-v2.ps1")
}
catch {
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Verbose "Error while deploying Dynatrace to the AKS Cluster: " -Verbose
  Write-Error -Message "ERROR: $ERROR_MESSAGE" -ErrorAction Stop
}

