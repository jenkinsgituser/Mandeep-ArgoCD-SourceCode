

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
    . ($SetupHostPath + "/SetupHost.ps1")
}
else {
    . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

###########################################################################

try {

    $ErrorActionPreference = "Stop"

    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }

    # AKS Environment Setup
    #****************************************************
    . ("$INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")
    . ("$INFRA_FOLDER/AzureKubernetesService/src/aksVariables.ps1")

    #validate is RG is Atlas
    Validate-DeploymentRGIsAtlas -resourceGroup $AKS_RG_NAME -forceFlag $false

    # validate/warn if non-LSA accounts are in group
    foreach ($adGroup in $APP_TEAM_AD_GROUPS) {
        $elevatedAccountResult = Ensure-OnlyElevatedAccessAccounts -groupName $adGroup
        Write-Verbose "Ensure-OnlyElevatedAccessAccounts result for group $($adGroup): $($elevatedAccountResult.result)" -Verbose
        if (!$elevatedAccountResult.result) {
            Write-Warning "Mail Enabled Members: $($elevatedAccountResult.invalidMemberList)"
        }
    }

    # Confirm that we can re-deploy atop existing cluster, if exists
    #****************************************************
    $redeploymentStatus = Get-AksRedeploymentSupported -aksName $AKS_NAME -resourceGroupName $AKS_RG_NAME
    if (!$redeploymentStatus.deploymentSupported) {
        throw $redeploymentStatus.errorMessage
    }
    else {
        Write-Verbose "Target cluster passed support check." -Verbose
    }

    if (!(Confirm-Kubectl)) {
        Write-Error "Unable to confirm Kubectl on agent. Exiting..."
        Exit 90
    }

    # if Get-AzADServicePrincipal retuerns a sp for the cluster name, we know the cluster exists is using a system identity
    $AKS_IDENTITY = Get-AzADServicePrincipal -DisplayName $AKS_NAME
    Write-Verbose -Verbose "AKS_IDENTITY is $AKS_NAME"
    if ($null -ne $AKS_IDENTITY) {
        Write-Verbose "If not Atlas 2.0.x and cluster already exists, check if AKS permissions setup is required." -Verbose

        $callAksSetupRunbook = Check-AtlasAksPermissionsSetupRequired -ResourceGroupName $AKS_RG_NAME `
            -AksServicePrincipalObjectId $AKS_IDENTITY.Id `
            -AppTeamRoleGroupObjectId $APP_TEAM_AD_GROUP_OBJECT_IDS

        if ($callAksSetupRunbook) {
            Write-Verbose -Verbose "Aks permissions setup has not yet been completed. Calling self-serve AKS permission setup..."
            # source and run the runbook to setup AKS permissions
            . ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
            $Params = @{"ResourceGroupName"     = $AKS_RG_NAME; `
                    "AksServicePrincipalAppId"  = $AKS_IDENTITY.AppId; `
                    "AppTeamRoleGroupObjectIds" = [array]$APP_TEAM_AD_GROUP_OBJECT_IDS; `
                    "SubscriptionName"          = $SUBSCRIPTION_NAME
            }
            Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-AksResourceGroupPermissionsSetup" -Parameters $Params
        }
    }

    # Network Deployments
    # NSGs deployed regardless, vNet only deployed
    # if it does not already exist
    #****************************************************
    $VerbosePreference = "Continue"  # need this set so that verbose output is returned from Start-ThreadJob
    Write-Verbose -Verbose "Starting NSG deployments..."

    # Added the following If statement because the Start Job command changed from PS 5 to PS 6
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $privateNSGJob = Start-ThreadJob -Name "PrivateNSG-Deploy" `
            -FilePath "$INFRA_FOLDER/AzureKubernetesService/src/azuredeployPrivateNSG.ps1"

        $publicNSGJob = Start-ThreadJob -Name "PublicNSG-Deploy" `
            -FilePath "$INFRA_FOLDER/AzureKubernetesService/src/azuredeployPublicNSG.ps1"
    }
    else {
        $privateNSGJob = Start-Job -Name "PrivateNSG-Deploy" `
            -LiteralPath "$INFRA_FOLDER/AzureKubernetesService/src/azuredeployPrivateNSG.ps1"

        $publicNSGJob = Start-Job -Name "PublicNSG-Deploy" `
            -LiteralPath "$INFRA_FOLDER/AzureKubernetesService/src/azuredeployPublicNSG.ps1"
    }

    #write the output of the jobs to the console
    Wait-JobCompletion -job $privateNSGJob
    Wait-JobCompletion -job $publicNSGJob

    Write-Verbose -Verbose "Awaiting vNet deployment..."
    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $vnetJob = Start-ThreadJob -Name "vNet-Deploy" `
            -FilePath ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployVirtualNetwork.ps1")
    }
    else {
        $vnetJob = Start-Job -Name "vNet-Deploy" `
            -LiteralPath ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployVirtualNetwork.ps1")
    }
    Wait-JobCompletion -job $vnetJob



    #****************************************************
    # Cluster & WAF Deployment Initiation
    #****************************************************
    #TODO: on a redeploy do we upgrade to latest K8s version regardless? Right now, yes we do.
    # do the cluster deploy
    Write-Verbose "Preparing to create AKS cluster and include RBAC ClusterRoles" -Verbose

    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $clusterJob = Start-ThreadJob -Name "Cluster-Deploy" `
            -FilePath "$INFRA_FOLDER/AzureKubernetesService/src/azuredeployKubernetesServiceRBAC.ps1"
    }
    else {
        $clusterJob = Start-Job -Name "Cluster-Deploy" `
            -LiteralPath "$INFRA_FOLDER/AzureKubernetesService/src/azuredeployKubernetesServiceRBAC.ps1"
    }
    . ("$INFRA_FOLDER/AzureKubernetesService/src/buildApplicationGatewayParameter.ps1")

    #TODO: we should provide a means for aggregating and feeding WAF rule disablements into the ARM template
    #so that any previously made changes persist if a redeploy event occurs.
    Write-Verbose -Verbose "Starting AGWAF deployment..."
    #  Set the AGWAF deployment script name
    $AGWAFDeploymentScript = "azuredeployGatewayWAF_v2_ssl.ps1"

    if ($PSVersionTable.PSVersion.Major -ge 6) {
        $wafJob = Start-ThreadJob -Name "WAF-Deploy" `
            -FilePath "$INFRA_FOLDER/AzureKubernetesService/src/$AGWAFDeploymentScript"
    }
    else {
        $wafJob = Start-Job -Name "WAF-Deploy" `
            -LiteralPath "$INFRA_FOLDER/AzureKubernetesService/src/$AGWAFDeploymentScript"
    }


    Write-Verbose "AGWAF Deploy started!" -Verbose

    #await cluster completion before tackling the remaining cluster setup steps
    Write-Verbose "Awaiting completion of cluster deployment" -Verbose
    Wait-JobCompletion -job $clusterJob

    #************************************************************
    # Get the current version of the system node pool

    if ($existingAksName) {
        # Problem:  Control Plane upgraded from 1.21 to 1.22
        #           A large system node pool will be upgrade to 1.22 before new Ingress is installed
        #           As nodes are upgraded, they will not work with 0.33.0 Ingress Controller
        #           Ingress is updated last, after the system node pool is upgraded
        #
        # To prevent an outage, we are forcing the upgrade of the control plane only.  The
        #   developer will have to run the deploy a second time to upgrade the system node pool.
        #
        # If existing AKS version is 1.21, then set Control Plane only to 'True'
        #   This is needed to prevent an outage when upgrading the system nodepool
        #
        Write-Verbose "Control Plane: Current_AKS_Version_Detail: $Current_AKS_Version_Detail" -Verbose
        Write-Verbose "Control Plane: AKS_KUBERNETES_VERSION: $AKS_KUBERNETES_VERSION" -Verbose
        $NeedToErrorOut = "false"
        if ($Current_AKS_Version_Detail -match "1.21" -and $AKS_KUBERNETES_VERSION -match "1.22") {
            if ($AKS_UPGRADE_CONTROL_PLANE_ONLY -eq "false") {
                Write-Warning "**** Forcing Control Plane only Upgrade to prevent an application outage."
                $AKS_UPGRADE_CONTROL_PLANE_ONLY = "true"
                $NeedToErrorOut = "true"
            }
        }

        if ($AKS_UPGRADE_CONTROL_PLANE_ONLY -eq "false") {
            Write-Verbose "Checking system node pools"  -Verbose
            $SysPools = (az aks nodepool list --resource-group $AKS_RG_NAME --cluster-name $AKS_NAME | ConvertFrom-Json)  2>$null | Where-Object { $_.mode -eq "system" }
            if (($SysPools | Measure-Object).Count -eq 1) {
                $AKS_SYSTEMPOOL_NAME = $SysPools.name
                Write-Verbose "`t Found system pool name: $AKS_SYSTEMPOOL_NAME" -Verbose
                $TempSysPoolVersion = $SysPools.orchestratorVersion
                Write-Verbose "`t Found system pool version: $TempSysPoolVersion"  -Verbose

                # do some checking to make sure the current system pool version is not 2 levels behind the control plane
                $AKSSystemNodePoolVersionFirstTwo = $TempSysPoolVersion.ToString().Split('.')[0..1] -Join '.'
                $AKSKubertesVersionFristTwo = $AKS_KUBERNETES_VERSION.ToString().Split('.')[0..1] -Join '.'
                if ( [decimal]$AKSKubertesVersionFristTwo - [decimal]$AKSSystemNodePoolVersionFirstTwo -gt 0.01) {
                    Write-Verbose "AKS version $AKS_KUBERNETES_VERSION (i.e. Control Plane) is at least two minor levels higher than the system node pool $TempSysPoolVersion" -Verbose
                    Write-Verbose "`t You can not jump two minor versions" -Verbose
                    Write-Verbose "`t You will need to run the deployAKSNodePool.ps1 first to upgrade system node pool to the next minor level" -Verbose
                    throw "AKS version $AKS_KUBERNETES_VERSION (i.e. Control Plane) is at least two minor levels higher than the system node pool $TempSysPoolVersion"
                }

                if ([version]$AKS_KUBERNETES_VERSION -gt [version]$TempSysPoolVersion ) {
                    # need to reset some system variables before calling add/upgrade node pool script
                    $env:AKS_NODE_POOL_NAME = $AKS_SYSTEMPOOL_NAME
                    $env:AKS_NODE_POOL_MODE_AFTER_CONTROL_PLANE = "System"
                    $AKS_ENVIRONMENT_SETUP_COMPLETE = $false
                    $env:AKS_KUBERNETES_VERSION = $AKS_KUBERNETES_VERSION
                    Write-Verbose "AKS Control Plane has been upgraded, we will now upgrade the system node pool" -Verbose
                    Write-Verbose "Upgrading System Node Pool $($env:AKS_NODE_POOL_NAME) to $AKS_KUBERNETES_VERSION" -Verbose
                    . ("$env:DEPLOY_FOLDER/AzureKubernetesService/NodePools/deployAKSNodePool.ps1")
                    Write-Verbose "System Node Pool $($env:AKS_NODE_POOL_NAME) has been upgraded" -Verbose
                }
                else {
                    Write-Verbose "AKS Control Plane and System Node Pool are at the same level." -Verbose
                    Write-Verbose "`t Skipping System Node Pool Upgrade." -Verbose
                }
            }
            else {
                Write-Verbose "More than one System Node Pool found" -Verbose
                Write-Verbose "`t Skipping System Node Pool Upgrade." -Verbose
            }
        }
        else {
            Write-Verbose "AKS_UPGRADE_CONTROL_PLANE_ONLY is set to True, skipping System Node Pool Upgrade. " -Verbose
            Write-Verbose "Checking system node pools AKS version; Control plane cannot be upgraded two levels above system Node pool AKS version"  -Verbose
            $NodePoolstemp = (az aks nodepool list --resource-group $AKS_RG_NAME --cluster-name $AKS_NAME | ConvertFrom-Json)  2>$null | Where-Object { $_.mode -eq "system" }
            foreach ($nodepool in $NodePoolstemp) {
                $AKS_NODEPOOL_NAME_TEMP = $nodepool.name
                Write-Verbose "`t Found System pool name: $AKS_NODEPOOL_NAME_TEMP" -Verbose
                $TempNodePoolVersion = $NodePool.orchestratorVersion
                Write-Verbose "`t Found System pool version: $TempNodePoolVersion"  -Verbose
                $AKSNodePoolVersionFirstTwotemp = $TempNodePoolVersion.ToString().Split('.')[0..1] -Join '.'
                $AKSKubertesVersionFirstTwo = $AKS_KUBERNETES_VERSION.ToString().Split('.')[0..1] -Join '.'
                if ( [decimal]$AKSKubertesVersionFirstTwo - [decimal]$AKSNodePoolVersionFirstTwotemp -gt 0.01) {

                    Write-Warning "AKS version $AKS_KUBERNETES_VERSION (i.e. Control Plane) is at least two minor levels higher than the System pool version  $TempNodePoolVersion; for the Nodepool: $AKS_NODEPOOL_NAME_TEMP" -Verbose
                    Write-Warning "`t You will need to run the deployAKSNodePool.ps1 first to upgrade system node pool to the next minor level" -Verbose
                    Write-Warning "`n AKS version $AKS_KUBERNETES_VERSION (i.e. Control Plane) is at least two minor levels higher than the System pool version  $TempNodePoolVersion; for the  Nodepool: $AKS_NODEPOOL_NAME_TEMP" -Verbose
                }
            }

        }
    }


    #****************************************************
    # Check if MC_ group permissions should be cascaded after everything has been created
    # Doing this in a finally block ensures the permissions are cascaded ALWAYS if applicable
    # and will avoid scenarios stemming from AGWAF deployment failures
    #****************************************************
    $cascadeMcGroupPermissions = Check-AtlasMcGroupPermissions -ResourceGroupName $AKS_RG_NAME `
        -AksCluster $AKS_NAME `
        -AppTeamRoleGroupObjectId $APP_TEAM_AD_GROUP_OBJECT_IDS

    if ($cascadeMcGroupPermissions) {
        Write-Verbose -Verbose "Beginning process to cascade permissions on the MC_ resource group..."

        #find and source the runbook
        ##########################################
        . ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
        $Params = @{"TargetResourceGroup" = $AKS_RG_NAME; `
                "TargetAksCluster"        = $AKS_NAME;
            "TargetSubscription"          = $SUBSCRIPTION_NAME;
        }
        Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-CascadeAksMcGroupPermissions" -Parameters $Params
        Write-Verbose -Verbose "MC_ resource group permissions have been cascaded."

        $stillNeedToCascade = Check-AtlasMcGroupPermissions -ResourceGroupName $AKS_RG_NAME `
            -AksCluster $AKS_NAME `
            -AppTeamRoleGroupObjectId $APP_TEAM_AD_GROUP_OBJECT_IDS
        # should now be false
        if ($stillNeedToCascade) {
            throw "MC_ group permissions were not appropriately setup. These permissions will be setup around 5am tomorrow by a separate process. Contact MB-TeamTitan or open a Cherwell incident should you require assistance before that time."
        }
    }
    else {
        Write-Verbose -Verbose "MC_ group permissions have previously been setup with the necessary inputs. No additional work required."
    }

    # Post Cluster Setup
    #****************************************************
    # Get a credential to complete the remaining setup
    $tempErrorActionPref = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Stop"
        az aks get-credentials -g "$AKS_RG_NAME" -n "$AKS_NAME" -a -f "$KUBE_CONFIG_PATH"  --overwrite-existing
    }
    catch {
        $currentException = $_
        Write-Verbose "The exception identified is: $($currentException.Exception.Message) " -Verbose
        if ($($currentException.Exception.Message).Contains("as current context in")) {
            Write-Verbose "The exception captured is expected, the script will continue..." -Verbose
        }
        else {
            Write-Verbose "Exception is unexpected. The script will end now" -Verbose
            throw $currentException.Exception.Message
        }
    }
    $ErrorActionPreference = $tempErrorActionPref

    if (Test-Path $KUBE_CONFIG_PATH) {

        Write-Verbose -Verbose "Kubeconfig file exists..."
    }
    else {
        Write-Error "Kubeconfig does not exist!"
    }

    # kubectl dumps a ton of output to error stream - rather than deal with each instance we're going to ignore it for now
    $initialErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = "SilentlyContinue"

    kubectl --kubeconfig "$KUBE_CONFIG_PATH" version short

    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployAADPodIdentityRBAC.ps1")

    # This script needs to run before azuredeployIngressController.ps1 IF end-to-end SSL is required, as this
    # script will setup the TLS secret in the Kubernetes cluster for the Ingress Controller to leverage in its
    # default configuration
    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployKubeSslCertificateSecret.ps1")
    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployIngressController.ps1")
    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployKubernetesNetworkPolicies.ps1")

    # recommending we remove the deployment of the kube dashboard as customers lack sufficient
    # access rights to consume, while it introduces a vector for cluster modification
    # as a system identity for those who do have sufficient privilege
    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployAtlasDiagnosticTester.ps1")

    # apply RBAC roles to the cluster -- viewer and admin
    Write-Verbose "Preparing to apply RBAC Rules" -Verbose
    . ("$INFRA_FOLDER/AzureKubernetesService/src/azuredeployKubeRBACRules.ps1")

    $ErrorActionPreference = $initialErrorActionPreference
    #****************************************************

    # Await WAF completion --
    # WAF deploy takes longer than Cluster deploy, hence we
    # finish off the cluster setup before checking on WAF for completion
    #****************************************************
    Write-Verbose -Verbose "Awaiting completion of AGWAF deployment..."
    $ErrorActionPreference = "Stop"
    Wait-JobCompletion -job $wafJob

    #****************************************************
    #TODO: In a truly idempotent deployment, we'd iterate over any exposed "operations" (e.g., removeFlexVolume.ps1)
    # to ensure that after running this deployment the cluster is in a known good state
    #****************************************************

    # new error code message here
    if ($NeedToErrorOut -eq "true") {
        Throw "A Control Plane only upgrade was forced to prevent an application outage.  Please run this deploy a second time to upgrade the System Node pool"
    }

    # cert validation
    Write-Verbose "AKS Deployment complete, beginning certificate validation..." -Verbose
    . ("$DEPLOY_FOLDER/AzureKubernetesService/operations/maintenance/AksCertValidation.ps1") -AKS_RG_NAME $AKS_RG_NAME -AKS_NAME $AKS_NAME -AKS_SSL_CERT_IDENTIFIER $AKS_SSL_CERT_IDENTIFIER

    # telemetry completion
    ######################################################################################
    $stopwatch.Stop()
    Write-AtlasTelemetryMetric -Name "deployAzureKubernetesService-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
    Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
    Clean-KubeConfigFile -Path $KUBE_CONFIG_PATH
    $ERROR_MESSAGE = $_.Exception.Message
    Write-Error "Error while loading or running supporting PowerShell Scripts: $ERROR_MESSAGE"
}
