param
(
  [Parameter(Mandatory = $true)]
  [string] $ResourceGroupName,

  [Parameter(Mandatory = $true)]
  [string] $AksCluster,

  [Parameter(Mandatory = $true)]
  [string] $NodePoolName,

  [Parameter(Mandatory = $false)]
  [boolean] $Force = $false

)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")


if ($null -eq $ResourceGroupName) {
  Write-Error "Resource group name not correctly passed in to script." -ErrorAction Stop
}

if ($null -eq $AksCluster) {
  Write-Error "AKS cluster name not correctly passed in to script." -ErrorAction Stop
}

if ($null -eq $NodePoolName) {
  Write-Error "Node pool name not correctly passed in to script." -ErrorAction Stop
}

$AksCluster = $AksCluster.trim()
$NodePoolName = $NodePoolName.trim()
$ResourceGroupName = $ResourceGroupName.trim()

Write-AtlasOutput -LogLevel "INFO" -Message "AKS Cluster: $AksCluster"
Write-AtlasOutput -LogLevel "INFO" -Message "Node pool name: $NodePoolName"
Write-AtlasOutput -LogLevel "INFO" -Message "Resource Group Name: $ResourceGroupName"
Write-AtlasOutput -LogLevel "INFO" -Message "Force parameter: $Force"


try {
  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }
  ######################################################################################

  # delete node pool
  . ("$INFRA_FOLDER/AzureKubernetesService/src/NodePools/deleteNodePool.ps1")

  # telemetry completion
  ######################################################################################
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "deleteNodePool-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
  Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
}

Write-Verbose "Main deployment complete." -Verbose