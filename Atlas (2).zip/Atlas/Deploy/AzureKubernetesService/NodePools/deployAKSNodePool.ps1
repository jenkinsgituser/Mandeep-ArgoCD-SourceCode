######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
  $ErrorActionPreference = "Stop"

  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }

  # Node Pool Environment Setup
  #****************************************************
  . ("$INFRA_FOLDER/AzureKubernetesService/src/aks-utilities.ps1")

  . ("$INFRA_FOLDER/AzureKubernetesService/src/NodePools/aksNodePoolVariables.ps1")

  # Confirm that we can deploy the Node Pool atop existing cluster, if exists
  #****************************************************
  $redeploymentStatus = Get-AksRedeploymentSupported -aksName $AKS_NAME -resourceGroupName $AKS_RG_NAME
  if (!$redeploymentStatus.deploymentSupported) {
    throw $redeploymentStatus.errorMessage
  }
  else {
    Write-Verbose "Target AKS cluster passed support check." -Verbose
  }

  # Node Pool deployment
  Write-Verbose "Preparing to create/update Node Pool" -Verbose

  # Added the following If statement because the Start Job command changed from PS 5 to PS 6
  if ($PSVersionTable.PSVersion.Major -ge 6) {
    $NodePoolJob = Start-ThreadJob -Name "Node-Pool-Deploy" `
      -FilePath ("$INFRA_FOLDER/AzureKubernetesService/src/NodePools/azuredeployAKSNodePool.ps1")
  }
  else {
    $NodePoolJob = Start-Job -Name "Node-Pool-Deploy" `
      -LiteralPath ("$INFRA_FOLDER/AzureKubernetesService/src/NodePools/azuredeployAKSNodePool.ps1")
  }

  Write-Verbose "Node Pool Deployment started!" -Verbose

  # wait for Node Pool completion
  Write-Verbose "Awaiting completion of Node Pool deployment" -Verbose
  Wait-JobCompletion $NodePoolJob

  # telemetry completion
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "deployAKSNodePool-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Error "Error while loading or running supporting PowerShell Scripts: $ERROR_MESSAGE"
}

