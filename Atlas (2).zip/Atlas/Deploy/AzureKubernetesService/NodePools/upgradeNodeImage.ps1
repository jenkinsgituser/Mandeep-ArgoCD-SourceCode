param
(
  [Parameter(Mandatory = $true)]
  [string] $ResourceGroupName,

  [Parameter(Mandatory = $true)]
  [string] $AksCluster,

  [Parameter(Mandatory = $true)]
  [string] $NodePoolName

)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

$Subscription = $(Get-AzContext).Subscription.Name
Write-Verbose "Subscription is $Subscription)" -Verbose

$AksCluster = $AksCluster.trim()
$NodePoolName = $NodePoolName.trim()
$ResourceGroupName = $ResourceGroupName.trim()

Write-AtlasOutput -LogLevel "INFO" -Message "AKS Cluster: $AksCluster"
Write-AtlasOutput -LogLevel "INFO" -Message "Node pool name: $NodePoolName"
Write-AtlasOutput -LogLevel "INFO" -Message "Resource Group Name: $ResourceGroupName"


try {
  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }
  ######################################################################################

  # upgrade node pool
  . ("$INFRA_FOLDER/AzureKubernetesService/src/NodePools/upgradeNodeImage.ps1")

  # telemetry completion
  ######################################################################################
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "updateNodePoolImage-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Error "Error while loading or running supporting PowerShell Scripts: $ERROR_MESSAGE"
}

Write-Verbose "Main deployment complete." -Verbose