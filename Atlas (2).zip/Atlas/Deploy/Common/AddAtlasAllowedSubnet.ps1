# This script will discover the subnet of a source compute resource (App Service, AKS cluster)
# and enable this compute resource to access a target PaaS resource. If the source subnet cannot be
# discovered (e.g., new type outside of those defined above), you can still enter the full source
# subnetId and we'll perform cursory validation and attempt to add it to the destination resource.
# In addition, if we can't determine the source or target resources by name and RG alone, there's
# the option to pass in the resource Type to we can infer the specific resource from a list of
# multiple resources.

param(
    [Parameter(Mandatory = $true)]  [string] $targetResourceName,
    [Parameter(Mandatory = $true)]  [string] $targetResourceGroup,
    # we'll try to lookup using name and group, but if there's a conflict (e.g., two resources same name)
    # we'll fallback to resource type to determine which one we're hitting
    [Parameter(Mandatory = $false)] [string] $targetResourceType = [string]::empty,

    [Parameter(Mandatory = $false)] [string] $sourceResourceName,
    [Parameter(Mandatory = $false)] [string] $sourceResourceGroup,
    [Parameter(Mandatory = $false)] [string] $sourceResourceType = [string]::empty,

    [Parameter(Mandatory = $false)] [string] $sourceSubnetId
)

# these could be done as parameter sets above, but this approach is very explicit
if (!$sourceSubnetId -and !$sourceResourceName -and !$sourceResourceGroup) {
    Write-Error "Must enter either a sourceResourceName and sourceResourceGroup or a sourceSubnetId!"
    Exit 1
}

if (($sourceResourceName -and !$sourceResourceGroup) -or ($sourceResourceGroup -and !$sourceResourceName)) {
    Write-Error "Must enter both sourceResourceName and sourceResourceGroup!"
    Exit 1
}

#TODO: Confirm source resource is Atlas?
#TODO: Confirm target resource is Atlas?

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
    . ($SetupHostPath + "/SetupHost.ps1")
}
else {
    . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# source utilities necessary
. ("$env:COMMON_FOLDER/azure-utilities.ps1")
. ("$env:COMMON_FOLDER/constants.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

# supported source resource types
#*****************************************************************************************
# AKS Clusters
# App Service resources (Web App, Function App)

# Supported destination resource types
#*****************************************************************************************
# Key Vault
# Storage Account
# Azure SQL Server
# Service Bus

# Figure out the source subnet
#*****************************************************************************************

if ($sourceResourceName -and $sourceResourceGroup) {
    # get the source resource give name and RG
    $sourceResource = Get-AtlasResourceFromInputs -resourceName $sourceResourceName -resourceGroup $sourceResourceGroup -resourceType $sourceResourceType
    $sourceSubscriptionId = $sourceResource.id.Split('/')[2]
    $sourceSubscriptionName = (Get-AzSubscription -SubscriptionId $sourceSubscriptionId).name
    switch ($sourceResource.type) {
        # get the source subnet -- if AKS, do AKS stuff.
        $CONST_AKS_TYPE {
            $sourceSubnetId = Get-AKSsubnets -aksClusterNames @($sourceResourceName)
        }
        # if App Service, do App Service stuff
        $CONST_APP_SERVICE_TYPE {
            $sourceSubnetId = $(az resource show --id "$($sourceResource.id)/config/virtualNetwork" --query "properties.subnetResourceId" -o tsv)
        }
        Default {
            Throw "Source resource type '$($sourceResource.type)' did not match any of the allowed types ($CONST_AKS_TYPE, $CONST_APP_SERVICE_TYPE). Please try again with a supported type or a fully qualified sourceSubnetId."
        }
    }
}
elseif ($sourceSubnetId) {
    # validate the input seems like a valid subnet
    # sample ID: /subscriptions/4ecbab23-0d34-4fd1-88a2-ca4f5f4121fe/resourceGroups/RG-CMFG-NP2-Atlas-Infrastructure-Build-Testing/providers/Microsoft.Network/virtualNetworks/VNet-CMFG-Atlas-Atlantis/subnets/026eb8a3-9f90-4e6f-b2fe-3da26ee5a07a-privatefunctions-subnet-v1
    $parts = $sourceSubnetId.Split('/')
    if ($parts.Count -ne 11 -or $parts[7] -ne "virtualNetworks") {
        Write-Error "Input subnet $sourceSubnetId does not appear to be a valid fully qualified subnet ID. Please try again!"
        Exit 1
    }
}

# Do the add to the target resource
#*****************************************************************************************
$targetResource = Get-AtlasResourceFromInputs -resourceName $targetResourceName -resourceGroup $targetResourceGroup -resourceType $targetResourceType

$targetSubscriptionId = $targetResource.id.Split('/')[2]
$targetSubscriptionName = (Get-AzSubscription -SubscriptionId $targetSubscriptionId).name
Write-Verbose "TargetSubscriptionName: $targetSubscriptionName" -Verbose
# most things take a fully qualified subnet as a param, but not everything does
# this will make the necessary components available where needed
$idPathParts = $sourceSubnetId.Split('/')
$subscription = $idPathParts[2]
#$vNet = $idPathParts[8]
#$subnet = $idPathParts[-1]

If ([string]::IsNullOrEmpty($sourceSubscriptionName)) {
    $sourceSubscriptionName = (Get-SubscriptionProperties -SubscriptionId $subscription).subscriptionName
}
Write-Verbose "SourceSubscriptionName: $sourceSubscriptionName" -Verbose

#Validate the subscription for both target and source resrouce. Both resources should be in the same type of environment(For example:sandbox or nonprod or prod).
Validate-TargetSourceSubscriptionIsAtlasAllowed -targetSubscription $targetSubscriptionName -sourceSubscription  $sourceSubscriptionName

# add the allow rule to the target resource
switch ($targetResource.type) {
    $CONST_KEY_VAULT_TYPE {
        $existingRules = az keyvault network-rule list --name  $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        If ($LASTEXITCODE -ne 0) {
            throw "KeyVault Network Rules List Not Found"
        }
        if (!($existingRules.virtualNetworkRules.id -Contains $sourceSubnetId)) {
            Wait-ResourceProvisioningState -resourceId $sourceSubnetId
            Write-Verbose "Adding subnet '$sourceSubnetId' as allowed to Key Vault '$targetResourceName'" -Verbose
            az keyvault network-rule add --name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
            If ($LASTEXITCODE -ne 0) {
                throw "KeyVault Network Rule Add ERROR"
            }
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' already allowed to Key Vault '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_SERVICE_BUS_TYPE {
        $existingRules = az servicebus namespace network-rule list --namespace-name $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        If ($LASTEXITCODE -ne 0) {
            throw "Service Bus Namespace Network Rule Not Found"
        }
        if (!($existingRules.virtualNetworkRules.subnet -Contains $sourceSubnetId)) {
            Wait-ResourceProvisioningState -resourceId $sourceSubnetId
            Write-Verbose "Adding subnet '$sourceSubnetId' as allowed to Service Bus Namespace '$targetResourceName'" -Verbose
            az servicebus namespace network-rule add --namespace-name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
            If ($LASTEXITCODE -ne 0) {
                throw "Service Bus Namespace Network Rule Add ERROR"
            }
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' already allowed to Service Bus Namespace '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_STORAGE_ACCOUNT_TYPE {
        $existingRules = az storage account network-rule list --account-name $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        If ($LASTEXITCODE -ne 0) {
            throw "Storage Account Network Rule List Not Found"
        }
        if (!($existingRules.virtualNetworkRules.virtualNetworkResourceId -Contains $sourceSubnetId)) {
            Wait-ResourceProvisioningState -resourceId $sourceSubnetId
            Write-Verbose "Adding subnet '$sourceSubnetId' as allowed to Storage Account '$targetResourceName'" -Verbose
            az storage account network-rule add --account-name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
            If ($LASTEXITCODE -ne 0) {
                throw "Storage Account Network Rule Add ERROR"
            }
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' already allowed to Storage Account '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_SQL_SERVER_TYPE {
        $existingRules = az sql server vnet-rule list --server $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        If ($LASTEXITCODE -ne 0) {
            throw "SQL Server Network Rule List Not Found"
        }
        if (!($existingRules.virtualNetworkSubnetId -Contains $sourceSubnetId)) {
            Wait-ResourceProvisioningState -resourceId $sourceSubnetId
            $sqlServerRuleName = "AddAtlasAllowedSubnet-$(Get-Date -f yyyyMMdd_HHmmss)"
            Write-Verbose "Adding subnet '$sourceSubnetId' as allowed to Sql Server '$targetResourceName'" -Verbose
            az sql server vnet-rule create --server $targetResourceName --name $sqlServerRuleName --resource-group $targetResourceGroup --subnet $sourceSubnetId
            If ($LASTEXITCODE -ne 0) {
                throw "SQL Server Network Rule Add ERROR"
            }
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' already allowed to Sql Server '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_EVENT_HUBS_TYPE {
        $existingRules = az eventhubs namespace network-rule list --namespace-name $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        If ($LASTEXITCODE -ne 0) {
            throw "Eventhubs Namespace Network Rule Not Found"
        }
        if (!($existingRules.virtualNetworkRules.subnet.id -Contains $sourceSubnetId)) {
            Wait-ResourceProvisioningState -resourceId $sourceSubnetId
            Write-Verbose "Adding subnet '$sourceSubnetId' as allowed to Event Hubs Namespace '$targetResourceName'" -Verbose
            az eventhubs namespace network-rule add --namespace-name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
            If ($LASTEXITCODE -ne 0) {
                throw "Eventhubs Namespace Network Rule Add ERROR"
            }
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' already allowed to Event Hubs Namespace '$targetResourceName'. No change made." -Verbose
        }
    }
    Default { Throw "Unable to determine resource type to have subnet added as allowed. Value passed was '$($targetResource.type)'" }
}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "AddAtlasAllowedSubnet-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "AddAtlasAllowedSubnet complete" -Verbose