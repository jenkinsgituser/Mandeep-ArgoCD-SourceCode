param(
    [Parameter(Mandatory=$false)]
    [string]$ResourceType="All",
    [Parameter(Mandatory=$false)]
    [string]$ResourceId,
    [Parameter(Mandatory=$false)]
    [string]$CallType="Audit"
    )

    function New-SAAccountObj {
        New-Object PSObject -Property @{
            UserName  = $null
            VaultName  = $null
        }
    }

    function New-AuditResultObj {
        New-Object PSObject -Property @{
            ResourceName        = $null
            ResourceType        = $null
            IsResourceAtlas     = $null
            IsResourceCompliant = $null
        }
    }


    function ParseAuditResults {
        param (
            [Parameter(Mandatory = $true)]
            [string] $AuditJson,
            [Parameter(Mandatory = $true)]
            [string] $ResourceType
        )
        
        $AuditObjFromJson = $AuditJson|ConvertFrom-Json
        $AtlasAuditResultObj = New-AuditResultObj
        Write-Verbose -Verbose "Audit property name is $($AuditObjFromJson.name)"
        Write-Verbose -Verbose "Audit resource atlas result is $($AuditObjFromjson.isAtlasAndCompliant)"
        $AtlasAuditResultObj.ResourceName = $AuditObjFromJson.name
        $AtlasAuditResultObj.ResourceType = $ResourceType
        #$AtlasAuditResultObj.IsResourceAtlas = $AuditObjFromJson.isAtlasAndCompliant.isAtlasTagged.hasAtlasTag
        $AtlasAuditResultObj.IsResourceCompliant = $AuditObjFromJson.isAtlasAndCompliant
        Return $AtlasAuditResultObj
    }
    # Get SA account password from Key Vault
    function Get-SAAccount-PW {
        param (
            [Parameter(Mandatory = $true)]
            [string] $vaultname,
            [Parameter(Mandatory = $true)]
            [string] $username
        )
        # Initialize rmSecret to spaces
        $rmSecret = ""
        Write-Verbose -Verbose "About to call Get-AzKeyVaultSecret"
        Write-Verbose -Verbose "Vault name is $vaultname and Username is $username"
        try {
            $Secret = Get-AzKeyVaultSecret -VaultName $vaultname -Name $username
            $rmSecret = [System.Net.NetworkCredential]::new("", $($Secret.SecretValue)).Password
        }
        catch {
            Throw "Unable to retrieve password for Service Account. Verify key vault:$vaultname and username:$username are correct"
        }
        
        Return $rmSecret
    }
    function Get-Environment {
        param (
            [Parameter(Mandatory = $true)]
            [string] $subscription
        )
        
        # Initialize Environment variable to nothing prior to determining the value from the current context
        $CurrentEnvironment = ""
        try {
            $subscriptionDetails = Get-SubscriptionProperties -SubscriptionName $Subscription
            $CurrentEnvironment = $subscriptionDetails.environment
            if ($CurrentEnvironment -eq "Sandbox") {
                $CurrentEnvironment = "NonProd"
            }
        }
        catch {
            throw "Unable to determine Environment. Check the selected Azure Subscription and confirm it is valid"
        }    
        Return $CurrentEnvironment
    }  
    
    function Get-ServiceAccountInfo {
        param (
            [Parameter(Mandatory = $true)]
            [string] $Environment
        )
        
        # Initialize Service Account object
        $AtlasAuditSAObj = New-SAAccountObj

        try {
            if ($Environment -eq "Prod" ) {
                Write-Verbose -Verbose "Determined environment is Prod"
                $username  = "SA-AtlasAuditAPI-P"
                $vaultname = "kv-atlasauditapi-p"  
            }
            elseif($Environment -eq "Nonprod") {
                Write-Verbose -Verbose "Determined environment is NonProd"
                $username = "SA-AtlasAuditAPI-M"
                $vaultname = "kv-atlasauditapi-np"
            }
            else{
                throw "A valid Environment was not found. Environment found was $Environment. Only 'NonProd' and 'Prod' are valid values. Check selected Azure subscription for validity"
            } 
            # Assign values to properties of object
            $AtlasAuditSAObj.UserName = $username
            $AtlasAuditSAObj.VaultName = $vaultname
        }
        catch {
            throw "Unable to create Service Account object "
        }
        
        Return $AtlasAuditSAObj
    }    

    function Get-AllResourceTypeInSubscription {
        param (
            [Parameter(Mandatory = $true)]
            [string] $Subscription,
            [Parameter(Mandatory = $true)]
            [string] $ResourceType
        )

        Write-Verbose -Verbose "Subscription is $Subscription"
        Write-Verbose -Verbose "ResourceType is $ResourceType"
        if($ResourceType.ToLower() -eq "storageaccounts") {
            $FullyQualifiedResourceType = "Microsoft.Storage/storageAccounts"
        }
        elseif ($ResourceType.ToLower() -eq "sites") {
            $FullyQualifiedResourceType = "Microsoft.Web/sites"
        }
        elseif ($ResourceType.ToLower() -eq "vaults") {
            $FullyQualifiedResourceType = "Microsoft.KeyVault/vaults"
        }
        elseif ($ResourceType.ToLower() -eq "applicationgateways") {
           $FullyQualifiedResourceType = "Microsoft.Network/applicationGateways"
        }
        elseif ($ResourceType.ToLower() -eq "serverfarms") {
            $FullyQualifiedResourceType = "Microsoft.Web/serverFarms"
        }
        elseif ($ResourceType.ToLower() -eq "userassignedidentities") {
            $FullyQualifiedResourceType = "Microsoft.ManagedIdentity/userAssignedIdentities"
        }
        elseif ($ResourceType.ToLower -eq "resourcegroups") {
            $FullyQualifiedResourceType = ""
        }

        Write-Verbose -Verbose "Fully Qualified ResourceType is $FullyQualifiedResourceType"
        $ResourceIdArray = ((Get-AzResource -ResourceType  $FullyQualifiedResourceType).ResourceId|ConvertTo-Json)
        Write-Verbose -Verbose "Got array - $ResourceIdArray"
      
        Return $ResourceIdArray
    }


    function IsAuditResource {
        param (
            [Parameter(Mandatory = $true)]
            [string] $ResourceType
        )

        Write-Verbose -Verbose "ResourceType passed to IsAuditResource function is $ResourceType"
        # Build array of auditable resources
        # John Scott - Removing 'sites' from this list until function apps are fully integrated.
        $AuditableResources = @('storageaccounts','userassignedidentities','vaults','applicationgateways','serverfarms')

        # Initialize flag used to determine if resource is contained in auditable list
        $FoundResource = $false

        # Loop through AuditableResources array to determine if passed in ResourceType is include and set flag
        foreach ($Resource in $AuditableResources) {
            if ($Resource -eq $ResourceType.ToLower()) {
                $FoundResource = $true
            }
        }
        Return $FoundResource    
    }
######################################################################################################

function CallAPI {
    param (
        [Parameter(Mandatory = $true)]
        [string] $Token,
        [Parameter(Mandatory = $true)]
        [string] $Environment,
        [Parameter(Mandatory = $false)]
        [string] $CallType = "Audit",
        [Parameter(Mandatory = $false)]
        [string] $ResourceId,
        [Parameter(Mandatory = $false)]
        [string] $ResourceType,
        [Parameter(Mandatory = $false)]
        [string] $ResourceName,
        [Parameter(Mandatory = $false)]
        [string] $ResourceGroup    
    )

    # Configure Api Header
    $ApiHeader = @{
        'Authorization' = 'Bearer ' + $Token
        'Content-Type' = 'application/json'
        'Accept' = 'application/json'
    }
    try { 

        if ($Environment.ToUpper() -eq "PROD") {
            $URLBase = "apimanager.trustage.com"
            $Subscription_Key = "63008066b1e048cfadfa5cee894d506a"
        }
        else {
            $URLBase = "dev-apimanager.trustage.com"
            $Subscription_Key = "ae2e33c9c73a43a5baef42d641cdfe96"
        }
        if ($CallType -eq "HealthCheck") {
            Write-Verbose -Verbose "Calling API for HealthCheck"
            # Configure Url for HealthChecks
            $ApiUribaseForHC = "https://$URLBase/AtlasAuditAPI/V1/healthchecks?subscription-key=$Subscription_Key"
                        
            $ApiURI = $ApiUribaseForHC
            $ApiResponse = (Invoke-RestMethod -Uri $ApiURI  -Method 'GET' -Headers $ApiHeader|ConvertTo-Json)
        }
        else {
            Write-Verbose -Verbose "Processing Audit Call Type in CallAPI"
            $ResourceType = $ResourceId.Split('/')[7]

            if ($ResourceType.ToLower() -eq "storageaccounts") {
                Write-Verbose -Verbose "Processing ResourceType of $ResourceType in APICall"
                $ApiBody = @{
                    "resourceID"="$ResourceId"
                }
                # Configure Url for Storage Account
                $ApiUribaseForSA = "https://$URLBase/AtlasAuditAPI/V1/StorageAccountAudit?subscription-key=$Subscription_Key"
                $ApiURI = $ApiUribaseForSA  
            }
            elseif ($ResourceType.ToLower() -eq "sites") {
                $ApiBody = @{
                    "resourceID"="$ResourceId"
                }
                $ApiUribaseForFA = "https://$URLBase/AtlasAuditAPI/V1/FunctionAppAudit?subscription-key=$Subscription_Key"
                $ApiURI = $ApiUribaseForFA 
            }
            elseif ($ResourceType.ToLower() -eq "vaults") {
                $ApiBody = @{
                    "resourceID"="$ResourceId"
                }
                $ApiUribaseForKV = "https://$URLBase/AtlasAuditAPI/V1/KeyVaultAudit?subscription-key=$Subscription_Key"
                $ApiURI = $ApiUribaseForKV 
            }
            elseif ($ResourceType.ToLower() -eq "applicationgateways") {
                $ApiBody = @{
                    "resourceID"="$ResourceId"
                }
                $ApiUribaseForAG = "https://$URLBase/AtlasAuditAPI/V1/AppGatewayAudit?subscription-key=$Subscription_Key"
                $ApiURI = $ApiUribaseForAG 
            }
            elseif ($ResourceType.ToLower() -eq "userassignedidentities") {
                $ApiBody = @{
                    "resourceID"="$ResourceId"
                }
                $ApiUribaseForMI = "https://$URLBase/AtlasAuditAPI/V1/ManagedIdentityAudit?subscription-key=$Subscription_Key"
                $ApiURI = $ApiUribaseForMI 
            }
            elseif ($ResourceType.ToLower() -eq "serverfarms") {
                $ApiBody = @{
                    "resourceID"="$ResourceId"
                }
                $ApiUribaseForAS = "https://$URLBase/AtlasAuditAPI/V1/AppServicePlanAudit?subscription-key=$Subscription_Key"
                $ApiURI = $ApiUribaseForAS
            } 
            elseif ($ResourceType.ToLower() -eq "resourcegroups") {
                    $ApiBody = @{
                        "resourceID"="$ResourceId"
                    }
                    $ApiUribaseForAS = "https://$URLBase/AtlasAuditAPI/V1/ResourceGroupAudit?subscription-key=$Subscription_Key"
                    $ApiURI = $ApiUribaseForAS 
            }else {
                Write-Verbose -Verbose "ResourceType of $ResourceType is not found. Please use a valid ResourceType. Valid resource types are storageAccounts,sites,userAssignedIdentities,vaults,applicationGateways,serverFarms"
                Throw "Invalid ResourceType. Valid ResourceTypes are storageAccounts,sites,userAssignedIdentities,vaults,applicationGateways,serverFarms"
            }
            Write-Verbose -Verbose "About to convert json body"
            $ApiBody_Json = $ApiBody|ConvertTo-Json 
            Write-Verbose -Verbose "Uri is $ApiURI"
            Write-Verbose -Verbose "Body is $ApiBody_Json"
            $ApiResponse = (Invoke-RestMethod -Uri $ApiURI -Body $ApiBody_Json -Method 'POST' -Headers $ApiHeader |ConvertTo-Json)
        }
        Return $ApiResponse
    }
    catch {
        Write-Verbose -Verbose "ERROR - API call to get API failed"
        #Write-Verbose -Verbose "API status Code is now $($ApiResponse.statusCode)"
        Write-Verbose -Verbose "Uri is $ApiURI"
        Write-Verbose -Verbose "API Response is: $ApiResponse"
        $Error
        Exit
    }
}

function Get-JWT-Token {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Environment,
        [Parameter(Mandatory=$true)]
        [string]$username,
        [Parameter(Mandatory=$true)]
        [string]$passwd
    )

    $error.Clear()

    
    Write-Verbose -Verbose "Getting JWT"
    Write-Verbose -Verbose "Environment is $Environment"

    $Dvlp_JWT_Key = "14bab739cede4d49a4a11be5c1e537c5"
    $Demo_JWT_Key = "0860f27a64af4640a473326f4cc79e00"
    $Prod_JWT_Key = "08cdef55ae2d4d608d3041eac2cf030e"
    $DvlpUrlBase = "dev-apimanager.trustage.com"
    $DemoUrlBase = "demo-apimanager.trustage.com"
    $ProdUrlBase = "apimanager.trustage.com"

    if ($Environment.ToUpper() -eq "NONPROD") {
        Write-Verbose -Verbose  "Getting NonProd JWT Token"
        $JWT_Key = $Dvlp_JWT_Key
        $UrlBase = $DvlpUrlBase
    }
    elseif ($Environment.ToUpper() -eq "PROD") {
        Write-Verbose -Verbose "Getting Prod JWT Token"
        $JWT_Key = $Prod_JWT_Key
        $UrlBase = $ProdUrlBase
    }
    else {
        throw "Bad Key"
    }

    # Get bearer token for future API calls
    # Bearer token expires after 30 minutes
    try {
        $JWTtokenURL = "https://dev-apimanager.trustage.com/openid-connect-authorization/token/V1/as/token.oauth2?subscription-key=14bab739cede4d49a4a11be5c1e537c5"
    
        $Body = "grant_type=password&scope=openid%20profile%20address%20email&username="+$username+"&password="+$passwd  
        #$Token_Response = Invoke-RestMethod -Uri $JWTtokenURL -Header $Auth_Header -Method 'Post' -Body $Body -ContentType "text/plain"  
        $Token_Response = Invoke-RestMethod -Uri $JWTtokenURL -Method 'Post' -Body $Body -ContentType "text/plain"  
        Return $Token_Response.access_token
    } 
    catch 
    {
        Write-Verbose -Verbose "ERROR - API call to get bearer token failed"
        Throw $Error
    }
}

function GetValidAuditResources {
    $AuditableResources = @('storageAccounts','sites','userAssignedIdentities','vaults','applicationGateways','serverFarms')
    Return $AuditableResources
}

########################################################################################################################
###############################################  Main ##################################################################
########################################################################################################################

# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

$context = $(Get-AzContext)
$Subscription = $context.Subscription.Name
Write-Verbose -Verbose "Subscription being processed is: $Subscription"

# Call method to get environment based on current context
$Environment = Get-Environment -subscription $Subscription
Write-Verbose -Verbose "The environment we are running in is $Environment"

# Determine the account that is consuming the API based on the environment passed in. We will get a JWT token for this account
Write-Verbose -Verbose "Getting Service Account Information"
$ServiceAccountObj = Get-ServiceAccountInfo -Environment $Environment

Write-Verbose -Verbose "User Name is $($ServiceAccountObj.UserName)"
Write-Verbose -Verbose "Key Vault name is $($ServiceAccountObj.VaultName)"
$userName = $ServiceAccountObj.UserName
$vaultName = $ServiceAccountObj.VaultName

# Retrieve the key vault secret (password) for the Service Account being used to execute this script
Write-Verbose -Verbose "Retrieving Key Vault secret"
$rmSecret = Get-SAAccount-PW -UserName  $userName -VaultName $vaultName

###########################################################################################################################
Write-Verbose -Verbose "Assigning Key Vault secret to password variable"
$passwd = $rmSecret

 Write-Verbose -Verbose "About to call Token API function"
try {
    Write-Verbose -Verbose "Environment for JWT token retrieval is $Environment"
    $TokenAPIResults = Get-JWT-Token -Environment $Environment -username $userName -passwd $passwd

    if ($TokenAPIResults) {
        Write-Verbose -Verbose "Got JWT Token"
    }
    else {
        Write-Verbose -Verbose "Call to Token API failed"
        Throw "Bad return from Token API call"
    }
}
catch {
    Write-Verbose -Verbose "Call to Token API function failed"
    Throw "Call to Token API Function failed"
}


# If a specific ResourceId was not passed in, then either all auditable resources are returned or the type(s) specified
# Initialize IsValidResource variable to false
$IsValidResource = $false

$AtlasAuditResultsColl = New-Object System.Collections.ArrayList

if ($CallType -eq "Audit") {
    if (!$ResourceId) {
        # Validate the Resource Type passed in  
        if ($ResourceType.ToLower() -eq "all") {
            Write-Verbose -Verbose "A ResourceId was not passed in and ResourceType is 'All' so processing all audit resources "
            $IsValidResource = $true
            $AuditResourcesList = GetValidAuditResources
            Write-Verbose -Verbose "List of valid resources is $AuditResourcesList"
            foreach ($AuditResource in $AuditResourcesList) {
                $ResourceListByID = Get-AllResourceTypeInSubscription -Subscription $Subscription -ResourceType $AuditResource |ConvertFrom-Json
                Write-Verbose -Verbose "About to start array processing"
                foreach($ResId in $ResourceListByID) {
                    Write-Verbose -Verbose "Getting Resource_Name from array"
                    $Resource_Name = $ResId.Split('/')[8]
                    $ResourceType = $ResId.Split('/')[7]
                    $Resource_Type = $ResId.Split('/')[6] +"/" + $ResId.Split('/')[7]
                    Write-Verbose -Verbose "Processing Resource Type $Resource_Type"
                    Write-Verbose -Verbose "Processing $Resource_Name"
                    Write-Verbose -Verbose "ResourceId being processed is $ResId"
                   
                    $Results = CallAPI -CallType $CallType -Environment $Environment -ResourceId $ResId -Token $TokenAPIResults
                    if ($Results) {
                        Write-Verbose -Verbose "Call to API was successful"
                        Write-Verbose -Verbose "Response is $Results"
                        Write-Verbose -Verbose "About to call ParsedResults"
                        $ParsedResults = ParseAuditResults -AuditJson $Results -ResourceType $ResourceType
                        Write-Verbose -Verbose "About to add to Audit Collection"
                        $AtlasAuditResultsColl.Add($ParsedResults) | Out-Null
                        Write-Verbose -Verbose "There are $($AtlasAuditResultsColl.Count) in the collection"
                    }
                    else {
                       Write-Verbose -Verbose "Call to API failed"
                    }
                }
            }     
        }
        else {
            # Specific ResourceType(s) was passed in so validate that type against the approved list
            Write-Verbose -Verbose "A specific ResourceType was passed in as $ResourceType. Checking ResourceType passed against valid audit resources."
            $IsValidResource = IsAuditResource -ResourceType $ResourceType
            if ($IsValidResource) {
                Write-Verbose -Verbose "ResourceType of $ResourceType is valid"
                $ResourceListByID = Get-AllResourceTypeInSubscription -Subscription $Subscription -ResourceType $ResourceType|ConvertFrom-Json

                foreach($ResId in $ResourceListByID) {
                    Write-Verbose -Verbose "Getting Resource_Name from array"
                    $Resource_Name = $ResId.Split('/')[8]
                    Write-Verbose -Verbose "Processing $Resource_Name"
                    #$Results = CallAPI -CallType $CallType -ResourceId $ResId -ResourceType $ResourceType -Token $TokenAPIResults
                    $Results = CallAPI -CallType $CallType -Environment $Environment -ResourceId $ResId -Token $TokenAPIResults

                    #$Results = CallAPI -ResourceType $ResourceType -CallType $CallType -ResourceName $ResourceName -ResourceGroup $ResourceGroup -Token $TokenAPIResults
                    if ($Results) {
                        Write-Verbose -Verbose "Call to API was successful"
                        Write-Verbose -Verbose "Response is $Results"
                        Write-Verbose -Verbose "About to call ParsedResults"
                        $ParsedResults = ParseAuditResults -AuditJson $Results -ResourceType $ResourceType
                        Write-Verbose -Verbose "About to add to Audit Collection"
                        $AtlasAuditResultsColl.Add($ParsedResults) | Out-Null
                        Write-Verbose -Verbose "There are $($AtlasAuditResultsColl.Count) in the collection"
                    }
                    else {
                       Write-Verbose -Verbose "Call to API failed"
                    }
                }
            }
            else {
                Write-Verbose -Verbose "ResourceType passed in ($ResourceType) is not a valid audit ResourceType."
                Throw "ResourceType is not valid."
            }
        }
    }
    else {
        # A specific ResourceId was passed in so only audit that resource and ignore whatever else was passed in
        if ($ResourceType -ne "All") {
            Write-Verbose -Verbose "You passed in both a ResourceId a ResourceType. Only one or the other can be used. Processing ResourceId"
        }
        else {
            Write-Verbose -Verbose "You passed in a specific ResourceId....processing ResourceId"
        }

        # Parse ResourceID for its component parts
        #todo make this a separate function to get properties of the resource from resourceid
        ##############################################################################################################
        # Get subscription from ResourceId
        $Subscription = $ResourceId.Split('/')[2]
        # Get Resource Group from ResourceId
        $ResourceGroup = $ResourceId.Split('/')[4]
        # Get the Resource Type from the ResourceId
        Write-Verbose -Verbose "About to get resource type"
        $ResourceType = $ResourceId.Split('/')[7]
        # Check if ResourceType is empty. If so, and ResourceId was passed in, then this is a resource group only
        if ($ResourceType -eq $null) {
            Write-Verbose -Verbose "ResourceType is null"

            Write-Verbose -Verbose "ResourceType is a Resource Group"
            $ResourceName = $ResourceGroup
        }
        else {
            Write-Verbose -Verbose "ResourceType is not null so get pos 8"
            $ResourceName = $ResourceId.Split('/')[8]
        }
        # Get resource name
        #$ResourceName = $ResourceId.Split('/')[8]

        # Validate the ResourceType against the approved list
        Write-Verbose -Verbose "ResourceType is $ResourceType"
        $IsValidResource = IsAuditResource -ResourceType $ResourceType

        if(!$IsValidResource) {
            Write-Verbose -Verbose "The ResourceType of the ResourceId passed in is not a valid audit resource. The ResourceType must be storageAccounts,sites,userAssignedIdentities,vaults, or applicationGateways"
        }
        else {
            Write-Verbose -Verbose "The ResourceType of $ResourceType is valid for Atlas Audit....continuing"
            $Results = CallAPI -CallType $CallType -Environment $Environment -ResourceId $ResourceId -ResourceType $ResourceType -Token $TokenAPIResults
            if ($Results) {
                Write-Verbose -Verbose "Call to API was successful"
                Write-Verbose -Verbose "Response is $Results"
                Write-Verbose -Verbose "About to call ParsedResults"
                $ParsedResults = ParseAuditResults -AuditJson $Results -ResourceType $ResourceType
                Write-Verbose -Verbose "About to add to Audit Collection"
                $AtlasAuditResultsColl.Add($ParsedResults) | Out-Null
                Write-Verbose -Verbose "There are $($AtlasAuditResultsColl.Count) in the collection"
            }
            else {
               Write-Verbose -Verbose "Call to API failed"
            }
        }
    }
} else {
    Write-Verbose -Verbose "Call Type is HealthCheck."
}

######################################  Compile Results ################################################
Write-Verbose -Verbose ""
Write-Verbose -Verbose ""
Write-Verbose -Verbose "################################## Compiled Results  ##############################################"
Write-Verbose -Verbose "###################################################################################################"
Write-Verbose -Verbose "###################################################################################################"
Write-Verbose -Verbose "The total count of resources is $($AtlasAuditResultsColl.Count)"

# Initialize variables/counters
$ResourceType = "initialize"
$ResourceCount = 0
$CompliantResourceCount = 0
$NonCompliantResourceCount = 0

# Loop through each API call result in the API call results collection
foreach ($Result in $AtlasAuditResultsColl) {
    if ($ResourceType -ne $Result.ResourceType) {
        if ($ResourceType -ne "initialize") {
            Write-Verbose -Verbose ""
            Write-Verbose -Verbose "A total of $ResourceCount $ResourceType resources were processed"
            Write-Verbose -Verbose "A total of $CompliantResourceCount $ResourceType were compliant"
            Write-Verbose -Verbose "A total of $NonCompliantResourceCount $ResourceType were NOT compliant"
            Write-Verbose -Verbose "Finished Processing $ResourceType"
        }
        $ResourceType = $Result.ResourceType
        Write-Verbose -Verbose ""
        Write-Verbose -Verbose "Processing ResourceType: $ResourceType"

        # Reset counters for each resource being processed
        $ResourceCount = 0
        $CompliantResourceCount = 0
        $NonCompliantResourceCount = 0
    }
    Write-Verbose -Verbose ""
    Write-Verbose -Verbose "`t Processing $($Result.ResourceName)"

    if ($Result.IsResourceCompliant) {
        Write-Verbose -Verbose "`t Resource is compliant"    
        $CompliantResourceCount +=1
    }
    else {
        Write-Verbose -Verbose "`t Resource is NOT COMPLIANT"
        $NonCompliantResourceCount +=1
    }
    #Write-Verbose -Verbose "`t Resource is Atlas: $($Result.IsResourceAtlas)"
    $ResourceCount +=1
}
Write-Verbose -Verbose ""
Write-Verbose -Verbose "A total of $ResourceCount $ResourceType resources were processed"
Write-Verbose -Verbose "A total of $CompliantResourceCount $ResourceType were compliant"
Write-Verbose -Verbose "A total of $NonCompliantResourceCount $ResourceType were NOT compliant"
Write-Verbose -Verbose "Finished Processing $ResourceType"
#######################################  End Script ###################################################
Write-Verbose -Verbose ""
Write-Verbose -Verbose ""
Write-Verbose -Verbose "Script is complete"
#######################################################################################################