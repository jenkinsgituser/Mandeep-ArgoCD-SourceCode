Param
(

    [Parameter (Mandatory = $true)]
    [string] $TargetResourceName,
    [Parameter (Mandatory = $true)]
    [string] $PrivateEndpointConnectionName
  
)
######################################################################################################
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
    . ($SetupHostPath + "/SetupHost.ps1")
}
else {
    . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

#########################################################################
# Trim leading and trailing spaces
$TargetResourceName = $TargetResourceName.trim()
$PrivateEndpointConnectionName = $PrivateEndpointConnectionName.trim()

#########################################################################
Write-Verbose "Passed in Target Resource: $TargetResourceName" -Verbose
Write-Verbose "Passed in Private Endpoint Connection $PrivateEndpointConnectionName" -Verbose

#Validate the resource passed in exists 
$TargetResourceInfo = Get-AzResource -Name $TargetResourceName 
if ($TargetResourceInfo) {
    Write-Verbose -Verbose  "Target Resource '$TargetResourceName' was found continuing.."
}
else {
    Write-Verbose -Verbose  "Target Resource '$TargetResourceName' was not found"
    throw "Target Resource '$TargetResourceName' was not found"
}

Write-Verbose -Verbose  "Getting info on target ResourceID: $TargetResourceName"
$TargetResourceID = $TargetResourceInfo.ResourceId
Write-Verbose -Verbose  "Getting private endpoint connections."
Write-Verbose -Verbose  "TargetResourceID: $($TargetResourceID)"

# Get all private endpoints for the target resource and filter to only get the private endpoint connection for the source resource we are looking for
$privateEndpointConnections = Get-AzPrivateEndpointConnection -PrivateLinkResourceId $TargetResourceID 

#Match private endpoint with provided connection name
$privateEndpointConnection = $PrivateEndpointConnections | Where-Object { $_.Name -eq $PrivateEndpointConnectionName }

if (![string]::IsNullOrEmpty($privateEndpointConnection)) {
    Write-Verbose -Verbose "Found private endpoint connection $($privateEndpointConnection.Name)  in reource $TargetResourceName"
    #Remove private endpoint connection from target resource
    Write-Verbose -Verbose "Deleting private endpoint with name $($privateEndpointConnection.Name) in resource $($TargetResourceName)"
    Remove-AzPrivateEndpointConnection -ResourceId $privateEndpointConnection.Id -Force
}
else {
    throw "Private endpoint connection with name $($PrivateEndpointConnectionName) was not found. Please verify you copied the correct name."
}
Write-Verbose "Process complete" -Verbose
