param(
#################################################################################

    [Parameter(Mandatory = $true)] [string] $targetResourceName,
    [Parameter(Mandatory = $true)] [string] $targetResourceGroup,

    # we'll try to lookup using name and group, but if there's a conflict (e.g., two resources same name)
    # we'll fallback to resource type to determine which one we're hitting
    [Parameter(Mandatory = $false)] [string] $targetResourceType = [string]::Empty,

    [Parameter(Mandatory = $false)] [string] $sourceResourceName,
    [Parameter(Mandatory = $false)] [string] $sourceResourceGroup,
    [Parameter(Mandatory = $false)] [string] $sourceResourceType,
#################################################################################

    [Parameter(Mandatory = $false)] [string] $sourceSubnetId = [string]::empty,
    [Parameter(Mandatory = $false)] [bool] $allSubnets = $false
)

# TODO: Only run against Atlas stuff?

# these could be done as parameter sets above, but this approach is very explicit
if (!$targetResourceName -or !$targetResourceName) {
    Write-Error "Must enter both a targetResourceName and targetResourceName !"
    Exit 1
}

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# source utilities necessary
. ("$env:COMMON_FOLDER/azure-utilities.ps1")
. ("$env:COMMON_FOLDER/constants.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

$resourceType = Get-AtlasResourceFromInputs -resourceName $targetResourceName -resourceGroup $targetResourceGroup -resourceType $targetResourceType

# most things take a fully qualified subnet as a param, but not everything does
# this will make the necessary components available where needed

#################################################################

if (!$sourceSubnetId -and $allSubnets -eq $false) {
    $sourceResource = Get-AtlasResourceFromInputs -resourceName $sourceResourceName -resourceGroup $sourceResourceGroup -resourceType $sourceResourceType
    #$sourceSubscriptionId = $sourceResource.id.Split('/')[2]
    #$sourceSubscriptionName = (Get-AzSubscription -SubscriptionId $sourceSubscriptionId).name

    switch ($sourceResource.type) {
        # get the source subnet -- if AKS, do AKS stuff.
        $CONST_AKS_TYPE {
            $sourceSubnetId = Get-AKSsubnets -aksClusterNames @($sourceResourceName)
        }
        # if App Service, do App Service stuff
        $CONST_APP_SERVICE_TYPE {
            $sourceSubnetId = $(az resource show --id "$($sourceResource.id)/config/virtualNetwork" --query "properties.subnetResourceId" -o tsv)
        }
    Default {
        Throw "Source resource type '$($sourceResource.type)' did not match any of the allowed types ($CONST_AKS_TYPE, $CONST_APP_SERVICE_TYPE). Please try again with a supported type or a fully qualified sourceSubnetId."
        }
    }
}
else {
    Write-Verbose "sourceSubnetId provided:  '$sourceSubnetId'" -Verbose
}

##################################################################

#$idPathParts = $sourceSubnetId.Split('/')
#$subscription = $idPathParts[2]
#$vNet = $idPathParts[8]
#$subnet = $idPathParts[-1]

# remove the requested rule from the target resource
switch ($resourceType.type) {
    $CONST_KEY_VAULT_TYPE {
        $existingRules = az keyvault network-rule list --name  $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        if ($allSubnets -eq $true) {
            Clean-KeyVaultNetworkRules -keyVault $targetResourceName -resourceGroup $targetResourceGroup
        }
        elseif ($existingRules.virtualNetworkRules.id -Contains $sourceSubnetId) {
            Write-Verbose "Removing subnet '$sourceSubnetId' as allowed to Key Vault '$targetResourceName'" -Verbose
            az keyvault network-rule remove --name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' not currently allowed to Key Vault '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_SERVICE_BUS_TYPE {
        $existingRules = az servicebus namespace network-rule list --namespace-name $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        if ($allSubnets -eq $true) {
            Clean-ServiceBusNetworkRules -namespace $targetResourceName -resourceGroup $targetResourceGroup
        }
        elseif ($existingRules.virtualNetworkRules.subnet.id -Contains $sourceSubnetId) {
            Write-Verbose "Removing subnet '$sourceSubnetId' as allowed to Service Bus Namespace '$targetResourceName'" -Verbose
            az servicebus namespace network-rule remove --namespace-name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' not currently allowed to Service Bus Namespace '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_STORAGE_ACCOUNT_TYPE {
        $existingRules = az storage account network-rule list --account-name $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        if ($allSubnets -eq $true) {
            Clean-StorageAccountNetworkRules -storageAccount $targetResourceName -resourceGroup $targetResourceGroup
        }
        elseif ($existingRules.virtualNetworkRules.virtualNetworkResourceId -Contains $sourceSubnetId) {
            Write-Verbose "Removing subnet '$sourceSubnetId' as allowed to Storage Account '$targetResourceName'" -Verbose
            az storage account network-rule remove --account-name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' not currently allowed to Storage Account '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_SQL_SERVER_TYPE {
        $existingRules = az sql server vnet-rule list --server $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        if ($allSubnets -eq $true) {
            Clean-SqlServerNetworkRules -sqlServer $targetResourceName -resourceGroup $targetResourceGroup
        }
        elseif ($existingRules.virtualNetworkSubnetId -Contains $sourceSubnetId) {
            Write-Verbose "Removing subnet '$sourceSubnetId' as allowed to Sql Server '$targetResourceName'" -Verbose
            $ruleName = $($existingRules | Where-Object { $_.virtualNetworkSubnetId -eq $sourceSubnetId }).name
            az sql server vnet-rule delete --server $targetResourceName --resource-group $targetResourceGroup --name $ruleName
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' not currently allowed to Sql Server '$targetResourceName'. No change made." -Verbose
        }
    }
    $CONST_EVENT_HUBS_TYPE {
        $existingRules = az eventhubs namespace network-rule list --namespace-name $targetResourceName --resource-group $targetResourceGroup | ConvertFrom-Json
        if ($allSubnets -eq $true) {
            Clean-EventHubsNetworkRules -namespace $targetResourceName -resourceGroup $targetResourceGroup
        }
        elseif ($existingRules.virtualNetworkRules.subnet.id -Contains $sourceSubnetId) {
            Write-Verbose "Removing subnet '$sourceSubnetId' as allowed to Event Hubs Namespace '$targetResourceName'" -Verbose
            az eventhubs namespace network-rule remove --namespace-name $targetResourceName --resource-group $targetResourceGroup --subnet $sourceSubnetId
        }
        else {
            Write-Verbose "Subnet '$sourceSubnetId' not currently allowed to Event Hubs Namespace '$targetResourceName'. No change made." -Verbose
        }
    }
    Default { Throw "Unable to determine resource type to have subnet added as allowed. Value passed was '$($resourceType.type)'" }
}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "RemoveAtlasAllowedSubnet-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "RemoveAtlasAllowedSubnet complete." -Verbose