# Starter Script
Param
(
  [Parameter (Mandatory = $true)]
  [string] $SourceSubscription,
  [Parameter (Mandatory = $true)]
  [string] $SourceResourceName,

  [Parameter (Mandatory = $true)]
  [string] $TargetSubscription,
  [Parameter (Mandatory = $true)]
  [string] $TargetResourceName
)
######################################################################################################
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

#########################################################################

Write-Verbose "Passed in Source Subscription: $SourceSubscription" -Verbose
Write-Verbose "Passed in Source Resource: $SourceResourceName" -Verbose

Write-Verbose "Passed in Target Subscription: $TargetSubscription" -Verbose
Write-Verbose "Passed in Target Resource: $TargetResourceName" -Verbose

#########################################################################
# Validation - Make sure not crossing environments (prod to nonprod or vise versa)
if ($TargetSubscription -eq $SourceSubscription) {
  Write-Verbose "Both resources are in the same subscription, continuing..." -Verbose
}
else {
  # Make sure not crossing prod and nonprod subscriptions
  $TargetSubEnv = (Get-SubscriptionProperties -SubscriptionName $TargetSubscription).environment
  $SourceSubEnv = (Get-SubscriptionProperties -SubscriptionName $SourceSubscription).environment

  if ($TargetSubEnv -eq $SourceSubEnv) {
    Write-Verbose "Both resources are in the same subscription environments ($TargetSubEnv), continuing..." -Verbose
  }
  else {
    # Allow sandbox to nonprod and nonprod to sandbox
    if (($TargetSubEnv -eq "Sandbox" -and $SourceSubEnv -eq "NonProd") -or ($TargetSubEnv -eq "NonProd" -and $SourceSubEnv -eq "Sandbox")) {
      Write-Verbose "Connection between $TargetSubEnv and $SourceSubEnv allowed, continuing..." -Verbose
    }
    else {
      # Throw because trying to cross subscription environments (nonprod to prod)
      throw "Cannot cross subscription environments '$TargetSubscription' and '$SourceSubscription'"
    }
  }
}

##########################################################################################
# Passed all validation, will now approve the request by calling the self serve runbook
# Store current subscription
$currentSub = (Get-AzContext).Subscription.Name

# Source the runbook
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")

Write-Verbose "Setting context to Target subscription passed in: $TargetSubscription" -Verbose

# Set the parameters
$Parameters = @{"SourceSubscription" = $SourceSubscription; `
    "SourceResourceName"             = $SourceResourceName; `
    "TargetSubscription"             = $TargetSubscription; `
    "TargetResourceName"             = $TargetResourceName
}

# Start the Self Service Runboox
Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-ApproveAllowedPrivateEndpointConnection" -Parameters $Parameters

# Restore current subscription after runbook execution changes it
Set-AzContext -Subscription $currentSub | Out-Null

Write-Verbose "Process complete" -Verbose
