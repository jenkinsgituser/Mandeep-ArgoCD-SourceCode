param (
  [Parameter(Mandatory = $true)]
  [string] $StorageAccountName,
  [Parameter(Mandatory = $false)]
  [string] $Containername = [string]::Empty,
  [Parameter(mandatory = $true)]
  [string] $PermissionsFile
)

$ErrorActionPreference = "Stop"

# Remove TypeData for this session.  This is required b/c of a bug in Powershell versions < 7.0
# This bug causes the .count and .value properties to be interjected into the $ArrayOfPerms below which
# in turn causes the build to fail.
if ($PSVersionTable.PSVersion.Major -lt 6) {
  Remove-TypeData -TypeName System.Array
}

#read permissions file and remove single quotes
$PermissionsFile = $PermissionsFile -replace "'", ""
$ArrayOfPerms = Get-Content -Raw -Path $PermissionsFile | ConvertFrom-Json
if (!$ArrayOfPerms) {
  Throw 'PermissionsFile not found or is empty, exiting...'
}

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1

#telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

# Get context
$Context = Get-AzContext

# If the container name has been passed in so we need to get the resource id of the container (sub resource)
if ($ContainerName) {
  # Get resource group name of the storage account name to use to get container resource id
  $ResourceGroupName = (Get-AzResource -Name $StorageAccountName -ResourceType "Microsoft.Storage/storageAccounts").ResourceGroupName
  # Get the resource type of a container
  $AtlasResourceObj = (Get-AzRmStorageContainer -Name $ContainerName -ResourceGroupName $ResourceGroupName -StorageAccountName $StorageAccountName)
  $ResourceId = $AtlasResourceObj.Id
}
else {
  # Call general purpose function to get resource ID from above
  $AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName $StorageAccountName -ResourceType "Microsoft.Storage/storageAccounts"
  $ResourceId = $AtlasResourceObj.ResourceId
}


# If ResourceId is not found exit
if (!$ResourceId) {
  Throw "Storage account was not found, exiting..."
}

$Json = @(
  @{
    Resources = @(
      @{
        ResourceId  = $ResourceId
        PermissionsArray = @($ArrayOfPerms)
      }
    )
  }
)

$jsonBody = $Json | ConvertTo-Json -Depth 10
Write-Verbose "jsonBody is $jsonBody" -Verbose

$ssRbacApiUrl = "https://gw.developer.cunamutual.com/cmfg/prod-int/secure-cloud-rbac/v1/requestrbac?client_id=bd9821d84cbdbe986abd0e41739691a6"
# Retrieve token scoped to the SSRBAC api for auth purposes
$ssRbacResourceUri = "https://securecloudrbacapi"
$token = (Get-AzAccessToken -ResourceUrl $ssRbacResourceUri).token

# Create auth header
$authHeader = @{
  "Authorization" = "Bearer " + $Token
}
Write-Verbose "About to call RBAC API" -Verbose
# Invoke Tiger's API
$results = Invoke-RestMethod -Uri $ssRbacApiUrl -Headers $authHeader -Method "POST" -Body $jsonBody -ContentType "application/json" -SkipHttpErrorCheck

Write-Verbose -Message "Rbac update via SARBAC api service returned: $results"
if ($results.statusCode -ne 200) {
  Write-Verbose "Rbac update via auth api service failed with error: $($results.RawContent)" -Verbose
  Write-Error $($results.error)
  }
  else {
  Write-Output "Added permission for storage account $StorageAccountName"
  
  }

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-StorageAccount-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Output "API Execution complete for Storage Account permission add."