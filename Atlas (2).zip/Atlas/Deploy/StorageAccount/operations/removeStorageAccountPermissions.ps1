Param(
  [Parameter(mandatory = $true)]
  [string] $StorageAccountName,

  [Parameter(mandatory = $false)]
  [string] $ContainerName,

  [Parameter(mandatory = $true)]
  [string] $Identity
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")
$currentSub = $(Get-AzContext).Subscription.Name

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}

### Main ############################################################################

# Get context
$Context = Get-AzContext

# If the container name has been passed in so we need to get the resource id of the container (sub resource)
if ($ContainerName) {
  # Get resource group name of the storage account name to use to get container resource id
  $ResourceGroupName = (Get-AzResource -Name $StorageAccountName -ResourceType "Microsoft.Storage/storageAccounts").ResourceGroupName
  # Get the resource type of a container
  $AtlasResourceObj = (Get-AzRmStorageContainer -Name $ContainerName -ResourceGroupName $ResourceGroupName -StorageAccountName $StorageAccountName)
  $ResourceId = $AtlasResourceObj.Id
}
else {
  # Call general purpose function to get resource ID from above
  $AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName $StorageAccountName -ResourceType "Microsoft.Storage/storageAccounts"
  $ResourceId = $AtlasResourceObj.ResourceId
}

# If ResourceId is not found exit
if (!$ResourceId) {
  Throw "Storage account was not found, exiting..."
}

# build up the request and pass through
######################################################################################
#payload here needs to match Atlas-ResourcePermissions -- ln 730ish
$Json = @(
  @{
    Resources = @(
      @{
        ResourceId       = $ResourceId
        PermissionsArray = @(
          @{
            Identity = $Identity;
            Action   = "Remove";
          })
      }
    )
  }
)

$jsonBody = $Json | ConvertTo-Json -Depth 10
Write-Verbose "jsonBody is $jsonBody" -Verbose

$ssRbacApiUrl = "https://gw.developer.cunamutual.com/cmfg/prod-int/secure-cloud-rbac/v1/requestrbac?client_id=bd9821d84cbdbe986abd0e41739691a6"
# Retrieve token scoped to the SSRBAC api for auth purposes
$ssRbacResourceUri = "https://securecloudrbacapi"
$token = (Get-AzAccessToken -ResourceUrl $ssRbacResourceUri).token

# Create auth header
$authHeader = @{
  "Authorization" = "Bearer " + $Token
}
Write-Verbose "About to call RBAC API" -Verbose
# Invoke Tiger's API
$results = Invoke-RestMethod -Uri $ssRbacApiUrl -Headers $authHeader -Method "POST" -Body $jsonBody -ContentType "application/json" -SkipHttpErrorCheck

Write-Verbose -Message "Rbac update via SARBAC api service returned: $results" -Verbose
if ($results.statusCode -ne 200) {
  Write-Verbose "Rbac update via auth api service failed with error: $($results.RawContent)" -Verbose
  Write-Error $($results.error)
}
else {
  Write-Output "Removed permission for storage account $StorageAccountName"
}

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "Atlas-dropDatabaseUser-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Output "API Execution complete for Storage Account permission remove."