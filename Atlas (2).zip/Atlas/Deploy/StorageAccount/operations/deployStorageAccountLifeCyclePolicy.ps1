param
(

  [Parameter(Mandatory = $true, ParameterSetName = "LifeCycleDeleteDays")]
  [Parameter(Mandatory = $true, ParameterSetName = "LifeCycleArchive")]
  [Parameter(Mandatory = $true, ParameterSetName = "DeleteLifeCycleRule")]
  [string] $SA_NAME,

  [Parameter(Mandatory = $true, ParameterSetName = "LifeCycleDeleteDays")]
  [string]$SA_DELETE_LIFECYCLE_DAYS = $null,

  [Parameter(Mandatory = $true, ParameterSetName = "LifeCycleArchive")]
  [Parameter(Mandatory = $true, ParameterSetName = "DeleteLifeCycleRule")]
  [string] $SA_ARCHIVE_LIFECYCLE_RULE_NAME = $null,

  [Parameter(Mandatory = $true, ParameterSetName = "LifeCycleArchive")]
  [ValidateSet("cool", "archive")]
  [string] $SA_ARCHIVE_LIFECYCLE_MOVE_TIER = $null,

  [Parameter(Mandatory = $true, ParameterSetName = "LifeCycleArchive")]
  [string] $SA_ARCHIVE_LIFECYCLE_MOVE_DAYS = $null,

  [Parameter(Mandatory = $true, ParameterSetName = "DeleteLifeCycleRule")]
  [bool] $SA_ARCHIVE_LIFECYCLE_RULE_NAME_DELETE = $false
)

#parameter set info:
# parm set "LifeCycleDeleteDays" - configure the number of days until a blob is deleted
#   $SA_NAME
#   $SA_DELETE_LIFECYCLE_DAYS

# parm set "LifeCycleArchive" - define a LifeCycle rule to migrate blob data to archive or cool tier
#   $SA_NAME
#   $SA_ARCHIVE_LIFECYCLE_RULE_NAME
#   $SA_ARCHIVE_LIFECYCLE_MOVE_TIER
#   $SA_ARCHIVE_LIFECYCLE_MOVE_DAYS

# parm set "DeleteLifeCycleRule" - delete a Lifecycle rule
#   SA_NAME
#   $SA_ARCHIVE_LIFECYCLE_RULE_NAME
#   $SA_ARCHIVE_LIFECYCLE_RULE_NAME_DELETE  #(bool)

$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

. ("$INFRA_FOLDER/StorageAccount/src/StorageAccountBlobLifeCyclePolicyVariables.ps1")

try {
  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }
  ######################################################################################

  # deploy storage account container
  . ("$INFRA_FOLDER/StorageAccount/src/StorageAccountBlobLifeCyclePolicy.ps1")

  # telemetry completion
  ######################################################################################
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "deployStorageAccountLifeCyclePolicy-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
  Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
  throw $ERROR_MESSAGE
}

Write-Verbose "Main deployment complete." -Verbose