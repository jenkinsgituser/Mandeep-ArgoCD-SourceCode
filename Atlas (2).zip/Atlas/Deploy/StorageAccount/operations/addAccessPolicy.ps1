param
(
  [Parameter(Mandatory = $true)]
  [string] $StorageAccountName,

  [Parameter(Mandatory = $true)]
  [string] $Identity,

  [Parameter(Mandatory = $false)]
  [string] $TargeResourceSubscription = [string]::empty,

  [Parameter(Mandatory = $false)]
  [string] $Permissions = "Storage Blob Data Contributor"
)
$ErrorActionPreference = "Stop"

######################################################################################################
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

if (!$TargeResourceSubscription) {
  $TargeResourceSubscription = $(Get-AzContext).Subscription.Name
}

$Context = Set-AzContext -Subscription $TargeResourceSubscription

# Get resource ID for Storage Account
$AtlasResourceObj = Get-AtlasResourceObjectByNameOrId -Context $Context -ResourceName $StorageAccountName -ResourceType "Microsoft.Storage/storageAccounts"
$ResourceId = $AtlasResourceObj.ResourceId

$PermissionRequest = @(
  @{
    Resources = @(
      @{
        ResourceId       = $ResourceId
        PermissionsArray = @(
          @{
            Identity    = $Identity
            Permissions = @($Permissions)
          }
        )
      }
    )
  }
)

$jsonBody = $PermissionRequest | ConvertTo-Json -Depth 10
Write-Verbose "jsonBody is $jsonBody" -Verbose

$ssRbacApiUrl = "https://gw.developer.cunamutual.com/cmfg/prod-int/secure-cloud-rbac/v1/requestrbac?client_id=bd9821d84cbdbe986abd0e41739691a6"
# Retrieve token scoped to the SSRBAC api for auth purposes
$ssRbacResourceUri = "https://securecloudrbacapi"
$token = (Get-AzAccessToken -ResourceUrl $ssRbacResourceUri).token

# Create auth header
$authHeader = @{
  "Authorization" = "Bearer " + $Token
}
Write-Verbose "About to call RBAC API" -Verbose
# Invoke Tiger's API
$results = Invoke-RestMethod -Uri $ssRbacApiUrl -Headers $authHeader -Method "POST" -Body $jsonBody -ContentType "application/json" -SkipHttpErrorCheck

Write-Verbose -Message "Rbac update via SARBAC api service returned: $results"
if ($results.statusCode -ne 200) {
  Write-Verbose "Rbac update via auth api service failed with error: $($results.RawContent)" -Verbose
  Write-Error $($results.error)
  }
  else {
  Write-Output "Added permission for storage account $StorageAccountName"
  
  }

#restore current subscription after runbook execution changes it
Set-AzContext -Subscription $TargeResourceSubscription | Out-Null

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-StorageAccount-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Output "API Execution complete for Storage Account permission add."
