param
(
    [Parameter (Mandatory = $false)]
    [string] $SubscriptionName,

    [Parameter (Mandatory = $false)]
    [bool] $ProductionDeployment = $true,

    [Parameter (Mandatory = $false)]
    [bool] $DeployAll = $true,

    [Parameter (Mandatory = $false)]
    [string] $TargetRunbookResourceGroupName = "rg-cmfg-nc1-p01-itinfrastructure",

    [Parameter (Mandatory = $false)]
    [string] $TargetRunbookName = "Atlas-AtlantisNetwork-Guardrail",

    [Parameter (Mandatory = $false)]
    [string] $TargetAutomationAccountName = "AA-CMFG-P01-InfraMgmt-AZ",

    [Parameter (Mandatory = $false)]
    [string] $TargetEventSubscriptionTemplateFile = "\EventSubscription\eventGridEventSubscrption.json",

    [Parameter (Mandatory = $false)]
    [string] $EventSubscriptionName = "Atlas-AtlantisPolicyGuardrail",

    [Parameter (Mandatory = $true)]
    [string] $Location,

    [Parameter (Mandatory = $false)]
    [string] $ResourceGroup
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
    . ($SetupHostPath + "/SetupHost.ps1")
}
else {
    . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "Atlas-CommonCode.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")

# Function to handle an Azure deployment
function DeployEventSubscription {
    param
    (
        [Parameter (Mandatory = $true)]
        [string] $ResourceGroupName,

        [Parameter (Mandatory = $true)]
        [psobject] $ParamObj

    )
    $deploymentResult = New-AzResourceGroupDeployment -Name "AtlantisPolicyEventSubscriptionDeployment" `
        -ResourceGroupName $ResourceGroupName `
        -TemplateParameterObject $ParamObj `
        -TemplateFile $TargetEventSubscriptionTemplateFile

    return $deploymentResult
}

Write-Verbose -Verbose "TargetAutomationAccountName ---------------:$TargetAutomationAccountName"

# check for target runbook RG. Fail the script if not able to find.
if ($TargetRunbookResourceGroupName -like "*p01*") {
    $DefaultProfile = Set-AzContext -SubscriptionName "CMFG Production"
    $exists = Get-AzResourceGroup -Name $TargetRunbookResourceGroupName -DefaultProfile  $DefaultProfile
}
elseif ($TargetRunbookResourceGroupName -like "*d01*") {
    $DefaultProfile = Set-AzContext -SubscriptionName "CMFG NonProduction"
    $exists = Get-AzResourceGroup -Name $TargetRunbookResourceGroupName -DefaultProfile  $DefaultProfile
}

if ($null -eq $exists) {
    throw "Unable to find target runbook in CMFG Production and CMFG NonProduction. "
}

# get current date plus 9 years
# split off the hours and minutes, keep only MM/dd/yyyy
# use part 0
$expiryDate = ((Get-Date).AddYears(9) -f "MM/dd/yyyy" -Split " ")[0]

$webhook = New-AzAutomationWebhook -Name "$EventSubscriptionName-$(Get-Date -f "MM-dd-yyyy_HH-mm")" `
    -IsEnabled $True `
    -ExpiryTime $expiryDate `
    -RunbookName $TargetRunbookName `
    -ResourceGroup $TargetRunbookResourceGroupName `
    -AutomationAccountName $TargetAutomationAccountName `
    -Force


# Deteremine which subscriptions to process
############################################
if ($SubscriptionName) {
    #process only a single subscription
    $SubscriptionName = (Get-AzSubscription -SubscriptionName $SubscriptionName -ErrorAction Stop).Name
    $subscriptions = @("$SubscriptionName")
}
elseif ($ProductionDeployment -eq $false) {
    #process non-production subscriptions only
    $subscriptions = $(Get-AzSubscription | Where-Object { ($_.State -eq "Enabled") -and ($_.Name -match "NonProd|Sandbox") } | Select-Object Name).Name
}
elseif ($DeployAll -eq $true) {
    #process all subscriptions
    $subscriptions = $(Get-AzSubscription | Where-Object { $_.State -eq "Enabled" } | Sort-Object Name | Select-Object Name).Name
}
elseif ($ProductionDeployment -eq $true) {
    #process all PRODUCTION subscriptions
    $subscriptions = $(Get-AzSubscription | Where-Object { ($_.State -eq "Enabled") -and ($_.Name -match "( Prod|-Prod)") } | Sort-Object Name | Select-Object Name).Name
}
else {
    Write-Error "No matching deployment parameters found. Please review input params!"
}

#Remove space and convert a string to all lowercase
$location = ($location.replace(' ' , '')).ToLower()
Write-Verbose -Verbose "Location: $location "

# Apply event subscription to Azure subscription
###############################################
foreach ($subscription in $subscriptions) {
    Set-AzContext -SubscriptionName $subscription
    $params = @{ eventSubName = $EventSubscriptionName; `
            endpoint          = $webhook.WebhookURI
    }

    try {
        $locationShortName = Get-LocationShortName -location $Location
    }
    catch {
        throw "Please provide a valid Location Name in the US Region."
    }

    if (!$ResourceGroup) {
        if ($subscription -match "NonProduction" -or $subscription -match "-NonProd" -or $subscription -match "Sandbox") {
            $ResourceGroup = "RG-CMFG-NP1-Atlas-Infrastructure" + $locationShortName
        }
        else {
            $ResourceGroup = "RG-CMFG-PR1-Atlas-Infrastructure" + $locationShortName
        }
    }
    Write-Verbose -Verbose "Resource group: $ResourceGroup "
    $TargetRgExists = Get-AzResourceGroup -Name $ResourceGroup -ErrorAction SilentlyContinue
    if ($TargetRgExists) {
        $TargetEventSubscriptionTemplateFile = $PSScriptRoot + $TargetEventSubscriptionTemplateFile
        DeployEventSubscription -ResourceGroupName $ResourceGroup -ParamObj $params

        $createdEvent = Get-AzEventGridSubscription -ResourceGroupName $ResourceGroup -EventSubscriptionName $EventSubscriptionName
        if (!$createdEvent) {
            Write-Error "Unable to find newly created event for subscription '$subscription', resource group '$ResourceGroup'"
        }
    }
    else {
        Write-Verbose -Verbose "$ResourceGroup does not exist in subscription $Subscription. Skipping further processing..."
    }
}
