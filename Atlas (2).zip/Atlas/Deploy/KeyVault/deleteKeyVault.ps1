param
(
    [Parameter(Mandatory = $true)]
    [string] $VaultName,

    [Parameter(Mandatory = $false)]
    [string] $Location,

    [Parameter(Mandatory = $false)]
    [string] $PerformPurge = $true
)
if ($Location) {
    Write-Warning -message "The input parameter named 'Location' is not used anymore. " -Verbose
}
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1") 4> $null

# Telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

if ($null -eq $VaultName ) {
    Write-Error "Vault Name not correctly passed in to script." -ErrorAction Stop
}

if ($PerformPurge) {
    $PerformPurge = [System.Convert]::ToBoolean($PerformPurge)
    Write-Verbose "PerformPurge: $PerformPurge" -Verbose
}

$vaultObj = $(az keyvault show --name $VaultName) | ConvertFrom-Json
Write-Verbose "Key Vault Location: $($vaultObj.location)" -Verbose

Write-Verbose "Deleting $VaultName..." -Verbose

# Added try/catch and covertFrom-Json to hide the Microsoft soft-delete error/warning to make the yaml build pass. Leaving the write-verbose for the warning message in the log.
# Tried to use > $null with 2,3,*. It didn't work. This warning message is only displayed in Azure DevOps not locally.
# Try/catch logic is not able to hide the warning in local execution, but this works in Azure Devops.
try {
    $(az keyvault delete --name $VaultName) | ConvertFrom-Json
}
catch {
    Write-Verbose "##[Warning] If you have soft-delete protection enabled on this key vault, you will not be able to reuse" -Verbose
    Write-Verbose "##[Warning](continue)this key vault name until the key vault has been purged from the soft deleted state." -Verbose
    Write-Verbose "##[Warning](continue)Please see the following documentation for additional guidance." -Verbose
}

# Get key vault detail after deleteing the key vault
try {
    $kvDetail = $(az keyvault show --name $VaultName) | ConvertFrom-Json
}
catch {
    # Expected an error if the key vault is deleted. Use try/catch to handle the error, so the YAML build won't fail due to the error.
    Write-Verbose "The Resource 'Microsoft.KeyVault/vaults/$VaultName' was not found within the subscription." -Verbose
}
# Double-check if the key vault gets deleted successfully
If ([string]::IsNullOrEmpty($kvDetail)) {
    # If $kvDetail is empty or null, write message to indicate the key vault is deleted.
    Write-Verbose "Key Vault $VaultName deleted." -Verbose
}
else {
    # Write error if $kvDetail has the value.
    Write-Error "Unable to delete key vault $VaultName successfully."
}

# Purge the vault if soft-delete was enabled
if ($vaultObj.properties.enableSoftDelete -and $PerformPurge -eq $true) {
    Write-Verbose "Moving to purge..." -Verbose
    az keyvault purge  --name $VaultName
    Write-Verbose "$VaultName deleted. Moving to purge..." -Verbose
}

# Telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "deleteKeyVault-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Verbose "Operation Complete." -Verbose
