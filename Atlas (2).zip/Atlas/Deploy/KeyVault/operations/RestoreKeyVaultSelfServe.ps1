# Starter Script to restore a Kev Vault in soft delete state
param (
  [Parameter(Mandatory = $true)] [string] $KeyVaultName
)

######################################################################################################
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# Store current subscription
$currentSub = (Get-AzContext).Subscription.Name

# Source the runbook
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")

Write-Verbose "Processing Key Vault in Subscription: $currentSub" -Verbose
Write-Verbose "Passed in Key Vault Name: $KeyVaultName" -Verbose

# Set the parameters
$Params = @{"Subscription" = $currentSub; `
    "KeyVaultName"         = $KeyVaultName; `
    "Action"               = "Restore";
}

# Start the Self Service Runboox
Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-SelfServePurgeRestoreKeyVault" -Parameters $Params

# Restore current subscription after runbook execution changes it
Set-AzContext -Subscription $currentSub | Out-Null

Write-Verbose "Process complete" -Verbose
