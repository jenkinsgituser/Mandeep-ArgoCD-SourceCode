param(
  [Parameter(Mandatory = $false)]
  [bool] $FORCE_NONATLAS_DEPLOY = $false
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1")


try {
  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }
  ######################################################################################

  #Include the common utilities PowerShell Script first to use the functions within the sqlVariables.ps1 script.
  . ("$INFRA_FOLDER/AzureSQL/src/sqlServerVariables.ps1")

  #validate is RG is Atlas
  Validate-DeploymentRGIsAtlas -resourceGroup $resourceGroup -forceFlag $FORCE_NONATLAS_DEPLOY

  . ("$INFRA_FOLDER/AzureSQL/src/sqlServer.ps1")

  # telemetry completion
  ######################################################################################
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "deployAzureSQLServer-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
  Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
}
finally {
  #TODO:
  #in finally - probably do same thing in deployAzureSQLDatabase.ps1
  #-set AAD Admin appropriately as a safety measure (if it's not already set as expected)
  #-remove network exception if one exists
  #   actually may not want to remove if it already existed prior to this deployment
  #   need to think about temporary exception vs. "permanent" exception

  # Verify Azure SQL Server exists and ensure standard firewall rules
  $server = az sql server list --resource-group $resourceGroup | ConvertFrom-Json
  $server = $server | Where-Object { $_.name -eq $serverName }
  if ($server) {
    Write-Verbose "ensure standard azure sql firewall rules" -Verbose
    $context = Get-AzContext
    Ensure-SqlFirewallRules -sqlServerRG $resourceGroup -sqlServerName $serverName -Context $context
  }
}

Write-Verbose "Main Azure SQL Server deployment complete." -Verbose
