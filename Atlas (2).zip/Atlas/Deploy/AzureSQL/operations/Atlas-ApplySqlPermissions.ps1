﻿Param(
  [Parameter(mandatory = $true)]
  [string] $sqlServer,

  [Parameter(mandatory = $true)]
  [string] $sqlDatabase,

  [Parameter(mandatory = $true)]
  [string] $sqlPermissionsFile
)

function Convert-SQLPermsToV2 {
  param([array]$ArrayOfPerms)
  # deep copy an array, stolen from stack overflow.  need this so the original array is not modified.
  $memStream = New-Object -TypeName IO.MemoryStream
  $formatter = New-Object -TypeName Runtime.Serialization.Formatters.Binary.BinaryFormatter
  $formatter.Serialize($memStream, $ArrayOfPerms)
  $memStream.Position = 0
  $ArrayOfPermsCopy = $formatter.Deserialize($memStream)

  $ArrayOfPermsCopy | ForEach-Object {
    # rename userid to Identity
    $_ | Add-Member "Identity" -NotePropertyValue $_."userid"
    $_.psobject.properties.remove("userid")
    # if dbRoles exists cast it as an array
    if ($_."dbRoles") {
      $_."dbRoles" = $($_."dbRoles" -split ",")
    }
  }

  return $ArrayOfPermsCopy
}

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}

### Main ############################################################################

#Verify SQL Server Name has "sql-" prefix
if (!($sqlServer.ToLower().StartsWith($CONST_SQL_PREFIX))) {
  $sqlServer = $CONST_SQL_PREFIX + $sqlServer
}
$sqlServer = ($sqlServer).ToLower()
Write-Verbose "sqlServer: $sqlServer" -Verbose


#read permissions file and remove single quotes
$sqlPermissionsFile = $sqlPermissionsFile -replace "'", ""
$ArrayOfPerms = Get-Content -Raw -Path $sqlPermissionsFile | ConvertFrom-Json
if (!$ArrayOfPerms) {
  Write-Error -Message 'sqlPermissionsFile not found or is empty, exiting...'
  exit 99
}

# Get the resource we need to pass
$currentSub = $(Get-AzContext).Subscription.Name
$sqlServerRg = $(Get-AzSqlServer -ServerName $sqlServer).ResourceGroupName
$ResourceId = $(Get-AzSqlDatabase -DatabaseName $sqlDatabase -ServerName $sqlServer -ResourceGroupName $sqlServerRg).ResourceId
if (!$ResourceId) {
  Write-Error -Message 'sql server and/or sql database not found or is empty, exiting...'
  exit 99
}

$cleanArrayOfPerms = Convert-SQLPermsToV2 -ArrayOfPerms $ArrayOfPerms

# build up the request and pass through
######################################################################################
$JsonSQL = @(
  @{
    Resources = @(
      @{
        ResourceId       = $ResourceId
        PermissionsArray = $cleanArrayOfPerms
      }
    )
  }
)

#find and source the runbook
##########################################
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")

[string]$Payload = $JsonSQL | ConvertTo-Json -Depth 10
Write-Verbose "Permission Payload: $Payload" -Verbose
$Params = @{"Payload" = $Payload }
Invoke-AtlasSelfServeRunbook -RunbookName $CONST_RESOURCE_PERMISSIONS_RUNBOOK_NAME -Parameters $Params

#restore current subscription after runbook execution changes it
Set-AzContext -Subscription $currentSub | Out-Null

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "Atlas-ApplySqlPermissions-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes



