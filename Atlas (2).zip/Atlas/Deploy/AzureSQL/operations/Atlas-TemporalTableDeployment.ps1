Param(
    [Parameter(mandatory = $true)]
    [string] $sqlServer,

    [Parameter(mandatory = $true)]
    [string] $sqlDatabase,

    [Parameter(mandatory = $true)]
    [string] $sqlScriptFile
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

#Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# source runbook common code (we need it here even though it's not a runbook)
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
#######################################################################################
### Main ###################
#######################################################################################

#validate azure sql server exists
$sqlServerObject = Get-AzResource -Name $sqlServer -ResourceType "Microsoft.Sql/servers"
if ($null -eq $sqlServerObject) {
    throw "azure sql server $sqlServer not found"
}

#validate azure sql database exists
$sqldbObject = Get-AzSqlDatabase -ServerName $sqlServer -DatabaseName $sqlDatabase -ResourceGroupName $sqlServerObject.ResourceGroupName
if ($null -eq $sqldbObject) {
    Write-AtlasOutput -Message "azure sql database $sqlDatabase not found on server $sqlServer"
    throw "azure sql database $sqlDatabase not found on server $sqlServer"
}

# read input sql script
$sqlScript = Get-Content -Raw -Path $sqlScriptFile
$sqlScript = $sqlScript | ConvertTo-Json
if ($null -eq $sqlScript) {
    Write-AtlasOutput -LogLevel "ERROR" -Message "sqlScriptFile not found or is empty, exiting..."
    throw "sqlScriptFile not found or is empty"
}

# this script validation happens here and in the backend runbook
$approvedSqlScript = $false
$approvedSqlScript, $sqlInvalidCommand = validate-SqlTemporalTableScript -sqlScript $sqlScript
Write-AtlasOutput -Message "sql script passed validation:  $approvedSqlScript"
if (!$approvedSqlScript) {
    Write-AtlasOutput -LogLevel "WARN" -Message "`rSQL script has failed validation due to unallowed command ($sqlInvalidCommand), only CREATE/ALTER/DROP TABLE commands are allowed."
    throw "SQL script has failed validation due to unallowed command ($sqlInvalidCommand), only CREATE/ALTER/DROP TABLE commands are allowed."
}

#######################################################################################
# Call out to Self Serve Runbook
#######################################################################################
$currentSub = (Get-AzContext).Subscription.Name
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
$Params = @{"subscription" = $currentSub; `
        "sqlServer"        = $sqlServer; `
        "sqlDatabase"      = $sqlDatabase; `
        "sqlScript"        = $sqlScript
}

Write-AtlasOutput -Message "Calling: Atlas-SelfServeSQLTemporalTableDeploy"
Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-SelfServeSQLTemporalTableDeploy" -Parameters $Params
#######################################################################################

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "Atlas-SelfServeSQLTemporalTableDeploy-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-AtlasOutput -Message "Atlas-TemporalTableDeployment script complete."
