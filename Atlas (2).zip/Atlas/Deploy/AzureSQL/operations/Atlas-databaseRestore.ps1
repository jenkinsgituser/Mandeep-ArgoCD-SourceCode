﻿<#  High level logic

check if target db exists
if target exists
    rename target to _backup_

if source and target are the same - and target existed
    restore source into target using renamedDb
ELSE
    restore source into target
#>

if (!$env:SQL_RESOURCE_GROUP -or `
        !$env:SQL_SERVER_NAME -or `
        !$env:SOURCE_DB_NAME -or `
        !$env:TARGET_DB_NAME -or `
        !$env:RESTORE_POINT_DATE_TIME_UTC) {
    Write-Error "You must set each of the following environment variables prior to executing this script:
    - SQL_RESOURCE_GROUP
    - SQL_SERVER_NAME
    - SOURCE_DB_NAME
    - TARGET_DB_NAME
    - RESTORE_POINT_DATE_TIME_UTC
    You are currently missing one or more of these variables."
    Exit 1
}

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

#setup variables
Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# source the sql-utlities for operations
. ("$env:INFRA_FOLDER/AzureSQL/src/sql-utilities.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################

$sqlResourceGroupName = "$env:SQL_RESOURCE_GROUP"
Write-Verbose "SQL_RESOURCE_GROUP: $sqlResourceGroupName" -Verbose

$sqlServerName = "$env:SQL_SERVER_NAME"
Write-Verbose "SQL_SERVER_NAME: $sqlServerName" -Verbose

$sourceDatabaseName = "$env:SOURCE_DB_NAME"
Write-Verbose "SOURCE_DB_NAME: $sourceDatabaseName" -Verbose

$targetDatabaseName = "$env:TARGET_DB_NAME"
Write-Verbose "TARGET_DB_NAME: $targetDatabaseName" -Verbose

$restorePointDateTime = "$env:RESTORE_POINT_DATE_TIME_UTC"
Write-Verbose "RESTORE_POINT_DATE_TIME_UTC: $restorePointDateTime" -Verbose

## main section ####################################################################################

#validate input - source sql server and database exist
$sourceDbExists = (az sql db list --resource-group $sqlResourceGroupName --server $sqlServerName --query [].name -o tsv) | Where-Object { $_ -eq $sourceDatabaseName }
if (!$sourceDbExists) {
    throw "The source sql server $sqlServerName or database $sourceDatabaseName was not found, exiting."
    exit
}

#validate the restorepoint passed in is a valid date
try {
    $restorePointDateTime = Get-Date $restorePointDateTime -Format s  #make sure we have a valid format for db restore
}
catch {
    Write-Verbose "RestorePoint datetime entered is not a valid date format" -Verbose
    throw $_
}

#get minimum restore date for the source database we are restoring
$earliestRestoreDate = az sql db show --name $sourceDatabaseName  `
    --resource-group $sqlResourceGroupName  `
    --server $sqlServerName  `
    --query earliestRestoreDate  `
    --output tsv

#validate that the restore point passed in is greater than the minimum restore point
$earliestRestoreDate = $earliestRestoreDate.Substring(0, 19)
if ((Get-Date $restorePointDateTime) -lt (Get-Date $earliestRestoreDate)) {
    throw "The restore point provided, $restorePointDateTime, is too old. The minimum restore point for database $sourceDatabaseName is $earliestRestoreDate."
    exit
}

try {
    #check if target db exists to determine next steps
    Write-Verbose "Check if target database exists: $targetDatabaseName" -Verbose
    $targetDbExists = (az sql db list --resource-group $sqlResourceGroupName --server $sqlServerName --query [].name -o tsv) | Where-Object { $_ -eq $targetDatabaseName }
    if ($targetDbExists) {
        #rename it to _backup_
        $bkupDt = Get-Date -f "yyyyMMddHHmmss"
        $renamedDB = $targetDatabaseName + '_backup_' + $bkupDt
        Write-Verbose "Target database exists, rename $targetDatabaseName to $renamedDB" -Verbose
        fn-RenameDatabase -targetDbNm $renamedDB -sourceDbNm $targetDatabaseName -sourceSvrNm $sqlServerName `
            -srcRGNm $sqlResourceGroupName
    }

    #source and target are the same - and target existed
    if (($sourceDatabaseName -eq $targetDatabaseName) -and ($targetDbExists)) {
        #restore source into target using renamedDb
        Write-Verbose "Restoring renamed database $renamedDB into $targetDatabaseName at restore point $restorePointDateTime" -Verbose
        fn-RestoreDatabase -targetDbNm $targetDatabaseName -sourceDbNm $renamedDB -sourceSvrNm $sqlServerName `
            -srcRGNm $sqlResourceGroupName -restorePoint $restorePointDateTime
    }
    else {
        #restore source into target
        Write-Verbose "Restoring $sourceDatabaseName into $targetDatabaseName at restore point $restorePointDateTime" -Verbose
        fn-RestoreDatabase -targetDbNm $targetDatabaseName -sourceDbNm $sourceDatabaseName -sourceSvrNm $sqlServerName `
            -srcRGNm $sqlResourceGroupName -restorePoint $restorePointDateTime
    }
}
Catch {
    Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
    Write-Verbose -Message 'Restore script ended in error, exiting.' -Verbose
    Throw $_
    exit
}

Write-Verbose "Restore script complete." -Verbose


# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "Atlas-databaseRestore-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes