Param(
    [Parameter(mandatory = $true)]
    [string] $sqlServer,

    [Parameter(mandatory = $true)]
    [string] $sqlDatabase,

    [Parameter(mandatory = $true)]
    [string] $schemaName
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

#Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# source the sql-utlities for operations
#. ("$env:INFRA_FOLDER/AzureSQL/src/sql-utilities.ps1")

# source runbook common code (we need it here even though it's not a runbook)
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1")
. ("$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonSQLCode.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
#######################################################################################
### Main ###################
#######################################################################################
#Verify SQL Server Name has "sql-" prefix
if (!($sqlServer.ToLower().StartsWith($CONST_SQL_PREFIX))) {
    $sqlServer = $CONST_SQL_PREFIX + $sqlServer
}
$sqlServer = ($sqlServer).ToLower()
Write-AtlasOutput -message "sqlServer: $sqlServer"
$currentSub = (Get-AzContext).Subscription.Name
Write-AtlasOutput -message "Current subscription is $currentSub"
$sqlResourceGroup = (Get-AzResource -Name $sqlServer).ResourceGroupName
Write-AtlasOutput -message "sqlServerResourceGroup: $sqlResourceGroup"


#######################################################################################
# Call out to Self Serve Runbook
#######################################################################################
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
$Params = @{"Subscription" = $currentSub; `
        "ResourceGroup"    = $sqlResourceGroup; `
        "sqlServer"        = $sqlServer; `
        "sqlDatabase"      = $sqlDatabase; `
        "SchemaName"       = $SchemaName
}

Invoke-AtlasSelfServeRunbook -RunbookName "Atlas-SelfServeCreateSQLSchema" -Parameters $Params
#######################################################################################

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "Atlas-databaseRestore-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes