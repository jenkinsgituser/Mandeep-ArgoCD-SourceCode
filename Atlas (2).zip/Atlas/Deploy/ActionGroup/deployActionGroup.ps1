[CmdletBinding()]
param(
  [Parameter(Mandatory = $True)] [string]$ConfigurationFilePath
)

if ( -not (Test-Path $ConfigurationFilePath) ) {
  Throw "File $ConfigurationFilePath does not exist."
}

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
  # telemetry setup
  $stopwatch = [Diagnostics.Stopwatch]::StartNew()
  if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
  }
  ######################################################################################

  . ("$INFRA_FOLDER/ActionGroup/src/actionGroup.ps1")

  $config = Get-Content $ConfigurationFilePath | ConvertFrom-Json

  # determine type of ActionGroup to create based on json payload provided
  if ($null -ne $config.cherwellWebhookJsonInput) {
      Write-Verbose "Based on input, create a Cherwell ActionGroup" -Verbose
      New-CherwellActionGroupWithActions -ConfigurationFilePath $ConfigurationFilePath
  }
  elseif ($null -ne $config.emailJsonInput) {
      Write-Verbose "Based on input, create an Email ActionGroup" -Verbose
      New-emailActionGroupWithActions -ConfigurationFilePath $ConfigurationFilePath
  }
  else {
    Write-Verbose "Couldn't determine ActionGroup to create based on configFile input" -Verbose
    throw "Couldn't determine ActionGroup to create based on configFile input"
  }


  # telemetry completion
  ######################################################################################
  $stopwatch.Stop()
  Write-AtlasTelemetryMetric -Name "deployCherwellActionGroup-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
  Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
  $ERROR_MESSAGE = $_.Exception.Message
  Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
  Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
}