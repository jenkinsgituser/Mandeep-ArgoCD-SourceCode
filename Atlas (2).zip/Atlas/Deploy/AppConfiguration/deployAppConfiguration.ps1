param(
    [Parameter(Mandatory = $false)]
    [string] $APP_CONFIG_NAME = $env:APP_CONFIG_NAME,

    [Parameter(Mandatory = $false)]
    [string] $APP_CONFIG_LOCATION = $env:APP_CONFIG_LOCATION,

    [Parameter(Mandatory = $false)]
    [string] $APP_CONFIG_RG_NAME = $env:APP_CONFIG_RG_NAME,

    [Parameter(Mandatory = $false)]
    [string] $APP_CONFIG_SKU = $env:APP_CONFIG_SKU,

    [Parameter(Mandatory = $false)]
    [string] $APP_CONFIG_IDENTITY = $env:APP_CONFIG_IDENTITY,

    [Parameter(Mandatory = $false)]
    [string] $APP_CONFIG_IDENTITY_RG_NAME = $env:APP_CONFIG_IDENTITY_RG_NAME,

    [Parameter(Mandatory = $false)]
    [bool] $FORCE_NONATLAS_DEPLOY = $false
)

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################


Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    ######################################################################################

    # import and validate variables
    . ("$INFRA_FOLDER/AppConfiguration/src/appConfigurationVariables.ps1")
    . ("$INFRA_FOLDER/AppConfiguration/src/appConfigurationExternalValidations.ps1")

    #validate is RG is Atlas
    Validate-DeploymentRGIsAtlas -resourceGroup $APP_CONFIG_RG_NAME -forceFlag $FORCE_NONATLAS_DEPLOY

    Write-Verbose "Provisioning the App Configuration." -Verbose

    # Create the resource
    az appconfig create --location $APP_CONFIG_LOCATION --name $APP_CONFIG_NAME --resource-group $APP_CONFIG_RG_NAME --sku $APP_CONFIG_SKU

    # Tag the resource
    az appconfig update --name $APP_CONFIG_NAME --resource-group $APP_CONFIG_RG_NAME --tags "TemplateVersion=$($TEMPLATE_VERSION)"

    # If they gave a user assigned managed identity, then assign it
    if ($APP_CONFIG_IDENTITY) {
        if ($APP_CONFIG_IDENTITY -ne "[system]") {
            $subscriptionId = Get-Atlas-Subscription -subscription "$SUBSCRIPTION_NAME" -queryParam "id"
            $identity = "/subscriptions/$subscriptionId/resourcegroups/$APP_CONFIG_IDENTITY_RG_NAME/providers/Microsoft.ManagedIdentity/userAssignedIdentities/$APP_CONFIG_IDENTITY"
            az appconfig identity assign --name $APP_CONFIG_NAME --resource-group $APP_CONFIG_RG_NAME --identities $identity
        }
        else {
            az appconfig identity assign --name $APP_CONFIG_NAME --resource-group $APP_CONFIG_RG_NAME --identities $APP_CONFIG_IDENTITY
        }
    }

    # telemetry completion
    ######################################################################################
    $stopwatch.Stop()
    Write-AtlasTelemetryMetric -Name "deployAppInsights-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
    Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
    $ERROR_MESSAGE = $_.Exception.Message
    Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
    Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
}

Write-Verbose "App Configuration deployment complete." -Verbose