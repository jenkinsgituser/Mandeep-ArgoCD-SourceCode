param (
  [Parameter(Mandatory = $true)] [string] $AppConfigName,
  [Parameter(mandatory = $true)] [string] $PermissionsFile
)

$ErrorActionPreference = "Stop"

# Remove TypeData for this session.  This is required b/c of a bug in Powershell versions < 7.0
# This bug causes the .count and .value properties to be interjected into the $ArrayOfPerms below which
# in turn causes the build to fail.
if ($PSVersionTable.PSVersion.Major -lt 6) {
  Remove-TypeData -TypeName System.Array
}

# Read permissions file and remove single quotes
$PermissionsFile = $PermissionsFile -replace "'", ""
$ArrayOfPerms = Get-Content -Raw -Path $PermissionsFile | ConvertFrom-Json
if (!$ArrayOfPerms) {
  Throw 'PermissionsFile not found or is empty, exiting...'
}

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################
Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

Write-Verbose "Linking to Atlas-CommonCode Runbook..." -Verbose
. $env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1

# Telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}
######################################################################################
$AppData = Get-AzResource -Name $AppConfigName -ResourceType "Microsoft.AppConfiguration/configurationStores"
$ResourceId = $AppData.ResourceId

# If ResourceId is not found exit
if (!$ResourceId) {
  Throw "App Configuration was not found, exiting..."
}

# Find and source the runbook
##########################################
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")

$Json = @(
  @{
    Resources = @(
      @{
        ResourceId       = $ResourceId
        PermissionsArray = $ArrayOfPerms
      }
    )
  }
)

[string]$Payload = $Json | ConvertTo-Json -Depth 10
Write-AtlasOutput -Message "Permission Payload: $Payload"
$Params = @{"Payload" = $Payload; }

try {
  # Check permissions prior to calling the runbook
  Validate-AtlasPermissionsRequest $Payload

  # Call runbook with permissions payload
  Invoke-AtlasSelfServeRunbook -RunbookName $CONST_RESOURCE_PERMISSIONS_RUNBOOK_NAME -Parameters $Params
  Write-AtlasOutput -Message "Added permission(s) for app configuration $($AppConfigName)"

}
catch {
  throw "Requested permission(s) were invalid for app configuration $($_.exception.message)"
}

# Telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-AppConfig-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-AtlasOutput -Message "Runbook Execution complete for app configuration permission(s) add."
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-AppConfig-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-AtlasOutput -Message "Runbook Execution complete for app configuration permission(s) add."
