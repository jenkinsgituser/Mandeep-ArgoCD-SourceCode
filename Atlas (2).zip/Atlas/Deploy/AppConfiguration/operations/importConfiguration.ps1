param (
    [Parameter(Mandatory = $false)]
    [string] $APP_CONFIG_NAME = $env:APP_CONFIG_NAME,

    [Parameter(Mandatory = $false)]
    [string] $CONFIG_FILE_PATH = $env:CONFIG_FILE_PATH,

    [Parameter(Mandatory = $false)]
    [string] $CONFIG_FILE_FORMAT = $env:CONFIG_FILE_FORMAT,

    [Parameter(Mandatory = $false)]
    [string] $CONFIG_FILE_SEPARATOR = $env:CONFIG_FILE_SEPARATOR
)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

try {
    # telemetry setup
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
        Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
    }
    ######################################################################################

    # import and validate variables
    . ("$INFRA_FOLDER/AppConfiguration/src/operations/importConfigurationVariables.ps1")
    . ("$INFRA_FOLDER/AppConfiguration/src/operations/importConfigurationExternalValidations.ps1")

    # import configuration
    Write-Verbose "Importing Configuration from $CONFIG_FILE_PATH into $APP_CONFIG_NAME" -Verbose
    az appconfig kv import --name $APP_CONFIG_NAME --source file --path $CONFIG_FILE_PATH --format $CONFIG_FILE_FORMAT --separator $CONFIG_FILE_SEPARATOR --yes
    Write-Verbose "Successfully Imported App Configuration from $CONFIG_FILE_PATH to $APP_CONFIG_NAME" -Verbose

    # telemetry completion
    ######################################################################################
    $stopwatch.Stop()
    Write-AtlasTelemetryMetric -Name "deployAppInsights-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes
}
catch {
    Write-AtlasTelemetryException -Exception $_.Exception -InvocationInfo $_.InvocationInfo
    $ERROR_MESSAGE = $_.Exception.Message
    Write-Verbose "Error while loading or running supporting PowerShell Scripts: " -Verbose
    Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
}

Write-Verbose "Import Configuration complete." -Verbose