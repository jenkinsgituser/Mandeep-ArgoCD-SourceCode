param
(
  [Parameter(Mandatory = $false)]
  [string] $APP_CONFIG_NAME = $env:APP_CONFIG_NAME,

  [Parameter(Mandatory = $false)]
  [string] $APP_CONFIG_RG_NAME = $env:APP_CONFIG_RG_NAME,

  [Parameter(Mandatory = $false)]
  [string] $IDENTITY_NAME = $env:IDENTITY_NAME

)
$ErrorActionPreference = "Stop"

######################################################################################################
#. ((Get-ChildItem -recurse -filter "productInformationV2.json").Directory.FullName + "\SetupHost.ps1")
# Setup Host Logic
Write-Verbose "SetupHost.ps1 is executing" -Verbose

$SetupHostPath = (Get-ChildItem -Recurse -Filter "productInformationV2.json").Directory.FullName
if ($SetupHostPath) {
  . ($SetupHostPath + "/SetupHost.ps1")
}
else {
  . ($env:ATLAS_REPO_ROOT + "/SetupHost.ps1")
}
######################################################################################################

Write-Verbose "setupEnvironment.ps1 is executing" -Verbose
. ("$env:ATLAS_REPO_ROOT/Common/setupEnvironment.ps1")

# telemetry setup
$stopwatch = [Diagnostics.Stopwatch]::StartNew()
if ($MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
  Write-AtlasDeploymentTelemetry -FileName (Split-Path $MyInvocation.MyCommand.Path -Leaf)
}

# validate required input
if ([string]::IsNullOrEmpty($APP_CONFIG_NAME)) {
  Write-Error "Missing required variable APP_CONFIG_NAME"
  Exit 1
}
Write-Verbose "APP_CONFIG_NAME: $APP_CONFIG_NAME" -Verbose

if ([string]::IsNullOrEmpty($APP_CONFIG_RG_NAME)) {
  Write-Error "Missing required variable APP_CONFIG_RG_NAME"
  Exit 1
}
Write-Verbose "APP_CONFIG_RG_NAME: $APP_CONFIG_RG_NAME" -Verbose

if ([string]::IsNullOrEmpty($IDENTITY_NAME)) {
  Write-Error "Missing required variable IDENTITY_NAME"
  Exit 1
}
Write-Verbose "IDENTITY: $IDENTITY_NAME" -Verbose

$resourceId = $(az appconfig show --name $APP_CONFIG_NAME --resource-group $APP_CONFIG_RG_NAME --query id -o tsv)

<#
  Note - This script should be consumed by an Azure PowerShell Azure DevOps job, as it relies on those commands and ultimately consumes an AA runbook.
  Az CLI does not currently have a means to consume an AA runbook.
#>
$Json = @(
  @{
    Resources = @(
      @{
        ResourceId       = $resourceId
        PermissionsArray = @(
          @{
            Identity = $IDENTITY_NAME
            Action   = "Remove"
          }
        )
      }
    )
  }
)

#store current subscription
$currentSub = (Get-AzContext).Subscription.Name

#find and source the runbook
##########################################
. ("$env:COMMON_FOLDER/api/executeAtlasSelfServiceRunbook.ps1")
[string]$Payload = $Json | ConvertTo-Json -Depth 10
Write-Verbose "Permission Payload: $Payload" -Verbose
$Params = @{"Payload" = $Payload; }

Invoke-AtlasSelfServeRunbook -RunbookName $CONST_RESOURCE_PERMISSIONS_RUNBOOK_NAME -Parameters $Params

#restore current subscription after runbook execution changes it
Set-AzContext -Subscription $currentSub | Out-Null

# telemetry completion
######################################################################################
$stopwatch.Stop()
Write-AtlasTelemetryMetric -Name "addAccessPolicy-AppConfiguration-TotalMinutes" -Value $stopwatch.Elapsed.TotalMinutes

Write-Output "Runbook Execution complete for App Configuration permission add."