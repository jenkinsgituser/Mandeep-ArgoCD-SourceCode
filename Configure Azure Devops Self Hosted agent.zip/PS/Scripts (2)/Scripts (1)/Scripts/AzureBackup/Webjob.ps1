﻿Param(
[string]$appsettings
)

$doc = Get-Content -Path $appsettings | ConvertFrom-Json

#extract and change connectionstrings

$doc.ConnectionString.CAQHUPDCRM = $CAQHUPDCRM
$doc.ConnectionString.CAQH_DirectoryAssure = $CAQH_DirectoryAssure
$doc.ConnectionString.DMSConnection = $DMSConnection
$doc.ConnectionString.UPDPortalConnection = $UPDPortalConnection

#extract and update other keys

#$doc.ClientId = $ClientId
#$doc.ClientSecret = $ClientSecret
#$doc.KeyVaultURI=$KeyVaultURI
$doc.DirectAssurePOPortalAPI = $DirectAssurePOPortalAPI
$doc.ServiceBusBaseUrl=$ServiceBusBaseUrl

#extract and update ServiceBus values

#$doc.ServiceBus.'pv-epm-queue' = $pvepmqueue
$doc.ServiceBus.ServiceBusConnectionString =$ServiceBusConnectionString

$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
