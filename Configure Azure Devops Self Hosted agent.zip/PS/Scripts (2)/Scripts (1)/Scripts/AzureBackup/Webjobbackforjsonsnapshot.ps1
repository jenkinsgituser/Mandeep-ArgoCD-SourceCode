
<#
This script deploys the webjobs in the webapps of the lower environments, for both continuous and triggered webjobs
#>

#Initialize the variables that are used in the script
Param(
[string]  $resourceGroupName, 
[string]  $webAppName,
[string]  $filePath,
#Name of the webjob to be deployed in the webapp
[string]  $jobname,
#Continuos/Triggered mode in the webapp
[string]  $jobType,		  
[string]  $scmSite
)

#Snippet to override error due to SSL related issues in agent VM. 
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

#Authenticate the script to the webapp by using the publishing credentials and header for the webapp
$Apiversion = "2018-02-01"
$resourceType = "Microsoft.Web/sites/config"
$resourceName = "$webAppName/publishingcredentials"
# Generating publishing credentials for the Azure webapp service
$publishingCredentials = Invoke-AzureRmResourceAction -ResourceGroupName $resourceGroupName -ResourceType $resourceType -ResourceName $resourceName -Action list  -ApiVersion $Apiversion -Force
$accessToken =  ("Basic {0}" -f [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $publishingCredentials.Properties.PublishingUserName, $publishingCredentials.Properties.PublishingPassword))))

#Generating header to create and publish the Webjob.
$Header = @{
'Content-Disposition'='attachment; attachment; filename=Copy.zip'
'Authorization'=$accessToken
}

#Generating header to delete the webjob from a certain path in the webapp.
$Header1 = @{
'Authorization'=$accessToken
}				
#Path to target the webjob deployed in the webapp
$Uri= "https://$webAppName.scm.$scmSite/api"

#takebackup of existing folder of the webjob
$foldercreate = @{
command = "mkdir D:\home\site\Backup\WebJob"
}
$cmd1 =$foldercreate | ConvertTo-Json
Invoke-RestMethod -Uri "$Uri/command" -Method Post -ContentType 'application/json' -Body $cmd1 -Headers $Header1 -ErrorAction SilentlyContinue

$Backup = @{
command = "Xcopy D:\home\site\wwwroot\App_Data\jobs\$jobType\$jobname D:\home\site\Backup\WebJob\$jobname\ /E"
}
$cmd2 =$Backup | ConvertTo-Json
Invoke-RestMethod -Uri "$Uri/command" -Method Post -ContentType 'application/json' -Body $cmd2 -Headers $Header1 -ErrorAction SilentlyContinue
