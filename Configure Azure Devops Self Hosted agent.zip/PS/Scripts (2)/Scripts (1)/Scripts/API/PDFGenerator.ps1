﻿Param(
[string]$Directory
)
$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(servicesoln)-L&D\Publish\APIs\PDFGenerator\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of connection strings
 

$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'DMSConnection'}
$con4=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHPortalContext'}
$con5=$root."connectionStrings"."add"| where {$_.name -eq 'ProviderChangeIntegrationContext'}
$con6=$root."connectionStrings"."add"| where {$_.name -eq 'FileUploadInfoContext'}

#Replacing the connection strings with environment specific release variables

 $newcon1=$con1.connectionString=$env:CrmServiceConfig
 $newcon2=$con2.connectionString=$env:CAQHUPDCRMConn
 $newcon3=$con3.connectionString=$env:DMSConnection
 $newcon4=$con4.connectionString=$env:CAQHPortalContext
 $newcon5=$con5.connectionString=$env:ProviderChangeIntegrationContext
 $newcon6=$con6.connectionString=$env:FileUploadInfoContext

 #Extracting values of keys
  
 $key1=$root."appSettings"."add"| where {$_.key -eq 'PDFInputPath'}
 $key2=$root."appSettings"."add"| where {$_.key -eq 'PDFFlatInputPath'}
 $key3=$root."appSettings"."add"| where {$_.key -eq 'PDFOutputPath'}
 $key4=$root."appSettings"."add"| where {$_.key -eq 'ProviderReplicaOutputPath'}
 $key5=$root."appSettings"."add"| where {$_.key -eq 'MultiPlanPOID'}
 $key6=$root."appSettings"."add"| where {$_.key -eq 'RetrievalServiceURL'}
 $key7=$root."appSettings"."add"| where {$_.key -eq 'CSVMapperFolderPath'}
  

 #Replacing the keys with environment specific release variables
 
 $newKey1=$Key1.value=$env:PDFInputPath
 $newKey2=$Key2.value=$env:PDFFlatInputPath
 $newKey3=$Key3.value=$env:PDFOutputPath
 $newKey4=$Key4.value=$env:ProviderReplicaOutputPath
 $newKey5=$Key5.value=$env:MultiPlanPOID
 $newKey6=$Key6.value=$env:RetrievalServiceURL
 $newKey7=$Key7.value=$env:CSVMapperFolderPath

#Adding a new key
  if($env:EnableCOQuestionSwap){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "EnableCOQuestionSwap"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "EnableCOQuestionSwap"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:EnableCOQuestionSwap
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }

    }

#Adding a new key
  if($env:COReplicaReleaseDate){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "COReplicaReleaseDate"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "COReplicaReleaseDate"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:COReplicaReleaseDate
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }


	}
 #Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node = $doc.selectSingleNode('//compilation')
$node.RemoveAttribute('debug')

 #creating a new endpoint

  if($env:newheaderPVSServiceSoap){
# First check if the header exists
$header=$root.'system.serviceModel'.client.endpoint | where {$_.bindingConfiguration -eq 'PVSServiceSoap'}
    if($header){
        Write-Host "The header already Exists"
        
    }
    else{

 $xmlConfigSections = $doc.SelectSingleNode("//system.serviceModel/client")


# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("endpoint")
$xmlAttr = $doc.CreateAttribute("address")
$xmlAttr.Value = $env:newheaderPVSServiceSoap
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("binding")
$xmlAttr1.Value = "basicHttpBinding"
$sectionGroup.Attributes.Append($xmlAttr1)
$xmlAttr2 = $doc.CreateAttribute("bindingConfiguration")
$xmlAttr2.Value = "PVSServiceSoap"
$sectionGroup.Attributes.Append($xmlAttr2)
$xmlAttr3 = $doc.CreateAttribute("contract")
$xmlAttr3.Value = "TINCheck.PVSServiceSoap"
$sectionGroup.Attributes.Append($xmlAttr3)
$xmlAttr4 = $doc.CreateAttribute("name")
$xmlAttr4.Value = "PVSServiceSoap"
$sectionGroup.Attributes.Append($xmlAttr4)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)
}
}

#creating a new endpoint

if($env:newheaderwspHVLookupSoap){
# First check if the header exists
$header=$root.'system.serviceModel'.client.endpoint | where {$_.bindingConfiguration -eq 'wspHVLookupSoap'}
    if($header){
        Write-Host "The header already Exists"
        
    }
    else{

 $xmlConfigSections = $doc.SelectSingleNode("//system.serviceModel/client")


# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("endpoint")
$xmlAttr = $doc.CreateAttribute("address")
$xmlAttr.Value = $env:newheaderwspHVLookupSoap
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("binding")
$xmlAttr1.Value = "basicHttpBinding"
$sectionGroup.Attributes.Append($xmlAttr1)
$xmlAttr2 = $doc.CreateAttribute("bindingConfiguration")
$xmlAttr2.Value = "wspHVLookupSoap"
$sectionGroup.Attributes.Append($xmlAttr2)
$xmlAttr3 = $doc.CreateAttribute("contract")
$xmlAttr3.Value = "HIPAASpace.wspHVLookupSoap"
$sectionGroup.Attributes.Append($xmlAttr3)
$xmlAttr4 = $doc.CreateAttribute("name")
$xmlAttr4.Value = "wspHVLookupSoap"
$sectionGroup.Attributes.Append($xmlAttr4)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)
}
}


#creating a new endpoint

if($env:newheaderdeawebsvcSoap){
# First check if the header exists
$header=$root.'system.serviceModel'.client.endpoint | where {$_.bindingConfiguration -eq 'deawebsvcSoap'}
    if($header){
        Write-Host "The header already Exists"
        
    }
    else{

 $xmlConfigSections = $doc.SelectSingleNode("//system.serviceModel/client")


# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("endpoint")
$xmlAttr = $doc.CreateAttribute("address")
$xmlAttr.Value = $env:newheaderdeawebsvcSoap
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("binding")
$xmlAttr1.Value = "basicHttpBinding"
$sectionGroup.Attributes.Append($xmlAttr1)
$xmlAttr2 = $doc.CreateAttribute("bindingConfiguration")
$xmlAttr2.Value = "deawebsvcSoap"
$sectionGroup.Attributes.Append($xmlAttr2)
$xmlAttr3 = $doc.CreateAttribute("contract")
$xmlAttr3.Value = "DEAService.deawebsvcSoap"
$sectionGroup.Attributes.Append($xmlAttr3)
$xmlAttr4 = $doc.CreateAttribute("name")
$xmlAttr4.Value = "deawebsvcSoap"
$sectionGroup.Attributes.Append($xmlAttr4)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)
}
}

#endpoint address modification from old edm urls to new edm urls

if($env:edmbulkextractdocs){
$endpoint1 = $root.'system.serviceModel'.client.endpoint | where {$_.bindingConfiguration -eq 'WSHttpBinding_IBulkExtractDocs'}
$newcon7 =$endpoint1.address= $env:edmbulkextractdocs
}
if($env:edmdocviewer){
$endpoint2 = $root.'system.serviceModel'.client.endpoint | where {$_.bindingConfiguration -eq 'WebHttpBinding_IDocServ'}
$newcon8 =$endpoint2.address=$env:edmdocviewer
}
 $doc.Save($webConfig)