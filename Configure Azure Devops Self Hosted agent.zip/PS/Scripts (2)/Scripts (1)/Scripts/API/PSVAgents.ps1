﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(servicesoln)-L&D\Publish\APIs\PSVAgents\web.config"
$doc = (Get-Content $webConfig) -as [Xml]  
$root=$doc.get_DocumentElement()

#Module1:-
#Extracting values of connection strings
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'DMSConnection'}
$con4=$root."connectionStrings"."add"| where {$_.name -eq 'PSVDBContext'}
$con5=$root."connectionStrings"."add"| where {$_.name -eq 'ADLDSConn'}

#Replacing the connection strings with environment specific release variables
$newcon1=$con1.connectionString=$env:CrmServiceConfig
$newcon2=$con2.connectionString=$env:CAQHUPDCRMConn
$newcon3=$con3.connectionString=$env:DMSConnection
$newcon4=$con4.connectionString=$env:PSVDBContext
$newcon5=$con5.connectionString=$env:ADLDSConn

#Module2:-
#Extracting values of keys
$key1=$root."appSettings"."add"| where {$_.key -eq 'ADLDSUsername'} 
$key2=$root."appSettings"."add"| where {$_.key -eq 'ADLDSPassword'}
$key3=$root."appSettings"."add"| where {$_.key -eq 'ADLDSPort'}
$key4=$root."appSettings"."add"| where {$_.key -eq 'ADLDSPartitionName'}

#Replacing the keys with environment specific release variables
$newKey1=$Key1.value=$env:ADLDSUsername
$newKey2=$Key2.value=$env:ADLDSPassword
$newKey3=$Key3.value=$env:ADLDSPort
$newKey4=$Key4.value=$env:ADLDSPartitionName

#Module3:-
#Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node1 = $doc.selectSingleNode('//compilation')
$node1.RemoveAttribute('debug')

#Extracting the values
$node5=$root."system.web".membership.providers.add| where {$_.name -eq 'MyDSProvider'} 

#Replacing the values
if($env:applicationName){ 
$newNode5_applicationName=$node5.applicationName=$env:MyDSProvider_applicationName
}
if($env:connectionUsername){ 
$newNode5_connectionUsername=$node5.connectionUsername=$env:MyDSProvider_connectionUsername
}
if($env:connectionPassword){ 
$newNode5_connectionPassword=$node5.connectionPassword=$env:MyDSProvider_connectionPassword
}

#save the web.config
$doc.Save($webConfig)