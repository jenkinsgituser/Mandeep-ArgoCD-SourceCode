﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(DAsoln)-L&D\Publish\APIs\DirectoryAssureAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()

#Module1:-
#Extracting values of connection strings
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'DirectoryAssureContext'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con4=$root."connectionStrings"."add"| where {$_.name -eq 'ADLDSConn'}

#Replacing the connection strings with environment specific release variables
$newcon1=$con1.connectionString=$env:DirectoryAssureContext
$newcon2=$con2.connectionString=$env:CrmServiceConfig
$newcon3=$con3.connectionString=$env:CAQHUPDCRMConn
$newcon4=$con4.connectionString=$env:ADLDSConn

#Adding a new key
  if($env:InputJsonFolderPath_DirectoryAssureAPI){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "InputJsonFolderPath"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "InputJsonFolderPath"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:InputJsonFolderPath_DirectoryAssureAPI
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }
}

#Adding a new key
  if($env:InputJsonTempPath_DirectoryAssureAPI){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "InputJsonTempPath"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "InputJsonTempPath"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:InputJsonTempPath_DirectoryAssureAPI
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }
	}
	
	#Adding a new key
  if($env:MatchReportFilePath_DirectoryAssureAPI){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "MatchReportFilePath"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "MatchReportFilePath"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:MatchReportFilePath_DirectoryAssureAPI
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }
}

#Module3:-
#Commenting out some appsettings in SIT2:-
$node1=$doc.SelectNodes('//add')| Where-Object{$_.Key -eq "DAJsonPath" }
if($node1)
{
$node1.ParentNode.InnerXml = $node1.ParentNode.InnerXml.Replace($node1.OuterXml, $node1.OuterXml.Insert(0, "<!--").Insert($node1.OuterXml.Length+4, "-->"))
}
$node2=$doc.SelectNodes('//add')| Where-Object{$_.Key -eq "ExtractPath" }
if($node2)
{
$node2.ParentNode.InnerXml = $node2.ParentNode.InnerXml.Replace($node2.OuterXml, $node2.OuterXml.Insert(0, "<!--").Insert($node2.OuterXml.Length+4, "-->"))
}
$node3=$doc.SelectNodes('//add')| Where-Object{$_.Key -eq "ReturnExtractPath" }
if($node3)
{
$node3.ParentNode.InnerXml = $node3.ParentNode.InnerXml.Replace($node3.OuterXml, $node3.OuterXml.Insert(0, "<!--").Insert($node3.OuterXml.Length+4, "-->"))
}

#Module4:-
#Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node4 = $doc.selectSingleNode('//compilation')
$node4.RemoveAttribute('debug')

#Extracting the values
$node5=$root."system.web".membership.providers.add| where {$_.name -eq 'MyDSProvider'} 

#Replacing the values
if($env:applicationName){ 
$newNode5_applicationName=$node5.applicationName=$env:MyDSProvider_applicationName
}
if($env:connectionUsername){ 
$newNode5_connectionUsername=$node5.connectionUsername=$env:MyDSProvider_connectionUsername
}
if($env:connectionPassword){ 
$newNode5_connectionPassword=$node5.connectionPassword=$env:MyDSProvider_connectionPassword
}
#Module 5:-
#Adding the new tags:-
$node6=$doc.CreateElement("pages")
$root."system.web".AppendChild($node6)
$subnode=$doc.CreateElement("namespaces")
$node6.AppendChild($subnode)
$subnodeNode=$doc.CreateElement("clear")
$subnode.AppendChild($subnodeNode)

#save the web.config
$doc.Save($webConfig)