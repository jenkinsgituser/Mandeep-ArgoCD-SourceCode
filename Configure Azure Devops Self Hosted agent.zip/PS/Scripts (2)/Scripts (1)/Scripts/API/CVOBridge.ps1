﻿Param(
[string]$Directory
)
$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(servicesoln)-L&D\Publish\APIs\CVOBridge\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]  
$root=$doc.get_DocumentElement()

#Module1:-
#Extracting values of connection strings
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'ADLDSConn'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con4=$root."connectionStrings"."add"| where {$_.name -eq 'CAQH_IntegrationConn'}

#Replacing the connection strings with environment specific release variables
$newcon1=$con1.connectionString=$env:ADLDSConn
$newcon2=$con2.connectionString=$env:CrmServiceConfig
$newcon3=$con3.connectionString=$env:CAQHUPDCRMConn
$newcon4=$con4.connectionString=$env:CAQH_IntegrationConn

#Module2:-
#Extracting values of keys
$key1=$root."appSettings"."add"| where {$_.key -eq 'ADLDSUsername'} 
$key2=$root."appsettings"."add"| where {$_.key -eq 'ADLDSPassword'}
$key3=$root."appsettings"."add"| where {$_.key -eq 'ADLDSPort'}
$key4=$root."appsettings"."add"| where {$_.key -eq 'ADLDSPartitionName'}
$key5=$root."appsettings"."add"| where {$_.key -eq 'ADLDSEnableSSL'}

#Replacing the keys with environment specific release variables
$newKey1=$Key1.value=$env:ADLDSUsername
$newKey2=$Key2.value=$env:ADLDSPassword
$newKey3=$Key3.value=$env:ADLDSPort
$newKey4=$Key4.value=$env:ADLDSPartitionName
$newKey5=$Key5.value=$env:ADLDSEnableSSL

#Module3:-
#Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node1 = $doc.selectSingleNode('//compilation')
$node1.RemoveAttribute('debug')

#Module4:-
#Commenting Out Section Name Entity Framework:-
$node1=$doc.SelectNodes('//section')| Where-Object{$_.name -eq "entityFramework" }
$node1.ParentNode.InnerXml = $node1.ParentNode.InnerXml.Replace($node1.OuterXml, $node1.OuterXml.Insert(0, "<!--").Insert($node1.OuterXml.Length+4, "-->"))

#save the web.config
$doc.Save($webConfig)