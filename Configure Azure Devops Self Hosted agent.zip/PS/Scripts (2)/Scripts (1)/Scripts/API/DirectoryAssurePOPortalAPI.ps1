﻿Param(
[string]$Directory
)
$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(DAsoln)-L&D\Publish\APIs\DirectAssurePOPortalAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of connection strings
 
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'DirectoryAssureContext'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con4=$root."connectionStrings"."add"| where {$_.name -eq 'DMSConnection'}
$con5=$root."connectionStrings"."add"| where {$_.name -eq 'FileUploadInfoContext'}

#Replacing the connection strings with environment specific release variables

 $newcon1=$con1.connectionString=$env:DirectoryAssureContext
 $newcon2=$con2.connectionString=$env:CrmServiceConfig
 $newcon3=$con3.connectionString=$env:CAQHUPDCRMConn
 $newcon4=$con4.connectionString=$env:DMSConnection
 $newcon5=$con5.connectionString=$env:FileUploadInfoContext
 
 #Module2:-
#Extracting values of keys
$key1=$root."appSettings"."add"| where {$_.key -eq 'Rosterftppath'} 
$key2=$root."appSettings"."add"| where {$_.key -eq 'BulkUploadTempPath'}

#Replacing the keys with environment specific release variables
$newKey1=$Key1.value=$env:Rosterftppath
$newKey2=$Key2.value=$env:BulkUploadTempPath

 #Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node4 = $doc.selectSingleNode('//compilation')
$node4.RemoveAttribute('debug')

#Adding the new tags:-
$node6=$doc.CreateElement("pages")
$root."system.web".AppendChild($node6)
$subnode=$doc.CreateElement("namespaces")
$node6.AppendChild($subnode)
$subnodeNode=$doc.CreateElement("clear")
$subnode.AppendChild($subnodeNode)

#save the web.config
$doc.Save($webConfig)