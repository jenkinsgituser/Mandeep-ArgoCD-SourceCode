﻿Param(
[string]$Directory
)
$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(DAsoln)-L&D\Publish\APIs\DirectAssureExtractAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of connection strings
 
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'DirectoryAssureContext'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}

#Replacing the connection strings with environment specific release variables

 $newcon1=$con1.connectionString=$env:DirectoryAssureContext
 $newcon2=$con2.connectionString=$env:CrmServiceConfig
 $newcon3=$con3.connectionString=$env:CAQHUPDCRMConn
 
 # Find node with key="ConnectionString"
$Remove1 = $root.appSettings.add |Where-Object {$_.Key -eq 'DAJsonPath'}
$Remove2 = $root.appSettings.add |Where-Object {$_.Key -eq 'ExtractPath'}
$Remove3 = $root.appSettings.add |Where-Object {$_.Key -eq 'ReturnExtractPath'}
$Remove4 = $root.appSettings.add |Where-Object {$_.Key -eq 'CommandTimeout'}

# Remove this node from it's parent
$root.appSettings.RemoveChild($Remove1) | Out-Null
$root.appSettings.RemoveChild($Remove2) | Out-Null
$root.appSettings.RemoveChild($Remove3) | Out-Null
$root.appSettings.RemoveChild($Remove4) | Out-Null





# create the new <sectionGroup> element with a 'name' attribute
$xmlConfigSections = $doc.SelectSingleNode("//system.web")

$newElement = $doc.CreateElement('pages')
$newElement.InnerXML = '<namespaces>
        <clear />
      </namespaces>'

$doc.configuration.'system.webServer'.AppendChild($newElement) | Out-Null




 if($env:newheaderrewrite){
# First check if the header exists
$header=$rootsystem.system.webServer.rewrite.rules.remove  | where {$_.name -eq $env:newheaderrewrite}
    if($header){
        Write-Host "The header already Exists"
        
    }
    else{

$newElement = $doc.CreateElement('rewrite')
$newElement.InnerXML = '<rules>
                <remove name="DirectAssureAPIRewrite" />
                <rule name="DomainRewriteforAPI" enabled="false" stopProcessing="true">
                    <match url=".*" />
                    <conditions logicalGrouping="MatchAny" />
                    <action type="Redirect" url="https://directassure.caqh.org/directassureextractapi/{R:0}" logRewrittenUrl="true" />
                </rule>
                <rule name="DirectAssureAPIRewrite" enabled="false">
                    <match url="^/directassureextractapi/.*" />
                    <conditions />
                    <serverVariables />
                    <action type="Rewrite" url="https://directassure.caqh.org/directassureextractapi/{R:0}" />
                </rule>
            </rules>'

$doc.configuration.'system.webServer'.AppendChild($newElement) | Out-Null
}
}

$node1=$root.runtime.assemblyBinding.dependentAssembly.assemblyIdentity| where {$_.name -eq 'System.Net.Http.Formatting'}
$node2=$node1.ParentNode
$node3=$node2.ParentNode
$node3.RemoveChild($node2)

$doc.Save($webConfig)
