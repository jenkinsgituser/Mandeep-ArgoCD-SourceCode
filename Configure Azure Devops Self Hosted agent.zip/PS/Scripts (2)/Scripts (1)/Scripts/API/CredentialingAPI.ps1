﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(servicesoln)-L&D\Publish\APIs\CredentialingAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]  
$root=$doc.get_DocumentElement()

#Module1:-
#Extracting values of connection strings
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'DMSConnection'}
$con4=$root."connectionStrings"."add"| where {$_.name -eq 'RosterIntegrationContext'}
$con5=$root."connectionStrings"."add"| where {$_.name -eq 'ADLDSConn'}

#Replacing the connection strings with environment specific release variables
$newcon1=$con1.connectionString=$env:CrmServiceConfig
$newcon2=$con2.connectionString=$env:CAQHUPDCRMConn
$newcon3=$con3.connectionString=$env:DMSConnection
$newcon4=$con4.connectionString=$env:RosterIntegrationContext
$newcon5=$con5.connectionString=$env:ADLDSConn

#Module2:-
#Extracting values of keys
$key1=$root."appSettings"."add"| where {$_.key -eq 'ADLDSUsername'} 
$key2=$root."appsettings"."add"| where {$_.key -eq 'ADLDSServer'}
$key3=$root."appsettings"."add"| where {$_.key -eq 'ADLDSPassword'}
$key4=$root."appsettings"."add"| where {$_.key -eq 'ADLDSPartitionName'}

#Replacing the keys with environment specific release variables
$newKey1=$Key1.value=$env:ADLDSUsername
$newKey2=$Key2.value=$env:ADLDSServer
$newKey3=$Key3.value=$env:ADLDSPassword
$newKey4=$Key4.value=$env:ADLDSPartitionName

#Module3:-
#Adding new appsetting:-
if($env:ReleaseDate)
{
    # First check if the header exists
    $header=$root.'appSettings'.add | where {$_.name -eq "ReleaseDate"}

        if($header)
        {
            Write-Host "The header already Exists"
        }
        else
        {
            # navigate to the <configSections> element 
            $xmlConfigSections = $doc.SelectSingleNode("//appSettings")
            # create the new <sectionGroup> element with a 'name' attribute 
            $sectionGroup = $doc.CreateElement("add") 
            $xmlAttr = $doc.CreateAttribute("key") 
            $xmlAttr.Value = "ReleaseDate"
            $sectionGroup.Attributes.Append($xmlAttr)
            $xmlAttr1 = $doc.CreateAttribute("value") 
            $xmlAttr1.Value = $env:ReleaseDate
            $sectionGroup.Attributes.Append($xmlAttr1)
            # now add the new <sectionGroup> element to the <configSections> element
            $xmlConfigSections.AppendChild($sectionGroup)
        }
}

#Module4:-
#Removing the appsetting:-
if($env:UniqueValuePOList)
{
    $node8=$root."appSettings"."add"| where {$_.key -eq 'UniqueValuePOList'} 
    $node8.Value=$env:UniqueValuePOList
}
else
{
    $node1=$doc.SelectNodes('//add')| Where-Object{$_.Key -eq "UniqueValuePOList" }
    $node2=$node1.ParentNode
    $node2.RemoveChild($node1)
}

#Module5:-
#Commenting out the <clear> tag as it is not getting deleted
$node3=$doc.selectSingleNode('//clear')
$node3.ParentNode.InnerXml = $node3.ParentNode.InnerXml.Replace($node3.OuterXml, $node3.OuterXml.Insert(0, "<!--").Insert($node3.OuterXml.Length+4, "-->"))

$node5=$root.appSettings.SelectSingleNode('//clear')
$node5.ParentNode.InnerXml = $node5.ParentNode.InnerXml.Replace($node5.OuterXml, $node5.OuterXml.Insert(0, "<!--").Insert($node5.OuterXml.Length+4, "-->"))

$node6=$root."system.web".membership.providers.FirstChild
$node6.ParentNode.InnerXml = $node6.ParentNode.InnerXml.Replace($node6.OuterXml, $node6.OuterXml.Insert(0, "<!--").Insert($node6.OuterXml.Length+4, "-->"))

#Module6:-
#Adding New Validation:-
if($env:validateIntegratedModeConfiguration)
{
            # navigate to the <configSections> element 
            $xmlConfigSections = $doc.SelectSingleNode("//system.webServer")
            # create the new <sectionGroup> element with a 'name' attribute 
            $sectionGroup = $doc.CreateElement("validation") 

            $xmlAttr = $doc.CreateAttribute("validateIntegratedModeConfiguration") 
            $xmlAttr.Value = "false"
            $sectionGroup.Attributes.Append($xmlAttr)
            # now add the new <sectionGroup> element to the <configSections> element
            $xmlConfigSections.AppendChild($sectionGroup)      

}

#Module7:-
#Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node4 = $doc.selectSingleNode('//compilation')
$node4.RemoveAttribute('debug')


#save the web.config
$doc.Save($webConfig)