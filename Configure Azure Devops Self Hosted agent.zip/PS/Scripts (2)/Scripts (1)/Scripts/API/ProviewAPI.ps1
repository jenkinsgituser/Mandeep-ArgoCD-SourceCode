﻿Param(
[string]$Directory
)
$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(servicesoln)-L&D\Publish\APIs\ProviewAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of connection strings
 

$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'DMSConnection'}
$con4=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHPortalContext'}
$con5=$root."connectionStrings"."add"| where {$_.name -eq 'PSVDBContext'}
$con6=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCredentialingAPIContext'}
$con7=$root."connectionStrings"."add"| where {$_.name -eq 'RosterIntegrationContext'}
$con8=$root."connectionStrings"."add"| where {$_.name -eq 'RosterAPIContext'}
$con9=$root."connectionStrings"."add"| where {$_.name -eq 'OutreachContext'}
$con10=$root."connectionStrings"."add"| where {$_.name -eq 'CAQH_IntegrationConn'}

#Replacing the connection strings with environment specific release variables

 $newcon1=$con1.connectionString=$env:CrmServiceConfig
 $newcon2=$con2.connectionString=$env:CAQHUPDCRMConn
 $newcon3=$con3.connectionString=$env:DMSConnection
 $newcon4=$con4.connectionString=$env:CAQHPortalContext
 $newcon5=$con5.connectionString=$env:PSVDBContext
 $newcon6=$con6.connectionString=$env:CAQHUPDCredentialingAPIContext
 $newcon7=$con7.connectionString=$env:RosterIntegrationContext
 $newcon8=$con8.connectionString=$env:RosterAPIContext
 $newcon9=$con9.connectionString=$env:OutreachContext
 $newcon10=$con10.connectionString=$env:CAQH_IntegrationConn

 #Extracting values of keys
  
 $key1=$root."appSettings"."add"| where {$_.key -eq 'Raw_File_Folder_Initial'}
 $key2=$root."appSettings"."add"| where {$_.key -eq 'Raw_File_Folder_Final'}
 $key3=$root."appSettings"."add"| where {$_.key -eq 'RetrievalServiceURL'}
 $key4=$root."appSettings"."add"| where {$_.key -eq 'ReplicaServiceURL'}
 $key5=$root."appSettings"."add"| where {$_.key -eq 'ExcludeProviderSections'}
 $key6=$root."appSettings"."add"| where {$_.key -eq 'ExcludeFieldsFromSections'}
 $key7=$root."appSettings"."add"| where {$_.key -eq 'EnableSwagger'}
 

 #Replacing the keys with environment specific release variables
 
 $newKey1=$Key1.value=$env:Raw_File_Folder_Initial
 $newKey2=$Key2.value=$env:Raw_File_Folder_Final
 $newKey3=$Key3.value=$env:RetrievalServiceURL
 $newKey4=$Key4.value=$env:ReplicaServiceURL
 $newKey5=$Key5.value=$env:ExcludeProviderSections
 $newKey6=$Key6.value=$env:ExcludeFieldsFromSections
 $newKey7=$Key7.value=$env:EnableSwagger

 
 #adding a new key
 if($env:RosterWorkFlowID){
# First check if the key exists
$header=$root.'appSettings'.add | where {$_.name -eq "RosterWorkFlowID"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "RosterWorkFlowID"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:RosterWorkFlowID
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }

	}


#adding a new key
 if($env:USPSBaseUrl){
# First check if the key exists
$header=$root.'appSettings'.add | where {$_.name -eq "USPSBaseUrl"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "USPSBaseUrl"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:USPSBaseUrl
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }

	}


#adding a new key
 if($env:USPSUserID){
# First check if the key exists
$header=$root.'appSettings'.add | where {$_.name -eq "USPSUserID"}
    if($header){
        Write-Host "The key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "USPSUserID"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:USPSUserID
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new key"
    }

	}


#adding a new key
 if($env:ADAPOID){
# First check if the key exists
    $header=$root.'appSettings'.add | where {$_.name -eq "ADAPOID"}
        if($header){
         Write-Host "The key already Exists"
        
                   }
        else{
 # navigate to the <configSections> element
        $xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
        $sectionGroup = $doc.CreateElement("add")
        $xmlAttr = $doc.CreateAttribute("key")
        $xmlAttr.Value = "ADAPOID"
        $sectionGroup.Attributes.Append($xmlAttr)
        $xmlAttr1 = $doc.CreateAttribute("value")
        $xmlAttr1.Value = $env:ADAPOID
        $sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
        $xmlConfigSections.AppendChild($sectionGroup)

        Write-Host "Created a new key"
                }

	          }

#endpoint address modification from old edm urls to new edm urls

if($env:edmbulkextractdocs){
$endpoint1 = $root.'system.serviceModel'.client.endpoint | where {$_.bindingConfiguration -eq 'WSHttpBinding_IBulkExtractDocs'}
$newcon11 =$endpoint1.address= $env:edmbulkextractdocs
}
if($env:edmdocviewer){
$endpoint2 = $root.'system.serviceModel'.client.endpoint | where {$_.bindingConfiguration -eq 'WebHttpBinding_IDocServ'}
$newcon12 =$endpoint2.address=$env:edmdocviewer
}

 #Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node = $doc.selectSingleNode('//compilation')
$node.RemoveAttribute('debug')

$doc.Save($webConfig)