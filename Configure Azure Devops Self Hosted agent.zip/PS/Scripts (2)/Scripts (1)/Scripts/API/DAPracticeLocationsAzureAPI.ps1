﻿Param(
[string]$Directory
)
$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(DAsoln)-L&D\Publish\APIs\DAPracticeLocationsAzureAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of connection strings
 

$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'DirectoryAssureContext'}

#Replacing the connection strings with environment specific release variables

 $newcon1=$con1.connectionString=$env:CrmServiceConfig
 $newcon2=$con2.connectionString=$env:CAQHUPDCRMConn
 $newcon3=$con3.connectionString=$env:DirectoryAssureContext
 
# create the new <sectionGroup> element with a 'name' attribute
$xmlConfigSections = $doc.SelectSingleNode("//system.web")

$newElement = $doc.CreateElement('pages')
$newElement.InnerXML = '<namespaces>
        <clear />
      </namespaces>'

$doc.configuration.'system.webServer'.AppendChild($newElement) | Out-Null


# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.configuration.'system.webServer'.modules
$xmlAttr = $doc.CreateAttribute("runAllManagedModulesForAllRequests")
$xmlAttr.Value = $env:newheader
$sectionGroup.Attributes.Append($xmlAttr)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)


$doc.Save($webConfig)