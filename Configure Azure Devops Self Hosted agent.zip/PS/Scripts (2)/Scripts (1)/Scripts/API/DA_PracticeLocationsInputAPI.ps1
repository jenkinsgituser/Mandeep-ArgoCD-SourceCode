﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(DAsoln)-L&D\Publish\APIs\DA_PracticeLocationsInputAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]  
$root=$doc.get_DocumentElement()

#Module1:-
#Extracting values of connection strings
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'DirectoryAssureContext'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}

#Replacing the connection strings with environment specific release variables
$newcon1=$con1.connectionString=$env:DirectoryAssureContext
$newcon2=$con2.connectionString=$env:CAQHUPDCRMConn
$newcon3=$con3.connectionString=$env:CrmServiceConfig

#Module2:-
#Extracting values of keys
$key1=$root."appSettings"."add"| where {$_.key -eq 'InputJsonFolderPath'} 
$key2=$root."appsettings"."add"| where {$_.key -eq 'InputJsonTempPath'}
$key3=$root."appsettings"."add"| where {$_.key -eq 'MatchReportFilePath'}

#Replacing the keys with environment specific release variables
$newKey1=$Key1.value=$env:InputJsonFolderPath
$newKey2=$Key2.value=$env:InputJsonTempPath
$newKey3=$Key3.value=$env:MatchReportFilePath

#Module3:-
#Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node4 = $doc.selectSingleNode('//compilation')
$node4.RemoveAttribute('debug')

#Extracting the values
$node5=$root."system.web".membership.providers.add| where {$_.name -eq 'MyDSProvider'} 

#Replacing the values
if($env:applicationName){ 
$newNode5_applicationName=$node5.applicationName=$env:MyDSProvider_applicationName
}
if($env:connectionUsername){ 
$newNode5_connectionUsername=$node5.connectionUsername=$env:MyDSProvider_connectionUsername
}
if($env:connectionPassword){ 
$newNode5_connectionPassword=$node5.connectionPassword=$env:MyDSProvider_connectionPassword
}

#Module 4:-
#Adding the new tags:-
$node6=$doc.CreateElement("pages")
$root."system.web".AppendChild($node6)
$subnode=$doc.CreateElement("namespaces")
$node6.AppendChild($subnode)
$subnodeNode=$doc.CreateElement("clear")
$subnode.AppendChild($subnodeNode)

$xmlConfigSections = $doc.SelectSingleNode("//system.webServer")
$node7=$doc.CreateElement("directoryBrowse")
$xmlAttr=$doc.CreateAttribute("enabled")
$xmlAttr.Value="false"
$node7.Attributes.Append($xmlAttr)
$root."system.webServer".AppendChild($node7)


#Module5:-
#Removing Dependent Asseblies:-
#Commenting out Assemly References:-

$node8=$root.runtime.assemblyBinding.dependentAssembly.assemblyIdentity| where {$_.name -eq 'Newtonsoft.Json'}
$node9=$node8.ParentNode
$node10=$node9.ParentNode
$node10.RemoveChild($node9)

$node11=$root.runtime.assemblyBinding.dependentAssembly.assemblyIdentity| where {$_.name -eq 'System.Web.Razor'}
$node12=$node11.ParentNode
$node13=$node12.ParentNode
$node13.RemoveChild($node12)

$node14=$root.runtime.assemblyBinding.dependentAssembly.assemblyIdentity| where {$_.name -eq 'System.Web.WebPages.Razor'}
$node15=$node14.ParentNode
$node16=$node15.ParentNode
$node16.RemoveChild($node15)

#Module6:-
#Updating the Assembly Binding Version:-

$node17=$root.runtime.assemblyBinding.dependentAssembly.assemblyIdentity| where {$_.name -eq 'System.Web.WebPages'}
$node18=$node17.ParentNode
$node18.bindingRedirect.oldVersion="1.0.0.0-3.0.0.0"

#save the web.config
$doc.Save($webConfig)