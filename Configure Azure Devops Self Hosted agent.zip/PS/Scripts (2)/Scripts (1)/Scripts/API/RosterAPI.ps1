﻿Param(
[string]$Directory
)
$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-API(servicesoln)-L&D\Publish\APIs\RosterAPI\Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of connection strings
 

$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$con3=$root."connectionStrings"."add"| where {$_.name -eq 'RosterAPIContext'}

#Replacing the connection strings with environment specific release variables

 $newcon1=$con1.connectionString=$env:CrmServiceConfig
 $newcon2=$con2.connectionString=$env:CAQHUPDCRMConn
 $newcon3=$con3.connectionString=$env:RosterAPIContext

 #Extracting values of keys
  
 $key1=$root."appSettings"."add"| where {$_.key -eq 'Raw_File_Folder_Initial'}
 $key2=$root."appSettings"."add"| where {$_.key -eq 'Raw_File_Folder_Final'}
 $key3=$root."appSettings"."add"| where {$_.key -eq 'ADLDSUsername'}
 
 #Replacing the keys with environment specific release variables
 
 $newKey1=$Key1.value=$env:Raw_File_Folder_Initial
 $newKey2=$Key2.value=$env:Raw_File_Folder_Final
 $newKey3=$Key3.value=$env:ADLDSUsername

 #Updating tags under System.web:-
#Removing Debug attribute from compilation tag:-
$node = $doc.selectSingleNode('//compilation')
$node.RemoveAttribute('debug')

# navigate to the <configSections> element
        $xmlConfigSections = $doc.SelectSingleNode("//system.web/httpRuntime")


# create the new <sectionGroup> element with a 'name' attribute
if($env:maxRequestLength){
$sectionGroup = $doc.configuration.'system.web'.httpRuntime
$xmlAttr = $doc.CreateAttribute("maxRequestLength")
$xmlAttr.Value = $env:maxRequestLength
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("executionTimeout")
$xmlAttr1.Value = $env:executionTimeout
$sectionGroup.Attributes.Append($xmlAttr1)
}

#Adding the new tags:-
$node1=$doc.CreateElement("clear")
$root.'system.web'.pages.namespaces.AppendChild($node1)
$root.runtime.AppendChild($node1)  

#Extracting the values
$node5=$root."system.web".membership.providers.add| where {$_.name -eq 'MyDSProvider'} 

#Replacing the values
if($env:applicationName){ 
$newNode5_applicationName=$node5.applicationName=$env:MyDSProvider_applicationName
}
if($env:connectionUsername){ 
$newNode5_connectionUsername=$node5.connectionUsername=$env:MyDSProvider_connectionUsername
}
if($env:connectionPassword){ 
$newNode5_connectionPassword=$node5.connectionPassword=$env:MyDSProvider_connectionPassword
}

#save the web.config
$doc.Save($webConfig)