﻿Param(
[string]$Directory
)

$Directory=$env:build_artifactstagingdirectory
$webConfig = "$($Directory)\Publish\UPD.Databases\CAQH.UPD.Databases.CAQHUPDCRM"

$FindDB = @("Proview_MSCRM","ProviewTestRelease9_MSCRM","ProviewSIT3_MSCRM","ProviewDev_MSCRM","ProviewHotFix_MSCRM","training_demo_MSCRM","ProviewSIT2_MSCRM")


Foreach($Find in $FindDB)
{
$Find
    Get-ChildItem $Path -Recurse -Include "*.*" | ForEach-Object { (Get-Content $_.FullName) | ForEach-Object {$_ -replace $Find,"Proview_MSCRM" } | Set-Content $_.FullName }
}

Get-ChildItem $Path -Recurse -Include "*.*" | ForEach-Object { (Get-Content $_.FullName) | ForEach-Object {$_ -replace "Proview_MSCRM",$env:CRMDBName } | Set-Content $_.FullName }
