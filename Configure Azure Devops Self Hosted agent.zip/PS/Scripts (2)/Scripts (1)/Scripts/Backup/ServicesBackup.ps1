$FolderName = (Get-Date).tostring("dd-MM-yyyy-hh-mm-ss")            
$NewFolder=New-Item -itemType Directory -Path $env:BKP_Dest -Name $FolderName
$pass=$env:WebServer_pwd|ConvertTo-SecureString -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PsCredential($env:WebServer_Username,$pass)
New-PSDrive -name bkp -Root $env:Root -Credential $cred -PSProvider filesystem
Copy-Item $env:BKP_Src -Destination $NewFolder -recurse -Force -Exclude "Miscellaneous"
Remove-PSDrive bkp