﻿#Same PowerShell script as vstsl_UpdateBuilInfoTag.ps1
#PowerShell script to create/ update the bild info tag in a webapp

Param(
  [string]$buildinfo,
  [string]$webappname,
  [string]$rg,
  [int]$debug
)
If($debug -eq 2){
    $InformationPreference="Continue"
}

Write-Information -MessageData "BuildInfoValue is: $buildinfo"
Write-Information -MessageData "Retrieving web app object"
$webapp = Get-AzureRmWebApp -ResourceGroupName $rg -Name $webappname
$tags = ($webapp).Tags
try{
    $tags += @{BuildInfo=$buildinfo}    
    Write-Information -MessageData "Build info not created adding it now."
}
catch{    
    Write-Information -MessageData "BuildInfo Already Created Updating value..."
    $tags['BuildInfo'] = $buildinfo
}

Write-Information -MessageData "Updating build info on $webappname1 with latest value"
Set-AzureRmResource -Tag $tags -ResourceId $webapp.id -Force | Out-Null
