Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig="$($Directory)\_CreateGetConfirmedPLInformationService-webjob\drop\CreateGetConfirmedPLInformationService-webjob\app.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()


#extract and change connectionstrings


$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CAQH_DirectoryAssure'}
$newcon3 = $con3.connectionString=$env:CAQH_DirectoryAssure


#extract and change auth


 #save the web.config
 $doc.Save($webConfig)