﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig="$($Directory)/_CI-WebAppDeployment/drop/Webapp/Web.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()


#extract and change connectionstrings
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
$newcon1 = $con1.connectionString=$env:CrmServiceConfig

$con2=$root."connectionStrings"."add"| where {$_.name -eq 'DirectoryAssureContext'}
$newcon2 = $con2.connectionString=$env:DirectoryAssureContext

$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$newcon3 = $con3.connectionString=$env:CAQHUPDCRMConn

$con4=$root."connectionStrings"."add"| where {$_.name -eq 'DMSConnection'}
$newcon4 = $con4.connectionString=$env:DMSConnection

$con5=$root."connectionStrings"."add"| where {$_.name -eq 'ADLDSConn'}
$newcon5 = $con5.connectionString=$env:ADLDSConn

$con6=$root."connectionStrings"."add"| where {$_.name -eq 'FileUploadInfoContext'}
$newcon6 = $con6.connectionString=$env:FileUploadInfoContext

$con7=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHPortalContext'}
$newcon7 = $con7.connectionString=$env:CAQHPortalContext

#extract and change auth

 $key1=$root."appSettings"."add"| where {$_.key -eq 'AuthTokenSecretKey'}
 $newkey1=$key1.value=$env:AuthTokenSecretKey

 $key2=$root."appSettings"."add"| where {$_.key -eq 'BulkUploadTempPath'}
 $newkey2=$key2.value=$env:BulkUploadTempPath 

 $key3=$root."appSettings"."add"| where {$_.key -eq 'Rosterftppath'}
 $newkey3=$key3.value=$env:Rosterftppath

 # Find keys which are not in use
 $Removekey1 = $root.appSettings.add |Where-Object {$_.Key -eq 'ServiceBusBaseUrl'}
 $Removekey2 = $root.appSettings.add |Where-Object {$_.Key -eq 'ClientId'}

# Remove this node from it's parent
$root.appSettings.RemoveChild($Removekey1) | Out-Null
$root.appSettings.RemoveChild($Removekey2) | Out-Null

 #save the web.config
 $doc.Save($webConfig)