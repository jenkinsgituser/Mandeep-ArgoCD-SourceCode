﻿ Param(
[string]$Directory
)

$keyvaultName = $env:Keyvault
$secrets = Get-AzureKeyVaultSecret -VaultName $keyvaultName
Write-Host $secrets
 
#Defining variable 
$secretName1= 'AddressStoreConnectionString'
$secretName2= 'AuthId'
$secretName3= 'AuthToken'
$secretName4= 'BlobStorageAccessKey'
$secretName5= 'ContainerName'
$secretName6= 'BlobInputFolderName'
$secretName7= 'BlobOutputFolderName'

#Fetching secretid for the variable defined above
$AddressStoreConnectionString = (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName1).Id
$AuthId = (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName2).Id
$AuthToken=(Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName3).Id
$BlobStorageAccessKey=(Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName4).Id
$ContainerName= (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName5).Id
$BlobInputFolderName= (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName6).Id
$BlobOutputFolderName= (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName7).Id

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)\_CI-SmartyStreet-webapp\drop\SmartyStreetWebapp\appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#updating secretid values to respective keys in config file

$doc.MySettings.ClientId=$env:ClientId
$doc.MySettings.ClientSecret=$env:ClientSecret
$doc.MySettings.AddressStoreConnectionString=$AddressStoreConnectionString
$doc.MySettings.AuthId=$AuthId
$doc.MySettings.AuthToken=$AuthToken
$doc.MySettings.BlobStorageAccessKey=$BlobStorageAccessKey
$doc.MySettings.MaximumInputAllowed=$env:MaximumInputAllowed
$doc.MySettings.HashGenerationField=$env:HashGenerationField
$doc.MySettings.ContainerName=$ContainerName
$doc.MySettings.BlobInputFolderName=$BlobInputFolderName
$doc.MySettings.BlobOutputFolderName=$BlobOutputFolderName
$doc.MySettings.ApplicationName=$env:ApplicationName

$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
