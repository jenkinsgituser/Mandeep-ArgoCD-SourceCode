﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)/_PMNPIIntegrationAPI-Webapp/drop/PMNPIIntegrationAPI/appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#extract and change connectionstrings

$doc.ConnectionString.PortalContext = $env:PortalContext
$doc.ConnectionString.StorageConnection = $env:StorageConnection


$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
