﻿Param(
[string]$Directory
)



$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)/_EPMMReconcilepracticelocations-WebJob/drop/CAQH.Proview.LocationReconciliation.Service/appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#extract and change connectionstrings

$doc.ConnectionString.CAQHUPDCRM = $env:CAQHUPDCRM
$doc.ConnectionString.CAQH_DirectoryAssure = $env:CAQH_DirectoryAssure
$doc.ConnectionString.DMSConnection = $env:DMSConnection
$doc.ConnectionString.UPDPortalConnection = $env:UPDPortalConnection

#extract and update other keys

$doc.ClientId = $env:ClientId
$doc.ClientSecret = $env:ClientSecret
$doc.KeyVaultURI= $env:KeyVaultURI
$doc.DirectAssurePOPortalAPI = $env:DirectAssurePOPortalAPI
$doc.ServiceBusBaseUrl=$env:ServiceBusBaseUrl

#extract and update ServiceBus values

#$doc.ServiceBus.pv-epm-queue = $env:pv-epm-queue
$doc.ServiceBus.ServiceBusConnectionString = $env:ServiceBusConnectionString

$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
