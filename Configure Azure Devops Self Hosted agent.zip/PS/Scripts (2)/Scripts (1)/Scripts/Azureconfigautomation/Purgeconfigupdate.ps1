﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)/PurgeEpmm-WebJob/drop/PurgEPMMWebJob/appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#extract and change connectionstrings

$doc.ConnectionString.CAQHUPDCRM = $env:CAQHUPDCRM
$doc.ConnectionString.CAQH_DirectoryAssure = $env:CAQH_DirectoryAssure
#extract and update other keys

#$doc.ClientId = $ClientId
#$doc.ClientSecret = $ClientSecret
#$doc.KeyVaultURI=$KeyVaultURI

$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
