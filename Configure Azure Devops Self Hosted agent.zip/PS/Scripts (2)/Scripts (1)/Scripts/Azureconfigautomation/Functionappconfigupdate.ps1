﻿ Param(
[string]$Directory
)

$keyvaultName = $env:Keyvault
$secrets = Get-AzureKeyVaultSecret -VaultName $keyvaultName
Write-Host $secrets

#Defining variable 
$secretName1= 'AuthTokenSecretKey'
$secretName2= 'DAPortalApiUrl'
$secretName3= 'DAPOPortalAPIUrl'
$secretName4= 'AuthTokenExpiry'
$secretName5= 'httpTimeout'

#Fetching secretid for the variable defined above
$AuthTokenSecretKey = (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName1).Id
$DAPortalApiUrl = (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName2).Id
$DAPOPortalAPIUrl=(Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName3).Id
$AuthTokenExpiry=(Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName4).Id
$httpTimeout= (Get-AzureKeyVaultSecret -VaultName $keyvaultName -Name $secretName5).Id

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)\_EPMMJsonGeneration-FunctionApp\drop\CAQH.DirectoryAssure.Services.GenerateEPMMJson\local.settings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#updating secretid values to respective keys in config file
$doc.Values.AzureWebJobsStorage=$env:AzureWebJobsStorage
$doc.Values.servicebusconnection=$env:servicebusconnection
$doc.Values.ClientId=$env:ClientId
$doc.Values.ClientSecret=$env:ClientSecret
$doc.Values.AuthTokenSecretKey=$AuthTokenSecretKey
$doc.Values.DAPortalApiUrl=$DAPortalApiUrl
$doc.Values.DAPOPortalAPIUrl=$DAPOPortalAPIUrl
$doc.Values.AuthTokenExpiry=$AuthTokenExpiry
$doc.Values.httpTimeout=$httpTimeout
$doc.Values.queuename=$env:queuename
$doc.Values.DLQqueuename=$env:DLQqueuename

$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
