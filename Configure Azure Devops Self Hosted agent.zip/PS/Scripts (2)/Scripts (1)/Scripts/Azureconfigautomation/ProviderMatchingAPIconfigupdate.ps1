﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig="$($Directory)/Azure-CD-ProviderMatching API-Webapp-dotnet6.0/drop/Webapp/web.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()


#extract and change auth

 $key1=$root."appSettings"."add"| where {$_.key -eq 'ManagedIdentityClientId'}
 $newkey1=$key1.value=$env:ManagedIdentityClientId

 $key2=$root."appSettings"."add"| where {$_.key -eq 'KeyVaultbaseURI'}
 $newkey2=$key2.value=$env:KeyVaultbaseURI
 
 $key3=$root."appSettings"."add"| where {$_.key -eq 'WebUserRoleId'}
 $newkey3=$key3.value=$env:WebUserRoleId


 #save the web.config
 $doc.Save($webConfig)