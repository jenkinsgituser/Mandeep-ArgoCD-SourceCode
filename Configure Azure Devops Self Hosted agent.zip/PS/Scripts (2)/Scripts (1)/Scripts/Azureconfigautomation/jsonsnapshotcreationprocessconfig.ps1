﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)\_CI-EPMM-Subscriber-JsonSnapshotcreateprocess_webjob\drop\CAQH.UPD.EPMM.Subscriber.JsonSnapshotCreationProcess\appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#extract and change Servicebus session
$doc.ConnectionString.CAQHPortalContext =$env:CAQHPortalContext
$doc.Azure.ServiceBusConnectionString =$env:ServiceBusConnectionString
$doc.Azure.jsonsnapshotcreationprocessqueue =$env:jsonsnapshotcreationprocessqueue
$doc.APPINSIGHTS_INSTRUMENTATIONKEY = $env:APPINSIGHTS_INSTRUMENTATIONKEY

#Save the changes
$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
