Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig="$($Directory)/_EPMMReconcilepracticelocations-WebJob/drop/CAQH.Proview.LocationReconciliation.Service/App.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()


#extract and change connectionstrings

$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHPortalContext'}
$newcon1 = $con1.connectionString=$env:CAQHPortalContext

 #save the web.config
 $doc.Save($webConfig)