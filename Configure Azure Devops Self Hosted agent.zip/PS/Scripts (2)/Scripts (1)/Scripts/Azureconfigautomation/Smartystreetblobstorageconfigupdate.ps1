﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)\_SmartyStreetBlobStorage-WebJob\drop\CAQH.UPD.SmartyStreetBlobStorageService\appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#extract and change Servicebus session

$doc.AzureWebJobsStorage=$env:AzureWebJobsStorage
$doc.AAD_Application_Id=$env:ClientId
$doc.AAD_Client_Secret=$env:ClientSecret
$doc.KeyVaultName=$env:KeyVaultName

#Save the changes
$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
