Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$dllConfig="$($Directory)\_CreateGetConfirmedPLInformationService-webjob\drop\CAQH.ProView.GetConfirmedPLInformationService\CAQH.ProView.GetConfirmedPLInformationService.dll.config"
$doc = (Get-Content $dllConfig) -as [Xml]
$root=$doc.get_DocumentElement()


#extract and change connectionstrings


$con3=$root."connectionStrings"."add"| where {$_.name -eq 'CAQH_DirectoryAssure'}
$newcon3 = $con3.connectionString=$env:CAQH_DirectoryAssure


#extract and change auth


 #save the web.config
 $doc.Save($dllConfig)