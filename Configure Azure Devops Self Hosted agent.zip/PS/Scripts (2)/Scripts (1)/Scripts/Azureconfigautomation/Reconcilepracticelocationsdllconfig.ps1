Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$dllConfig="$($Directory)/_EPMMReconcilepracticelocations-WebJob/drop/CAQH.Proview.LocationReconciliation.Service/CAQH.Proview.LocationReconciliation.Service.dll.config"
$doc = (Get-Content $dllConfig) -as [Xml]
$root=$doc.get_DocumentElement()


#extract and change connectionstrings

$con1=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHPortalContext'}
$newcon1 = $con1.connectionString=$env:CAQHPortalContext

 #save the web.config
 $doc.Save($dllConfig)