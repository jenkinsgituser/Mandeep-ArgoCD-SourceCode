﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)/_CI-ReplicaCachingWebjob/drop/ReplicaCaching/appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#extract and change Servicebus session

$doc.AzureConnectionStrings.ServiceBusConnectionString = $env:ServiceBusConnectionString
$doc.AzureConnectionStrings.StorageAccountConnectionString = $env:StorageAccountConnectionString

#extract and change connectionstrings

$doc.ConnectionString.CAQHUPDCRM = $env:CAQHUPDCRM
$doc.ConnectionString.DMSConnection = $env:DMSConnection

#extract and update other keys

$doc.ReplicaServiceURL = $ReplicaServiceURL

$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
