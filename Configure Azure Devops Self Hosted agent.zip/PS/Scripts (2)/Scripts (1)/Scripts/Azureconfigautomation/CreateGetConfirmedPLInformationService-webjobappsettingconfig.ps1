Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)\_CreateGetConfirmedPLInformationService-webjob\drop\CreateGetConfirmedPLInformationService-webjob\appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json


#extract and change Servicebus session

$doc.ConnectionString.CAQH_DirectoryAssure=$env:CAQH_DirectoryAssure


#Save the changes
$doc | ConvertTo-Json -Depth 32 | set-content $appsettings