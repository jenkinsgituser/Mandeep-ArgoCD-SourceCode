Param(
[string]$Directory
)

$Directory= $env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$($Directory)\_CI_EPMM_Subscriber_GroupPlanExtractGeneration_Webjob\drop\CAQH.UPD.EPMM.Subscriber.GroupPlanExtractGeneration\appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

$doc.Azure.ServiceBusConnectionString= $env:ServiceBusConnectionString
$doc.Azure.AzureBlobConnectionString= $env:AzureBlobConnectionString
$doc.Azure.ServiceBusBaseUrl= $env:ServiceBusBaseUrl

$doc.APPINSIGHTS_INSTRUMENTATIONKEY= $env:APPINSIGHTS_INSTRUMENTATIONKEY

#Save the changes
$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
