﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$settingsjob="$($Directory)/CreateDAJson-WebJob/drop/CAQH.UPD.CreateDAJson.Service/settings.job"
$doc = Get-Content -path $settingsjob | ConvertFrom-Json

#extract and change connectionstrings

$doc.schedule = $env:cronexpression 

$doc | ConvertTo-Json -Depth 32 | set-content $settingsjob 