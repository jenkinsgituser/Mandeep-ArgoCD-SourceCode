﻿#Same PowerShell script as vstsh_UpdatingValuesInAppsettingsFromApplicationSettingsOfWebapp.ps1. Same PowerShell script can be used for Groups lower and higher environments.

#This script works for all webapps in the environment.
#This script is meant to execute for a single webapp of an environment and not all webapps of the environment.
#This script is meant to update appsettings.json file of one webjob to be deployed in a webapp of an environment at a time, and not to update appsettings.json file for all webjobs in the webapps of the environment at a time.
#This script prepares appsettings.json file for webjobs to be deployed in webapps of the lower environments that is DEVa, SIT1, SIT2, SITa and UATA. This script prepares appsettings.json file for both continuous and triggered webjobs that are deployed in webapps of the lower environments.

#PowerShell script to connect to webapp, read the values from application settings of webapp and update the same in appsettings.json file of webjob to be deployed in webapp. This script prepares the appsettings.json file having environmental variables and custom variables of webjob.

#Initialize the variables that are used in the script
param(
#Initialize the path of appsettings.json file from the unzipped folder of the build artifacts
[string] $jsonfilepath, 
#Initialize the resource group name where the webapp is hosted
[string] $resourceGroup, 
<#
Initialize the webapp name where the webjob is to be uploaded. Initialize the webapp where the zipped folder of the webjob is to be uploaded. 
Initialize the webapp where the webjob is to be deployed. Assign the name of the webapp of the environment with the help of argument in Azure PowerShell task in the release pipeline in VSTS.
#>
[string] $webappName,
#Initialize the endpoint of API for some of the webjobs
[string] $webappendpoint,
#Initialize the APIM key for some of the webjobs
[string] $APIMSubscriptionKey,
#Initialize the Address book API Url for webjob deployed in webapp3
[string] $AddressBookAPIUrl,
#Initialize the Download blob prefix Url for webjob deployed in webapp4 and webapp5
[string] $downloadBlobPrefixURL,
#Initialize the Url of GroupManagementService for webjob deployed in webapp4
[string] $_ChangeReportAPIUrl,
#Initialize the Url of Auth.TokenIssuer for webjob deployed in webapp3 and webapp4
[string] $AuthTokenIssuer,
#Initialize the Url of Auth.TokenAudience for webjob deployed in webapp3 and webapp4
[string] $AuthTokenAudience,
#Initialize the Url of PractitionerURL for webjob deployed in webapp4
[string] $PractitionerURL,
#Initialize the Url of LocationURL for webjob deployed in webapp4
[string] $LocationURL,
#Initialize the Url of PractitionerLocationURL for webjob deployed in webapp4
[string] $PractitionerLocationURL,
#Initialize the Url of Groups portal in the environment for webjob deployed in webapp10
[string] $GroupsPortalUrl,
#Initialize the Boolean flag as true or false for SFTP webjob deployed in webapp10
[string] $BoolValue
)

<#
Fetch the values from application settings of the webapp, and no need to authenticate with the SCM site of the webapp by using publishing credentials and header for the webapp.
No need to get inside the SCM site of the webapp. These values can be simply obtained from application settings of the webapp.
#>
#Getting all the values from application settings of the webapp, but using only three environmental variables i.e. ClientId, ClientSecret and keyVaultURI
Write-Host ("Reading details from {0} webapp service" -f $webappName)
$appservicedetails = Get-AzureRmWebApp -ResourceGroupName $resourceGroup -Name $webappName
$appsettingsfrom = $appservicedetails.SiteConfig.AppSettings

foreach($key in $appsettingsfrom.GetEnumerator())
{
    # $key will have one parameter at a time from application settings of the webapp for each loop execution.
    if($key.Name -eq "ClientId")
    {
    $ClientId = $key.Value
    }
    elseif($key.Name -eq "ClientSecret")
    {
    $ClientSecret = $key.Value
    }
    elseif ($key.Name -eq "KeyVaultURI")
    {
    $KeyVaultURI = $key.Value
    }
}

<#
Read content from appsettings.json file in temp folder in the build artifacts location. Replace values in the same appsettings.json file in temp folder in the build artifacts location.
So, the original appsettings.json file will be overwritten and the modified appsettings.json file will be present in the same temp folder in the build artifacts folder.
#>
#original appsettings file
Write-Host ("Reading content of {0} jsonfile " -f $jsonfilepath)
#Read the original content of appsettings.json file from the temp folder in the build artifacts location and store the content in a variable.
$appsettingsfromjson = Get-Content -Path $jsonfilepath |convertfrom-json
#Traversing through all the key-value pairs in appsettings.json file by using foreach loop.
foreach($values in $appsettingsfromjson)												 
{
    # $values will have one parameter from appsettings.json file at a time for each loop execution.
	Write-Host("show the values of appsettings.json file {0}" -f $values)
    #Replacing the environmental variables ClientId, ClientSecret and KeyVaultURI in appsettings.json of webjob as per the values from application settings of the webapp.
	if($values.ClientId)
	{
	$appsettingsfromjson.ClientId = "$ClientId"
	}
	if($values.ClientSecret)
	{
	$appsettingsfromjson.ClientSecret = "$ClientSecret"
	}
	if($values.KeyVaultURI)
	{
	$appsettingsfromjson.KeyVaultURI = "$KeyVaultURI"
	}
    #Replacing the custom values in appsettings.json file of webjob as per the environment.
	if($values.APIURI.EmailApiURI)
	{
	$appsettingsfromjson.APIURI.EmailApiURI = "$webappendpoint"
	}
	if($values.ProviderMatchingApiUrl)
	{
	$appsettingsfromjson.ProviderMatchingApiUrl = "$webappendpoint/ProviderMatching/Match?reducedOutput=1"
	}
    if($values.OcpApimSubscriptionValue)
    {
    $appsettingsfromjson.OcpApimSubscriptionValue = "$APIMSubscriptionKey"
    }
    if($values.fcsSubscriptionkey)
    {
    $appsettingsfromjson.fcsSubscriptionkey = "$APIMSubscriptionKey"
    }
    if($values.AddressBookAPIUrl_Get)
    {
    $appsettingsfromjson.AddressBookAPIUrl_Get = "$AddressBookAPIUrl/AddressBook/GetFilteredLocationsFromAddressBook"
    }
    if($values.APIURI.AddressBookAPIUrl_Post)
	{
	$appsettingsfromjson.APIURI.AddressBookAPIUrl_Post = "$AddressBookAPIUrl/AddressBook/SaveSubmittedAddress"
	}
    if($values.Auth.TokenIssuer)
	{
	$appsettingsfromjson.Auth.TokenIssuer = "$AuthTokenIssuer"
	}
    if($values.Auth.TokenAudience)
	{
	$appsettingsfromjson.Auth.TokenAudience = "$AuthTokenAudience"
	}
    if($values.downloadBlobPrefix)
	{
	$appsettingsfromjson.downloadBlobPrefix = "$downloadBlobPrefixURL"
	}
    if($values.ChangeReportAPIUrl)
    {
    $appsettingsfromjson.ChangeReportAPIUrl = "$_ChangeReportAPIUrl/ChangeReport/GetChangeReport"    
    }
    if($values.PractitionerURL)
    {
    $appsettingsfromjson.PractitionerURL = "$PractitionerURL"    
    }
    if($values.LocationURL)
    {
    $appsettingsfromjson.LocationURL = "$LocationURL"    
    }
    if($values.PractitionerLocationURL)
    {
    $appsettingsfromjson.PractitionerLocationURL = "$PractitionerLocationURL"    
    }
    <#
    if($values.'Subscription-Key')
    {
    $appsettingsfromjson.'Subscription-Key' = "$APIMSubscriptionKey"    
    }
    if($values -match 'Subscription-Key')
    {
    $appsettingsfromjson.'Subscription-Key' = "$APIMSubscriptionKey"    
    }
    #>
    if($values.JsonAPISubscriptionKey)
    {
    $appsettingsfromjson.JsonAPISubscriptionKey = "$APIMSubscriptionKey"    
    }
    if($values.GroupsHomeUrl)
    {
    $appsettingsfromjson.GroupsHomeUrl = "$GroupsPortalUrl/"
    }
    if($values.UploadRosterUrl)
    {
    $appsettingsfromjson.UploadRosterUrl = "$GroupsPortalUrl/uploadRoster"
    }
    if($values.GroupsContactUrl)
    {
    $appsettingsfromjson.GroupsContactUrl = "$GroupsPortalUrl/"
    }
    if($values.EnableSFTPFeature)
    {
    $appsettingsfromjson.EnableSFTPFeature = "$BoolValue"
    }
}

#If the script is able to update appsettings.json file in the temp folder in the build artifacts location, then it is a success. The script executes the 'try' section in the 'try-catch' block.
try{			   
    #Modified appsettings file
    Write-Host ("Replacing values  of {0} jsonfile " -f $jsonfilepath)
    #Save the content from the variable in appsettings.json file. Save the modified content in appsettings.json file in the temp folder in the build artifacts location.
    $appsettingsfromjson|ConvertTo-Json  | set-content $jsonfilepath
    Write-Host ("Values successfully updated in appsettings.json file needed for the webjob") -BackgroundColor Green
}
#If the script failes to update appsettings.json file in the temp folder in the build artifacts location, then it is a failure. The script catches the exception in 'catch' section in the try-catch' block.
catch
{
    Write-Host ("Values could not be replaced in appsettings.json file needed for the webjob") -BackgroundColor Red
}

#This script does not use REST API in PowerShell.

<#
Note:
In case the PowerShell script is being run from 'Azure PowerShell' task with a version 4.0 or above in the VSTS release by using the private agent VM, then the script fails with an error - Could not find the modules: 'Az.Accounts' with Version: ''. If the module was recently installed, retry after restarting the Azure Pipelines task agent. Reference link: https://developercommunity.visualstudio.com/content/problem/818578/could-not-find-the-modules-azaccounts-with-version.html.
To fix the issue, import Az modules in the private agent VM, then run the script from 'Azure PowerShell' task with a version 4.0 or above in the VSTS release. Or else, simply use version 3.0 in 'Azure PowerShell' tasks in the VSTS release. Then execute the PowerShell script from 'Azure PowerShell' task in the VSTS release by using the private agent VM. This is because 'AzureRM' modules for PowerShell have been installed/ imported in the private agent VM and 'AzureAz' modules have been never installed/ imported for PowerShell in the private agent VM.
This is a problem with VSTS itself. So, it is better to go with Azure PowerShell task versin 3.0 in release pipeline in VSTS.
Any of the PowerShell script that is being executed from Azure PowerShell task in the VSTS release can fail, if Azure PowerShell task version is above 3.0. Therefore, it is better to run the PowerShell script from Azure PowerShell task version 3.0 in the VSTS release.
#>
