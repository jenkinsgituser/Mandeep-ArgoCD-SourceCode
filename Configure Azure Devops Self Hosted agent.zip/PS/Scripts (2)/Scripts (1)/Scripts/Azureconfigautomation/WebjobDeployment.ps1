﻿
<#
This script deploys the webjobs in the webapps of the lower environments, for both continuous and triggered webjobs
#>

#Initialize the variables that are used in the script
Param(
[string]  $resourceGroupName, 
[string]  $webAppName,
[string]  $filePath,
#Name of the webjob to be deployed in the webapp
[string]  $jobname,
#Continuos/Triggered mode in the webapp
[string]  $jobType,		  
[string]  $scmSite
)

#Snippet to override error due to SSL related issues in agent VM. 
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

#Authenticate the script to the webapp by using the publishing credentials and header for the webapp
$Apiversion = "2018-02-01"
$resourceType = "Microsoft.Web/sites/config"
$resourceName = "$webAppName/publishingcredentials"
# Generating publishing credentials for the Azure webapp service
$publishingCredentials = Invoke-AzureRmResourceAction -ResourceGroupName $resourceGroupName -ResourceType $resourceType -ResourceName $resourceName -Action list  -ApiVersion $Apiversion -Force
$accessToken =  ("Basic {0}" -f [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $publishingCredentials.Properties.PublishingUserName, $publishingCredentials.Properties.PublishingPassword))))

#Generating header to create and publish the Webjob.
$Header = @{
'Content-Disposition'='attachment; attachment; filename=Copy.zip'
'Authorization'=$accessToken
}

#Generating header to delete the webjob from a certain path in the webapp.
$Header1 = @{
'Authorization'=$accessToken
}				
#Path to target the webjob deployed in the webapp
$Uri= "https://$webAppName.scm.$scmSite/api"

#Delete existing folder of the webjob in the webapp.
$DosCmdBody1 = @{
command= "del D:\home\site\wwwroot\App_Data\jobs\$jobType\$jobname /Q"
}
$cmd1 =$DosCmdBody1 | ConvertTo-Json
Invoke-RestMethod -Uri "$Uri/command" -Method Post -ContentType 'application/json' -Body $cmd1 -Headers $Header1 -ErrorAction SilentlyContinue

#Folder creation
$DosCmdBody2 = @{
command= "mkdir D:\home\site\wwwroot\App_Data\jobs\$jobType\$jobname"
}
$cmd2 =$DosCmdBody2 | ConvertTo-Json
Invoke-RestMethod -Uri "$Uri/command" -Method Post -ContentType 'application/json' -Body $cmd2 -Headers $Header1 -ErrorAction SilentlyContinue

#Files copy
$apiUrl = "https://$webAppName.scm.$scmSite/api/zip/site/wwwroot/App_Data/jobs/$jobType/$jobname"
try{
Write-Host ("starting webjob deployment in {0} webapp service" -f $webAppName) -ForegroundColor Green
$result = Invoke-RestMethod -Uri $apiUrl -Headers $Header -Method Put -InFile $filePath -ContentType 'application/zip'  -ErrorAction Stop
Write-Host ("Deployment of {0} webjob is done in {1} webapp service" -f $jobname, $webAppName) -ForegroundColor Green
}
catch
{
Write-Host ("Webjob deployment in webapp failed. Deployment of {0} webjob in {1} webapp service is failed" -f $jobname, $webAppName) -ForegroundColor Red
Write-Error ($_.Exception.Message)
}

