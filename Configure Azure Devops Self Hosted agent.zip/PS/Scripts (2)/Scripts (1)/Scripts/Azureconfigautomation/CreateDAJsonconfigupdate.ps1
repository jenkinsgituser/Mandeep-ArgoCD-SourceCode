﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig="$($Directory)/CreateDAJson-WebJob/drop/CAQH.UPD.CreateDAJson.Service/app.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()


#extract and change connectionstrings
$con1=$root."connectionStrings"."add"| where {$_.name -eq 'UPDDocumentManagement'}
$newcon1 = $con1.connectionString=$env:UPDDocumentManagement

$con2=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
$newcon2 = $con2.connectionString = $env:CAQHUPDCRMConn

$con3=$root."connectionStrings"."add"| where {$_.name -eq 'DirectoryAssureContext'}
$newcon3 = $con3.connectionString=$env:DirectoryAssureContext

$con7=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHPortalContext'}
$newcon7 = $con7.connectionString=$env:CAQHPortalContext

#extract and change auth

 $key1=$root."appSettings"."add"| where {$_.key -eq 'DAAPIURL'}
 $newkey1=$key1.value=$env:DAAPIURL

 $key2=$root."appSettings"."add"| where {$_.key -eq 'RecordCount'}
 $newkey2=$key2.value=$env:RecordCount


 #save the web.config
 $doc.Save($webConfig)