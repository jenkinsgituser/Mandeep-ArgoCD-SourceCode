﻿Param(
[string]$build.artifactstagingdirectory
)



$$build.artifactstagingdirectory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$appsettings="$(build.artifactstagingdirectory)/_CI-EPMM-Subscriber-ProviderStagingProcess/drop/CAQH.UPD.EPMM.Subscriber.ProviderStagingProcess/appsettings.json"
$doc = Get-Content -path $appsettings | ConvertFrom-Json

#extract and change connectionstrings

$doc.Azure.ServiceBusConnectionString = $env:ServiceBusConnectionString
$doc.Azure.AzureBlobConnectionString = $env:AzureBlobConnectionString
$doc.Azure.ProviderStagingProcessQueue = $env:ProviderStagingProcessQueue
$doc.APPINSIGHTS_INSTRUMENTATIONKEY = $env:APPINSIGHTS_INSTRUMENTATIONKEY
$doc.EMSV2PublisherAPIBaseUrl = $env:EMSV2PublisherAPIBaseUrl

#extract and update other keys

$doc.azureKeyVault.clientId = $env:ClientId
$doc.azureKeyVault.ClientSecret = $env:ClientSecret
$doc.azureKeyVault.vault = $env:vault
$doc.SmartyStreetAPIUrl=$env:SmartyStreetAPIUrl
$doc.CRMAPIBaseURL=$env:CRMAPIBaseURL





$doc | ConvertTo-Json -Depth 32 | set-content $appsettings 
