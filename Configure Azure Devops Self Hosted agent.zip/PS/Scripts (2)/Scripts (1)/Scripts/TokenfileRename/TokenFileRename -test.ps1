Remove-Item -Path "$(build.artifactstagingdirectory)/_CI-API(servicesoln)-L&D/Publish/Files/APIs/CAQH.UPD.Services.CredentialingAPI/Web.config
"
Rename-Item -NewName Web.config -Path "$(build.artifactstagingdirectory)/_CI-API(servicesoln)-L&D/Publish/Files/APIs/CAQH.UPD.Services.CredentialingAPI/WebToken.config
"