﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\_CI-RosterAPIProcessingService/Publish/RosterAPIProcessingService/CAQH.UPD.Services.RosterAPIProcessingService.exe.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of keys

 $key1=$root."log4net"."appender"| where {$_.type -eq 'log4net.Appender.RollingFileAppender'}

 $newkey1=$key1.file.value=$env:filevalue

 $key2=$root."appSettings"."add"| where {$_.key -eq 'filevalue'}
 $newkey2=$key2.value=$env:filevalue

 $key3=$root."appSettings"."add"| where {$_.key -eq 'TimerInterval'}
 $newkey3=$key3.value=$env:TimerInterval 

 $key4=$root."appSettings"."add"| where {$_.key -eq 'TaskToExecute'}
 $newkey4=$key4.value=$env:TaskToExecute

 $key5=$root."appSettings"."add"| where {$_.key -eq 'ServiceName'}
 $newkey5=$key5.value=$env:ServiceName

 $key6=$root."appSettings"."add"| where {$_.key -eq 'RostersProcessedRepository'}
 $newkey6=$key6.value=$env:RostersProcessedRepository

 $key6=$root."appSettings"."add"| where {$_.key -eq 'RostersProcessRepository'}
 $newkey6=$key6.value=$env:RostersProcessRepository
 
  $key6=$root."appSettings"."add"| where {$_.key -eq 'RostersFtppath'}
 $newkey6=$key6.value=$env:RostersFtppath
 
  $key6=$root."appSettings"."add"| where {$_.key -eq 'RostersFailedFilesRepository'}
 $newkey6=$key6.value=$env:RostersFailedFilesRepository
 
  $key6=$root."appSettings"."add"| where {$_.key -eq 'ReturnJsonStorePath'}
 $newkey6=$key6.value=$env:ReturnJsonStorePath
 
   $key6=$root."appSettings"."add"| where {$_.key -eq 'ADAPOID'}
 $newkey6=$key6.value=$env:ADAPOID
 
   $key6=$root."appSettings"."add"| where {$_.key -eq 'ReturnJsonPath'}
 $newkey6=$key6.value=$env:ReturnJsonPath
 
   $key6=$root."appSettings"."add"| where {$_.key -eq 'AgentEnabled'}
 $newkey6=$key6.value=$env:AgentEnabled

 #save the web.config
 $doc.Save($webConfig)