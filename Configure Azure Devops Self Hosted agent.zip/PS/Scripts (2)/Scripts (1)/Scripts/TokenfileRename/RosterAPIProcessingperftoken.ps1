﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\_CI-RosterAPIProcessingService/Publish/RosterAPIProcessingService/RosterAPIProcessingToken.exe.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of keys

 $key1=$root."log4net"."appender"| where {$_.type -eq 'log4net.Appender.RollingFileAppender'}

 $newkey1=$key1.file.value=$env:filevalue

 $key3=$root."appSettings"."add"| where {$_.key -eq 'TimerInterval'}
 $newkey3=$key3.value=$env:TimerInterval 

 $key4=$root."appSettings"."add"| where {$_.key -eq 'TaskToExecute'}
 $newkey4=$key4.value=$env:TaskToExecute

 $key5=$root."appSettings"."add"| where {$_.key -eq 'ServiceName'}
 $newkey5=$key5.value=$env:ServiceName

 $key6=$root."appSettings"."add"| where {$_.key -eq 'RostersProcessedRepository'}
 $newkey6=$key6.value=$env:RostersProcessedRepository

 $key7=$root."appSettings"."add"| where {$_.key -eq 'RostersProcessRepository'}
 $newkey7=$key7.value=$env:RostersProcessRepository
 
 $key8=$root."appSettings"."add"| where {$_.key -eq 'RostersFtppath'}
 $newkey8=$key8.value=$env:RostersFtppath
 
 $key9=$root."appSettings"."add"| where {$_.key -eq 'RostersFailedFilesRepository'}
 $newkey9=$key9.value=$env:RostersFailedFilesRepository
 
 $key10=$root."appSettings"."add"| where {$_.key -eq 'ReturnJsonStorePath'}
 $newkey10=$key10.value=$env:ReturnJsonStorePath
 
 $key11=$root."appSettings"."add"| where {$_.key -eq 'ADAPOID'}
 $newkey11=$key11.value=$env:ADAPOID
 
 $key12=$root."appSettings"."add"| where {$_.key -eq 'ReturnJsonPath'}
 $newkey12=$key12.value=$env:ReturnJsonPath
 
 $con1=$root."connectionStrings"."add"| where {$_.name -eq 'RosterAPIContext'}
 $newcon1 = $con1.connectionString=$env:RosterAPIContext

 $con2=$root."connectionStrings"."add"| where {$_.name -eq 'FileUploadInfoContext'}
 $newcon2 = $con2.connectionString=$env:FileUploadInfoContext

 $con3=$root."connectionStrings"."add"| where {$_.name -eq 'CrmServiceConfig'}
 $newcon3 = $con3.connectionString=$env:CrmServiceConfig

 $con4=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHUPDCRMConn'}
 $newcon4 = $con4.connectionString=$env:CAQHUPDCRMConn

 $con5=$root."connectionStrings"."add"| where {$_.name -eq 'CAQHPortalContext'}
 $newcon5 = $con5.connectionString=$env:CAQHPortalContext

 $con6=$root."connectionStrings"."add"| where {$_.name -eq 'DMSConnection'}
 $newcon6 = $con6.connectionString=$env:DMSConnection
 
 $key19=$root."appSettings"."add"| where {$_.key -eq 'NewRelic.AgentEnabled'}
 $newkey19=$key19.value=$env:AgentEnabled
 
 #save the web.config
 $doc.Save($webConfig)