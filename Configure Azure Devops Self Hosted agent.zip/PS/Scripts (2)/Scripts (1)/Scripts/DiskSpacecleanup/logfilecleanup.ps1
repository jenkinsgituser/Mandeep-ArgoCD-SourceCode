﻿#Establishing PSDrive session with the server
$pass=$env:WebServer_pwd|ConvertTo-SecureString -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PsCredential($env:WebServer_Username,$pass)
New-PSDrive -name temp -Root $env:Root -Credential $cred -PSProvider filesystem

#Checking for environment details before clearing logs
if($env:component -ne "DEMO")
{
$targetfolders = $env:targetfolders
$Extension = "*.log"
$LastWrite = (Get-Date).AddDays(-$env:Days) #delete files in a folder that are older than 30 days

#command to find/get the file details
$Files =Get-ChildItem –Path $targetfolders -Include $Extension -Recurse -Force | Where-Object {($_.LastWriteTime -lt $LastWrite)}

foreach ($File in $Files)
  {
  if ($File -ne $NULL)
    {
      write-host "Deleting File $File" -ForegroundColor "DarkRed"
    Remove-Item $File -ErrorAction Ignore | out-null
    }
  else
    { Write-Host "No more files to delete!" -foregroundcolor "Green" }
  }
  }
  else
  {
  $targetfolders = "$env:Root\Training_DemoEnvironment\B2BServices\*\Miscellaneous\Logs"
  $Extension = "*.log"
  $Days = "30"
  $LastWrite = (Get-Date).AddDays(-$Days) #delete files in a folder that are older than 30 days

#command to find/get the file details
$Files =Get-ChildItem –Path $targetfolders -Include $Extension -Recurse -Force | Where-Object {($_.LastWriteTime -lt $LastWrite)}

foreach ($File in $Files)
  {
  if ($File -ne $NULL)
    {
      write-host "Deleting File $File" -ForegroundColor "DarkRed"
    Remove-Item $File -ErrorAction Ignore | out-null
    }
  else
    { Write-Host "No more files to delete!" -foregroundcolor "Green" }
  }
  }

  #removing the PSSession
  Remove-PSDrive temp
