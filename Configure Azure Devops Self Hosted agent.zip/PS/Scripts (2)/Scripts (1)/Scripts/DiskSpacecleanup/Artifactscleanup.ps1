﻿$pass=$env:WebServer_pwd|ConvertTo-SecureString -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PsCredential($env:WebServer_Username,$pass)
New-PSDrive -name temp -Root $env:Root -Credential $cred -PSProvider filesystem

$targetfolders = "$env:Root\agent\_work"
$Excludefiles = 'ReleaseRootMapping','SourceRootMapping','_tool','_update','_tasks','_temp'
$LastWrite = (Get-Date).AddDays(-$env:Days) #delete files in a folder that are older than 30 days

#command to find/get the file details and to remove unwanted files

Get-ChildItem -Path $targetfolders -Exclude $Excludefiles -Directory | Where-Object {($_.LastWriteTime -lt $LastWrite)} | Remove-Item -Force -ErrorAction 'Stop' -Recurse -Verbose

Write-Host "No more files to delete" -foregroundcolor "Green"
Remove-PSDrive temp