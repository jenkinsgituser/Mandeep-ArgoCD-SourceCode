﻿Import-Module WebAdministration
$appPool = "CAQH_Portal_ProView"
 
 if(Test-Path IIS:\AppPools\$appPool)
  {
   Remove-WebAppPool $appPool
  }
 
   $iisAppPoolName = $appPool
   $appPool = New-WebAppPool -Name $iisAppPoolName  
   $appPool.managedPipelineMode = "Integrated"
   $appPool.managedRuntimeVersion = "v4.0"
   $appPool |Set-Item