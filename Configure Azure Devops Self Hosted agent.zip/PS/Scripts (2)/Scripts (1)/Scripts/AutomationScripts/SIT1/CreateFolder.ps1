﻿$path = ("AppLogs","Areas","bin","Content","ejThemes","fonts","Helpers","Images","OfflinePage","Scripts","Service References","Views")


foreach($item in $path){
    $testPath = "C:\inetpub\wwwroot\" + $item
 if (Test-Path $testPath) 
   {
    Remove-Item $testPath -Force
   }
   
   $fso = New-Object -ComObject scripting.filesystemobject
   $fso.CreateFolder($testPath)

   	$acl = Get-Acl $testPath
	$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("everyone","FullControl","Allow")
	$acl.SetAccessRule($accessRule)
	$acl | Set-Acl $testPath
}