Remove-Item -Path $env:ConfigPath
Rename-Item -NewName $env:Type -Path $env:TokenPath