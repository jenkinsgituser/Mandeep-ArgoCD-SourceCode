﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-buildversion\Publish\ProViewPortal\WebToken.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()

#Extracting values of Buildversion key
$key1=$root."appSettings"."add"| where {$_.key -eq 'BuildVersion'}
$versionString=$key1.value

#To Incrementing the last decimal value as per section change
$version = [version] $versionString
$Path="C:\agent\buildversion.txt"

if($versionString -le $versionString)
{
$versionStringIncremented = [string] [version]::new(
  $version.Major,
  $version.Minor+1
)
$initialversion=$key1.value=$versionStringIncremented
Write-Host "the new buildversion is" $initialversion
Clear-Content -Path $Path
$initialversion | Add-Content -Path $Path
}
elseif ($environment -eq "SIT4")
{
$text = Get-Content $Path -Raw 
$version1 = [version] $text
$versionStringIncremented1 = [string] [version]::new(
  $version1.Major,
  $version1.Minor+1
)
$Updatedversion=$key1.value=$versionStringIncremented1
Write-Host "the new buildversion is" $Updatedversion
}
else
{
$text = Get-Content $Path -Raw 
$envversion=$key1.value=$text
Write-Host "the new buildversion is" $envversion
}

#save the web.config
  $doc.Save($webConfig)