Remove-Item -Path 'CI-buildversion\Publish\ProviewPortal/Web.config'
Rename-Item -NewName Web.config -Path 'CI-buildversion\Publish\ProviewPortal\WebToken.config'