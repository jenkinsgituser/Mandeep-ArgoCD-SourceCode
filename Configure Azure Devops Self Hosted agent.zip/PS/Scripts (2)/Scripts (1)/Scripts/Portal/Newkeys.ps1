﻿Param(
[string]$Directory
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$webConfig = "$($Directory)\CI-buildversion\Publish\ProViewPortal\WebToken.config"
$doc = (Get-Content $webConfig) -as [Xml]
 $root=$doc.get_DocumentElement()

 #Extracting values of keys

 $key=$root."appSettings"."add"| where {$_.key -eq 'BuildVersion'}

#Replacing the keys with environment specific release variables

 $newKey=$Key.value=$env:BuildVersion

 #Adding a new key

 if($env:InviteNewGroupsFeature){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "InviteNewGroupsFeature"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "InviteNewGroupsFeature"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:InviteNewGroupsFeature
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}

if($env:ADALogoutURL){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "ADALogoutURL"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "ADALogoutURL"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:ADALogoutURL
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}

if($env:PSVEnhancedFileSharePath){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "PSVEnhancedFileSharePath"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "PSVEnhancedFileSharePath"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:PSVEnhancedFileSharePath
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}

if($env:PSVSimpleFileSharePath){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "PSVSimpleFileSharePath"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "PSVSimpleFileSharePath"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:PSVSimpleFileSharePath
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}

 if($env:AHANotification){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "AHANotification"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "AHANotification"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:AHANotification
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}

    if($env:EnableNUCCFormat){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "EnableNUCCFormat"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "EnableNUCCFormat"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:EnableNUCCFormat
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}

  if($env:DelegatedToggle){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "DelegatedToggle"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "DelegatedToggle"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:DelegatedToggle
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}

    
  if($env:AffiliationSuggestedFixvalidationDate){
# First check if the header exists
$header=$root.'appSettings'.add | where {$_.name -eq "AffiliationSuggestedFixvalidationDate"}
    if($header){
        Write-Host "The Key already Exists"
        
    }
    else{
        # navigate to the <configSections> element
$xmlConfigSections = $doc.SelectSingleNode("//appSettings")
# create the new <sectionGroup> element with a 'name' attribute
$sectionGroup = $doc.CreateElement("add")
$xmlAttr = $doc.CreateAttribute("key")
$xmlAttr.Value = "AffiliationSuggestedFixvalidationDate"
$sectionGroup.Attributes.Append($xmlAttr)
$xmlAttr1 = $doc.CreateAttribute("value")
$xmlAttr1.Value = $env:AffiliationSuggestedFixvalidationDate
$sectionGroup.Attributes.Append($xmlAttr1)
# now add the new <sectionGroup> element to the <configSections> element
$xmlConfigSections.AppendChild($sectionGroup)

Write-Host "Created a new Key"
    }

	}
Write-host $env:BuildVersion


#save the web.config
  $doc.Save($webConfig)
