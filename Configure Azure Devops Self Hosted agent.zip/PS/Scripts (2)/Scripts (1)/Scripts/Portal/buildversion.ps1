﻿Param(
[string]$Directory,
[string]$agentpath
)

$Directory=$env:SYSTEM_DEFAULTWORKINGDIRECTORY
$agentpath=$env:agentpath
$tempconfig = "$($agentpath)"
$tempdoc = (Get-Content $tempconfig) -as [Xml]
$temproot=$tempdoc.get_DocumentElement()

#Extracting values of Buildversion key
$key1=$temproot."appSettings"."add"| where {$_.key -eq 'BuildVersion'}
$tempversionString=$key1.value

#To Incrementing the last decimal value as per section change
$version = [version] $tempversionString

if($env:component -eq "SIT")
{
$versionStringIncremented = [string] [version]::new(
  $version.Major,
  $version.Minor+1
)
$newversion=$key1.value=$versionStringIncremented
#save the web.config
  $tempdoc.Save($tempconfig)
$webConfig = "$($Directory)\CI-PortalRelease-L&D\Publish\ProViewPortal\WebToken.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()

#Extracting values of Buildversion key
$key1=$root."appSettings"."add"| where {$_.key -eq 'BuildVersion'}
$versionString=$key1.value=$newversion

Write-Host "the new buildversion is" $versionString

#save the web.config
  $doc.Save($webConfig)
}
else{
  $webConfig = "$($Directory)\CI-PortalRelease-L&D\Publish\ProViewPortal\WebToken.config"
$doc = (Get-Content $webConfig) -as [Xml]
$root=$doc.get_DocumentElement()

#Extracting values of Buildversion key
$key1=$root."appSettings"."add"| where {$_.key -eq 'BuildVersion'}
$versionString=$key1.value=$tempversionString
Write-Host "the new buildversion is" $versionString

#save the web.config
  $doc.Save($webConfig)
}



  