﻿$Path = $env:csvpath
$Processes = Import-CSV $Path

#Establishing PS session with Portal/API server
$pass=$env:WebServer_pwd|ConvertTo-SecureString -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PsCredential($env:WebServer_Username,$pass)
New-PSDrive -name API -Root $env:API -Credential $cred -PSProvider filesystem

#Establishing PS session with service server
$pass=$env:Server_pwd|ConvertTo-SecureString -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PsCredential($env:WebServer_Username,$pass)
New-PSDrive -name service -Root $env:service -Credential $cred -PSProvider filesystem

#Fetching Source config paths, keys names from csv file and retrieving key value from the config  
$Processes | ForEach-Object {
$Sourcekey = $_.Sourcekey
$sourcedoc = (Get-Content $($_.SourceFile)) -as [Xml]
$sourceroot=$sourcedoc.get_DocumentElement()
$apikey= $sourceroot.appSettings.add | where { $_.key -eq $Sourcekey}
$Sourcevalue=$apikey.value
write-host "$Sourcekey value is $Sourcevalue in $($_.SourceFile)"

#Fetching Target config paths, keys names from csv file and retrieving key value from the config  
$Targetkey = $_.Targetkey
$targetdoc = (Get-Content $($_.TargetFile)) -as [Xml]
$targetroot=$targetdoc.get_DocumentElement()
$servicekey=$targetroot."appSettings"."add"| where {$_.key -eq $Targetkey}
$Targetvalue=$servicekey.value
write-host "$Targetkey value is $Targetvalue in $($_.TargetFile)"

#checking source and target key values 
if($Sourcevalue -eq $Targetvalue){
    write-host "Values are same"
}
else{
Write-Host "##[error] VALUES ARE DIFFERENT for $Sourcekey and $Targetkey" 
Write-Host "##vso[task.complete result=Failed;]DONE"
}
}

#removing the PSsession
Remove-PSDrive API
Remove-PSDrive service