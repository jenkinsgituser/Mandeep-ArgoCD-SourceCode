### Added for DLX-NonProd Testing
#Set-AzContext -SubscriptionName "DLX-NonProd"

if (!$ATLAS_ENVIRONMENT_SETUP_COMPLETE) {
    $ATLAS_REPO_ROOT = $env:ATLAS_REPO_ROOT
    . "$env:COMMON_FOLDER/AutomationAccount/AtlasCommon/Atlas-CommonCode.ps1" 4> $null

    Write-Verbose -Verbose "ATLAS_REPO_ROOT: $ATLAS_REPO_ROOT"

    $INFRA_FOLDER = $env:INFRA_FOLDER
    Write-Verbose -Verbose "INFRA_FOLDER: $INFRA_FOLDER"

    $DEPLOY_FOLDER = $env:DEPLOY_FOLDER
    Write-Verbose -Verbose "DEPLOY_FOLDER: $DEPLOY_FOLDER"

    $COMMON_FOLDER = $env:COMMON_FOLDER
    Write-Verbose -Verbose "COMMON_FOLDER: $COMMON_FOLDER"

    $CREATED_DATE = Get-Date -Format "yyyy-MM-dd"
    Write-Verbose -Verbose "CREATED_DATE: $CREATED_DATE"

    # source constants prior to utilities, as utils can rely on these values
    Write-Verbose -Verbose "Sourcing constants.ps1"
    . ("$COMMON_FOLDER/constants.ps1")

    Write-Verbose -Verbose "Sourcing azure-utilities.ps1"
    . ("$COMMON_FOLDER/azure-utilities.ps1")

    Write-Verbose -Verbose "Sourcing utilities.ps1"
    . ("$COMMON_FOLDER/utilities.ps1")

    Write-Verbose -Verbose "Sourcing logging-utilities.ps1"
    . ("$COMMON_FOLDER/logging-utilities.ps1")

    Write-Verbose -Verbose "Sourcing Custom ARM utilities: AtlasArmRestClient.ps1"
    . ("$COMMON_FOLDER/api/AtlasArmRestClient.ps1")

    #only set the Template version to latest if its an atlas deploy
    Write-Verbose -Verbose "TEMPLATE_VERSION value before setting in setup environment: $TEMPLATE_VERSION"
    if ($TEMPLATE_VERSION -notmatch "Non-Atlas") {
        $TEMPLATE_VERSION = Get-AtlasVersionNumber
        Write-Verbose -Verbose "TEMPLATE_VERSION: $TEMPLATE_VERSION"
    }
    # Get the Tenant Id in which the Subscription exists
    $context = $(Get-AzContext)
    $TENANT_ID = $context.Tenant.Id
    Write-Verbose -Verbose "TENANT_ID: $TENANT_ID"
    Write-Host "##vso[task.setvariable variable=TENANT_ID;]$TENANT_ID"

    # Get the Account Subscription Id
    $SUBSCRIPTION_ID = $context.Subscription.Id
    Write-Verbose -Verbose "SUBSCRIPTION_ID: $SUBSCRIPTION_ID"
    Write-Host "##vso[task.setvariable variable=SUBSCRIPTION_ID;]$SUBSCRIPTION_ID"

    # Get the Subscription Name
    $SUBSCRIPTION_NAME = $context.Subscription.Name
    Write-Verbose -Verbose "SUBSCRIPTION_NAME: $SUBSCRIPTION_NAME"
    Write-Host "##vso[task.setvariable variable=SUBSCRIPTION_NAME;]$SUBSCRIPTION_NAME"

    #trims all leading and trailing whitespace from environment variables
    #prevents the need to tackle each var individually
    Write-AtlasSanitizeInputs

    # verify the powershell Az modules are installed which is required for this script to execute.
    if ($(Get-Module -Name Az.*).Count -eq 0) {
        Write-Verbose -Verbose "The Powershell Az modules are not installed on this host."
        Write-Verbose -Verbose "Please check/verify that your Azure Powershell task version is set to 4.* or greater."
        throw "Powershell Az modules not installed - make sure Azure Powershell task version is set to 4.* or greater"

    }
    Write-Verbose -Verbose "Requested By: $env:RELEASE_REQUESTEDFOREMAIL"

    #----------------------------------------------------------------

    if ($env:ATLAS_DEBUG_RELEASE) {
        Write-Verbose -Verbose "Determine portfolio RM keyvault"
    }

    if (!$env:IsLocal) {
        #Setup Az CLI
        $rmAppId = $context.Account.Id
        Write-Verbose -Verbose "Running account application id: $rmAppId"
        
        $RMDisplayName = (Get-AzADServicePrincipal -ApplicationId $rmAppId).DisplayName
        $rmKeyvaultName = "kv" + $RMDisplayName.Substring(2)
        Write-Verbose -Verbose "Running account display name: $RMDisplayName"
        Write-Verbose -Verbose "Running account kv: $rmKeyvaultName"
        $Secret = Get-AzKeyVaultSecret -VaultName $rmKeyvaultName -Name $RMDisplayName
        Write-Verbose -Verbose "Retrieved RM secret"
        $rmSecret = [System.Net.NetworkCredential]::new("", $($Secret.SecretValue)).Password

        if ($rmSecret -and $rmAppId) {
            Write-Verbose -Verbose "Log into Azure using DevOps service principal"
            # 12/7/2022 - Commenting this az login line out and replacing it with straight double quotes around
            # the rmSecret variable value since it started throwing errors indicating the login was failing. 
            # It appears to be a problem with the way the escape characters around the rmsecret are working. 
            # These were in place due to a known issue with az login mis-interpreting special characters
            # in the secret value. This appears to have changed now that Microsoft is using GUID values as passwords.
            # If this problem re-appears we will have to re-evaluate this resolution. 
            #az login --service-principal -u $rmAppId -p "`"$rmSecret`"" -t "$TENANT_ID". 
            az login --service-principal -u $rmAppId -p "$rmSecret" -t "$TENANT_ID"
            az account set -s "$SUBSCRIPTION_NAME"
        }
        $loggedIn = az account show
        if (!$loggedIn) {
            throw "Unable to authenticate to Azure CLI"
        }
        $PORT_NAME = Get-PortfolioByRunningAppId -RmAcctAppId $rmAppId
        $RUNNING_ACCOUNT_OBJECT_ID = (Get-AzADServicePrincipal -ApplicationId $rmAppId).Id
    }
    else {
        $loggedIn = az account show
        if (!$loggedIn) {
            Write-Error "Please log into Azure." -Exception
        }
        $PORT_NAME = "Sandbox"
        $userName = $(az account show --query user.name -o tsv) 2> $null
        Write-Verbose "Getting Azure User ObjectId for Sandbox Testing" -Verbose
        $RUNNING_ACCOUNT_OBJECT_ID = Get-UserObjectId -UserName $userName
    }

    # Set variables based on running identity
    Write-Verbose -Verbose "PORT_NAME: $PORT_NAME"
    Write-Host "##vso[task.setvariable variable=PORT_NAME;]$PORT_NAME"

    Write-Verbose -Verbose "RUNNING_ACCOUNT_OBJECT_ID: $RUNNING_ACCOUNT_OBJECT_ID"
    Write-Host "##vso[task.setvariable variable=RUNNING_ACCOUNT_OBJECT_ID;]$RUNNING_ACCOUNT_OBJECT_ID"

    # Get the name of the user who launched this script
    $USER_NAME = $(az account show --query user.name -o tsv)
    Write-Verbose -Verbose "User Name: $USER_NAME"
    Write-Host "##vso[task.setvariable variable=USER_NAME;]$USER_NAME"

    # Get the name of the user who launched this script
    $DEFAULT_LOCATION = "eastus2"
    Write-Verbose -Verbose "Default Location: $DEFAULT_LOCATION"
    Write-Host "##vso[task.setvariable variable=DEFAULT_LOCATION;]$DEFAULT_LOCATION"

    Write-Verbose -Verbose "Environment setup complete."

    $ATLAS_ENVIRONMENT_SETUP_COMPLETE = $true
}
else {
    Write-Verbose -Verbose "Environment setup skipped as 'ATLAS_ENVIRONMENT_SETUP_COMPLETE' = $ATLAS_ENVIRONMENT_SETUP_COMPLETE"
}
