function Get-AtlasRepoRoot() {
    # Set path to the folder location of the current script
    $path = ($pwd).path

    # Loop until desired root folder is found
    while (!$rootpath) {
        try {
            # Search for file in current folder
            if (!$env:IsLocal) {
                $filePath = $(Get-ChildItem $path -Recurse | Where-Object { $_.Name -match "^productInformationV2.json" }).Directory.FullName
            }
            else {
                $filePath = $(Get-ChildItem $path | Where-Object { $_.Name -match "^productInformationV2.json" }).Directory.FullName
            }
            return $filePath
        }
        catch {
            $ERROR_MESSAGE = $_.Exception.Message
            Write-Verbose "Error while discovering Atlas Repo Root" -Verbose
            Write-Error "ERROR: $ERROR_MESSAGE" -Verbose
            Exit
        }
    }
}

Write-Verbose "AGENT_NAME: $env:AGENT_NAME" -Verbose

if (!($env:AGENT_NAME -match 'atlas')) {

    Write-Host ""
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "############                                                                          ############" -Verbose
    Write-Verbose "############                       NOT USING AN ATLAS-HOSTED AGENT                    ############" -Verbose
    Write-Verbose "############                                                                          ############" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Verbose "##################################################################################################" -Verbose
    Write-Host ""
}
else {
    Write-Host ""
    Write-Verbose "###   ATLAS Agent Detected   ###" -Verbose
    Write-Host ""
}

if (!$env:AGENT_ID) {
    Write-Verbose "Identified that we are running local because AGENT_ID is not set" -Verbose
    $env:IsLocal = $true
}

# validate - Atlas deployments require powershell version 6+
# Display message in logs if Powershell version 5 detected
Write-Verbose "Powershell Version Detected: $($PSVersionTable.PSVersion.Major)" -Verbose
if ($PSVersionTable.PSVersion.Major -lt 6) {
    Write-Verbose "**************************************************************************" -Verbose
    Write-Verbose "* " -Verbose
    Write-Verbose "*  WARNING: Older Powershell version found." -Verbose
    Write-Verbose "* " -Verbose
    Write-Verbose "*  Please update all Powershell DevOps tasks to use Powershell Core"  -Verbose
    Write-Verbose "*     Under Advanced, click the checkbox next to 'Use Powershell Core'" -Verbose
    Write-Verbose "* " -Verbose
    Write-Verbose "*  See Wiki:" -Verbose
    Write-Verbose "*     https://dev.azure.com/cunamutual/SecureCloudEnablement/_wiki/wikis/Atlas%20Wiki%20V2/14638/Use-Powershell-Core-in-DevOps-tasks" -Verbose
    Write-Verbose "* " -Verbose
    Write-Verbose "**************************************************************************" -Verbose
}

# only set the environment variables if setuphost has not already run
if ( ($null -eq $env:ATLAS_REPO_ROOT)  `
        -or ($null -eq $env:COMMON_FOLDER)  `
        -or ($null -eq $env:DEPLOY_FOLDER)  `
        -or ($null -eq $env:INFRA_FOLDER) ) {
    Write-Verbose "setting Atlas environment variables in setuphost" -Verbose

    $env:ATLAS_REPO_ROOT = Get-AtlasRepoRoot
    Write-Host "##vso[task.setvariable variable=ATLAS_REPO_ROOT;]$env:ATLAS_REPO_ROOT"
    Write-Verbose "ATLAS_REPO_ROOT: $env:ATLAS_REPO_ROOT" -Verbose

    $env:COMMON_FOLDER = "$env:ATLAS_REPO_ROOT/Common"
    Write-Host "##vso[task.setvariable variable=COMMON_FOLDER;]$env:COMMON_FOLDER"
    Write-Verbose "COMMON_FOLDER: $env:COMMON_FOLDER" -Verbose

    $env:DEPLOY_FOLDER = "$env:ATLAS_REPO_ROOT/Deploy"
    Write-Host "##vso[task.setvariable variable=DEPLOY_FOLDER;]$env:DEPLOY_FOLDER"
    Write-Verbose "DEPLOY_FOLDER: $env:DEPLOY_FOLDER" -Verbose

    $env:INFRA_FOLDER = "$env:ATLAS_REPO_ROOT/Infra"
    Write-Host "##vso[task.setvariable variable=INFRA_FOLDER;]$env:INFRA_FOLDER"
    Write-Verbose "INFRA_FOLDER: $env:INFRA_FOLDER" -Verbose
}

if ($env:IsLocal) {
    Write-Verbose "Verifying local setup..." -Verbose

    # Required for workstations running Netskope
    $cacertFile = "$env:ATLAS_REPO_ROOT/Tools/Netskope/cacert.pem"

    # Tells Netskope where to find you
    if (!$env:REQUESTS_CA_BUNDLE) {
        $env:REQUESTS_CA_BUNDLE = $cacertFile
    }

    $version = (az version) | Select-String '"azure-cli"'
    # ensure the version is 2.0.72 or greater
    if ($version -notmatch '((2\.((0\.(7[2-9]+|[8-9]\d+|1\d\d+))|(([1-9]\d*)(\.\d+)*)))|(([3-9]|[1-9]\d+)\.\d+(\.\d+)*))') {
        Write-Error "You must have at least version Az CLI 2.0.72 to successfully execute these deployments."
        Exit 1
    }

    $LoggedAzIn = $null

    try {
        # Log into Azure using the Azure CLI
        $LoggedAzIn = az account show 2> $null
    }
    catch {
        Write-Verbose "You are not logged in using the Azure CLI. Attempting to log in now." -Verbose
    }

    if (!$LoggedAzIn) {
        az login
    }

    #$azPowershellModule = Get-Module Az.Accounts
    $azPowershellModule = Get-InstalledModule -Name Az.Accounts
    if (!$azPowershellModule -or `
        ($azPowershellModule.Version.ToString() -notmatch '^((1\.(([6-9]\d*)|([1-5]\d+)))|(([2-9]\d*)|(1\d+)\.\d+))(\.\d+)*')) {
        Write-Verbose "Az PowerShell modules not already imported. We'll try to import these if they're installed..." -Verbose
        Import-Module Az

        $azPowershellModule = Get-Module Az.Accounts
        if (!$azPowershellModule -or `
            ($azPowershellModule.Version.ToString() -notmatch '^((1\.(([6-9]\d*)|([1-5]\d+)))|(([2-9]\d*)|(1\d+)\.\d+))(\.\d+)*')) {
            Write-Error "You must have at least version Az PowerShell 1.6 execute these deployments."
            Write-Warning "If you have the latest Az PowerShell installed, ensure it is available in your PowerShell module path."
            Exit 1
        }
    }

    $LoggedPwshIn = Get-AzContext
    if (!$LoggedPwshIn) {
        Connect-AzAccount
    }

    # Ensure you specify your Azure subscription
    # (if you have more than one subscription)
    #$SUBSCRIPTION_NAME = "CMFG-Sandbox"

    #Write-Verbose "Set the default PowerShell AZ Context subscription" -Verbose
    #Set-AzContext -Subscription "$SUBSCRIPTION_NAME"

    #Write-Verbose "Set the default Azure CLI subscription" -Verbose
    #az account set --subscription "$SUBSCRIPTION_NAME"
}

# Use the following to clear log out of Azure after receiving updated resource permissions
# Clear-AzContext
# az logout
